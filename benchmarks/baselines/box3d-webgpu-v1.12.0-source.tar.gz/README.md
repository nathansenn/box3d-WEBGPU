# Box3D WebGPU — AAA Physics Lab

> **v1.12 Sixth Production Optimization — current:** re-audits every retained v1.2–v1.11 gain against the actual source and closes missed paths with exact Racing Sail WASM batching, axis-aligned cloth/water instance matrices, effect drag-factor hoisting, allocation-free camera-track sampling, and density-aware native Box3D transform synchronization. The final source-frozen v1.11-versus-v1.12 tournament contains exactly 100 cases with eight balanced samples per implementation/case: **14 accepted wins, 14 borderline results, 0 no-win rejections, 72 controls, and 0 correctness failures**, with a **1.0640× changed-path geometric mean**. Dedicated exact gates additionally measure 1.748× cloth-sphere staging, 4.135× 768-droplet staging, 1.140× camera sampling, and 1.678× static-heavy native transform sync. See [`docs/PERFORMANCE_V1.12.md`](docs/PERFORMANCE_V1.12.md).

> **v1.11 Exact Production Optimization — previous validated baseline:** retained allocation-free camera matrices and fallback contacts, version-keyed main-frame line staging, one-time static streams, exact explosion/collision rejection, right-sized soft-system memory, native transform/material revisions with settled-world skipping, and dead-pipeline removal. See [`docs/PERFORMANCE_V1.11.md`](docs/PERFORMANCE_V1.11.md).

> **v1.10 Performance Integration — previous validated baseline:** bundles the pinned native Box3D WASM backend, restores allocation-light effects staging, removes dead water-frame storage, qualifies maximum-stress rope batching across 250 scene/stress combinations, skips unchanged rigid/effect/debug/soft uploads, throttles DOM telemetry, and makes quality profiles change real MSAA, shadow-map, and PCF work. See [`docs/V1.10_INTEGRATION_AND_TEST_MATRIX.md`](docs/V1.10_INTEGRATION_AND_TEST_MATRIX.md).

> **v1.9 Semantic Integration — validated:** manually ports the verified v1.9 cloth and rope rendering architecture onto this repository's reconstructed v1.8.1 foundation. Intact cloth uses adaptive 4/6/8 projection ceilings and sends 12 dynamic position bytes per vertex plus an immutable rest pose; rope publishes compact node/segment data that WebGPU compute expands into instance streams. Numerical cloth, rope, water, collision, and break solvers remain CPU/JavaScript or CPU/WebAssembly work. The supplied archive is SHA-256 `09fa0eec3db1858d57cdc58a9fe8f021b76cd6c19c5b8913eb9d55e1667a1fbb`, but it descends from a different original-v1.8.0 line, so the changes were ported rather than copied wholesale. The manifest-sealed `validate:v1.9` gate passed on July 14, 2026. See [`docs/INTEGRATION_V1.9.md`](docs/INTEGRATION_V1.9.md).

> **v1.8.1 Reconstructed GPU-Surface Edition:** rebuilds the latest architecture described in the prior project conversation on top of the verified v1.4.1 source available in this workspace. The referenced v1.8 release archive was not available, so this repository does not claim a byte-for-byte import or repeat its historical benchmark numbers. The implementation here is independently testable: intact cloth and shallow-water surfaces are reconstructed in WebGPU, cloth/rope/water numerical kernels can run in persistent SIMD or scalar WebAssembly memory, rope render streams can be generated in WASM, and unchanged soft frames skip redundant reconstruction and uploads.

See [`docs/RECONSTRUCTION_V1.8.md`](docs/RECONSTRUCTION_V1.8.md) for the provenance, implemented scope, and claims intentionally not inherited.

> **v1.4.1 Camera Orientation Hotfix:** corrects the final HDR presentation pass so WebGPU render-target rows are displayed with the intended vertical orientation. Camera controls, projection math, and world-space physics remain unchanged.

> **v1.4.0 TurboQuant Evaluation:** adds independent blockwise TurboQuant-MSE and structured Fast-TurboQuant-style codecs, predictive simulation-state streams, target-browser diagnostics, real cloth/rope/water benchmarks, local Worker tests, and network break-even modeling. TurboQuant remains opt-in because it reduces bytes dramatically but does not accelerate the existing same-thread GPU path. See [`docs/TURBOQUANT.md`](docs/TURBOQUANT.md).

> **v1.3.0 Streaming/Texture Optimization:** packs dynamic vertices to 24 bytes, uses `uint16` surface indices, caches topology, adds KTX2 BC4/R8 material textures, and removes further soft-simulation and renderer allocation pressure. See [`docs/PERFORMANCE_V1.3.md`](docs/PERFORMANCE_V1.3.md).

A browser-native 3D simulation showcase that combines **Box3D rigid-body physics**, deterministic **position-based cloth and rope**, an interactive **shallow-water solver**, and an HDR **WebGPU** renderer.

```text
Box3D C17 / WebAssembly                 Soft-system coordinator
rigid bodies, collisions, impacts       cloth PBD · rope PBD · shallow water
                 \                     SIMD WASM · scalar WASM · JS fallback
                  \ fixed-step coordinator /
                solver-native state + compact render streams
                                      ↓
              WebGPU surface reconstruction + rope expansion / HDR / post
                                      ↓
                     750 deterministic capability scenes
                     30 cinematic hero demonstrations
```

> **Version 1.1.0:** adds 150 cloth, rope, and water scenes; six new directed hero demonstrations; indexed dynamic-surface rendering; woven-cloth and translucent-water WGSL pipelines; soft-system telemetry; deterministic tearing and cable breakage; water currents, foam, droplets, and buoyancy proxies; deep numerical soak tests; and a strict C17 bridge syntax gate.

This is an **AAA-style capability lab and production foundation**, not a claim that every system of a finished commercial engine is complete. The project concentrates on physics behavior, deterministic testability, high-volume WebGPU streaming, cinematic readability, and a clean architecture that can keep growing.

---

## What this edition delivers

### Rigid-body simulation

- Box3D C17 backend, compiled to WebAssembly with Emscripten.
- Fixed 60 Hz stepping with four solver substeps by default.
- Continuous collision enabled in the native bridge.
- 4,096 rigid-body slots and deterministic transform/color streams.
- Impulse, radial explosion, projectile, and body-rain actions.
- Deterministic preview backend so the application runs before the WASM artifact is built.
- Coherent longest-axis sweep-and-prune in the preview backend, with persistent typed ordering and bounds storage.

### Cloth simulation

- Deterministic position-based dynamics using Verlet-style integration.
- Structural, shear, and bend constraints.
- Multiple pinning layouts for banners, curtains, canopies, hammocks, sails, cargo nets, and membranes.
- Wind, turbulence, gravity, ground collision, and sphere collision.
- Strain visualization and controlled constraint failure.
- Topology-aware tears that remove affected cloth triangles.
- Projectile, blast, rain, and broad-impulse interaction.
- Persistent WebAssembly constraint projection for intact cloth, with deterministic JavaScript fallback.
- Adaptive intact-cloth projection ceilings: four passes for membrane drums, six for hammocks/collider drapes, and eight for other intact recipes; tearing cloth retains its full schedule.
- Solver-native positions uploaded at 12 dynamic bytes per vertex, plus an immutable rest-pose buffer uploaded only when its identity/topology changes.
- WebGPU reconstruction of strain, normals, UVs, checker palette, stress heat, woven shading, and shadow position from current/rest positions.
- Topology-changing tears retain the packed CPU surface path so holes and disconnected triangles remain correct.
- Whole-cloth projectile AABB rejection avoids particle traversal for distant impacts.

### Rope and cable simulation

- Deterministic PBD chains with distance and bend constraints.
- Single cables, catenaries, ladders, mooring arrays, cable curtains, slings, ziplines, and rope nets.
- Fixed anchors, concentrated payloads, line tension, resonance, and controlled breakage.
- Projectile severing, explosions, stress rain, ground collision, and payload swing.
- Persistent WebAssembly constraint projection with deterministic JavaScript fallback.
- Compact node positions and eight-float segment metadata, expanded into oriented matrices and tension colors by a WebGPU compute pass.
- Raw segment length remains the tension input while a clamped length protects zero-length matrix construction.
- JavaScript remains the deterministic fallback when neither packaged module can load.
- Whole-rope projectile AABB rejection avoids particle traversal for distant impacts.

### Interactive water

- Stable 2.5D linear shallow-water heightfield.
- Height and horizontal velocity fields with reflected boundaries and drag.
- Ripples, storm seas, waves, wakes, fountains, rain, dam-break fronts, vortices, harbor floaters, and impact basins.
- Surface normals, curvature/speed-derived foam, droplets, current-vector diagnostics, and buoyancy proxies.
- Projectile and explosion displacement.
- Persistent WebAssembly shallow-water stepping, with scalar and JavaScript fallbacks.
- GPU-resident `eta`, `u`, and `v` state uploaded at 12 bytes per cell.
- WebGPU reconstruction of position, normals, curvature, foam, and translucent material response.

### Optional TurboQuant state transport

- Independent TypeScript blockwise adaptation of TurboQuant-MSE for high-dimensional simulation snapshots.
- Structured randomized Walsh–Hadamard transform for a faster O(d log d) option.
- Specialized 2-, 3-, and 4-bit packing with Gaussian Lloyd–Max scalar codebooks.
- Predictive streams synchronized against the prior reconstructed frame.
- Real maximum-detail cloth, rope, and water benchmarks with error and byte accounting.
- Local Worker transfer benchmark and modeled network break-even rates.
- Dynamically loaded browser probe for measurements on the target machine.
- Deliberately disabled on the default physics → WebGPU path when measurements show a local slowdown.

See [`docs/TURBOQUANT.md`](docs/TURBOQUANT.md) and the generated [`benchmarks/results/TURBOQUANT_BENCHMARK.md`](benchmarks/results/TURBOQUANT_BENCHMARK.md).

### Fresh benchmark against the original reproducible soft-system baseline

The earliest bundled source with directly comparable maximum-detail cloth, rope, and water recipes is v1.2.0. A fresh Apple M3 Ultra run used seven isolated processes per variant and workload, rotating execution order and applying 20,000 paired-bootstrap resamples:

| Maximum-detail CPU workload | v1.2 JavaScript | v1.10 SIMD/WASM | Speedup | Paired 95% interval |
|---|---:|---:|---:|---:|
| Tensioned Membrane cloth | 6.5829 ms | 0.8966 ms | **7.342×** | 7.272–7.442× |
| Rope Net Resonance | 0.9573 ms | 0.3486 ms | **2.746×** | 2.702–2.786× |
| Leviathan water | 0.4360 ms | 0.0327 ms | **13.342×** | 12.473–14.056× |

The geometric mean is **6.455×** for the production SIMD/WASM path and **3.692×** for JavaScript-to-JavaScript. All variants were deterministic and passed the 0.5% cross-version state-error gate; observed relative L2 error was 0.068–0.229%. Dynamic frame-handoff data fell by 75.0% for cloth, 87.6% for rope, and 75.0% for water.

These numbers measure CPU simulation plus CPU render-handoff work. They exclude physical-GPU time, GPU reconstruction/compute, native Box3D rigid bodies, and universal browser FPS. See the [full original-baseline report](benchmarks/results/original-v1.2-v1.9.md), [raw JSON](benchmarks/results/original-v1.2-v1.9.json), and rerun it with:

```bash
npm run bench:original
```

### V1.10 integration gains

The current pass also benchmarks optimizations that are not represented by the three original soft-system workloads:

| Path | Fresh result | Boundary |
|---|---:|---|
| Effects changed-frame staging | **1.477×** | Node CPU staging |
| Effects update | **1.379×** | Node CPU update |
| Water construction | **1.375×** | Removed dead packed-frame state |
| Water retained typed memory | **28.24% lower** | 549,604 → 394,396 bytes |
| Qualified maximum-stress rope scenes | **1.096×** geometric mean | Five exact-state scenes; 38/250 combinations use batching |
| Unchanged renderer upload call | **95.52×** | 20.24 ns vs 1,933.46 ns microcall; zero uploaded bytes |

The effects unchanged-frame cache also eliminates nearly all rebuild work, but its roughly 19,000× timer-floor microcall ratio is intentionally not presented as a frame-rate gain. See the [integration evidence](benchmarks/results/v1.10-integration-hotpaths.json), [rope qualification](benchmarks/results/rope-batching-qualification.json), and [full integration matrix](docs/V1.10_INTEGRATION_AND_TEST_MATRIX.md).

### AAA WebGPU presentation

- Shared instanced rigid/rope/effect geometry, with GPU-compute expansion of compact rope render data.
- Storage-buffer reconstruction for intact cloth and shallow water; packed indexed fallback for tearing cloth.
- Upload-once `uint16` topology and frame-version caches for surface and soft-instance streams.
- Quality-dependent directional shadows: disabled in Performance, 1,024²/1-tap in Balanced, and 2,048²/3×3 PCF in Cinematic/Ultra.
- `rgba16float` HDR scene target with 1× MSAA in Performance/Balanced and 4× MSAA in Cinematic/Ultra.
- PBR-inspired GGX solid shading.
- Two-sided cloth lighting and transparent water rendering.
- Atmospheric sky, horizon haze, procedural stars, sun glow, and distance fog.
- ACES-inspired tone mapping, lightweight bloom, vignette, and film grain.
- Deterministic sparks, smoke, dust, shockwaves, muzzle flashes, rain flashes, and camera shake.
- Runtime WGSL compilation diagnostics.

---

## 750-scene capability matrix

The catalog is generated as:

```text
15 families × 5 presentation modes × 10 variants = 750 deterministic scenes
```

| Family | Scenes | Primary capability |
|---|---:|---|
| Stack Labs | 50 | stacked contacts, settling, buckling, sleeping |
| Domino Dynamics | 50 | thin bodies, timing, contact-wave propagation |
| Tall Structures | 50 | floors, columns, impacts, progressive collapse |
| Bridges / Infrastructure | 50 | segmented decks, concentrated loads, span failure |
| Material Labs | 50 | friction, restitution, mass, damping, ramps |
| Rain / Stress | 50 | body creation, collision density, transform bandwidth |
| Demolition | 50 | walls, fortifications, projectiles, radial disruption |
| Vehicles / Machines | 50 | moving cargo, obstacles, rollover, impact lanes |
| Marble / Toy Physics | 50 | small-body flow, pegs, ramps, timing gates |
| Construction Sites | 50 | framing, scaffolds, modular loads, crane staging |
| Warehouses / Logistics | 50 | racks, pallets, sorting lanes, inventory cascades |
| Architecture | 50 | atriums, colonnades, façades, large structures |
| **Cloth / Fabric** | **50** | folds, wind, pinning, drape, strain, tearing |
| **Rope / Rigging** | **50** | tension, payloads, anchors, resonance, breakage |
| **Water / Fluids** | **50** | wave propagation, currents, foam, wakes, impacts |

The five presentation modes increase density and direction from a clean baseline through cinematic and maximum-stress arrangements. The **30 hero sequences** add authored cameras, timed actions, slow motion, effects, and telemetry capture over selected scenes.

See [`docs/AAA_SHOWCASE.md`](docs/AAA_SHOWCASE.md) and [`docs/SOFT_BODY_AND_WATER.md`](docs/SOFT_BODY_AND_WATER.md).

---

## Six new hero demonstrations

| Hero | System | What it proves |
|---|---|---|
| **Tempest Standard Protocol** | Cloth | pinned banner, wind front, impact, tear, recovery |
| **Parachute Canopy Failure** | Cloth | curved membrane, four-corner load, puncture, failure |
| **Sky Crane Cable Failure** | Rope | payload swing, tension, line severing, residual motion |
| **Suspension Cable Resonance** | Rope | coupled catenaries, cross-links, resonance, partial failure |
| **Tsunami Research Array** | Water | traveling wave front, reflections, interference, foam |
| **Leviathan Impact Basin** | Water | rain, waves, ballistic impact, splash crown, floaters |

Press **T** or click **Maximum AAA Tour** to play all 30 hero sequences.

---

## Run immediately

From the project root—the directory containing `package.json`:

```bash
npm install
npm run dev
```

Open the localhost URL printed by Vite in a WebGPU-capable browser.

The app first attempts to load the rigid backend:

```text
public/box3d/box3d.js
public/box3d/box3d.wasm
```

The release includes those pinned native artifacts, their license, and build
provenance, so a clean install and GitHub Pages build use real Box3D WASM by
default. When the files are intentionally removed, the application uses the
deterministic preview backend for rigid staging. Independently, the
soft-system loader tries:

```text
public/soft-kernels-simd.wasm
        ↓ if unsupported or unavailable
public/soft-kernels-scalar.wasm
        ↓ if unavailable
deterministic JavaScript fallback
```

Cloth, rope, and water therefore remain active even without the native Box3D artifact. Rebuild and verify the packaged soft kernels with `npm run build:soft-kernels` or `npm run verify:soft-kernels`.

### Correct folder

Run npm commands here:

```text
box3d-WEBGPU/
├── package.json
├── src/
├── wasm/
└── scripts/
```

Do not run them inside `third_party/box3d/`; that folder is the upstream C/CMake dependency and intentionally has no Node `package.json`.

Verify the source and environment:

```bash
npm run verify:source
npm run doctor
```

After intentionally changing release-tracked files, regenerate and verify the portable checksum manifest:

```bash
npm run manifest:generate
npm run verify:source
```

Generated build folders, dependencies, transient benchmark logs, and the user-owned `SOURCE_MANIFEST 2.sha256` file are excluded from this manifest. Persisted benchmark evidence and the bundled native JS/WASM artifacts are included.

Run the simulation-state compression evaluation:

```bash
TQ_FRAMES=60 TQ_SAMPLES=5 TQ_WARMUPS=2 TQ_FANOUTS=1,4,16 npm run bench:turboquant:all
```

---

## Build the native Box3D WASM backend

### 1. Activate Emscripten

```bash
git clone https://github.com/emscripten-core/emsdk.git ~/emsdk
cd ~/emsdk
./emsdk install 4.0.23
./emsdk activate 4.0.23
source ./emsdk_env.sh
```

### 2. Fetch Box3D

```bash
cd /path/to/box3d-WEBGPU
npm run fetch:box3d
```

The fetch script defaults to the pinned revision configured by the project. A deliberate override is supported:

```bash
BOX3D_REF=main npm run fetch:box3d
```

### 3. Build and run

```bash
npm run build:wasm
npm run test:native-wasm
npm run dev
```

Generated files:

```text
public/box3d/box3d.js
public/box3d/box3d.wasm
```

The application backend badge should then report **Box3D WASM**.

The native soak executes all 750 recipes twice, checks deterministic replay
hashes and finite transform/material streams, then exercises the projectile,
rain, impulse, and explosion ABI. Emscripten 4.0.23 is the pinned toolchain
used for the reproducible release artifact.

---

## Controls

| Input | Action |
|---|---|
| Pointer drag | Orbit camera and leave cinematic mode |
| Mouse wheel | Zoom |
| Hero Play / Restart / Next | Control the selected cinematic demonstration |
| Maximum AAA Tour / `T` | Chain all 30 hero sequences |
| Search / family / scene | Browse all 750 scenes |
| Previous / Next / arrow keys | Step through filtered scenes |
| Random / `R` | Load a random matching scene |
| Stress | Rebuild at level 1–5 |
| Render profile | Performance, Balanced, Cinematic, or Ultra |
| Time scale | 0.25×, 0.5×, 1×, or 2× |
| Space | Broad structural/soft-system impulse |
| `E` | Radial blast; displaces cloth, cables, and water |
| `F` | Fire a projectile; can puncture cloth or sever rope |
| Rain | Spawn rigid stress bodies or soft/fluid impacts |
| `P` | Pause/resume |
| `N` | Advance one fixed frame |
| `D` | Toggle bounds, grid, axes, constraints/currents, and effects |

---

## Telemetry

The command deck reports:

```text
rigid bodies / dynamic bodies / effects
soft-system type / nodes / constraints or cells / broken links / energy
FPS / simulation CPU ms / render encode-submit CPU ms
GPU upload MB / active backend / quality profile / replay hash
```

Render-submit timing is CPU-side command encoding/submission time, not GPU timestamp-query time.

---

## Test and validate

### Standard gate

```bash
npm run validate:v1.12
```

This is the cross-platform release gate for the optimized v1.12 tree. It runs the full application and soft-system test stack, exact maximum-stress rope qualification, the tracked native Box3D WASM soak, all retained prior integration checks, the source-frozen v1.11 and v1.12 evidence gates, both production builds, and source-manifest verification.

It runs:

1. strict TypeScript checking;
2. 21 deterministic Node suites;
3. constructors for all 750 scenes;
4. validation for all 30 hero timelines;
5. cloth/rope/water action and replay tests;
6. repository and UI contract checks;
7. strict C17 bridge syntax with warnings as errors;
8. deterministic SIMD/scalar soft-kernel rebuild and numerical/integration tests;
9. Dawn validation of the packed/GPU rigid/cloth/water pipelines and GPU rope compute expansion;
10. execution of the actual renderer runtime against Dawn, including repeated-frame zero-upload checks for current/rest cloth state and compact rope topology;
11. native Box3D execution across all 750 scenes, actions, invalid-timestep guards, and deterministic replay;
12. exact 720-frame rope comparison over all 250 scene/stress combinations;
13. retained v1.9/v1.10/v1.11 integration and evidence gates;
14. the source-frozen v1.12 100-case gate plus focused runtime, effects, camera, and native exact-evidence checks;
15. production and relative-base Pages builds.

The Metal-only hardware gate is intentionally separate from Linux CI:

```bash
npm run validate:hardware
```

It runs the actual renderer and KTX2 path on Dawn/Metal, captures timestamp-query quality-profile evidence, checks fresh-process renderer startup, and measures the unchanged-upload fast path. These device-specific results do not prove universal browser FPS.

### Deep soft-system soak

```bash
npm run test:soft-soak
npm run test:soft-soak:wasm
```

This builds every one of the 150 cloth/rope/water scenes, drives impulses, projectiles, blasts, and rain, validates topology and finite streams, and performs paired deterministic replays for maximum cloth, rope, and water scenes.

Increase the soak duration:

```bash
SOFT_SOAK_FRAMES=120 SOFT_DEEP_FRAMES=1200 npm run test:soft-soak:all
```

### Live browser gate

Inside the running app, click **Run 750 + 30 State Tests**. It creates and steps every recipe, validates rigid/soft state and surface contracts, samples every hero camera, and restores the selected scene. Run it once with the preview backend and again after building Box3D WASM; use the manual browser checklist for actual frame and presentation coverage.

Detailed plans and results:

- [`docs/INTEGRATION_V1.9.md`](docs/INTEGRATION_V1.9.md)
- [`docs/TEST_PLAN.md`](docs/TEST_PLAN.md)
- [`docs/LOCAL_BROWSER_VALIDATION.md`](docs/LOCAL_BROWSER_VALIDATION.md)
- [`VALIDATION_REPORT.md`](VALIDATION_REPORT.md)

---

## Architecture and source map

```text
src/main.ts
  fixed-step coordinator, UI, camera, cinematic director, action routing,
  rigid/soft stream composition, telemetry, live browser validation

src/scenes.ts
  deterministic 750-scene catalog across 15 families

src/showcases.ts
  30 directed sequences with camera tracks and timed beats

src/soft/simulations.ts
  cloth PBD, rope PBD, shallow-water solver, tearing/breakage,
  adaptive intact-cloth schedules, compact rope frames,
  GPU-surface contracts, frame-version caching, telemetry and validation

src/soft/kernels.ts
  SIMD → scalar → JavaScript soft-kernel selection, persistent WASM arena,
  typed views and numerical-kernel wrappers

src/effects.ts
  deterministic particles, shockwaves, dust, flashes, camera shake

src/physics/wasm.ts
  Emscripten loading and stable Box3D PhysicsBackend wrapper

src/physics/fallback.ts
  deterministic rigid staging when native WASM is unavailable

src/webgpu/renderer.ts
  rigid instancing, GPU cloth/water reconstruction, GPU rope expansion,
  packed tear fallback,
  cached uploads, shadow passes, HDR/MSAA, sky/fog/effects/post-processing

wasm/box3d_web.c
  native Box3D world and body creation, transform/color streams,
  impulses, projectiles, rain, replay hash, scene staging

wasm/soft_kernels.c
  standalone C17 cloth/rope/water numerical kernels,
  compiled reproducibly to SIMD and scalar WebAssembly binaries

scripts/soft-simulation-soak.cjs
  150-scene numerical and deterministic soft/fluid stress gate

scripts/soft-kernel-test.mjs / scripts/soft-kernel-integration-test.cjs
  SIMD/scalar ABI, numerical parity, fallback, and scene-integration gates

scripts/webgpu-pipeline-test.mjs
  Dawn shader/pipeline/resource/full-frame validation

scripts/webgpu-renderer-runtime-test.mjs
  executes the actual WebGPURenderer class against Dawn
```

---

## Current technical boundaries

- Box3D is authoritative for rigid bodies. The soft-system coordinator is TypeScript, while stable cloth, rope, water, and rope-instance hot paths can execute in packaged WebAssembly kernels.
- Water is an interactive **2.5D heightfield**, not a general volumetric SPH/FLIP/Navier–Stokes solver.
- Cloth/rope/water currently exchange actions and staging with rigid scenes, but they are not yet fully bidirectionally coupled to arbitrary Box3D collision shapes.
- Soft numerical kernels remain CPU/WASM work. WebGPU reconstructs intact cloth and water presentation and expands compact rope render data; GPU-compute physics solvers remain a future path.
- The renderer supports one active cloth or water surface per scene, plus instanced ropes, payloads, droplets, rigid bodies, and effects.
- Tearing cloth intentionally uses the topology-aware packed CPU fallback instead of the intact-grid GPU reconstruction path.
- The native bridge supplies rigid staging for the new families; one-to-one native recipe parity remains future work.
- A target-browser visual acceptance run and the local Emscripten build remain required before calling a specific machine/browser combination production-certified.

---

## License and attribution

This project is MIT licensed. Upstream Box3D remains under its own license and is fetched separately. See [`THIRD_PARTY_NOTICES.md`](THIRD_PARTY_NOTICES.md).
