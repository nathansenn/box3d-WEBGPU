# Performance Edition v1.8.0

GPU-resident intact cloth removes CPU surface reconstruction, measuring 109.70× geometric-mean faster frame handoff across 35 cloth scenes, 1.15× across 25 complete cloth workloads, and 1.064× across isolated dynamic/mixed release workloads.

Intact-cloth dynamic uploads are 33.33% smaller. Tearing cloth retains the topology-aware CPU path.

See [docs/PERFORMANCE_V1.8.md](docs/PERFORMANCE_V1.8.md).
