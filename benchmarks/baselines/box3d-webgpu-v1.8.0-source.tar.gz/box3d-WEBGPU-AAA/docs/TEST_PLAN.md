# Test Plan — Box3D WebGPU AAA Physics Lab

## Quality-gate sequence

```text
source integrity
  → strict TypeScript
  → 15 deterministic Node suites
  → 750 scene constructors / 30 hero definitions
  → repository and UI contracts
  → strict C17 bridge syntax
  → Dawn WGSL/pipeline/full-frame validation
  → actual renderer runtime validation
  → production bundling
  → 150-scene soft/fluid soak
  → visible browser and native-WASM acceptance
```

## Standard automated gate

```bash
npm run validate
```

Stages:

1. `tsc --noEmit`;
2. test-only CommonJS compilation;
3. 15 deterministic Node suites;
4. repository self-test;
5. strict C17 bridge syntax/API-contract test;
6. Dawn WebGPU pipeline/full-frame test;
7. actual renderer runtime test;
8. Vite production build.

## Node suites

| Suite | Purpose |
|---|---|
| `testMath` | matrix identity/multiplication and finite projections |
| `testSceneCatalog` | exactly 750 unique scenes, 15 families, valid metadata |
| `testHeroShowcaseCatalog` | exactly 30 unique heroes, sorted keys/beats, finite camera sampling |
| `testFallbackCanCreateEveryScene` | every scene creates valid rigid staging, finite transforms, nonzero hash |
| `testAAACinematicSetDressing` | cinematic modes and hero scenes receive and step authored staging |
| `testFeaturedScenesStep` | featured scenes survive multiple fixed steps |
| `testDeterminism` | identical rigid scene/seed/action sequence matches replay hash |
| `testSoftSimulationCatalog` | all 150 cloth/rope/water scenes construct, step, publish valid streams/topology |
| `testSoftSimulationActionsAndDeterminism` | soft kick/projectile/explosion/rain actions and paired replay hashes |
| `testTurboQuantCodec` | deterministic dense/structured codecs, compression, predictive reconstruction error |
| `testBreakthroughPackedSurfaceFastPath` | host endianness detection and shared packed RGBA upload storage |
| `testBreakthroughReuseContracts` | sweep/effect typed buffers are allocated geometrically and reused |
| `testBreakthroughStormDeterminism` | 150-impact cloth and 96-impact rope storms remain finite and deterministic; cloth hierarchy covers all constraints |
| `testCinematicEffects` | effect budgets, emissive tags, lines, shake, finite streams |
| `testActions` | rigid impulse, explosion, projectile, rain, body growth, stepping |

## Repository self-test

Checks include:

- required source, docs, workflows, and test scripts;
- package version and all build/test commands;
- C bridge exports and CMake/WASM flags;
- 30 authored hero definitions;
- required HTML IDs exactly once;
- 750-scene family generation including cloth/rope/water;
- soft-system classes, budgets, constraints, water integration, dynamic surfaces;
- HDR/MSAA/shadow/post and cloth/water renderer markers;
- WGSL uniformity, pass-depth, and shadow-resource regressions;
- GitHub CI and Pages workflows.

## C bridge syntax gate

```bash
npm run test:cbridge
```

A temporary API-contract header representing the pinned Box3D calls is generated, then `wasm/box3d_web.c` is compiled in syntax-only C17 mode with:

```text
-Wall -Wextra -Werror
```

This does not replace an Emscripten link against real upstream Box3D; it catches syntax, declaration, and warnings-as-errors regressions in constrained environments.

## Dawn WebGPU gate

```bash
npm run test:webgpu
```

The pipeline test validates eight WGSL modules and the complete render topology:

- rigid shadow;
- cloth-surface shadow;
- atmospheric sky;
- PBR rigid solids;
- woven cloth;
- interactive water;
- debug/effect lines;
- post-processing and swapchain-format compatibility.

It creates bind groups, depth/HDR/MSAA attachments, dynamic surface buffers, indexed draws, and submits one complete shadow → HDR → post command buffer.

The runtime test transpiles and executes the actual `WebGPURenderer` class with rigid, cloth, and water frames, including resize and empty/no-shadow paths. Uncaptured WebGPU errors must remain zero.

## Soft/fluid soak gate

```bash
npm run test:soft-soak
```

Default coverage is executed once with the JavaScript solver and once with the packaged SIMD WebAssembly kernels:

```text
150 scenes × 24 frames = 3,600 catalog frames per variant
3 maximum scenes × 2 paired solvers × 300 frames = 1,800 replay frames per variant
variants: javascript + simd
```

The action schedule injects kick, projectile, explosion, and rain events. Every inspected frame must satisfy:

- correct active solver kind;
- initialized nodes and constraints/cells;
- explicit instance budget;
- exact matrix/color stream lengths;
- finite instance and surface values;
- finite nonnegative energy;
- initialized replay hash;
- exact 24-byte packed dynamic-surface stride;
- every surface index in range;
- paired deterministic hash equality.

Longer run:

```bash
SOFT_SOAK_FRAMES=120 SOFT_DEEP_FRAMES=1200 npm run test:soft-soak
```

## Breakthrough performance gate

Run all standard validation, the soft-system soak, exactly 100 candidate experiments, the same-process comparison, the fresh-process comparison, and the evidence assertions:

```bash
npm run validate:breakthrough
```

Individual commands:

```bash
npm run bench:breakthrough:100
npm run bench:breakthrough:integrated
npm run bench:breakthrough:isolated
npm run bench:breakthrough:gate
```

The fresh-process driver launches baseline and optimized modules separately so they cannot share JIT state or garbage-collector history. Its release gate requires determinism, exact hashes where expected, representative non-tearing cloth error below 0.2%, and conservative minimum speedups for the measured environment. Machine-to-machine timings may differ; target-browser FPS and GPU timing remain a separate manual gate.

## v1.6 second breakthrough gate

Run the packaged kernel tests, both soft-system soak variants, the second exactly-100 experiment evidence gate, and both production builds:

```bash
npm run validate:v1.6
```

Individual commands:

```bash
npm run build:soft-kernels
npm run test:soft-kernels
npm run test:soft-soak:js
npm run test:soft-soak:wasm
npm run bench:second:100
npm run bench:kernels:isolated
npm run bench:second:gate
```

The 100-result gate requires exactly 100 records, at least 70 accepted wins, retained fidelity rejections, a dynamic geometric-mean speedup above 1.35×, every dynamic release workload above 1.10× with a paired lower interval above 1.0, and every unchanged-frame workload above 50×.

The isolated benchmark automatically extracts and compiles `benchmarks/baselines/box3d-webgpu-v1.5.0-source.tar.gz`; no absolute development-machine path is required.

## Live browser validation

Click **Run 750 + 30 Browser Tests**.

The app:

1. stops cinematic playback;
2. creates and steps all 750 scenes against the active rigid backend;
3. builds and validates the active cloth/rope/water frame when present;
4. checks body counts, matrices, colors, indexed surfaces, and hashes;
5. samples every hero camera and validates beat ordering;
6. creates/advances an explosion effect frame;
7. restores the previous scene and UI state;
8. prints the pass summary.

## Manual rendering matrix

| Area | Checks |
|---|---|
| Startup | adapter/device/context, readable failure state |
| WGSL | zero compilation errors; warnings reviewed |
| Resize | desktop, narrow layout, high DPR, browser zoom |
| Shadows | rigid and cloth shadows, PCF stability, no feedback error |
| HDR/post | finite output, exposure, bloom, tone map, fog |
| Cloth | two-sided light, normals, weave, tears, stress colors |
| Rope | segment orientation, tension colors, anchors, payloads, breaks |
| Water | transparency, depth order, normals, Fresnel, foam, currents |
| Effects | profile budget, emissive sparks, shockwave alignment |
| Camera/director | orbit, zoom, cuts, slow motion, manual handoff, tour |
| Diagnostics | pins/nodes, rope markers, water current vectors, line budget |
| Backend | preview label; Box3D WASM label after native build |

## Performance matrix

Measure stress 1, 3, and 5 for:

- Titan Foundry Stackfall;
- Aegis Tower: Kinetic Breach;
- Orbital Cargo Storm;
- Tempest Standard Protocol;
- Sky Crane Cable Failure;
- Tsunami Research Array;
- Leviathan Impact Basin.

Record:

```text
browser / OS / GPU
backend and quality profile
viewport / DPR
rigid bodies and soft nodes
constraints/cells and breaks
FX count
FPS
simulation CPU ms
render encode-submit CPU ms
upload MB/frame
replay hash
```

Do not label CPU encode/submit time as GPU time. GPU timestamp queries are a future gate.

## Native build gate

With Emscripten active:

```bash
npm run fetch:box3d
npm run build:wasm
npm run dev
```

Verify artifacts exist and are non-empty, backend reports **Box3D WASM**, memory growth does not detach heap views, rigid projectiles/large stacks use native collision behavior, and the live 780-scenario gate passes.

## Honesty boundary

When Emscripten or a visible GPU browser is unavailable, source/C/Dawn validation may pass, but native linking and visible hardware rendering must not be claimed as executed. `VALIDATION_REPORT.md` records this boundary.


## v1.7 performance and GPU-water gates

- `npm run bench:third:100`: exactly 100 alternating-order, median/MAD production-path comparisons against bundled v1.6 source.
- `npm run bench:v1.6-v1.7`: ten fresh-process workloads with paired bootstrap intervals.
- `npm run bench:third:gate`: result counts, speed thresholds, payload reduction, deterministic hashes, stream equivalence, and WebAssembly export checks.
- `npm run test:webgpu`: nine WGSL modules plus first/repeated/changed GPU-water upload behavior and indexed draw submission under Dawn.
- `npm run validate:v1.7`: tests, dual soft-system soak, evidence gate, production build, and GitHub Pages build.
## v1.8 performance and GPU-cloth gates

- `npm run bench:fourth:100`: four sharded groups totaling exactly 100 alternating-order v1.7/v1.8 comparisons with five samples, medians/MAD, visual fidelity, deterministic hashes, and byte accounting.
- `npm run bench:v1.7-v1.8`: ten fresh-process workloads with paired bootstrap intervals.
- `npm run bench:fourth:gate`: verifies counts, correctness, performance floors, visual limits, hash equality, and one-third dynamic-byte reduction.
- `npm run test:webgpu`: compiles ten WGSL modules and submits legacy/GPU cloth, legacy/GPU water, rigid, shadow, line, HDR/MSAA, and post passes through Dawn.
- `npm run validate:v1.8`: full tests, dual soft-system soak, evidence gate, production build, and GitHub Pages build.

