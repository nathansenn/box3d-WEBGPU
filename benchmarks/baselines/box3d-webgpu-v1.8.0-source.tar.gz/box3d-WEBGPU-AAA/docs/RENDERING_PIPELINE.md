# Rendering Pipeline

## Frame graph

```text
CPU / WASM / TypeScript
  Box3D fixed step
  cloth PBD · rope PBD · shallow-water step
  rigid/soft transform + color streams
  cloth/water indexed dynamic surface
  cinematic effects and debug lines
          │
          ├── Pass 1: directional shadow depth (2048² depth32float)
          │       instanced rigid/rope geometry
          │       indexed cloth surface
          │
          ├── Pass 2: HDR scene (rgba16float, 4× MSAA)
          │       atmospheric sky
          │       instanced PBR-inspired rigid/rope/effect solids
          │       two-sided woven cloth
          │       translucent water
          │       additive debug/effect lines
          │       resolve to single-sample HDR texture
          │
          └── Pass 3: post-processing to swapchain
                  neighborhood glow
                  exposure
                  ACES-inspired tone map
                  vignette
                  film grain
                  display gamma
```

## Stream layouts

### Instanced geometry

Each rigid body, rope segment, payload, projectile, droplet, floater, or solid effect uses:

```text
model matrix   16 floats
color/tag       4 floats
```

The alpha component acts as an emissive/material-strength tag. One shared cube mesh handles the current instanced solid path.

### Dynamic indexed surfaces

Cloth and water use one active dynamic surface stream:

```text
position.xyz   float32x3
normal.xy      octahedral snorm16x2
color.rgba     unorm8x4
uv.xy          unorm16x2
24 bytes per vertex
uint16 triangle indices
```

Hard renderer budgets:

```text
16,384 vertices
98,304 indices
```

The renderer validates stream lengths, clamps counts to GPU capacity, and verifies every uploaded index before submission. Version 1.6 also caches backing-buffer identity, byte offset, `frameVersion`, vertex count, and topology version; unchanged surfaces return zero uploaded bytes and skip redundant `GPUQueue.writeBuffer` calls.

## Material pipelines

| Pipeline | Geometry | Key behavior |
|---|---|---|
| PBR solid | instanced cubes | GGX-inspired light, shadowing, emissive tag, fog |
| Woven cloth | indexed surface | two-sided light, weave modulation, stress heat, shadows |
| Interactive water | indexed surface | alpha blend, Fresnel, dual specular, foam, micro-waves |
| Line/effect | line list | additive debug vectors, grid, axes, shockwaves |
| Sky | fullscreen triangle | procedural atmosphere, stars, sun, horizon |
| Post | fullscreen triangle | bloom proxy, exposure, tone map, vignette, grain |

Cloth casts and receives directional shadows. Water receives scene lighting but does not cast in this edition and disables depth writes to support transparency.

## Scene uniform block

The 192-byte uniform block contains:

| Range | Data |
|---|---|
| 0–15 | camera view-projection |
| 16–31 | light view-projection |
| 32–35 | camera position + elapsed time |
| 36–39 | light direction + exposure |
| 40–43 | fog color + density |
| 44–47 | viewport + bloom + shadow contribution |

## Quality profiles

| Profile | Internal resolution | Shadows | Effect budget | Intended use |
|---|---:|---:|---:|---|
| Performance | 70% | skipped | 256 | low-power/mobile diagnostics |
| Balanced | 85% | reduced | 512 | general interaction |
| Cinematic | 100% | full | 1,024 | default demonstration |
| Ultra | 115% | full | 1,536 | high-end capture |

Internal resolution is multiplied by device pixel ratio and capped to protect allocations.

## WGSL validation protections

- `GPUShaderModule.getCompilationInfo()` promotes readable shader failures during startup.
- Shadow PCF uses `textureSampleCompareLevel`, avoiding fragment uniformity restrictions.
- Projected shadow coordinates are clamped and masked without a per-fragment early return before comparison sampling.
- The sky pipeline declares `depth24plus` compatibility for the shared HDR pass.
- The shadow pass uses a uniform-only bind group, so the writable shadow map is not simultaneously sampled.
- Empty rigid draws are skipped.
- Dynamic cloth/water surfaces are exercised with actual indexed draws in the Dawn tests.
- Repeated identical surface frames are asserted to perform zero additional vertex/index upload.

## Validation gate

```bash
npm run test:webgpu
```

The gate compiles eight WGSL modules, creates all rigid/cloth/water/shadow/sky/line/post pipelines, validates layouts and attachments, submits a full offscreen frame through Dawn, and runs the actual `WebGPURenderer` class with rigid, cloth, and water frames.

## Deliberate simplifications

- Water is transparent forward rendering without order-independent transparency.
- Only one active dynamic indexed cloth or water surface is drawn per scene.
- Bloom is a compact neighborhood glow rather than a mip-chain implementation.
- Ambient occlusion is a lightweight proxy rather than GTAO/SSAO.
- Solid materials are inferred from stream data rather than texture sets.
- Render telemetry is CPU encode/submit time, not physical-GPU timestamp duration.


## v1.7 GPU-resident water path

Normal water rendering no longer uploads a CPU-built packed vertex stream. The renderer binds three read-only storage fields (`eta`, `u`, `v`), a compact grid uniform, and static `uint16` topology. The water vertex shader derives world position, central-difference normal, velocity/curvature foam, UV, shadow position, and material color. State uploads are revision-cached; topology and uniforms are independently cached.

The legacy packed-water pipeline remains available for regression validation and fallback testing. Dawn directly compiles and submits both pipelines.
## v1.8 GPU-resident intact-cloth path

Intact cloth now uses two read-only storage buffers and a compact uniform:

```text
positions: float32 × 3 per vertex
strain:    float32 × 1 per vertex
uniform:   dimensions, orientation, two palettes, X/Y checker masks
indices:   uint16 static topology
```

WebGPU reconstructs UVs, central-difference normals, the legacy checker palette, stress coloration, woven response, and shadow positions. Dynamic traffic is 16 bytes per vertex rather than the former 24-byte packed CPU vertex. Topology is uploaded only when its identity/version changes, and identical frame revisions skip all cloth state writes. Tearing cloth still uses the packed dynamic-surface pipeline because its holes and disconnected edges require triangle-aware topology and normals.

