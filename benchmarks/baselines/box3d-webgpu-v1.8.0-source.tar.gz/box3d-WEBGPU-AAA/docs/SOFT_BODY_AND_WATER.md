# Cloth, Rope, and Water Simulation Architecture

## Purpose

The soft-system layer provides three deterministic simulation families without destabilizing the native Box3D boundary. Version 1.6 keeps TypeScript scene control and interaction logic while accelerating stable numerical hot loops with packaged SIMD/scalar WebAssembly modules:

```text
Box3D / WASM                           SoftSimulationSuite
rigid-body authority                   TypeScript control + WASM hot kernels
       │                                      │
       ├── model matrices + colors            ├── rope segment instances
       │                                      ├── cloth indexed surface
       │                                      ├── water indexed surface
       │                                      └── telemetry / debug vectors
       └────────────────── fixed-step coordinator ──────────────────┐
                                                                    ↓
                                                               WebGPU renderer
```

Box3D remains the rigid-body solver. Cloth, rope, and water are deliberately isolated behind `SoftSimulationSuite`, which exposes the same interaction vocabulary—step, kick, explosion, projectile, rain, frame, hash, validation—without mirroring internal solver data into the UI.

## Shared runtime contract

Each active system publishes a `SoftSimulationFrame`:

| Field | Purpose |
|---|---|
| `kind` / `label` | active solver and human-readable configuration |
| `matrices` / `colors` | instanced rope segments, payloads, projectiles, droplets, floaters |
| `surface` | optional indexed cloth or water vertex/index stream |
| `debugLines` | pins, sample nodes, current vectors, and diagnostics |
| `nodeCount` | particles/cells plus transient objects |
| `constraintCount` | PBD links or water-field cell relationships |
| `brokenCount` | torn cloth links or broken rope segments |
| `energy` | normalized motion/field-energy diagnostic |
| `hash` | quantized deterministic replay signature |
| `frameVersion` | exact visual-state revision used for memoization and upload suppression |

Hard budgets:

```text
soft instances                 2,048
water droplets                   768
dynamic surface vertices      16,384
dynamic surface indices       98,304
surface vertex stride             24 bytes
```

The packed surface stride is:

```text
position.xyz       float32 × 3   12 bytes
normal.xy          oct snorm16    4 bytes
color.rgba         unorm8         4 bytes
uv.xy              unorm16        4 bytes
                                  --------
                                  24 bytes
indices            uint16
```

## v1.6 execution tiers

The runtime initializes the soft kernels independently from the native Box3D build:

```text
soft-kernels-simd.wasm
        ↓ unsupported or unavailable
soft-kernels-scalar.wasm
        ↓ unavailable
authoritative JavaScript implementation
```

The WebAssembly arenas hold persistent positions, previous positions, inverse masses, packed constraints, shallow-water fields, and water surface output. A one-time scene migration replaces per-step copying; the typed arrays published to TypeScript point directly into the fixed WebAssembly memory.

Conservative boundaries remain explicit:

- tearing cloth stays on the JavaScript topology path;
- cloth yields to the JavaScript step while live projectile contacts need mutable interaction logic;
- rope projectile contacts and break bookkeeping remain in TypeScript;
- water integration and packed surface generation use the WebAssembly path;
- any module load or instantiation failure falls back without preventing startup.

Every visual mutation increments `frameVersion`. Repeated `buildFrame()` calls without a mutation return the cached frame, allowing both the director and renderer to skip identical CPU construction and GPU queue writes.

## Cloth solver

### Numerical model

Cloth uses deterministic position-based dynamics:

1. Verlet-style integration derives velocity from current and previous positions.
2. Gravity and time-varying wind/turbulence are applied.
3. Structural, shear, and bend constraints project positions toward rest lengths.
4. Ground and optional sphere collisions project penetrating particles outward.
5. Projectiles and rain particles transfer momentum.
6. Breakable constraints are evaluated against controlled stretch thresholds.
7. Dynamic normals, strain colors, topology, energy, and replay hash are rebuilt only when the visual state is dirty.

The solver uses bounded substeps and a stress/mode-dependent iteration count. Stable non-tearing projection is accelerated by the selected WebAssembly kernel; tearing retains the JavaScript implementation.

### Constraint classes

| Class | Purpose |
|---|---|
| Structural | horizontal and vertical weave integrity |
| Shear | diagonal resistance and shape retention |
| Bend | longer-range resistance to unrealistic folding |
| Pin | zero inverse-mass boundary or corner attachment |

### Tearing

Structural links may break in designated tear scenes or high-intensity modes. The solver records horizontal and vertical break maps. During index generation, triangles spanning broken structural edges are omitted, producing a real visual opening instead of only coloring an intact mesh.

Breakage is budgeted per step to avoid deleting a large part of the fabric in a single unstable frame. Strain is visualized from cool fabric colors toward hot emissive red near failure.

### Cloth collision and interaction

- ground-plane collision with tangential damping;
- optional sphere collision for drape/hammock/canopy scenes;
- broad kick impulse;
- radial explosion impulse;
- ballistic projectile collision and local tearing;
- rain/body-drop collision proxies;
- deterministic wind and turbulence.

### Cloth variants

1. Tempest Standard
2. Royal Banner Wind Tunnel
3. Parachute Canopy Deployment
4. Cargo Net Load Catch
5. Suspended Hammock Dynamics
6. Racing Sail Aerodynamics
7. Progressive Fabric Tear Lab
8. Drape Over Collider
9. Grand Theater Curtain
10. Tensioned Membrane Drum

## Rope and cable solver

### Numerical model

Rope uses the same deterministic Verlet/PBD foundation but publishes oriented instanced segments instead of a continuous triangle surface.

Each cable can contain:

- fixed anchors;
- renderable distance constraints;
- non-rendered bend constraints;
- one or more concentrated payload particles;
- cross-links between adjacent lines;
- break thresholds and tension colors.

The renderer constructs a model matrix between each active pair of particle endpoints. Segment thickness shrinks slightly under high tension and color shifts toward emissive red near failure.

### Rope interaction

- gravity, damping, ground collision, and bounded world limits;
- broad impulses and deterministic excitation;
- radial blasts;
- projectile impacts and nearest-link severing;
- rain impacts;
- payload inertia and swing;
- controlled high-tension breakage.

### Rope variants

1. Sky Crane Cable Load
2. Suspension Cable Bridge
3. Heavy Pendulum Strike
4. Industrial Rope Ladder
5. Four-Point Mooring Array
6. Cable Curtain Failure
7. High-Speed Zipline
8. Grappling Line Tension
9. Multi-Sling Rigging Test
10. Rope Net Resonance

## Water solver

### Numerical model

Water is a deterministic 2.5D linear shallow-water heightfield. Each grid cell tracks:

```text
eta   surface-height displacement
u     horizontal x velocity
v     horizontal z velocity
```

A step updates velocity from surface gradients, applies drag, updates surface height from velocity divergence, and reflects flow at the domain boundaries. The time step is clamped and substepped to keep the explicit integration stable.

This model is excellent for basin-scale ripples, wave fronts, wakes, fountains, rain impacts, and currents. It is intentionally not a volumetric free-surface solver and does not model overturning waves, air entrainment, viscosity layers, or arbitrary 3D topology.

### Water interaction

- localized height and velocity disturbances;
- automatic traveling waves and oscillators;
- rain droplets that inject impulses on contact;
- projectile/impact floaters;
- simple buoyancy and horizontal-current coupling for floating boxes;
- current-vector debug lines;
- curvature and speed-derived foam.

### Water variants

1. Interactive Ripple Basin
2. Tsunami Research Flume
3. Storm Ocean Surface
4. Hydrodynamic Boat Wake
5. Oscillating Fountain Pool
6. Rain Impact Reservoir
7. Dam-Breach Wave Front
8. Vortex Current Chamber
9. Harbor Buoyancy Lab
10. Leviathan Impact Pool

## WebGPU surface rendering

Cloth and water share a dynamic indexed surface upload path but use separate materials.

### Cloth material

- two-sided triangle rendering;
- dynamic normal lighting;
- subtle procedural weave modulation;
- stress and emissive heat visualization;
- directional shadow reception and casting;
- HDR/fog integration.

### Water material

- alpha blending and disabled depth writes;
- dynamic normals;
- Fresnel edge response;
- broad and sharp specular lobes;
- foam derived from per-vertex alpha;
- procedural micro-wave detail;
- HDR/fog/post-processing integration.

Cloth participates in the directional shadow pass. Water does not cast a shadow in the current edition, avoiding a visually heavy opaque depth silhouette for a transparent surface.

## Determinism

Every soft/fluid system is seeded by scene identity and a caller-provided seed. Replay hashes quantize a bounded subset of the simulation state before FNV-style accumulation. Determinism tests run paired instances with identical actions and verify matching hashes during long simulations.

The hash is a regression signal, not a cryptographic digest and not a promise of bit-identical behavior across every future JavaScript engine or code revision.

## Validation

Run:

```bash
npm test
npm run test:soft-soak
```

The gates verify:

- all 150 soft/fluid scene constructors;
- finite matrices, colors, vertices, normals, and energy;
- valid vertex stride and index bounds;
- explicit instance and droplet budgets;
- action routing for kick, projectile, explosion, and rain;
- deterministic paired replays in both JavaScript and WebAssembly modes;
- packaged SIMD/scalar module exports and stable-horizon fidelity;
- frame-version invalidation and unchanged-frame reuse;
- cloth tear topology;
- rope breakage and segment-stream integrity;
- water stability and bounded field values;
- WGSL compilation and indexed draw compatibility through Dawn;
- the actual renderer runtime path for cloth and water.

## Performance profile

The v1.6 fresh-process comparison against v1.5 measured:

```text
1.4708× dynamic geometric-mean speedup
1.5317× dynamic median speedup
1.44–1.59× cloth workloads
1.15–1.23× rope workloads
1.64–1.83× water workloads
115–959× unchanged-frame construction
```

The dynamic results include simulation and frame construction. The unchanged-frame result is exact memoization, not reduced solver quality. These are CPU measurements from one Linux/x64 Node environment—not universal browser, physical-GPU, or battery guarantees. See `docs/PERFORMANCE_V1.6.md`.

## Next engineering steps

1. Bidirectional coupling against arbitrary Box3D shape queries.
2. Self-collision and continuous collision for cloth and rope.
3. XPBD compliance parameters and physically meaningful stiffness tuning.
4. Cloth aerodynamic pressure from relative wind and triangle area.
5. Rope pulleys, winches, motors, and contact against convex shapes.
6. Water obstacles, shoreline masks, depth maps, and rigid-body force integration.
7. Worker isolation and double-buffered soft-state streams.
8. WebGPU compute versions of constraint projection and water integration.
9. Multiple simultaneous dynamic surfaces and material batches.
10. GPU timestamp queries and target-device performance baselines.


## v1.7 render handoff

The shallow-water solver remains authoritative on the CPU/WASM side, but surface reconstruction moves to WebGPU. `WaterGridFrame` exposes height, horizontal velocity, static topology, grid dimensions, and monotonic revisions. This halves steady state traffic compared with the 24-byte packed surface and removes the CPU normal/foam traversal.

Rope segment render frames are generated by `rope_instances` in the persistent soft-kernel arena. Payload and projectile instances remain TypeScript-owned. Zero-length connector tension is based on raw length while model-matrix normalization uses a safe clamped length.
## v1.8 intact-cloth render handoff

The PBD/WASM solver remains authoritative. For non-tearing grids, `buildFrame()` now returns `ClothGridFrame` instead of rebuilding a packed surface. The frame contains live positions and strain, static `uint16` topology, dimensions, orientation, palette, and revision numbers. The renderer performs reconstruction in the vertex shader. Tearing scenes continue returning `DynamicSurfaceFrame` so broken constraints can remove triangles and recompute normals around real openings.

The release compares the GPU reconstruction mathematically against the v1.7 packed stream. Positions and topology are exact; maximum normal relative-L2 error is below 0.000055; maximum color error is one 8-bit step; and maximum UV error is below 0.000008.

