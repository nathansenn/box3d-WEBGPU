# Box3D WebGPU AAA v1.8.0 — GPU-Cloth Breakthrough Performance Report

## Executive result

This pass moves intact regular-grid cloth surface reconstruction from the CPU to the WebGPU vertex stage. The authoritative PBD/WASM solver still owns positions and strain; WebGPU reconstructs smooth normals, UVs, the legacy checker palette, stress color, woven shading, and shadows. Tearing cloth keeps the topology-aware packed CPU surface path.

### 100-experiment tournament

- Experiments: **100**
- Samples per experiment: **5**
- Iteration scale: **0.35×** of the standard loop count
- Baseline/optimized order alternated for every experiment.
- Warm-up precedes timing.
- Medians and median absolute deviations are retained in raw evidence.
- Every changed path must preserve finite state, deterministic and cross-version hashes, topology, positions, reconstructed normals/colors/UVs, output shape, and transport contracts.

- Accepted changed paths: **68**
- Borderline changed paths: **9**
- Unchanged-path controls: **20**
- No-win rejections: **3**
- Correctness failures: **0**
- Changed-path geometric mean: **8.30×** (dominated by eliminated frame reconstruction and not a whole-engine claim)

| Category | Tests | Geometric mean | Median | Accepted |
|---|---:|---:|---:|---:|
| cloth-frame | 35 | **109.70×** | 128.02× | 35 |
| cloth-full | 25 | **1.15×** | 1.11× | 20 |
| cloth-storm | 20 | **1.07×** | 1.07× | 13 |
| cloth-tearing-control | 7 | **1.00×** | 1.00× | 0 |
| water-full-control | 7 | **1.05×** | 0.98× | 0 |
| rope-full-control | 6 | **0.99×** | 0.99× | 0 |

### Isolated fresh-process comparison

- Samples per workload: **5**
- Paired bootstrap resamples: **5000**
- Each measurement uses a fresh Node process; process startup is excluded from the timed loop.
- Version order alternates.

- Changed-path geometric mean: **3.23×**
- Dynamic/mixed geometric mean: **1.064×**

| Workload | v1.7 ms | v1.8 ms | Speedup | Paired 95% interval |
|---|---:|---:|---:|---:|
| Standard cloth · render handoff | 0.030364 | 0.000361 | **84.08×** | 77.88–86.04× |
| Maximum cloth · render handoff | 0.036408 | 0.000371 | **98.21×** | 84.59–106.51× |
| Standard cloth · solver + handoff | 0.878585 | 0.837817 | **1.05×** | 1.01–1.07× |
| Maximum cloth · solver + handoff | 1.043541 | 0.997261 | **1.05×** | 1.04–1.07× |
| Collider drape · solver + handoff | 1.041166 | 0.934275 | **1.11×** | 1.07–1.17× |
| Maximum cloth · 120-projectile storm | 1.947342 | 1.822752 | **1.07×** | 1.04–1.09× |
| Banner cloth · 120-projectile storm | 1.859168 | 1.798461 | **1.03×** | 0.99–1.12× |
| Tearing cloth · topology control | 3.834907 | 3.795390 | **1.01×** | 0.98–1.02× |
| Maximum water · unchanged control | 0.067094 | 0.070186 | **0.96×** | 0.92–0.98× |
| Mixed maximum cloth + rope + water | 1.630740 | 1.520882 | **1.07×** | 1.05–1.09× |

## Architecture

```text
v1.7 intact cloth
PBD/WASM solver → CPU normal/color/UV packing → 24-byte vertex upload → WebGPU

v1.8 intact cloth
PBD/WASM solver → position + strain storage upload → WebGPU reconstruction/shading

Tearing cloth
PBD topology mutation → topology-aware CPU surface → WebGPU
```

For intact cloth, steady dynamic data falls from 24 bytes per vertex to 16 bytes per vertex: **33.33% fewer uploaded bytes**. Topology is static and cached. Unchanged frame revisions produce zero additional uploads.

## Visual and numerical fidelity

- Simulation positions and hashes are exact across v1.7 and v1.8 for all 100 experiments.
- Topology and output counts are exact.
- A compact pair of X/Y parity masks preserves the legacy CPU checker pattern, including floating-point endpoint behavior, without uploading per-vertex colors.
- Dawn compiles and submits both the main and shadow GPU-cloth pipelines.

- Maximum reconstructed-normal relative L2: **0.00005495**
- Maximum color RMS error: **0.00235790**
- Maximum per-channel color error: **0.00392155** (one 8-bit step)
- Maximum UV error: **0.00000763**

## Interpretation

The 80–100× handoff numbers measure elimination of CPU vertex reconstruction near the timer floor; they are not whole-engine or physical-GPU FPS multipliers. Complete cloth workloads improve more modestly because constraint solving remains dominant. The fresh-process mixed maximum cloth/rope/water workload is the most conservative application-level result for this pass.

No target-Mac physical-GPU timestamp result is claimed. Dawn proves WGSL, bind groups, storage buffers, shadow and HDR pipeline compatibility, indexed draws, upload caching, and command submission in this environment.

## Reproduction

```bash
npm ci
npm run bench:fourth:100
npm run bench:v1.7-v1.8
npm run bench:fourth:gate
npm run validate:v1.8
```

Raw evidence: `benchmarks/results/v1.8-fourth-breakthrough-100.json` and `benchmarks/results/v1.7-v1.8-isolated.json`.
