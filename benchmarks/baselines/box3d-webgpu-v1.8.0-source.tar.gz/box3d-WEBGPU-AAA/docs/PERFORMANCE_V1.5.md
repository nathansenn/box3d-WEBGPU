# Box3D WebGPU AAA v1.5.0 — Breakthrough Performance Report

## Executive result

Version 1.5.0 applies the winning candidates from an exactly **100-experiment** optimization tournament to the real simulation and rendering-preparation source. It then compares the integrated build with the bundled v1.4.0 baseline using complete simulation-plus-frame workloads.

The stricter fresh-process benchmark measured:

- **2.10× geometric-mean speedup** across ten representative workloads;
- **2.27× median workload speedup**;
- **6.75×** for maximum cloth under a 150-projectile impact storm;
- **3.22×** for maximum rope under its 96-projectile cap;
- **3.00×** for the dense bridge preview scene;
- no meaningful steady-rope regression: **1.013×**, with the paired confidence interval spanning parity.

These ratios are measured independently. They are not multiplied into an artificial “total engine” number.

## Fresh-process integrated proof

5 fresh-process paired samples per workload, alternating version order; medians, MAD, paired speed ratios, and 5000-resample paired bootstrap confidence intervals. Timers cover complete simulation plus frame construction, not process startup.

| Workload | v1.4 ms | v1.5 ms | Speedup | Paired bootstrap 95% CI | Replay relation | Position error |
|---|---:|---:|---:|---:|---|---:|
| cloth-steady | 3.5390 | 1.5576 | **2.27×** | 2.26–2.30× | bounded approximation | 0.0346% |
| cloth-rain | 21.8939 | 3.2436 | **6.75×** | 6.25–7.13× | bounded approximation | 0.0132% |
| cloth-sphere | 5.2432 | 3.8395 | **1.37×** | 1.26–1.41× | exact hash | 0.0000% |
| cloth-tear | 6.0799 | 5.4415 | **1.12×** | 1.11–1.13× | exact hash | 0.0000% |
| rope-steady | 0.5804 | 0.5729 | **1.01×** | 0.99–1.04× | exact hash | 0.0000% |
| rope-rain | 5.3418 | 1.6605 | **3.22×** | 3.19–3.27× | exact hash | 0.0000% |
| water | 0.3681 | 0.3111 | **1.18×** | 1.11–1.22× | exact hash | n/a |
| rigid-grid | 2.7490 | 1.2118 | **2.27×** | 2.26–2.65× | deterministic reordered solver | n/a |
| rigid-bridge | 4.5409 | 1.5117 | **3.00×** | 2.79–3.04× | deterministic reordered solver | n/a |
| rigid-material | 2.1916 | 0.7975 | **2.75×** | 2.73–2.81× | deterministic reordered solver | n/a |

The confidence intervals are paired bootstrap intervals over fresh-process sample speed ratios. They characterize this Linux/x64 Node environment and these workloads, not every browser, CPU, or GPU.

## 100-experiment tournament

| Outcome | Count |
|---|---:|
| Accepted measured wins | 84 |
| Borderline / within noise | 1 |
| Rejected — no speed win | 11 |
| Rejected — correctness or visual fidelity | 4 |
| **Total** | **100** |

Experiment families:

| Family | Experiments |
|---|---:|
| rigid-broadphase | 24 |
| cloth-solver-schedule | 36 |
| cloth-projectile-collision | 12 |
| cloth-surface-generation | 6 |
| water-surface-generation | 6 |
| cinematic-effects | 8 |
| cloth-sphere-collision | 4 |
| rope-projectile-collision | 4 |

Every JSON experiment record includes raw samples, medians, speedup, a quality/correctness object, and the accept/reject decision. The complete index is in `benchmarks/results/V1.5_BREAKTHROUGH_100.md`; machine-readable evidence is in `v1.5-breakthrough-100.json` and `.csv`.

### Fastest search results

| # | Candidate | Speedup | Decision |
|---:|---|---:|---|
| 100 | rope-projectile-collision: AABB + squared-distance · 96 projectiles | **6.70×** | accepted |
| 14 | rigid-broadphase: insertion-y | **6.70×** | accepted |
| 11 | rigid-broadphase: native-sort-y | **5.63×** | accepted |
| 70 | cloth-projectile-collision: aabb-plus-squared · 150 projectiles | **5.29×** | accepted |
| 71 | cloth-projectile-collision: grid-1.0 · 150 projectiles | **5.22×** | accepted |
| 72 | cloth-projectile-collision: grid-2.0 · 150 projectiles | **5.21×** | accepted |
| 99 | rope-projectile-collision: AABB + squared-distance · 72 projectiles | **5.10×** | accepted |
| 98 | rope-projectile-collision: AABB + squared-distance · 48 projectiles | **3.92×** | accepted |
| 22 | rigid-broadphase: insertion-y | **3.72×** | accepted |
| 69 | cloth-projectile-collision: squared-distance · 150 projectiles | **3.61×** | accepted |
| 66 | cloth-projectile-collision: aabb-plus-squared · 80 projectiles | **3.49×** | accepted |
| 68 | cloth-projectile-collision: grid-2.0 · 80 projectiles | **3.47×** | accepted |
| 67 | cloth-projectile-collision: grid-1.0 · 80 projectiles | **3.46×** | accepted |
| 19 | rigid-broadphase: native-sort-y | **3.28×** | accepted |
| 8 | rigid-broadphase: insertion-auto-axis | **3.27×** | accepted |

The tournament numbers are search measurements. The fresh-process integrated table above is the release-level proof for the actual selected source. Rope tournament loads stay at or below the real 96-projectile solver cap; the evidence records executed, not merely requested, work.

## Integrated optimizations

### 1. Hierarchical cloth projection

Non-tearing cloth now separates packed structural, shear, and bend constraints. Structural links run every projection pass; shear and bend run at measured lower cadences with pass-count stiffness compensation. The maximum fast schedule is eight iterations and two integration substeps. Tearing scenes retain the original full constraint order and remain exact-hash equivalent in the integrated test.

For representative non-tearing cloth, the selected schedule produced relative position errors of:

- steady cloth: **0.0346%**;
- impact-storm cloth: **0.0132%**.

Both remain below the 0.2% release ceiling. The exact values, RMSE, and maximum absolute delta are in the JSON evidence.

### 2. Broad rejection for projectile coupling

Cloth and rope first reject entire projectile paths against the active particle AABB. Only surviving projectiles enter particle narrow phase, where squared distance rejects misses before a square root. This removes the previous O(projectiles × all particles) cost for distant rain/impact particles while preserving exact rope replay output.

### 3. Coherent sweep-and-prune rigid preview

The deterministic JavaScript preview backend replaces its quadratic candidate scan with a longest-axis sweep-and-prune broadphase. Typed order/bounds arrays are retained across frames and insertion-sorted, taking advantage of temporal coherence. A scalar in-place AABB resolver removes temporary vector allocations.

The collision pair order is intentionally different from v1.4, so preview hashes differ across versions. Within v1.5, repeated runs remain deterministic, finite, and preserve body/dynamic counts. The native Box3D WASM backend is not changed by this preview optimization.

### 4. Dynamic surface preparation

Intact cloth grids derive normals from central tangents in O(vertices), while torn cloth keeps triangle accumulation so holes and disconnected topology shade correctly. Packed RGBA uses a shared 32-bit write on little-endian hosts with an explicit byte fallback elsewhere. Typed-array conversion replaces repeated scalar rounding.

### 5. Allocation-free cinematic effects

Effect particles and shockwaves compact in place. Matrix/color output uses geometrically grown reusable buffers, debug-line objects are reused, and shockwave rings use trigonometric recurrence rather than repeated per-segment sine/cosine calls.

## Correctness and quality decisions

Exact v1.4 replay hashes were retained for:

- cloth-sphere
- cloth-tear
- rope-steady
- rope-rain
- water

Bounded, deterministic cloth approximation is used for:

- cloth-steady: 0.0346% relative L2 error
- cloth-rain: 0.0132% relative L2 error

The following tournament candidates were rejected specifically because output equivalence or visual quality failed:

- Experiment 78, cloth-surface-generation, forward-packed-u32: `{"deterministic":true,"finite":true,"samePhysicsHash":true}`
- Experiment 79, water-surface-generation, truncate-normals: `{"deterministic":true,"finite":true,"samePhysicsHash":true}`
- Experiment 81, water-surface-generation, truncate-plus-packed: `{"deterministic":true,"finite":true,"samePhysicsHash":true}`
- Experiment 82, water-surface-generation, color-lut: `{"deterministic":true,"finite":true,"samePhysicsHash":true}`

This is why v1.5 does not simply enable every candidate that benchmarked quickly.

## Reproduce the evidence

Compile the benchmark modules:

```bash
npm run bench:breakthrough:compile
```

Run exactly 100 experiments:

```bash
npm run bench:breakthrough:100
```

Run the quick same-process integrated comparison:

```bash
npm run bench:breakthrough:integrated
```

Run the stricter fresh-process proof:

```bash
BREAKTHROUGH_SAMPLES=5 BREAKTHROUGH_BOOTSTRAPS=5000 npm run bench:breakthrough:isolated
```

Run all validation and benchmark gates:

```bash
npm run validate:breakthrough
```

## Evidence boundary

- Timings cover CPU simulation and CPU frame construction in Node, not physical-GPU execution.
- Dawn tests validate WebGPU shaders, resources, pipelines, and command submission; they do not provide target-device frame timing.
- The native Box3D WASM solver was not recompiled by these JavaScript preview/soft-system optimizations.
- A target-browser benchmark on the intended Mac/GPU remains required before quoting browser FPS.
- TurboQuant remains disabled on the local frame path because v1.4 proved it slows local Worker transport despite reducing bytes.

## Next performance frontier

The remaining large opportunities require architecture changes rather than more scalar cleanup:

1. worker-owned soft simulation with SharedArrayBuffer double buffering;
2. WASM SIMD kernels for constraints and shallow water;
3. WebGPU compute cloth and water solvers;
4. GPU compaction and indirect drawing;
5. spatial partitioning for cloth/rigid bidirectional coupling;
6. GPU timestamp-query profiling on supported target hardware;
7. multithreaded native Box3D with cross-origin isolation.
