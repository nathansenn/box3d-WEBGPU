# Box3D WebGPU AAA v1.7.0 — Third Breakthrough Performance Report

## Executive result

This pass ran exactly **100 scene-diverse production-path experiments** against the bundled v1.6 source, followed by ten alternating-order fresh-process comparisons. The integrated changes are GPU-resident shallow-water reconstruction and WebAssembly rope instance generation. Simulation authority and numerical state remain unchanged.

### Measurement method

- Tournament samples per experiment: **5**
- Tournament iteration scale: **0.25×** of each workload’s standard loop count (recorded in the raw JSON)
- Warm-up before timing: **yes**
- Baseline/optimized order: **alternated**
- Summary statistic: **median**, with median absolute deviation
- Tournament acceptance threshold: **1.05×**, plus finite-state and output-equivalence gates
- Fresh-process samples per workload: **7**
- Paired bootstrap resamples: **10000**
- Process startup is excluded from timed regions.
- The very large water-frame ratios measure eliminated CPU frame reconstruction near the timer floor; the fresh-process 44.42× result is the preferred isolated handoff claim, not a whole-engine or GPU-frame claim.

### 100-experiment tournament

- Accepted: **80**
- Borderline changed-path results: **0**
- Unchanged-path controls: **20**
- Rejected, no speedup: **0**
- Correctness failures in integrated paths: **0**

| Category | Experiments | Geometric mean | Median | Accepted |
|---|---:|---:|---:|---:|
| water-frame | 25 | **99.29×** | 193.91× | 25 |
| water-full | 20 | **1.95×** | 2.11× | 20 |
| rope-frame | 20 | **7.71×** | 9.18× | 20 |
| rope-full | 15 | **1.26×** | 1.23× | 15 |
| cloth-full-control | 10 | **0.99×** | 1.00× | 0 |
| water-step-control | 10 | **1.01×** | 0.97× | 0 |

### Fresh-process release comparison

- Changed-path geometric mean: **2.52×**
- Dynamic/mixed geometric mean: **1.56×**

| Workload | v1.6 ms | v1.7 ms | Speedup | Paired 95% interval |
|---|---:|---:|---:|---:|
| Water maximum · render handoff | 0.096998 | 0.002184 | **44.42×** | 42.32–47.96× |
| Water wave · solver + render handoff | 0.265793 | 0.091697 | **2.90×** | 2.81–3.12× |
| Water maximum · solver + render handoff | 0.192184 | 0.067165 | **2.86×** | 2.78–2.98× |
| Rope maximum · render stream | 0.019293 | 0.007624 | **2.53×** | 2.49–2.54× |
| Rope maximum · solver + instances | 0.450340 | 0.417673 | **1.08×** | 1.07–1.09× |
| Rope mooring · zero-length-link guard | 0.217667 | 0.178464 | **1.22×** | 1.20–1.23× |
| Rope storm · 96 impacts | 0.884709 | 0.764837 | **1.16×** | 1.08–1.19× |
| Cloth maximum · unchanged control | 1.049067 | 1.046942 | **1.00×** | 0.98–1.02× |
| Water maximum · solver-only control | 0.064103 | 0.061983 | **1.03×** | 1.00–1.08× |
| Mixed maximum cloth + rope + water frame | 1.958651 | 1.723418 | **1.14×** | 1.12–1.18× |

## Architecture changes

### GPU-resident shallow-water reconstruction

v1.6 built a 24-byte packed vertex for every water cell on the CPU after each solver step. v1.7 uploads the authoritative `eta`, `u`, and `v` fields (12 bytes per cell), keeps topology static, and reconstructs position, normal, foam, and material color in the WebGPU vertex shader. This removes the CPU mesh traversal and cuts steady dynamic water traffic by 50%.

### WebAssembly rope instance generation

Rope segment basis construction, tension coloring, and matrix packing now run in the persistent soft-kernel WebAssembly arena. Payloads and projectile instances remain in TypeScript. A zero-length connector edge case discovered by the benchmark was corrected by separating raw segment length from the clamped matrix length.

## Correctness and limits

- All 100 integrated experiments retained finite state and deterministic hashes.
- Cross-version state hashes match in every fresh-process workload.
- Rope matrices/colors are checked against v1.6 with bounded relative error.
- Dawn validates the GPU-water storage-buffer pipeline, bind groups, indexed draw, HDR/MSAA pass, and upload cache.
- CPU timing and command-submission validation in this environment do not substitute for physical-GPU timestamp measurements on the target Mac.

## Reproduction

```bash
npm ci
npm run bench:third:100
npm run bench:v1.6-v1.7
npm run bench:third:gate
npm run validate:v1.7
```

Raw evidence: `benchmarks/results/v1.7-third-breakthrough-100.json` and `benchmarks/results/v1.6-v1.7-isolated.json`.
