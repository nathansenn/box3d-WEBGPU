# Performance Engineering — v1.6 WebAssembly Soft-Kernel Edition

## Executive result

Version 1.6 performs a second, independent **exactly 100-experiment** optimization search after the v1.5 breakthrough release. The pass moves the stable cloth, rope, and shallow-water hot loops into persistent-memory WebAssembly kernels and adds exact frame/upload invalidation so paused or unchanged systems do not rebuild and resend identical geometry.

The stronger release comparison uses fresh Node processes, alternates baseline/optimized order, excludes process startup from timed regions, reports median/MAD, and computes paired bootstrap intervals.

```text
Dynamic geometric-mean speedup:      1.4708×
Dynamic median speedup:              1.5317×
Unchanged-frame cache geometric mean: 330.1×
```

These ratios compare v1.5 source with v1.6 source in this Linux/x64 Node environment. They measure CPU simulation plus CPU frame construction, not target-browser physical-GPU execution.

## Exactly 100 experiments

The second tournament covers:

```text
30 cloth-kernel experiments
20 rope-kernel experiments
20 shallow-water-kernel experiments
10 compiler/optimization-mode experiments
10 cloth cadence and fidelity experiments
10 unchanged-frame memoization experiments
= 100 total
```

Recorded decisions:

| Decision | Count |
|---|---:|
| Accepted measured wins | **75** |
| Borderline / within noise | **8** |
| Rejected — no speedup | **10** |
| Rejected — correctness or fidelity | **7** |
| **Total** | **100** |

Every candidate uses repeated warmups and timed samples, median time per operation, median absolute deviation, deterministic-state checks, finiteness checks, and relative-L2 fidelity gates wherever arithmetic or solver cadence may alter output.

Raw evidence:

```text
benchmarks/results/v1.6-second-breakthrough-100.json
benchmarks/results/v1.6-second-breakthrough-100.csv
benchmarks/results/V1.6_SECOND_BREAKTHROUGH_100.md
```

Run it again:

```bash
npm run bench:second:100
npm run bench:second:gate
```

## Fresh-process v1.5 → v1.6 proof

| Complete workload | v1.5 median | v1.6 median | Speedup | Paired 95% interval |
|---|---:|---:|---:|---:|
| Cloth standard · step + surface | 1.626664 ms | 1.130046 ms | **1.44×** | 1.41–1.48× |
| Cloth maximum · step + surface | 1.658881 ms | 1.083053 ms | **1.53×** | 1.49–1.58× |
| Cloth maximum · solver only | 1.575863 ms | 0.992809 ms | **1.59×** | 1.56–1.61× |
| Rope maximum · step + instances | 0.564510 ms | 0.459731 ms | **1.23×** | 1.21–1.25× |
| Rope storm · 96 impacts | 0.996575 ms | 0.862939 ms | **1.15×** | 1.15–1.18× |
| Water wave · step + surface | 0.498752 ms | 0.272121 ms | **1.83×** | 1.81–1.86× |
| Water maximum · step + surface | 0.316556 ms | 0.193382 ms | **1.64×** | 1.59–1.67× |
| Cloth paused · unchanged frame | 0.035852 ms | 0.000110 ms | **325.26×** | 309.86–339.35× |
| Rope paused · unchanged frame | 0.019301 ms | 0.000167 ms | **115.30×** | 113.80–126.39× |
| Water paused · unchanged frame | 0.107569 ms | 0.000112 ms | **959.32×** | 870.64–1003.41× |

Method:

```text
7 fresh-process samples per workload
alternating v1.5/v1.6 execution order
10,000 paired bootstrap resamples
process startup excluded
median and median-absolute-deviation reporting
replay determinism checked in every sample
```

Evidence:

```text
benchmarks/results/v1.5-v1.6-kernel-isolated.json
benchmarks/results/V1.5_V1.6_KERNEL_ISOLATED.md
benchmarks/baselines/box3d-webgpu-v1.5.0-source.tar.gz
```

The isolated benchmark automatically extracts and compiles the bundled baseline. An external baseline can still be supplied through `V15_ROOT`.

```bash
V16_SAMPLES=7 V16_BOOTSTRAPS=10000 npm run bench:kernels:isolated
```

## Architecture

### Persistent-memory kernels

```text
TypeScript scene setup
        ↓ one-time migration
fixed 4 MiB WebAssembly memory
        ├── cloth positions / previous positions / inverse masses / constraints
        ├── rope positions / previous positions / inverse masses / constraints
        └── water eta/u/v fields and packed surface output
        ↓ repeated zero-copy kernel calls
TypeScript interactions, telemetry, and WebGPU stream publication
```

The runtime probes:

```text
1. soft-kernels-simd.wasm
2. soft-kernels-scalar.wasm
3. authoritative JavaScript fallback
```

Both WebAssembly modules are built from the same checked-in C source:

```text
wasm/soft_kernels.c
scripts/build-soft-kernels.sh
```

The scalar module preserves WebAssembly acceleration on systems without SIMD support. Failure to fetch or instantiate either module leaves the existing JavaScript solver operational.

### Conservative solver boundary

The optimized path is intentionally selective:

- **Non-tearing cloth:** WebAssembly integration and constraint projection.
- **Tearing cloth:** authoritative JavaScript path, preserving mutable topology behavior.
- **Cloth with live projectile contacts:** yields to the JavaScript interaction path for that step.
- **Rope:** WebAssembly integration and constraint projection; JavaScript retains projectile interaction and break bookkeeping.
- **Water:** WebAssembly field update and packed dynamic-surface generation.

This avoids pretending that every feature belongs in one kernel merely because a microbenchmark is faster.

## Exact dirty-frame and upload suppression

Every soft-system frame carries a monotonically changing `frameVersion`. Building a frame without any simulation or visual-state change returns the same cached frame object. The renderer separately tracks:

```text
backing ArrayBuffer identity
byte offset
frameVersion
vertex count
index topology version
```

When all relevant values are unchanged, v1.6 skips:

1. rebuilding matrices, colors, or dynamic surface vertices;
2. rebuilding immutable topology;
3. writing unchanged vertex data to the GPU queue;
4. writing unchanged index data to the GPU queue.

The 115–959× paused-frame results are therefore real elimination of redundant work, not a faster approximation of the same rebuild.

## Correctness and fidelity

The packaged runtime test validates both SIMD and scalar modules, finite state, deterministic action sequences within the new solver, cache invalidation behavior, and the tearing fallback.

Representative stable-horizon position differences relative to v1.5:

| System | Relative L2 |
|---|---:|
| SIMD cloth standard | **0.01404%** |
| SIMD maximum cloth | **0.000819%** |
| SIMD rope | **0.002249%** |
| SIMD water | **0.0000598%** |

The scalar WebAssembly module produced the same tested fidelity class. Water retained the tested replay hash. Chaotic systems can diverge over long horizons after discontinuous explosions or tearing even when each implementation is deterministic, so the release does not claim indefinite cross-version trajectory identity.

Seven aggressive cloth-cadence candidates were rejected when they failed the configured fidelity gate. Tearing remains on the original path rather than accepting a visually unstable shortcut.

## Build and test the kernels

```bash
npm run build:soft-kernels
npm run test:soft-kernels
npm run test:soft-soak
```

`test:soft-soak` runs all 150 cloth/rope/water scenes once with the JavaScript solver and once with the packaged SIMD WebAssembly solver.

Complete v1.6 gate:

```bash
npm run validate:v1.6
```

## Performance boundaries

The measured results prove CPU-path improvements in the recorded environment. They do not prove universal browser FPS, GPU duration, battery use, or driver behavior. Dawn validates shaders, resources, indexed draws, and command submission, while final hardware timing still belongs in the target browser.

The next architectural frontier is larger than another scalar cleanup pass:

```text
worker-owned simulation with SharedArrayBuffer
multithreaded WASM and native Box3D
WebGPU compute cloth and water
GPU spatial hashing and compaction
indirect drawing
GPU timestamp-query profiling
multi-surface rendering and batching
```

Those ideas require separate correctness and hardware-benchmark programs. They are not included in the v1.6 speedup claims.
