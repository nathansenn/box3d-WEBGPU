# Validation Report — v1.8.0

The exact release candidate adds GPU-resident intact-cloth reconstruction while preserving topology-aware CPU rendering for tearing. The release gate covers 100 v1.7/v1.8 production-path comparisons, ten fresh-process workloads, exact simulation hashes, reconstructed visual-stream fidelity, SIMD/scalar soft kernels, JavaScript and WASM soft-system soaks, ten WGSL modules, actual Dawn renderer execution, production builds, and source checksums.

Key measured release results:

- 68 accepted changed-path wins, nine borderline results, three no-win rejections, 20 unchanged controls, and zero correctness failures.
- 109.696× geometric mean across 35 cloth frame-handoff workloads.
- 1.154× geometric mean across 25 complete cloth workloads.
- 1.067× geometric mean across 20 cloth projectile-storm workloads.
- 1.064× dynamic/mixed geometric mean in the isolated v1.7/v1.8 comparison.
- 33.33% lower steady intact-cloth dynamic upload bytes.
- Maximum color difference remained one 8-bit step; positions, topology, and simulation hashes match exactly.

## v1.8 browser-render validation boundary

Dawn validates the GPU-cloth WGSL modules, storage-buffer layouts, checker-mask uniform, main and shadow pipelines, indexed draws, state updates, upload caching, HDR/MSAA integration, and command submission. This environment does not provide trustworthy physical-GPU timestamp measurements or target-Mac pixel inspection; those remain target-device acceptance gates.

---

# Validation Report — v1.7.0

The exact release candidate adds GPU-resident water reconstruction and WebAssembly rope frame generation. The release gate covers 100 production-path comparisons, ten fresh-process workloads, deterministic cross-version hashes, SIMD/scalar kernel runtime tests, JavaScript and WASM soft-system soaks, nine WGSL modules, the real renderer runtime under Dawn, production builds, and source checksums.

Key measured release results:

- 80 changed-path wins across 100 experiments; 20 unchanged-path controls; zero correctness failures.
- 1.947× geometric mean across 20 complete water workloads.
- 7.714× geometric mean across 20 rope frame-construction workloads.
- 2.517× changed-path geometric mean in the isolated v1.6/v1.7 comparison.
- 50% lower steady water-state upload bytes.

## Browser-render validation boundary

Dawn validates WGSL compilation, resource layouts, pipeline compatibility, storage-buffer binding, indexed draws, upload caching, and full command submission. This environment does not provide trustworthy physical-GPU timestamp measurements or a visible target-Mac capture; those remain target-device acceptance gates.

---

# Validation Report — Box3D WebGPU AAA Physics Lab v1.6.0

## Release scope

This report covers the v1.6 WebAssembly soft-kernel edition: the validated rigid/WebGPU, cloth, rope, water, KTX2, packed-surface, and optional TurboQuant foundation; the v1.5 breakthrough work; and a second exactly-100 experiment tournament with production-integrated SIMD/scalar WebAssembly kernels and exact unchanged-frame/upload suppression.

```text
750 deterministic scenes
30 cinematic hero demonstrations
150 cloth/rope/water scenes
8 WGSL shader modules in the Dawn gate
15 deterministic Node suites plus packaged SIMD/scalar kernel tests
```

## Automated release gates

| Gate | Result |
|---|---:|
| Strict TypeScript | Passed |
| Deterministic Node suites | 15 / 15 passed |
| Packaged SIMD and scalar soft-kernel modules | Passed |
| Soft-kernel fidelity, determinism, cache, and fallback tests | Passed |
| Generated scene constructors | 750 / 750 passed |
| Cloth/rope/water constructors | 150 / 150 passed |
| Hero definitions and camera/beat validation | 30 / 30 passed |
| Repository/UI/build contract self-test | Passed |
| C17 native bridge syntax (`-Wall -Wextra -Werror`) | Passed |
| Dawn WGSL compilation | 8 / 8 shader modules passed |
| Rigid, cloth, water, line, sky, shadow, and post pipelines | Passed |
| Indexed dynamic-surface upload/draw | Passed |
| Full shadow → HDR/MSAA → post frame submission | Passed |
| Actual `WebGPURenderer` runtime path | Passed |
| Unchanged dynamic-surface upload suppression | Passed |
| Dawn uncaptured validation errors | 0 |
| Production Vite build | Passed |
| GitHub Pages relative-base build | Passed |
| npm moderate-or-higher audit | 0 vulnerabilities |


## v1.6 second breakthrough validation

The release records exactly 100 new optimization experiments in `benchmarks/results/v1.6-second-breakthrough-100.json`: 75 accepted measured wins, eight borderline candidates, ten no-win rejections, and seven correctness/fidelity rejections. The search covers cloth, rope, shallow water, compiler modes, solver cadence, and exact unchanged-frame work.

The stronger v1.5 → v1.6 proof uses seven fresh-process samples per workload, alternating execution order, medians/MAD, and 10,000 paired bootstrap resamples. Process startup is excluded.

| Complete workload | v1.5 median | v1.6 median | Speedup | Paired 95% CI |
|---|---:|---:|---:|---:|
| Cloth standard · step + surface | 1.626664 ms | 1.130046 ms | **1.44×** | 1.41–1.48× |
| Cloth maximum · step + surface | 1.658881 ms | 1.083053 ms | **1.53×** | 1.49–1.58× |
| Cloth maximum · solver only | 1.575863 ms | 0.992809 ms | **1.59×** | 1.56–1.61× |
| Rope maximum · step + instances | 0.564510 ms | 0.459731 ms | **1.23×** | 1.21–1.25× |
| Rope storm · 96 impacts | 0.996575 ms | 0.862939 ms | **1.15×** | 1.15–1.18× |
| Water wave · step + surface | 0.498752 ms | 0.272121 ms | **1.83×** | 1.81–1.86× |
| Water maximum · step + surface | 0.316556 ms | 0.193382 ms | **1.64×** | 1.59–1.67× |
| Cloth paused · unchanged frame | 0.035852 ms | 0.000110 ms | **325.26×** | 309.86–339.35× |
| Rope paused · unchanged frame | 0.019301 ms | 0.000167 ms | **115.30×** | 113.80–126.39× |
| Water paused · unchanged frame | 0.107569 ms | 0.000112 ms | **959.32×** | 870.64–1003.41× |

Dynamic geometric-mean speedup is **1.4708×**, dynamic median is **1.5317×**, and unchanged-frame cache geometric mean is **330.1×**. The cache result eliminates exact redundant frame construction and GPU queue writes; it is not a reduced-quality approximation.

Both packaged modules are tested. The runtime prefers SIMD WebAssembly, falls back to scalar WebAssembly, then falls back to the JavaScript implementation if either binary is unavailable. Tearing cloth retains the JavaScript topology path. Representative stable-horizon relative-L2 differences against v1.5 remain below 0.015% in the recorded cloth/rope/water checks. Seven aggressive cadence candidates were rejected for fidelity.

See `docs/PERFORMANCE_V1.6.md`, `benchmarks/results/V1.6_SECOND_BREAKTHROUGH_100.md`, and `benchmarks/results/V1.5_V1.6_KERNEL_ISOLATED.md`.

## v1.5 breakthrough performance validation

The release executes exactly 100 candidate experiments and keeps raw samples and decisions in `benchmarks/results/v1.5-breakthrough-100.json`. In the recorded tournament, 84 candidates cleared the local speed/correctness threshold, three were borderline, nine failed to improve performance, and four were rejected for output-quality or equivalence failures.

A separate fresh-process proof launches baseline and optimized workloads in isolated Node processes, alternates version order, and reports medians, MAD, paired speed ratios, and bootstrap confidence intervals. Process startup is outside the timed region.

| Complete workload | v1.4 median | v1.5 median | Speedup | Paired 95% CI |
|---|---:|---:|---:|---:|
| Cloth steady | 3.5390 ms | 1.5576 ms | **2.27×** | 2.26–2.30× |
| Cloth impact storm (150) | 21.8939 ms | 3.2436 ms | **6.75×** | 6.25–7.13× |
| Cloth sphere | 5.2432 ms | 3.8395 ms | **1.37×** | 1.26–1.41× |
| Cloth tear | 6.0799 ms | 5.4415 ms | **1.12×** | 1.11–1.13× |
| Rope steady | 0.5804 ms | 0.5729 ms | **1.01×** | 0.99–1.04× |
| Rope impact storm (96 cap) | 5.3418 ms | 1.6605 ms | **3.22×** | 3.19–3.27× |
| Water | 0.3681 ms | 0.3111 ms | **1.18×** | 1.11–1.22× |
| Rigid grid preview | 2.7490 ms | 1.2118 ms | **2.27×** | 2.26–2.65× |
| Rigid bridge preview | 4.5409 ms | 1.5117 ms | **3.00×** | 2.79–3.04× |
| Rigid material preview | 2.1916 ms | 0.7975 ms | **2.75×** | 2.73–2.81× |

Geometric-mean speedup across the ten workloads was **2.10×**. Steady rope is treated as parity rather than a win because its confidence interval spans 1.0. Exact v1.4 hashes remain for cloth sphere/tear, rope steady/storm, and water. The fast non-tearing cloth schedule is deterministic with representative relative position errors of 0.0346% steady and 0.0132% under the impact storm. Preview rigid hashes change because sweep-and-prune changes pair order, but repeated v1.5 runs are deterministic and finite with matching body counts.

See `docs/PERFORMANCE_V1.5.md` for methodology, candidate decisions, raw-evidence paths, and limitations.

## TurboQuant transport benchmark

TurboQuant is implemented as an optional bandwidth-boundary codec and is not enabled in the authoritative solver or the same-thread WebGPU upload path. The exact benchmark used 60 real maximum-detail frames per workload, two warmups, five timed samples, and predictive structured 4-bit blocks.

| Workload | Raw/frame | Packet/frame | Reduction | Codec time/frame | Relative L2 | Modeled link break-even |
|---|---:|---:|---:|---:|---:|---:|
| Cloth | 20,400 B | 2,880 B | 7.08× | 0.4410 ms | 1.258% | 39.7 MB/s |
| Rope | 25,664 B | 3,636 B | 7.06× | 0.5270 ms | 1.126% | 41.8 MB/s |
| Water | 77,280 B | 10,872 B | 7.11× | 1.6501 ms | 1.244% | 40.2 MB/s |

A 48-frame local Worker transfer test reduced water bytes 7.11× but took 94.383 ms with TurboQuant versus 5.751 ms raw, a 0.0609× speedup (16.4× slower). Therefore the release preserves the lossless local path and exposes TurboQuant only for opt-in network, archive, replay, and remote-state use. See `docs/TURBOQUANT.md` and `benchmarks/results/TURBOQUANT_BENCHMARK.md`.

## Soft-system catalog soak

The permanent `npm run test:soft-soak` gate performs the complete representative stress sequence twice—once with the JavaScript solver and once with the packaged SIMD WebAssembly kernels—and runs paired deterministic replays for the maximum cloth, rope, and water entries.

Default gate result:

```text
150 scenes
3,600 catalog frames
1,800 paired deterministic replay frames
50 cloth scenes
50 rope scenes
50 water scenes
maximum nodes:       7,011
maximum constraints: 18,360
maximum instances:     571
maximum breaks:        129
maximum energy:        447.4376 JS / 447.4445 SIMD
```

Each frame is checked for:

- finite model matrices and material colors;
- valid instance counts and stream lengths;
- finite energy and initialized replay hashes;
- finite dynamic-surface vertices;
- exact 24-byte packed surface stride;
- complete index streams with every index in range;
- correct solver family and initialized telemetry.

## Extended stress evidence

Additional long-duration runs were executed during release preparation.

| System | Coverage | Frames | High-water marks / result |
|---|---:|---:|---|
| Cloth | 50 scenes | 6,000 | 1,700 nodes, 9,782 constraints, 357 controlled breaks; finite topology |
| Rope | 50 scenes | 9,000 | 405 nodes, 783 constraints, 474 instances, 77 breaks; finite segment stream |
| Water | 50 scenes | 12,000 | 6,785 nodes, 18,360 cells, 345 instances; bounded finite field |

Deep paired/repeated deterministic runs:

```text
cloth scene 649  · 600 frames  · final hash 1423879200
rope scene 699   · 1,200 frames · final hash 3510898898
water scene 749  · 3,600 frames · final hash 4288531700
```

Hashes are regression signatures for this code/revision and action schedule. They are not cryptographic guarantees across future implementations.

## Renderer validation

The Dawn test extracts and compiles eight WGSL modules and creates the complete render topology:

```text
rigid shadow pipeline
dynamic cloth shadow pipeline
atmospheric sky pipeline
PBR rigid solid pipeline
woven cloth pipeline
interactive water pipeline
line/effect pipeline
post-processing pipeline
```

It also creates a BGRA post-process compatibility variant, binds isolated shadow resources, uploads dynamic indexed cloth/water surfaces, and submits a complete offscreen frame.

A second test transpiles and runs the actual `WebGPURenderer` class against a Dawn-backed canvas shim. It covers:

- renderer construction and resource allocation;
- rigid instances;
- cloth indexed surface upload and draw;
- water indexed surface upload and draw;
- shadows and dynamic-surface shadows;
- debug/effect lines;
- target resize;
- empty/no-shadow frames;
- zero uncaptured WebGPU errors.

The v1.0.2 protections remain enforced:

- `textureSampleCompareLevel` avoids derivative-uniformity failure;
- atmospheric sky declares `depth24plus` compatibility;
- writable shadow depth is isolated from the later sampled bind group;
- zero-instance rigid draws are skipped.

## Production bundle

The v1.6.0 production and relative-base GitHub Pages builds completed with:

```text
dist/index.html                       24.71 kB · 6.64 kB gzip
dist/assets/index-DeebO-Kp.js        196.57 kB · 58.97 kB gzip
dist/assets/turboquant-DEooNtgG.js    9.25 kB · 3.18 kB gzip (lazy-loaded)
dist/soft-kernels-simd.wasm           6.90 kB
dist/soft-kernels-scalar.wasm         4.85 kB
```

The asset hash can change when source or toolchain output changes; the size is recorded as a release reference rather than a permanent contract.

## Solver performance observations

The v1.5 and v1.6 figures above measure complete CPU simulation plus frame-construction workloads in this Node environment. They do not include browser compositing, physical-GPU execution, or process startup. The exact 100-candidate tournament is a search tool; the fresh-process table is the stronger release comparison. Ratios are not compounded across unrelated workloads.

## Dawn harness stability observation

One combined validation attempt produced a native-process segmentation fault after both Dawn tests had printed successful assertions. The renderer/pipeline tests were then repeated **12 consecutive times** with no failure, and the complete `validate:v1.6` sequence subsequently passed. The observed crash occurred during native test-process shutdown, not during an uncaptured WebGPU error or application assertion. It remains an environment/addon stability observation rather than a source correctness claim, and target-browser validation is still required.

## Browser-render validation boundary

Dawn validates shader compilation, pipeline creation, attachment compatibility, resources, indexed draws, and command submission without requiring a visible hardware-backed browser window. A target-device browser run is still required for:

- pixel-level appearance and transparency ordering;
- browser/driver-specific behavior;
- hardware performance;
- device-loss behavior;
- high-DPI and resize behavior;
- full-screen capture quality.

Use `docs/LOCAL_BROWSER_VALIDATION.md` and the in-app **Run 750 + 30 Browser Tests** control.

## Native Box3D build boundary

The native C bridge passed strict syntax/API-contract validation. A true Emscripten link against the fetched upstream Box3D source still requires a local machine with Emscripten activated:

```bash
npm run fetch:box3d
npm run build:wasm
npm run validate
npm run dev
```

Cloth, rope, and water use independently packaged SIMD/scalar WebAssembly soft kernels when available and retain a JavaScript fallback; they do not depend on the Emscripten Box3D artifact. The native Box3D build changes rigid-body staging from the deterministic preview backend to Box3D WASM.

## Release assessment

The v1.6.0 source is suitable as a validated **engineering/demo release**: the codebase, generated catalog, soft-system numerical behavior, shader modules, pipeline resources, indexed rendering, and production bundle pass the automated gates. Native Box3D linking and a visible target-browser acceptance run remain the final machine-specific production gates.
