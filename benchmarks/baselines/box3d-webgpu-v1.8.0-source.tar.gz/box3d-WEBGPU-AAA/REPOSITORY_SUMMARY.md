# Repository Summary

## Box3D WebGPU AAA Physics Lab v1.8.0

| Area | Delivered |
|---|---|
| Rigid physics | Box3D C17 → Emscripten/WASM bridge plus deterministic preview backend |
| Cloth | PBD particles, structural/shear/bend constraints, pinning, wind, collision, tearing |
| Rope | PBD cables, bend links, anchors, payloads, tension visualization, controlled breakage |
| Water | Interactive 2.5D shallow-water heightfield, currents, foam, droplets, floaters |
| Catalog | 750 deterministic scenes across 15 families |
| Direction | 30 cinematic hero demonstrations and Maximum AAA Tour |
| Rendering | WebGPU instancing, packed cloth surfaces, GPU-resident water fields, KTX2 BC4/R8 materials, HDR, 4× MSAA, shadows, fog, post |
| Diagnostics | Rigid/soft counts, constraints/cells, breaks, energy, CPU times, uploads, hashes |
| Validation | 15 unit suites, SIMD/scalar kernel tests, dual JS/WASM 150-scene soak, ten-shader Dawn pipeline/runtime validation, strict C17 bridge test, four 100-experiment tournaments |
| Transport | Optional predictive TurboQuant codec; measured network/storage use only, disabled on local frame path |
| Deployment | Vite production build, GitHub Pages workflow, push scripts, source checksum manifest |

### New in v1.8.0

- GPU-resident intact cloth reconstruction from position and strain storage buffers.
- Dedicated cloth main and shadow pipelines with smooth grid normals, legacy checker masks, stress heat, woven shading, and indexed topology.
- 33.33% lower steady intact-cloth dynamic upload traffic.
- Tearing cloth remains on the topology-aware CPU surface path.
- Fourth 100-workload benchmark: 109.70× frame-handoff geometric mean, 1.15× complete-cloth geometric mean, 0 correctness failures.
- Five-sample isolated proof: 84–98× handoff, 1.064× dynamic/mixed geometric mean, and 1.072× mixed maximum workload.

### New in v1.7.0

- GPU-resident shallow-water reconstruction from authoritative `eta`, `u`, and `v` storage buffers.
- 50% lower steady dynamic water upload volume and upload-once topology.
- WebAssembly rope segment matrix and tension-color generation.
- Exactly 100 scene-diverse comparisons: 80 changed-path wins, 20 unchanged-path controls, zero correctness failures.
- Fresh-process v1.6/v1.7 proof: 2.517× changed-path geometric mean and 1.559× dynamic/mixed geometric mean in this environment.
- Direct Dawn validation of the ninth WGSL module, water storage bindings, cache behavior, and indexed GPU-water draw.

### New in v1.6.0

- Second exactly-100 optimization tournament with 75 accepted wins, eight borderline results, ten no-win rejections, and seven fidelity rejections.
- Persistent-memory SIMD WebAssembly kernels for stable cloth, rope, and shallow-water hot loops.
- Scalar WebAssembly and JavaScript fallback tiers.
- Exact soft-frame memoization and renderer upload suppression driven by `frameVersion`.
- Fresh-process v1.5/v1.6 proof: 1.4708× dynamic geometric mean, 1.5317× dynamic median, and 330.1× unchanged-frame cache geometric mean in this environment.
- Bundled reproducible v1.5 source baseline and packaged-kernel runtime/fidelity tests.

### New in v1.5.0

- Exactly 100 optimization experiments with raw timing, quality, replay, and decision evidence.
- Hierarchical cloth constraint scheduling with stiffness compensation and bounded representative error.
- Exact broad rejection for cloth/rope impact storms.
- Deterministic coherent sweep-and-prune in the JavaScript rigid preview backend.
- Reusable packed-surface and cinematic-effect output streams.
- Fresh-process v1.4/v1.5 proof with a 2.10× geometric-mean speedup across ten release workloads in this environment.

### New in v1.4.0

- Independent blockwise TurboQuant-MSE and structured Walsh–Hadamard codecs.
- Predictive 4-bit simulation-state transport with real cloth/rope/water evidence.
- In-browser target-device TurboQuant probe loaded as a separate lazy chunk.
- Explicit local-path rejection after the Worker benchmark measured a 16.4× regression.
- Network break-even modeling around 40–42 MB/s for the recommended workloads in this environment.
- Updated Dawn tests for packed 24-byte vertices, `uint16` indices, KTX2 material binding, and cached topology uploads.

### New in v1.1.0

- 50 cloth scenes and two cloth hero demonstrations.
- 50 rope/rigging scenes and two cable hero demonstrations.
- 50 water scenes and two fluid hero demonstrations.
- Dynamic indexed cloth/water renderer path.
- Woven cloth and translucent water WGSL materials.
- Deterministic topology failure, line breakage, waves, currents, foam, droplets, and floaters.
- Permanent long-duration soft-simulation soak and C bridge syntax gates.

### Architectural boundary

Box3D owns rigid-body simulation. The soft-simulation suite owns cloth, rope, and water; TypeScript retains scene/interaction authority while stable numerical hot loops may execute in packaged SIMD/scalar WebAssembly kernels. WebGPU receives model matrices, material colors, dynamic indexed surfaces, and debug lines from both domains. The project does not misrepresent the current water solver as a volumetric fluid engine or the current soft systems as GPU-compute solvers.
