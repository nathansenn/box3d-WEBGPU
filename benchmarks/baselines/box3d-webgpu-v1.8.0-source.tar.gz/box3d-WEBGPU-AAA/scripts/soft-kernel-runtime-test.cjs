'use strict';

const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');

const root = path.resolve(__dirname, '..');
const { SCENES } = require(path.join(root, '.test-build/src/scenes.js'));
const { SoftSimulationSuite } = require(path.join(root, '.test-build/src/soft/simulations.js'));
const { installSoftKernelModule } = require(path.join(root, '.test-build/src/soft/wasm-kernels.js'));

function loadModule(filename) {
  const bytes = fs.readFileSync(path.join(root, 'public', filename));
  const module = new WebAssembly.Module(bytes);
  const instance = new WebAssembly.Instance(module, {});
  for (const symbol of ['memory', 'cloth_substep', 'rope_integrate', 'rope_solve', 'rope_instances', 'water_step', 'water_surface']) {
    assert.ok(instance.exports[symbol], `${filename} is missing ${symbol}`);
  }
  assert.equal(instance.exports.memory.buffer.byteLength, 4 * 1024 * 1024, `${filename} must retain its fixed 4 MiB arena`);
  return module;
}

function stateOf(suite) {
  const active = suite.active;
  if (active.kind === 'water') return Float32Array.from(active.eta);
  return Float32Array.from(active.positions);
}

function relativeError(reference, candidate) {
  assert.equal(reference.length, candidate.length);
  let error2 = 0;
  let reference2 = 0;
  let maxAbsolute = 0;
  for (let i = 0; i < reference.length; i++) {
    const delta = candidate[i] - reference[i];
    error2 += delta * delta;
    reference2 += reference[i] * reference[i];
    maxAbsolute = Math.max(maxAbsolute, Math.abs(delta));
  }
  return {
    relativeL2: Math.sqrt(error2 / Math.max(reference2, 1e-30)),
    maxAbsolute,
  };
}

function make(sceneId, seed) {
  const suite = new SoftSimulationSuite();
  assert.ok(suite.createScene(SCENES[sceneId], 5, seed));
  return suite;
}

function advanceSteady(suite, frames) {
  for (let frame = 0; frame < frames; frame++) suite.step(1 / 60, 4);
}

function exerciseDeterministic(suite, sceneId, frames) {
  for (let frame = 0; frame < frames; frame++) {
    if (frame === Math.floor(frames * 0.20)) suite.kick(18);
    if (frame === Math.floor(frames * 0.42) && sceneId >= 690) suite.spawnRain(sceneId >= 740 ? 80 : 32, 14, 22);
    if (frame === Math.floor(frames * 0.70)) suite.explode([0, 5, 0], 28, 16);
    suite.step(1 / 60, 4);
  }
  const first = suite.buildFrame(false);
  const firstVersion = first.frameVersion;
  const second = suite.buildFrame(false);
  assert.equal(second, first, 'unchanged frame must reuse the same result object');
  assert.equal(second.frameVersion, firstVersion, 'unchanged frame must not advance its revision');
  suite.step(1 / 60, 4);
  const third = suite.buildFrame(false);
  assert.ok(third.frameVersion > firstVersion, 'simulation step must invalidate the frame cache');
  assert.ok(suite.validate().ok, `${SCENES[sceneId].title} failed validation`);
}

const simd = loadModule('soft-kernels-simd.wasm');
const scalar = loadModule('soft-kernels-scalar.wasm');
const cases = [
  { sceneId: 640, limit: 0.0020, label: 'cloth' },
  { sceneId: 649, limit: 0.0020, label: 'maximum cloth' },
  { sceneId: 699, limit: 0.0020, label: 'rope' },
  { sceneId: 749, limit: 0.0001, label: 'water' },
];

for (const variant of [['simd', simd], ['scalar', scalar]]) {
  for (const testCase of cases) {
    const seed = 0x160000 + testCase.sceneId;

    // Cross-version arithmetic fidelity is measured on a stable horizon.
    // Chaotic impacts are validated as deterministic within the new solver,
    // rather than pretending two floating-point implementations preserve the
    // same trajectory indefinitely after an explosion.
    installSoftKernelModule(null);
    const baseline = make(testCase.sceneId, seed);
    advanceSteady(baseline, 36);
    const reference = stateOf(baseline);

    installSoftKernelModule(variant[1], variant[0]);
    const optimizedSteady = make(testCase.sceneId, seed);
    advanceSteady(optimizedSteady, 36);
    const candidate = stateOf(optimizedSteady);
    const error = relativeError(reference, candidate);
    assert.ok(error.relativeL2 <= testCase.limit,
      `${variant[0]} ${testCase.label} relative L2 ${error.relativeL2} exceeded ${testCase.limit}`);

    const optimizedA = make(testCase.sceneId, seed);
    const optimizedB = make(testCase.sceneId, seed);
    exerciseDeterministic(optimizedA, testCase.sceneId, 72);
    exerciseDeterministic(optimizedB, testCase.sceneId, 72);
    const actionA = stateOf(optimizedA);
    const actionB = stateOf(optimizedB);
    assert.deepEqual(actionA, actionB, `${variant[0]} ${testCase.label} action sequence must be deterministic`);
    assert.ok(actionA.every(Number.isFinite), `${variant[0]} ${testCase.label} produced non-finite state`);
    console.log(`✓ ${variant[0]} ${testCase.label}: steady relative L2 ${error.relativeL2.toExponential(3)}, max |Δ| ${error.maxAbsolute.toExponential(3)}`);
  }
}

// Tearing retains the authoritative JavaScript path even when the module is available.
installSoftKernelModule(simd, 'simd');
const tearing = make(647, 0x160647);
assert.equal(tearing.active.kernel, null, 'tearing cloth must not attach the approximate non-tearing kernel');
exerciseDeterministic(tearing, 647, 48);

installSoftKernelModule(null);
console.log('✅ packaged SIMD/scalar soft kernels passed exports, zero-copy state, determinism, fidelity, frame-cache, and tearing-fallback validation');
