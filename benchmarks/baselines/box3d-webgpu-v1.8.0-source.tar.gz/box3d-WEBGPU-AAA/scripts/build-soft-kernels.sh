#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CLANG="${CLANG:-$(command -v clang || true)}"
if [[ -z "$CLANG" ]]; then
  echo "clang is required to rebuild the optional soft-kernel modules." >&2
  exit 1
fi
COMMON=(--target=wasm32 -nostdlib -Wl,--no-entry \
  -Wl,--export=cloth_substep -Wl,--export=rope_integrate \
  -Wl,--export=rope_solve -Wl,--export=rope_instances \
  -Wl,--export=water_step \
  -Wl,--export=water_surface -Wl,--export-memory \
  -Wl,--initial-memory=4194304 -Wl,--max-memory=4194304 \
  -Wl,--allow-undefined)
"$CLANG" "${COMMON[@]}" -O3 -msimd128 \
  -o "$ROOT/public/soft-kernels-simd.wasm" "$ROOT/wasm/soft_kernels.c"
"$CLANG" "${COMMON[@]}" -Os \
  -o "$ROOT/public/soft-kernels-scalar.wasm" "$ROOT/wasm/soft_kernels.c"
echo "Built soft-kernels-simd.wasm and soft-kernels-scalar.wasm"
