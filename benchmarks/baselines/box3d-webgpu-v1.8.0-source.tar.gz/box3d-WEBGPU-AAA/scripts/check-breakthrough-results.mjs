import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const tournament = JSON.parse(fs.readFileSync(path.join(root, 'benchmarks/results/v1.5-breakthrough-100.json'), 'utf8'));
const isolated = JSON.parse(fs.readFileSync(path.join(root, 'benchmarks/results/v1.4-v1.5-isolated.json'), 'utf8'));

if (tournament.experimentCount !== 100 || tournament.experiments?.length !== 100) {
  throw new Error(`breakthrough tournament must contain exactly 100 experiments; found ${tournament.experimentCount}`);
}
if (tournament.acceptedCount < 60) throw new Error(`too few measured candidates passed: ${tournament.acceptedCount}`);
if (tournament.experiments.some((entry) => !Number.isFinite(entry.speedup) || entry.speedup <= 0)) {
  throw new Error('tournament contains invalid speed ratios');
}

const minimums = {
  'cloth-steady': 1.5,
  'cloth-rain': 4.0,
  'cloth-sphere': 1.05,
  'cloth-tear': 1.02,
  'rope-steady': 0.90,
  'rope-rain': 2.0,
  water: 1.03,
  'rigid-grid': 1.5,
  'rigid-bridge': 1.5,
  'rigid-material': 1.5,
};
for (const [name, minimum] of Object.entries(minimums)) {
  const entry = isolated.results[name];
  if (!entry) throw new Error(`missing isolated workload ${name}`);
  if (!entry.optimizedDeterministic) throw new Error(`${name} optimized replay is not deterministic`);
  if (entry.ratioOfMediansSpeedup < minimum) {
    throw new Error(`${name} speedup ${entry.ratioOfMediansSpeedup.toFixed(3)}x did not clear ${minimum}x release floor`);
  }
}
for (const name of ['cloth-sphere', 'cloth-tear', 'rope-steady', 'rope-rain', 'water']) {
  if (!isolated.results[name].exactHash) throw new Error(`${name} must remain bit-replay equivalent to v1.4`);
}
for (const name of ['cloth-steady', 'cloth-rain']) {
  const error = isolated.results[name].positionError?.relativeL2;
  if (!Number.isFinite(error) || error > 0.002) throw new Error(`${name} position error ${error} exceeds 0.2% release ceiling`);
}
if (isolated.results['cloth-rain'].baselineSpawnedRain !== 150 || isolated.results['cloth-rain'].optimizedSpawnedRain !== 150) {
  throw new Error('cloth-rain evidence must execute the declared 150-projectile workload');
}
if (isolated.results['rope-rain'].baselineSpawnedRain !== 96 || isolated.results['rope-rain'].optimizedSpawnedRain !== 96) {
  throw new Error('rope-rain evidence must execute the real 96-projectile solver cap');
}
const ropeExperiments = tournament.experiments.filter((entry) => entry.category === 'rope-projectile-collision');
if (ropeExperiments.some((entry) => (entry.parameters?.projectileCount ?? 0) > 96)) {
  throw new Error('rope tournament may not label requested work above the 96-projectile execution cap');
}
if (isolated.aggregate.geometricMeanSpeedup < 1.5) {
  throw new Error(`aggregate geometric-mean speedup ${isolated.aggregate.geometricMeanSpeedup.toFixed(3)}x is below 1.5x`);
}
console.log(`✅ breakthrough evidence gate passed: ${tournament.experimentCount} experiments, ${tournament.acceptedCount} accepted, ${isolated.aggregate.geometricMeanSpeedup.toFixed(2)}x geometric-mean integrated speedup`);
