#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

if [[ ! -f SOURCE_MANIFEST.sha256 ]]; then
  echo "SOURCE_MANIFEST.sha256 is missing" >&2
  exit 1
fi

if command -v sha256sum >/dev/null 2>&1; then
  sha256sum --check SOURCE_MANIFEST.sha256
elif command -v shasum >/dev/null 2>&1; then
  shasum -a 256 --check SOURCE_MANIFEST.sha256
else
  echo "Neither sha256sum nor shasum is available." >&2
  exit 1
fi
