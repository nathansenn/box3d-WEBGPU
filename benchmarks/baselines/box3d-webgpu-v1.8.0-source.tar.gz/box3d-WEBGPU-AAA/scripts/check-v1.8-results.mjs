import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = (name) => JSON.parse(fs.readFileSync(path.join(root, name), 'utf8'));
const tournament = read('benchmarks/results/v1.8-fourth-breakthrough-100.json');
assert.equal(tournament.summary.experimentCount, 100, 'v1.8 tournament must contain exactly 100 experiments');
assert.equal(tournament.experiments.length, 100, 'v1.8 experiment array must contain exactly 100 records');
assert.equal(tournament.summary['rejected-correctnessCount'], 0, 'no integrated v1.8 path may fail correctness');
assert.equal(tournament.summary.controlCount, 20, 'the tournament must retain exactly 20 unchanged-path controls');
assert.ok(tournament.summary.acceptedCount >= 60, `expected at least 60 accepted changed-path wins, received ${tournament.summary.acceptedCount}`);
assert.equal(
  tournament.summary.acceptedCount + tournament.summary.borderlineCount + tournament.summary.controlCount +
    tournament.summary['rejected-no-winCount'] + tournament.summary['rejected-correctnessCount'],
  100,
  'all 100 outcomes must be classified exactly once',
);
assert.ok(tournament.experiments.every((entry) => entry.correctness.passed), 'all integrated production-path experiments must pass correctness');
const categories = tournament.summary.categories;
assert.equal(categories['cloth-frame'].count, 35);
assert.equal(categories['cloth-full'].count, 25);
assert.equal(categories['cloth-storm'].count, 20);
assert.equal(categories['cloth-tearing-control'].count, 7);
assert.equal(categories['water-full-control'].count, 7);
assert.equal(categories['rope-full-control'].count, 6);
assert.ok(categories['cloth-frame'].geometricMeanSpeedup >= 50, 'GPU-resident cloth handoff must clear 50× geometric mean');
assert.ok(categories['cloth-full'].geometricMeanSpeedup >= 1.10, 'complete cloth frames must clear 1.10× geometric mean');
assert.ok(categories['cloth-storm'].geometricMeanSpeedup >= 1.02, 'cloth impact storms must retain a measurable aggregate win');
for (const entry of tournament.experiments.filter((item) => item.category.startsWith('cloth-') && !item.category.endsWith('-control'))) {
  assert.equal(entry.correctness.crossVersionHashMatch, true, `${entry.id} simulation hash changed`);
  assert.ok(entry.correctness.visualNormalRelativeL2 <= 2.5e-4, `${entry.id} normal fidelity drifted`);
  assert.ok(entry.correctness.visualColorRms <= 0.0045, `${entry.id} color RMS drifted`);
  assert.ok(entry.correctness.visualColorMax <= 0.006, `${entry.id} maximum color error drifted`);
  assert.ok(entry.correctness.visualUvMax <= 2e-5, `${entry.id} UV fidelity drifted`);
  assert.ok(entry.payload.byteReduction >= 1 / 3 - 1e-12, `${entry.id} must retain at least one-third dynamic-byte reduction`);
}

const isolated = read('benchmarks/results/v1.7-v1.8-isolated.json');
assert.equal(isolated.results.length, 10, 'fresh-process comparison must contain ten release workloads');
assert.ok(isolated.summary.changedGeometricMeanSpeedup >= 2.5, 'changed-path fresh-process geometric mean must clear 2.5×');
assert.ok(isolated.summary.dynamicGeometricMeanSpeedup >= 1.03, 'dynamic/mixed fresh-process geometric mean must clear 1.03×');
assert.ok(isolated.results.every((entry) => entry.baselineDeterministic && entry.optimizedDeterministic), 'fresh-process workloads must be deterministic');
assert.ok(isolated.results.every((entry) => entry.crossVersionHashMatch), 'GPU-cloth handoff must preserve cross-version simulation hashes');
const byId = Object.fromEntries(isolated.results.map((entry) => [entry.id, entry]));
assert.ok(byId['cloth-standard-frame'].speedup >= 40, 'standard cloth handoff must clear 40×');
assert.ok(byId['cloth-maximum-frame'].speedup >= 40, 'maximum cloth handoff must clear 40×');
assert.ok(byId['cloth-sphere-full'].speedup >= 1.05, 'collider drape full workload must clear 1.05×');
assert.ok(byId['cloth-storm-full'].speedup >= 1.03, 'maximum cloth storm must clear 1.03×');
assert.ok(byId['mixed-maximum'].speedup >= 1.04, 'mixed maximum workload must clear 1.04×');
for (const id of ['cloth-standard-frame', 'cloth-maximum-frame', 'cloth-standard-full', 'cloth-maximum-full', 'cloth-sphere-full', 'cloth-storm-full', 'cloth-banner-storm', 'mixed-maximum']) {
  assert.ok(byId[id].payload.byteReduction >= 1 / 3 - 1e-12, `${id} must retain one-third dynamic-byte reduction`);
}
console.log(`✅ v1.8 evidence gate passed: 100 experiments, ${tournament.summary.acceptedCount} accepted, ${categories['cloth-frame'].geometricMeanSpeedup.toFixed(2)}× cloth-frame geometric mean, ${categories['cloth-full'].geometricMeanSpeedup.toFixed(2)}× cloth-full geometric mean, ${isolated.summary.dynamicGeometricMeanSpeedup.toFixed(2)}× isolated dynamic/mixed geometric mean`);
