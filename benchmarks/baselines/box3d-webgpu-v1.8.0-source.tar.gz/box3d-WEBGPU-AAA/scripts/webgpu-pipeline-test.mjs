import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { create, globals } from 'webgpu';

Object.assign(globalThis, globals);

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const rendererSource = fs.readFileSync(path.join(root, 'src/webgpu/renderer.ts'), 'utf8');
const shaderPattern = /const\s+(\w+)\s*=\s*\/\*\s*wgsl\s*\*\/\s*`([\s\S]*?)`;/g;
const shaderSources = new Map([...rendererSource.matchAll(shaderPattern)].map((match) => [match[1], match[2]]));
const uniformStruct = shaderSources.get('sceneUniformStruct');
const packedSurfaceDecode = shaderSources.get('packedSurfaceDecode');
assert.ok(uniformStruct, 'renderer must contain sceneUniformStruct WGSL');
assert.ok(packedSurfaceDecode, 'renderer must contain packedSurfaceDecode WGSL');

function shader(name) {
  const source = shaderSources.get(name);
  assert.ok(source, `renderer must contain ${name} WGSL`);
  return source
    .replaceAll('${sceneUniformStruct}', uniformStruct)
    .replaceAll('${packedSurfaceDecode}', packedSurfaceDecode);
}

let gpu = create(['backend=null']);
const adapter = await gpu.requestAdapter();
assert.ok(adapter, 'Dawn null backend must return an adapter');
const device = await adapter.requestDevice();
const uncapturedErrors = [];
device.addEventListener?.('uncapturederror', (event) => {
  uncapturedErrors.push(event.error?.message ?? String(event.error));
});

async function checked(label, operation) {
  device.pushErrorScope('validation');
  let value;
  let thrown;
  try {
    value = await operation();
  } catch (error) {
    thrown = error;
  }
  const scopedError = await device.popErrorScope();
  assert.equal(thrown, undefined, `${label} threw: ${thrown?.message ?? thrown ?? ''}`);
  assert.equal(scopedError, null, `${label} validation error: ${scopedError?.message ?? ''}`);
  return value;
}

const shaderNames = [
  'shadowShader',
  'surfaceShadowShader',
  'skyShader',
  'solidShader',
  'clothShader',
  'clothGridShader',
  'waterShader',
  'waterGridShader',
  'lineShader',
  'postShader',
];
const modules = {};
for (const name of shaderNames) {
  const module = device.createShaderModule({ label: name, code: shader(name) });
  const info = await module.getCompilationInfo();
  const errors = info.messages.filter((message) => message.type === 'error');
  const warnings = info.messages.filter((message) => message.type === 'warning');
  assert.deepEqual(
    errors.map((message) => `${message.lineNum}:${message.linePos} ${message.message}`),
    [],
    `${name} must compile without WGSL errors`,
  );
  assert.deepEqual(
    warnings.map((message) => `${message.lineNum}:${message.linePos} ${message.message}`),
    [],
    `${name} must compile without WGSL warnings`,
  );
  modules[name] = module;
}

const shadowBindGroupLayout = device.createBindGroupLayout({
  label: 'AAA shadow uniform layout test',
  entries: [{ binding: 0, visibility: GPUShaderStage.VERTEX, buffer: { type: 'uniform' } }],
});
const shadowLayout = device.createPipelineLayout({ bindGroupLayouts: [shadowBindGroupLayout] });
const sceneBindGroupLayout = device.createBindGroupLayout({
  label: 'AAA scene layout test',
  entries: [
    { binding: 0, visibility: GPUShaderStage.VERTEX | GPUShaderStage.FRAGMENT, buffer: { type: 'uniform' } },
    { binding: 1, visibility: GPUShaderStage.FRAGMENT, texture: { sampleType: 'depth', viewDimension: '2d' } },
    { binding: 2, visibility: GPUShaderStage.FRAGMENT, sampler: { type: 'comparison' } },
    { binding: 3, visibility: GPUShaderStage.FRAGMENT, texture: { sampleType: 'float', viewDimension: '2d' } },
    { binding: 4, visibility: GPUShaderStage.FRAGMENT, sampler: { type: 'filtering' } },
  ],
});
const sceneLayout = device.createPipelineLayout({ bindGroupLayouts: [sceneBindGroupLayout] });
const clothGridBindGroupLayout = device.createBindGroupLayout({
  label: 'AAA GPU cloth grid layout test',
  entries: [
    { binding: 0, visibility: GPUShaderStage.VERTEX, buffer: { type: 'uniform' } },
    { binding: 1, visibility: GPUShaderStage.VERTEX, buffer: { type: 'read-only-storage' } },
    { binding: 2, visibility: GPUShaderStage.VERTEX, buffer: { type: 'read-only-storage' } },
  ],
});
const clothGridLayout = device.createPipelineLayout({ bindGroupLayouts: [sceneBindGroupLayout, clothGridBindGroupLayout] });
const clothGridShadowLayout = device.createPipelineLayout({ bindGroupLayouts: [shadowBindGroupLayout, clothGridBindGroupLayout] });
const waterGridBindGroupLayout = device.createBindGroupLayout({
  label: 'AAA GPU water grid layout test',
  entries: [
    { binding: 0, visibility: GPUShaderStage.VERTEX, buffer: { type: 'uniform' } },
    { binding: 1, visibility: GPUShaderStage.VERTEX, buffer: { type: 'read-only-storage' } },
    { binding: 2, visibility: GPUShaderStage.VERTEX, buffer: { type: 'read-only-storage' } },
    { binding: 3, visibility: GPUShaderStage.VERTEX, buffer: { type: 'read-only-storage' } },
  ],
});
const waterGridLayout = device.createPipelineLayout({ bindGroupLayouts: [sceneBindGroupLayout, waterGridBindGroupLayout] });
const postBindGroupLayout = device.createBindGroupLayout({
  label: 'AAA post layout test',
  entries: [
    { binding: 0, visibility: GPUShaderStage.FRAGMENT, texture: { sampleType: 'float', viewDimension: '2d' } },
    { binding: 1, visibility: GPUShaderStage.FRAGMENT, sampler: { type: 'filtering' } },
    { binding: 2, visibility: GPUShaderStage.VERTEX | GPUShaderStage.FRAGMENT, buffer: { type: 'uniform' } },
  ],
});
const postLayout = device.createPipelineLayout({ bindGroupLayouts: [postBindGroupLayout] });

const instanceVertexBuffers = [
  {
    arrayStride: 6 * 4,
    stepMode: 'vertex',
    attributes: [
      { shaderLocation: 0, offset: 0, format: 'float32x3' },
      { shaderLocation: 1, offset: 3 * 4, format: 'float32x3' },
    ],
  },
  {
    arrayStride: 16 * 4,
    stepMode: 'instance',
    attributes: [
      { shaderLocation: 2, offset: 0, format: 'float32x4' },
      { shaderLocation: 3, offset: 4 * 4, format: 'float32x4' },
      { shaderLocation: 4, offset: 8 * 4, format: 'float32x4' },
      { shaderLocation: 5, offset: 12 * 4, format: 'float32x4' },
    ],
  },
  {
    arrayStride: 4 * 4,
    stepMode: 'instance',
    attributes: [{ shaderLocation: 6, offset: 0, format: 'float32x4' }],
  },
];
const surfaceVertexBuffers = [{
  arrayStride: 24,
  stepMode: 'vertex',
  attributes: [
    { shaderLocation: 0, offset: 0, format: 'float32x3' },
    { shaderLocation: 1, offset: 12, format: 'snorm16x2' },
    { shaderLocation: 2, offset: 16, format: 'unorm8x4' },
    { shaderLocation: 3, offset: 20, format: 'unorm16x2' },
  ],
}];

const shadowPipeline = await checked('shadow render pipeline', () => device.createRenderPipelineAsync({
  label: 'AAA shadow map pipeline test',
  layout: shadowLayout,
  vertex: { module: modules.shadowShader, entryPoint: 'vsMain', buffers: instanceVertexBuffers },
  primitive: { topology: 'triangle-list', cullMode: 'front' },
  depthStencil: { format: 'depth32float', depthWriteEnabled: true, depthCompare: 'less' },
}));
const surfaceShadowPipeline = await checked('cloth surface shadow pipeline', () => device.createRenderPipelineAsync({
  label: 'AAA surface shadow pipeline test',
  layout: shadowLayout,
  vertex: { module: modules.surfaceShadowShader, entryPoint: 'vsMain', buffers: surfaceVertexBuffers },
  primitive: { topology: 'triangle-list', cullMode: 'none' },
  depthStencil: { format: 'depth32float', depthWriteEnabled: true, depthCompare: 'less' },
}));
const skyPipeline = await checked('sky render pipeline', () => device.createRenderPipelineAsync({
  label: 'AAA atmospheric sky pipeline test',
  layout: sceneLayout,
  vertex: { module: modules.skyShader, entryPoint: 'vsMain' },
  fragment: { module: modules.skyShader, entryPoint: 'fsMain', targets: [{ format: 'rgba16float' }] },
  primitive: { topology: 'triangle-list' },
  depthStencil: { format: 'depth24plus', depthWriteEnabled: false, depthCompare: 'always' },
  multisample: { count: 4 },
}));
const solidPipeline = await checked('PBR solid render pipeline', () => device.createRenderPipelineAsync({
  label: 'AAA solid pipeline test',
  layout: sceneLayout,
  vertex: { module: modules.solidShader, entryPoint: 'vsMain', buffers: instanceVertexBuffers },
  fragment: { module: modules.solidShader, entryPoint: 'fsMain', targets: [{ format: 'rgba16float' }] },
  primitive: { topology: 'triangle-list', cullMode: 'back' },
  depthStencil: { format: 'depth24plus', depthWriteEnabled: true, depthCompare: 'less' },
  multisample: { count: 4 },
}));
const clothPipeline = await checked('dynamic cloth render pipeline', () => device.createRenderPipelineAsync({
  label: 'AAA cloth pipeline test',
  layout: sceneLayout,
  vertex: { module: modules.clothShader, entryPoint: 'vsMain', buffers: surfaceVertexBuffers },
  fragment: { module: modules.clothShader, entryPoint: 'fsMain', targets: [{ format: 'rgba16float' }] },
  primitive: { topology: 'triangle-list', cullMode: 'none' },
  depthStencil: { format: 'depth24plus', depthWriteEnabled: true, depthCompare: 'less-equal' },
  multisample: { count: 4 },
}));
const clothGridShadowPipeline = await checked('GPU-resident cloth shadow pipeline', () => device.createRenderPipelineAsync({
  label: 'AAA GPU-resident cloth shadow pipeline test',
  layout: clothGridShadowLayout,
  vertex: { module: modules.clothGridShader, entryPoint: 'vsShadow' },
  primitive: { topology: 'triangle-list', cullMode: 'none' },
  depthStencil: { format: 'depth32float', depthWriteEnabled: true, depthCompare: 'less' },
}));
const clothGridPipeline = await checked('GPU-resident cloth render pipeline', () => device.createRenderPipelineAsync({
  label: 'AAA GPU-resident cloth pipeline test',
  layout: clothGridLayout,
  vertex: { module: modules.clothGridShader, entryPoint: 'vsMain' },
  fragment: { module: modules.clothGridShader, entryPoint: 'fsMain', targets: [{ format: 'rgba16float' }] },
  primitive: { topology: 'triangle-list', cullMode: 'none' },
  depthStencil: { format: 'depth24plus', depthWriteEnabled: true, depthCompare: 'less-equal' },
  multisample: { count: 4 },
}));
const waterPipeline = await checked('interactive water render pipeline', () => device.createRenderPipelineAsync({
  label: 'AAA water pipeline test',
  layout: sceneLayout,
  vertex: { module: modules.waterShader, entryPoint: 'vsMain', buffers: surfaceVertexBuffers },
  fragment: {
    module: modules.waterShader,
    entryPoint: 'fsMain',
    targets: [{
      format: 'rgba16float',
      blend: {
        color: { srcFactor: 'src-alpha', dstFactor: 'one-minus-src-alpha', operation: 'add' },
        alpha: { srcFactor: 'one', dstFactor: 'one-minus-src-alpha', operation: 'add' },
      },
    }],
  },
  primitive: { topology: 'triangle-list', cullMode: 'none' },
  depthStencil: { format: 'depth24plus', depthWriteEnabled: false, depthCompare: 'less-equal' },
  multisample: { count: 4 },
}));
const waterGridPipeline = await checked('GPU-resident water render pipeline', () => device.createRenderPipelineAsync({
  label: 'AAA GPU-resident water pipeline test',
  layout: waterGridLayout,
  vertex: { module: modules.waterGridShader, entryPoint: 'vsMain' },
  fragment: {
    module: modules.waterGridShader,
    entryPoint: 'fsMain',
    targets: [{
      format: 'rgba16float',
      blend: {
        color: { srcFactor: 'src-alpha', dstFactor: 'one-minus-src-alpha', operation: 'add' },
        alpha: { srcFactor: 'one', dstFactor: 'one-minus-src-alpha', operation: 'add' },
      },
    }],
  },
  primitive: { topology: 'triangle-list', cullMode: 'none' },
  depthStencil: { format: 'depth24plus', depthWriteEnabled: false, depthCompare: 'less-equal' },
  multisample: { count: 4 },
}));
const linePipeline = await checked('line/effect render pipeline', () => device.createRenderPipelineAsync({
  label: 'AAA line pipeline test',
  layout: sceneLayout,
  vertex: {
    module: modules.lineShader,
    entryPoint: 'vsMain',
    buffers: [{
      arrayStride: 7 * 4,
      stepMode: 'vertex',
      attributes: [
        { shaderLocation: 0, offset: 0, format: 'float32x3' },
        { shaderLocation: 1, offset: 3 * 4, format: 'float32x4' },
      ],
    }],
  },
  fragment: {
    module: modules.lineShader,
    entryPoint: 'fsMain',
    targets: [{
      format: 'rgba16float',
      blend: {
        color: { srcFactor: 'src-alpha', dstFactor: 'one', operation: 'add' },
        alpha: { srcFactor: 'one', dstFactor: 'one-minus-src-alpha', operation: 'add' },
      },
    }],
  },
  primitive: { topology: 'line-list' },
  depthStencil: { format: 'depth24plus', depthWriteEnabled: false, depthCompare: 'less-equal' },
  multisample: { count: 4 },
}));
const postPipeline = await checked('post-process render pipeline', () => device.createRenderPipelineAsync({
  label: 'AAA post pipeline test',
  layout: postLayout,
  vertex: { module: modules.postShader, entryPoint: 'vsMain' },
  fragment: { module: modules.postShader, entryPoint: 'fsMain', targets: [{ format: 'rgba8unorm' }] },
  primitive: { topology: 'triangle-list' },
}));
await checked('BGRA post-process pipeline compatibility', () => device.createRenderPipelineAsync({
  label: 'AAA BGRA post pipeline test',
  layout: postLayout,
  vertex: { module: modules.postShader, entryPoint: 'vsMain' },
  fragment: { module: modules.postShader, entryPoint: 'fsMain', targets: [{ format: 'bgra8unorm' }] },
  primitive: { topology: 'triangle-list' },
}));

const uniformBuffer = device.createBuffer({ size: 48 * 4, usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST });
const vertexBuffer = device.createBuffer({ size: 36 * 6 * 4, usage: GPUBufferUsage.VERTEX | GPUBufferUsage.COPY_DST });
const matrixBuffer = device.createBuffer({ size: 16 * 4, usage: GPUBufferUsage.VERTEX | GPUBufferUsage.COPY_DST });
const colorBuffer = device.createBuffer({ size: 4 * 4, usage: GPUBufferUsage.VERTEX | GPUBufferUsage.COPY_DST });
const lineBuffer = device.createBuffer({ size: 2 * 7 * 4, usage: GPUBufferUsage.VERTEX | GPUBufferUsage.COPY_DST });
const surfaceVertexBuffer = device.createBuffer({ size: 4 * 24, usage: GPUBufferUsage.VERTEX | GPUBufferUsage.COPY_DST });
const surfaceIndexBuffer = device.createBuffer({ size: 6 * 2, usage: GPUBufferUsage.INDEX | GPUBufferUsage.COPY_DST });
const clothGridUniformBuffer = device.createBuffer({ size: 64, usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST });
const clothGridPositionBuffer = device.createBuffer({ size: 4 * 3 * 4, usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_DST });
const clothGridStrainBuffer = device.createBuffer({ size: 4 * 4, usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_DST });
const clothGridIndexBuffer = device.createBuffer({ size: 6 * 2, usage: GPUBufferUsage.INDEX | GPUBufferUsage.COPY_DST });
const waterGridUniformBuffer = device.createBuffer({ size: 32, usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST });
const waterEtaBuffer = device.createBuffer({ size: 16 * 4, usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_DST });
const waterUBuffer = device.createBuffer({ size: 16 * 4, usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_DST });
const waterVBuffer = device.createBuffer({ size: 16 * 4, usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_DST });
const waterGridIndexBuffer = device.createBuffer({ size: 54 * 2, usage: GPUBufferUsage.INDEX | GPUBufferUsage.COPY_DST });

device.queue.writeBuffer(matrixBuffer, 0, new Float32Array([1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]));
device.queue.writeBuffer(colorBuffer, 0, new Float32Array([0.8, 0.4, 0.2, 1]));
device.queue.writeBuffer(uniformBuffer, 0, new Float32Array(48));
device.queue.writeBuffer(lineBuffer, 0, new Float32Array(14));
const packedSurface = new Uint8Array(4 * 24);
const packedView = new DataView(packedSurface.buffer);
const packedPositions = [[-1, 2, -1], [1, 2, -1], [-1, 2, 1], [1, 2, 1]];
for (let i = 0; i < packedPositions.length; i++) {
  const offset = i * 24;
  packedView.setFloat32(offset, packedPositions[i][0], true);
  packedView.setFloat32(offset + 4, packedPositions[i][1], true);
  packedView.setFloat32(offset + 8, packedPositions[i][2], true);
  packedView.setInt16(offset + 12, 0, true);
  packedView.setInt16(offset + 14, 0, true);
  packedView.setUint8(offset + 16, 30 + i * 20);
  packedView.setUint8(offset + 17, 120 + i * 15);
  packedView.setUint8(offset + 18, 220);
  packedView.setUint8(offset + 19, 64 + i * 40);
  packedView.setUint16(offset + 20, (i & 1) ? 65535 : 0, true);
  packedView.setUint16(offset + 22, (i > 1) ? 65535 : 0, true);
}
device.queue.writeBuffer(surfaceVertexBuffer, 0, packedSurface);
device.queue.writeBuffer(surfaceIndexBuffer, 0, new Uint16Array([0, 2, 1, 1, 2, 3]));
const clothUniformBytes = new ArrayBuffer(64);
const clothUniformView = new DataView(clothUniformBytes);
clothUniformView.setUint32(0, 2, true);
clothUniformView.setUint32(4, 2, true);
clothUniformView.setUint32(8, 0, true);
for (let i = 0; i < 4; i++) clothUniformView.setFloat32(16 + i * 4, [0.08, 0.24, 0.62, 1][i], true);
for (let i = 0; i < 4; i++) clothUniformView.setFloat32(32 + i * 4, [0.84, 0.88, 0.96, 1][i], true);
clothUniformView.setUint32(48, 0, true);
clothUniformView.setUint32(52, 0, true);
clothUniformView.setUint32(56, 0, true);
clothUniformView.setUint32(60, 0, true);
device.queue.writeBuffer(clothGridUniformBuffer, 0, clothUniformBytes);
device.queue.writeBuffer(clothGridPositionBuffer, 0, new Float32Array(packedPositions.flat()));
device.queue.writeBuffer(clothGridStrainBuffer, 0, new Float32Array([0, 0.04, 0.08, 0.12]));
device.queue.writeBuffer(clothGridIndexBuffer, 0, new Uint16Array([0, 2, 1, 1, 2, 3]));
const gridUniformBytes = new ArrayBuffer(32);
const gridUniformView = new DataView(gridUniformBytes);
gridUniformView.setUint32(0, 4, true);
gridUniformView.setUint32(4, 4, true);
gridUniformView.setFloat32(8, 6, true);
gridUniformView.setFloat32(12, 6, true);
gridUniformView.setFloat32(16, 1.25, true);
gridUniformView.setFloat32(20, 0.25, true);
gridUniformView.setFloat32(24, 0.25, true);
device.queue.writeBuffer(waterGridUniformBuffer, 0, gridUniformBytes);
device.queue.writeBuffer(waterEtaBuffer, 0, new Float32Array([0, 0.08, -0.03, 0.02, 0.12, -0.05, 0.03, 0, -0.02, 0.04, 0.09, -0.01, 0, -0.03, 0.02, 0.06]));
device.queue.writeBuffer(waterUBuffer, 0, new Float32Array(16));
device.queue.writeBuffer(waterVBuffer, 0, new Float32Array(16));
const gridIndices = [];
for (let z = 0; z < 3; z++) for (let x = 0; x < 3; x++) {
  const i = z * 4 + x;
  gridIndices.push(i, i + 4, i + 1, i + 1, i + 4, i + 5);
}
device.queue.writeBuffer(waterGridIndexBuffer, 0, new Uint16Array(gridIndices));

const shadowTexture = device.createTexture({
  size: [64, 64],
  format: 'depth32float',
  usage: GPUTextureUsage.RENDER_ATTACHMENT | GPUTextureUsage.TEXTURE_BINDING,
});
const shadowView = shadowTexture.createView();
const shadowSampler = device.createSampler({
  compare: 'less',
  magFilter: 'linear',
  minFilter: 'linear',
  addressModeU: 'clamp-to-edge',
  addressModeV: 'clamp-to-edge',
});
const linearSampler = device.createSampler({
  magFilter: 'linear',
  minFilter: 'linear',
  addressModeU: 'clamp-to-edge',
  addressModeV: 'clamp-to-edge',
});
const materialTexture = device.createTexture({
  size: [4, 4],
  format: 'r8unorm',
  usage: GPUTextureUsage.TEXTURE_BINDING | GPUTextureUsage.COPY_DST,
});
device.queue.writeTexture(
  { texture: materialTexture },
  new Uint8Array([0, 32, 64, 96, 32, 64, 96, 128, 64, 96, 128, 160, 96, 128, 160, 192]),
  { bytesPerRow: 4, rowsPerImage: 4 },
  [4, 4, 1],
);
const materialSampler = device.createSampler({ magFilter: 'linear', minFilter: 'linear' });
const shadowBindGroup = device.createBindGroup({
  layout: shadowBindGroupLayout,
  entries: [{ binding: 0, resource: { buffer: uniformBuffer } }],
});
const sceneBindGroup = device.createBindGroup({
  layout: sceneBindGroupLayout,
  entries: [
    { binding: 0, resource: { buffer: uniformBuffer } },
    { binding: 1, resource: shadowView },
    { binding: 2, resource: shadowSampler },
    { binding: 3, resource: materialTexture.createView() },
    { binding: 4, resource: materialSampler },
  ],
});
const clothGridBindGroup = device.createBindGroup({
  layout: clothGridBindGroupLayout,
  entries: [
    { binding: 0, resource: { buffer: clothGridUniformBuffer } },
    { binding: 1, resource: { buffer: clothGridPositionBuffer } },
    { binding: 2, resource: { buffer: clothGridStrainBuffer } },
  ],
});
const waterGridBindGroup = device.createBindGroup({
  layout: waterGridBindGroupLayout,
  entries: [
    { binding: 0, resource: { buffer: waterGridUniformBuffer } },
    { binding: 1, resource: { buffer: waterEtaBuffer } },
    { binding: 2, resource: { buffer: waterUBuffer } },
    { binding: 3, resource: { buffer: waterVBuffer } },
  ],
});
const hdrTexture = device.createTexture({
  size: [64, 64],
  format: 'rgba16float',
  usage: GPUTextureUsage.RENDER_ATTACHMENT | GPUTextureUsage.TEXTURE_BINDING,
});
const msaaTexture = device.createTexture({
  size: [64, 64],
  sampleCount: 4,
  format: 'rgba16float',
  usage: GPUTextureUsage.RENDER_ATTACHMENT,
});
const depthTexture = device.createTexture({
  size: [64, 64],
  sampleCount: 4,
  format: 'depth24plus',
  usage: GPUTextureUsage.RENDER_ATTACHMENT,
});
const outputTexture = device.createTexture({
  size: [64, 64],
  format: 'rgba8unorm',
  usage: GPUTextureUsage.RENDER_ATTACHMENT | GPUTextureUsage.COPY_SRC,
});
const postBindGroup = device.createBindGroup({
  layout: postBindGroupLayout,
  entries: [
    { binding: 0, resource: hdrTexture.createView() },
    { binding: 1, resource: linearSampler },
    { binding: 2, resource: { buffer: uniformBuffer } },
  ],
});

await checked('complete offscreen rigid + cloth + water frame', async () => {
  const encoder = device.createCommandEncoder({ label: 'AAA complete hybrid frame test' });
  const shadowPass = encoder.beginRenderPass({
    colorAttachments: [],
    depthStencilAttachment: {
      view: shadowView,
      depthClearValue: 1,
      depthLoadOp: 'clear',
      depthStoreOp: 'store',
    },
  });
  shadowPass.setBindGroup(0, shadowBindGroup);
  shadowPass.setPipeline(shadowPipeline);
  shadowPass.setVertexBuffer(0, vertexBuffer);
  shadowPass.setVertexBuffer(1, matrixBuffer);
  shadowPass.setVertexBuffer(2, colorBuffer);
  shadowPass.draw(36, 1);
  shadowPass.setPipeline(surfaceShadowPipeline);
  shadowPass.setVertexBuffer(0, surfaceVertexBuffer);
  shadowPass.setIndexBuffer(surfaceIndexBuffer, 'uint16');
  shadowPass.drawIndexed(6, 1);
  shadowPass.setPipeline(clothGridShadowPipeline);
  shadowPass.setBindGroup(1, clothGridBindGroup);
  shadowPass.setIndexBuffer(clothGridIndexBuffer, 'uint16');
  shadowPass.drawIndexed(6, 1);
  shadowPass.end();

  const mainPass = encoder.beginRenderPass({
    colorAttachments: [{
      view: msaaTexture.createView(),
      resolveTarget: hdrTexture.createView(),
      clearValue: { r: 0.003, g: 0.006, b: 0.015, a: 1 },
      loadOp: 'clear',
      storeOp: 'discard',
    }],
    depthStencilAttachment: {
      view: depthTexture.createView(),
      depthClearValue: 1,
      depthLoadOp: 'clear',
      depthStoreOp: 'store',
    },
  });
  mainPass.setBindGroup(0, sceneBindGroup);
  mainPass.setPipeline(skyPipeline);
  mainPass.draw(3, 1);
  mainPass.setPipeline(solidPipeline);
  mainPass.setVertexBuffer(0, vertexBuffer);
  mainPass.setVertexBuffer(1, matrixBuffer);
  mainPass.setVertexBuffer(2, colorBuffer);
  mainPass.draw(36, 1);
  mainPass.setVertexBuffer(0, surfaceVertexBuffer);
  mainPass.setIndexBuffer(surfaceIndexBuffer, 'uint16');
  mainPass.setPipeline(clothPipeline);
  mainPass.drawIndexed(6, 1);
  mainPass.setPipeline(clothGridPipeline);
  mainPass.setBindGroup(1, clothGridBindGroup);
  mainPass.setIndexBuffer(clothGridIndexBuffer, 'uint16');
  mainPass.drawIndexed(6, 1);
  mainPass.setBindGroup(0, sceneBindGroup);
  mainPass.setPipeline(waterPipeline);
  mainPass.setVertexBuffer(0, surfaceVertexBuffer);
  mainPass.setIndexBuffer(surfaceIndexBuffer, 'uint16');
  mainPass.drawIndexed(6, 1);
  mainPass.setPipeline(waterGridPipeline);
  mainPass.setBindGroup(1, waterGridBindGroup);
  mainPass.setIndexBuffer(waterGridIndexBuffer, 'uint16');
  mainPass.drawIndexed(gridIndices.length, 1);
  mainPass.setBindGroup(0, sceneBindGroup);
  mainPass.setPipeline(linePipeline);
  mainPass.setVertexBuffer(0, lineBuffer);
  mainPass.draw(2, 1);
  mainPass.end();

  const postPass = encoder.beginRenderPass({
    colorAttachments: [{
      view: outputTexture.createView(),
      clearValue: { r: 0, g: 0, b: 0, a: 1 },
      loadOp: 'clear',
      storeOp: 'store',
    }],
  });
  postPass.setPipeline(postPipeline);
  postPass.setBindGroup(0, postBindGroup);
  postPass.draw(3, 1);
  postPass.end();

  device.queue.submit([encoder.finish()]);
  await device.queue.onSubmittedWorkDone();
});

assert.deepEqual(uncapturedErrors, [], 'Dawn emitted no uncaptured WebGPU errors');
console.log('✅ Dawn WebGPU pipeline test passed: 10 shaders, rigid/legacy-cloth/GPU-cloth/legacy-water/GPU-water pipelines, indexed surfaces, storage-buffer cloth and water, shadow isolation, HDR/MSAA, and complete offscreen frame');

device.destroy();
gpu = null;
