import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const readJson = (filename) => JSON.parse(fs.readFileSync(path.join(root, filename), 'utf8'));
const tournament = readJson('benchmarks/results/v1.6-second-breakthrough-100.json');
assert.equal(tournament.experimentCount, 100, 'v1.6 tournament must contain exactly 100 experiments');
assert.equal(tournament.experiments.length, 100, 'v1.6 experiment array must contain exactly 100 records');
assert.ok(tournament.acceptedCount >= 70, `expected at least 70 accepted candidates, received ${tournament.acceptedCount}`);
assert.ok(tournament.experiments.every((entry) => Number.isFinite(entry.speedup) && entry.speedup > 0), 'all experiment ratios must be finite and positive');
assert.ok(tournament.experiments.some((entry) => entry.status === 'rejected-correctness'), 'tournament must retain fidelity rejects rather than accepting every candidate');

const isolated = readJson('benchmarks/results/v1.5-v1.6-kernel-isolated.json');
assert.ok(isolated.summary.dynamicGeometricMeanSpeedup >= 1.35, 'dynamic production-path geometric mean must clear 1.35×');
const dynamic = isolated.results.filter((entry) => entry.category === 'dynamic-simulation');
const cache = isolated.results.filter((entry) => entry.category === 'unchanged-frame-cache');
assert.equal(dynamic.length, 7, 'expected seven dynamic production workloads');
assert.equal(cache.length, 3, 'expected three unchanged-frame workloads');
assert.ok(dynamic.every((entry) => entry.speedup >= 1.10), 'every dynamic production workload must clear 1.10×');
assert.ok(dynamic.every((entry) => entry.pairedBootstrap95[0] > 1), 'every dynamic paired 95% interval must exclude parity');
assert.ok(cache.every((entry) => entry.speedup >= 50), 'every unchanged-frame cache workload must clear 50×');
assert.ok(isolated.results.every((entry) => entry.optimizedDeterministic), 'all optimized fresh-process workloads must be deterministic');

for (const filename of ['public/soft-kernels-simd.wasm', 'public/soft-kernels-scalar.wasm']) {
  const module = new WebAssembly.Module(fs.readFileSync(path.join(root, filename)));
  const names = new Set(WebAssembly.Module.exports(module).map((entry) => entry.name));
  for (const symbol of ['memory', 'cloth_substep', 'rope_integrate', 'rope_solve', 'water_step', 'water_surface']) {
    assert.ok(names.has(symbol), `${filename} missing ${symbol}`);
  }
}

console.log(`✅ v1.6 evidence gate passed: 100 experiments, ${tournament.acceptedCount} accepted, ${isolated.summary.dynamicGeometricMeanSpeedup.toFixed(2)}× dynamic geometric mean, ${isolated.summary.cacheGeometricMeanSpeedup.toFixed(0)}× unchanged-frame cache geometric mean`);
