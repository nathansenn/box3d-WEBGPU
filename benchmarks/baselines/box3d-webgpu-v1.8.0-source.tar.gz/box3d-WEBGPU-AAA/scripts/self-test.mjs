import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = (file) => fs.readFileSync(path.join(root, file), 'utf8');
const requiredFiles = [
  'index.html',
  'LICENSE',
  'CHANGELOG.md',
  'THIRD_PARTY_NOTICES.md',
  'SOURCE_MANIFEST.sha256',
  'package.json',
  'src/main.ts',
  'src/math.ts',
  'src/scenes.ts',
  'src/showcases.ts',
  'src/effects.ts',
  'src/types.ts',
  'src/soft/simulations.ts',
  'src/soft/packed-surface.ts',
  'src/soft/wasm-kernels.ts',
  'src/compression/turboquant.ts',
  'src/assets/ktx2.ts',
  'src/physics/fallback.ts',
  'src/physics/wasm.ts',
  'src/webgpu/renderer.ts',
  'wasm/box3d_web.c',
  'wasm/CMakeLists.txt',
  'wasm/soft_kernels.c',
  'scripts/build-wasm.sh',
  'scripts/build-soft-kernels.sh',
  'scripts/fetch-box3d.sh',
  'scripts/doctor.sh',
  'scripts/c-bridge-syntax-test.sh',
  'scripts/soft-simulation-soak.cjs',
  'scripts/soft-kernel-runtime-test.cjs',
  'scripts/compile-turboquant-benchmarks.mjs',
  'benchmarks/turboquant-benchmark.cjs',
  'benchmarks/turboquant-worker-benchmark.cjs',
  'benchmarks/turboquant-worker-thread.cjs',
  'benchmarks/turboquant-report.mjs',
  'scripts/verify-source-manifest.sh',
  'scripts/push-existing-box3d-webgpu.sh',
  'docs/AAA_SHOWCASE.md',
  'docs/BOX3D_PORT.md',
  'docs/RENDERING_PIPELINE.md',
  'docs/TEST_PLAN.md',
  'docs/DEMO_GUIDE.md',
  'docs/LOCAL_BROWSER_VALIDATION.md',
  'docs/SOFT_BODY_AND_WATER.md',
  'docs/PERFORMANCE_V1.3.md',
  'docs/PERFORMANCE_V1.5.md',
  'docs/PERFORMANCE_V1.6.md',
  'docs/PERFORMANCE_V1.7.md',
  'docs/PERFORMANCE_V1.8.md',
  'docs/TURBOQUANT.md',
  'benchmarks/breakthrough-100.cjs',
  'benchmarks/breakthrough-worker.cjs',
  'benchmarks/build_breakthrough_report.py',
  'benchmarks/v1.4-v1.5-integrated.cjs',
  'benchmarks/v1.4-v1.5-isolated.cjs',
  'benchmarks/results/v1.5-breakthrough-100.json',
  'benchmarks/results/v1.5-breakthrough-100.csv',
  'benchmarks/results/v1.4-v1.5-integrated.json',
  'benchmarks/results/v1.4-v1.5-isolated.json',
  'scripts/check-breakthrough-results.mjs',
  'scripts/check-v1.6-results.mjs',
  'benchmarks/breakthrough-second-100.cjs',
  'benchmarks/v1.5-v1.6-kernel-worker.cjs',
  'benchmarks/v1.5-v1.6-kernel-isolated.cjs',
  'benchmarks/baselines/box3d-webgpu-v1.5.0-source.tar.gz',
  'benchmarks/results/v1.6-second-breakthrough-100.json',
  'benchmarks/results/v1.6-second-breakthrough-100.csv',
  'benchmarks/results/v1.5-v1.6-kernel-isolated.json',
  'scripts/check-v1.7-results.mjs',
  'benchmarks/breakthrough-third-100.cjs',
  'benchmarks/v1.6-v1.7-worker.cjs',
  'benchmarks/v1.6-v1.7-isolated.cjs',
  'benchmarks/build_v17_report.py',
  'benchmarks/baselines/box3d-webgpu-v1.6.0-source.tar.gz',
  'benchmarks/results/v1.7-third-breakthrough-100.json',
  'benchmarks/results/v1.7-third-breakthrough-100.csv',
  'benchmarks/results/v1.6-v1.7-isolated.json',
  'scripts/check-v1.8-results.mjs',
  'benchmarks/breakthrough-fourth-100.cjs',
  'benchmarks/run-v18-tournament.cjs',
  'benchmarks/merge-v18-shards.cjs',
  'benchmarks/v1.7-v1.8-worker.cjs',
  'benchmarks/v1.7-v1.8-isolated.cjs',
  'benchmarks/build_v18_report.py',
  'benchmarks/baselines/box3d-webgpu-v1.7.0-source.tar.gz',
  'benchmarks/results/v1.8-fourth-breakthrough-100.json',
  'benchmarks/results/v1.8-fourth-breakthrough-100.csv',
  'benchmarks/results/v1.7-v1.8-isolated.json',
  'public/soft-kernels-simd.wasm',
  'public/soft-kernels-scalar.wasm',
  'public/textures/material-noise-bc4.ktx2',
  'public/textures/material-noise-r8.ktx2',
];

for (const file of requiredFiles) {
  assert.ok(fs.existsSync(path.join(root, file)), `missing ${file}`);
}

const packageJson = JSON.parse(read('package.json'));
assert.equal(packageJson.name, 'box3d-webgpu');
assert.equal(packageJson.version, '1.8.0');
assert.equal(packageJson.license, 'MIT');
for (const script of ['dev', 'build', 'build:pages', 'fetch:box3d', 'build:wasm', 'build:soft-kernels', 'doctor', 'verify:source', 'typecheck', 'test', 'test:webgpu', 'test:cbridge', 'test:soft-kernels', 'test:soft-soak', 'test:soft-soak:js', 'test:soft-soak:wasm', 'bench:turboquant', 'bench:turboquant:worker', 'bench:turboquant:all', 'validate:turboquant', 'bench:breakthrough:compile', 'bench:breakthrough:100', 'bench:breakthrough:integrated', 'bench:breakthrough:isolated', 'bench:breakthrough:gate', 'bench:second:100', 'bench:second:gate', 'bench:kernels:isolated', 'bench:third:100', 'bench:v1.6-v1.7', 'bench:third:gate', 'bench:third', 'perf:v1.7:report', 'bench:fourth:100', 'bench:v1.7-v1.8', 'bench:fourth:gate', 'bench:fourth', 'perf:v1.8:report', 'perf:breakthrough:report', 'bench:breakthrough', 'validate:breakthrough', 'validate:v1.6', 'validate:v1.7', 'validate:v1.8', 'validate']) {
  assert.equal(typeof packageJson.scripts?.[script], 'string', `package.json missing script ${script}`);
}

const cBridge = read('wasm/box3d_web.c');
const cmake = read('wasm/CMakeLists.txt');
const wasmLoader = read('src/physics/wasm.ts');
const expectedExports = [
  'b3w_create_scene',
  'b3w_create_demo',
  'b3w_destroy',
  'b3w_body_count',
  'b3w_dynamic_count',
  'b3w_matrices_ptr',
  'b3w_colors_ptr',
  'b3w_max_bodies',
  'b3w_sync_transforms',
  'b3w_step',
  'b3w_apply_impulse',
  'b3w_kick_stack',
  'b3w_explode',
  'b3w_launch_projectile',
  'b3w_spawn_rain',
  'b3w_replay_hash',
];

for (const symbol of expectedExports) {
  assert.ok(cmake.includes(`_${symbol}`), `CMake does not export _${symbol}`);
  assert.ok(cBridge.includes(symbol), `C bridge does not define/reference ${symbol}`);
}
assert.match(cmake, /add_subdirectory\(/, 'Box3D must be wrapped as a subproject');
assert.match(cmake, /box3d::box3d/, 'WASM bridge must link the upstream Box3D target');
assert.match(cmake, /MODULARIZE=1/, 'WASM output must be modularized');
assert.match(cmake, /EXPORT_ES6=1/, 'WASM output must be an ES module');
assert.match(cmake, /ALLOW_MEMORY_GROWTH=1/, 'WASM build must allow heap growth');
assert.match(cmake, /-msimd128/, 'WASM build must support SIMD');
assert.match(cBridge, /b3w_add_aaa_set_dressing/, 'native bridge missing AAA set dressing');
assert.match(cBridge, /mode\s*>=\s*3/, 'native bridge missing cinematic scene mode');
assert.match(wasmLoader, /get HEAPF32\(\)/, 'WASM heap view must be refreshed after memory growth');

const html = read('index.html');
const requiredIds = [
  'gpu-canvas', 'warning', 'showcase-select', 'showcase-title', 'showcase-play',
  'showcase-restart', 'showcase-next', 'cinematic-progress', 'cinematic-progress-bar',
  'scene-buttons', 'scene-search', 'category-filter', 'scene-select', 'max-tour',
  'quality', 'speed', 'stress', 'stress-value', 'pause', 'step', 'reset', 'debug',
  'kick', 'projectile', 'explode', 'rain', 'run-tests', 'run-turboquant', 'test-log', 'body-count',
  'dynamic-count', 'effect-count', 'soft-system', 'soft-nodes', 'soft-constraints', 'soft-breaks', 'soft-energy', 'fps', 'sim-ms', 'render-ms', 'upload', 'backend',
  'hash', 'quality-stat',
];
for (const id of requiredIds) {
  const matches = html.match(new RegExp(`id=["']${id}["']`, 'g')) ?? [];
  assert.equal(matches.length, 1, `index.html must contain exactly one #${id}`);
}
const allIds = [...html.matchAll(/id=["']([^"']+)["']/g)].map((match) => match[1]);
assert.equal(new Set(allIds).size, allIds.length, 'index.html contains duplicate ids');

const showcases = read('src/showcases.ts');
const showcaseDefinitions = [...showcases.matchAll(/\bid:\s*'[^']+'\s*,\s*sceneId:/g)];
assert.equal(showcaseDefinitions.length, 30, 'expected exactly 30 authored hero showcases');
assert.match(showcases, /cameraTrack:/, 'showcases need authored camera tracks');
assert.match(showcases, /beats:/, 'showcases need timed physics beats');
assert.match(showcases, /sampleShowcaseCamera/, 'showcases need camera interpolation');

const scenes = read('src/scenes.ts');
assert.match(scenes, /FAMILIES\.flatMap/, 'catalog must be generated across all families');
assert.match(scenes, /familyIndex \* 50 \+ mode \* 10 \+ variant/, 'catalog must contain 50 recipes per family');
assert.match(scenes, /family:\s*'cloth'/, 'catalog must include cloth recipes');
assert.match(scenes, /family:\s*'rope'/, 'catalog must include rope recipes');
assert.match(scenes, /family:\s*'water'/, 'catalog must include water recipes');

const soft = read('src/soft/simulations.ts');
for (const marker of ['ClothSimulation', 'RopeSimulation', 'WaterSimulation', 'SoftSimulationSuite', 'horizontalBroken', 'shallow-water', 'buildSurface']) {
  assert.ok(soft.includes(marker), `soft simulation system missing ${marker}`);
}
assert.match(soft, /MAX_SOFT_INSTANCES\s*=\s*2048/, 'soft simulation instance budget must remain explicit');
assert.match(soft, /MAX_WATER_DROPLETS\s*=\s*768/, 'water droplet budget must remain explicit');
assert.match(soft, /breakThreshold/, 'cloth/rope constraints need controlled break thresholds');
assert.match(soft, /solveShallowWater/, 'water system must advance the shallow-water field');
assert.match(soft, /DynamicSurfaceFrame/, 'cloth and tearing paths must publish dynamic indexed surfaces');
assert.match(soft, /WaterGridFrame/, 'water must publish a GPU-resident grid frame');
assert.match(soft, /ClothGridFrame/, 'intact cloth must publish a GPU-resident grid frame');
assert.match(soft, /clothGridResult/, 'intact cloth must retain a reusable GPU-grid frame');
assert.match(soft, /fastIterations/, 'cloth must include the measured hierarchical fast schedule');
assert.match(soft, /constraintStructural/, 'cloth must keep a packed structural constraint list');
assert.match(soft, /constraintShear/, 'cloth must keep a packed shear constraint list');
assert.match(soft, /constraintBend/, 'cloth must keep a packed bend constraint list');
assert.match(soft, /PACKED_SURFACE_LITTLE_ENDIAN/, 'dynamic surfaces must retain the endianness-safe packed-color path');
assert.match(soft, /createSoftKernelArena/, 'soft systems must expose the zero-copy WebAssembly kernel path');
assert.match(soft, /frameVersion/, 'soft systems must version unchanged frames for upload suppression');

const softKernels = read('src/soft/wasm-kernels.ts');
assert.match(softKernels, /soft-kernels-simd\.wasm/, 'runtime must probe the SIMD soft-kernel module');
assert.match(softKernels, /soft-kernels-scalar\.wasm/, 'runtime must retain a scalar WebAssembly fallback');
assert.match(read('wasm/soft_kernels.c'), /cloth_substep/, 'native soft kernels must export cloth_substep');
assert.match(read('wasm/soft_kernels.c'), /water_surface/, 'native soft kernels must export water_surface');
assert.match(read('wasm/soft_kernels.c'), /rope_instances/, 'native soft kernels must export rope_instances');

const renderer = read('src/webgpu/renderer.ts');
for (const marker of [
  "'rgba16float'",
  'MSAA_SAMPLE_COUNT',
  'shadowPipeline',
  'textureSampleCompareLevel',
  'GGX',
  'bloom',
  'tone',
  'fog',
  'getCompilationInfo',
  'resolutionScale',
  'surfaceShadowPipeline',
  'clothPipeline',
  'waterPipeline',
  'waterGridPipeline',
  'uploadWaterGrid',
  'clothGridPipeline',
  'clothGridShadowPipeline',
  'uploadClothGrid',
  'drawIndexed',
  'uploadSurface',
]) {
  assert.ok(renderer.toLowerCase().includes(marker.toLowerCase()), `renderer missing AAA marker: ${marker}`);
}
assert.ok(!/textureSampleCompare\s*\(/.test(renderer), 'PBR solid shader must not use derivative-sensitive textureSampleCompare');
assert.ok(/textureSampleCompareLevel\s*\(/.test(renderer), 'PBR solid shader must use textureSampleCompareLevel for WebGPU uniformity safety');
assert.ok(/uvUnclamped/.test(renderer) && /inBounds/.test(renderer), 'shadow shader must mask out-of-bounds samples without per-fragment early return');
assert.match(
  renderer,
  /label:\s*'AAA atmospheric sky pipeline'[\s\S]*?depthStencil:\s*\{\s*format:\s*'depth24plus',\s*depthWriteEnabled:\s*false,\s*depthCompare:\s*'always'\s*\}/,
  'sky pipeline must declare depth24plus compatibility for the shared HDR render pass',
);
assert.match(
  renderer,
  /label:\s*'AAA shadow uniform layout'[\s\S]*?entries:\s*\[\s*\{\s*binding:\s*0,[\s\S]*?buffer:\s*\{\s*type:\s*'uniform'\s*\}[\s\S]*?\][\s\S]*?label:\s*'AAA shadow uniform bind group'/,
  'shadow pass must use a uniform-only bind group and never sample its writable depth attachment',
);
assert.match(renderer, /shadowPass\.setBindGroup\(0, this\.shadowBindGroup\)/, 'shadow pass must bind the isolated shadow bind group');
assert.match(renderer, /if \(safeCount > 0\) \{[\s\S]*?mainPass\.draw\(CUBE_VERTEX_COUNT, safeCount\)/, 'renderer must skip zero-instance solid draw calls');
assert.match(renderer, /surfaceFrameVersion/, 'renderer must cache unchanged dynamic-surface vertices');
assert.match(renderer, /waterGridFrameVersion/, 'renderer must cache unchanged GPU-water state');
assert.match(renderer, /clothGridFrameVersion/, 'renderer must cache unchanged GPU-cloth state');
assert.match(renderer, /var<storage, read> eta/, 'GPU-water shader must read the authoritative height field from storage');
assert.match(renderer, /var<storage, read> clothPositions/, 'GPU-cloth shader must read authoritative particle positions from storage');
assert.match(renderer, /checkerMaskX0/, 'GPU-cloth shader must retain exact legacy checker parity masks');

const turboQuant = read('src/compression/turboquant.ts');
for (const marker of ['TurboQuantCodec', 'TurboQuantDeltaStream', 'Lloyd-Max', 'Walsh-Hadamard', 'encodeIntoAndReconstruct']) {
  assert.ok(turboQuant.includes(marker), `TurboQuant codec missing ${marker}`);
}
assert.match(turboQuant, /TurboQuantBits\s*=\s*2\s*\|\s*3\s*\|\s*4/, 'TurboQuant must retain explicit 2/3/4-bit modes');
assert.match(turboQuant, /Keep this outside the authoritative solver/, 'TurboQuant source must document its non-authoritative transport boundary');
assert.match(read('src/main.ts'), /runTurboQuantBrowserProbe/, 'browser command deck must expose a target-device TurboQuant probe');
assert.match(read('docs/TURBOQUANT.md'), /Do not enable TurboQuant on the current same-thread|default local frame path remains lossless/i, 'TurboQuant docs must preserve the measured local-path decision');

const fallback = read('src/physics/fallback.ts');
assert.match(fallback, /broadphaseOrder/, 'preview backend must retain coherent sweep order storage');
assert.match(fallback, /broadphaseMins/, 'preview backend must retain broadphase bounds storage');
assert.match(fallback, /insertion sort/i, 'preview backend must document the coherent insertion-sort broadphase');

const breakthrough = read('benchmarks/breakthrough-100.cjs');
assert.match(breakthrough, /experiments\.length !== 100/, 'breakthrough tournament must enforce exactly 100 experiments');
const breakthroughResults = JSON.parse(read('benchmarks/results/v1.5-breakthrough-100.json'));
assert.equal(breakthroughResults.experimentCount, 100, 'recorded breakthrough result must contain exactly 100 experiments');
assert.equal(breakthroughResults.experiments.length, 100, 'recorded experiment array must contain exactly 100 entries');
const secondResults = JSON.parse(read('benchmarks/results/v1.6-second-breakthrough-100.json'));
assert.equal(secondResults.experimentCount, 100, 'second breakthrough pass must contain exactly 100 experiments');
assert.equal(secondResults.experiments.length, 100, 'second experiment array must contain exactly 100 entries');
assert.equal(secondResults.acceptedCount, 75, 'second pass accepted count drifted');
assert.equal(secondResults.borderlineCount, 8, 'second pass borderline count drifted');
assert.equal(secondResults.rejectedCorrectnessCount, 7, 'second pass fidelity-reject count drifted');
assert.equal(secondResults.experimentCount - secondResults.acceptedCount - secondResults.borderlineCount - secondResults.rejectedCorrectnessCount, 10, 'second pass no-win count drifted');
const isolatedV16 = JSON.parse(read('benchmarks/results/v1.5-v1.6-kernel-isolated.json'));
assert.ok(isolatedV16.summary.dynamicGeometricMeanSpeedup > 1.3, 'v1.6 production dynamic benchmark must retain a material win');
assert.ok(isolatedV16.summary.cacheGeometricMeanSpeedup > 50, 'v1.6 unchanged-frame cache benchmark must retain a material win');
assert.match(read('benchmarks/v1.5-v1.6-kernel-isolated.cjs'), /box3d-webgpu-v1\.5\.0-source\.tar\.gz/, 'isolated benchmark must use the bundled reproducible v1.5 source baseline');
const thirdResults = JSON.parse(read('benchmarks/results/v1.7-third-breakthrough-100.json'));
assert.equal(thirdResults.summary.experimentCount, 100, 'third breakthrough pass must contain exactly 100 experiments');
assert.equal(thirdResults.experiments.length, 100, 'third experiment array must contain exactly 100 entries');
assert.equal(thirdResults.summary['rejected-correctnessCount'], 0, 'integrated third-pass paths must have zero correctness failures');
assert.ok(thirdResults.summary.categories['water-full'].geometricMeanSpeedup > 1.7, 'third pass must retain the complete-water-frame breakthrough');
assert.ok(thirdResults.summary.categories['rope-frame'].geometricMeanSpeedup > 2, 'third pass must retain the rope-frame breakthrough');
const isolatedV17 = JSON.parse(read('benchmarks/results/v1.6-v1.7-isolated.json'));
assert.ok(isolatedV17.summary.changedGeometricMeanSpeedup > 2, 'v1.7 changed-path fresh-process benchmark must retain a material win');
assert.ok(isolatedV17.results.every((entry) => entry.crossVersionHashMatch), 'v1.7 frame-path changes must preserve cross-version simulation hashes');
assert.match(read('benchmarks/v1.6-v1.7-isolated.cjs'), /box3d-webgpu-v1\.6\.0-source\.tar\.gz/, 'v1.7 isolated benchmark must use the bundled reproducible v1.6 source baseline');
const fourthResults = JSON.parse(read('benchmarks/results/v1.8-fourth-breakthrough-100.json'));
assert.equal(fourthResults.summary.experimentCount, 100, 'fourth breakthrough pass must contain exactly 100 experiments');
assert.equal(fourthResults.experiments.length, 100, 'fourth experiment array must contain exactly 100 entries');
assert.equal(fourthResults.summary['rejected-correctnessCount'], 0, 'fourth-pass GPU-cloth paths must have zero correctness failures');
assert.equal(fourthResults.summary.categories['cloth-frame'].count, 35, 'fourth pass must retain 35 cloth-frame handoff experiments');
assert.ok(fourthResults.summary.categories['cloth-frame'].geometricMeanSpeedup > 50, 'fourth pass must retain the GPU-cloth frame-handoff breakthrough');
assert.ok(fourthResults.summary.categories['cloth-full'].geometricMeanSpeedup > 1.05, 'fourth pass must retain a complete-cloth-frame win');
assert.equal(fourthResults.summary.controlCount, 20, 'fourth pass must retain 20 unchanged-path controls');
const isolatedV18 = JSON.parse(read('benchmarks/results/v1.7-v1.8-isolated.json'));
assert.ok(isolatedV18.summary.changedGeometricMeanSpeedup > 2, 'v1.8 changed-path fresh-process benchmark must retain a material win');
assert.ok(isolatedV18.summary.dynamicGeometricMeanSpeedup > 1.02, 'v1.8 dynamic/mixed fresh-process benchmark must retain a measurable win');
assert.ok(isolatedV18.results.every((entry) => entry.crossVersionHashMatch), 'v1.8 GPU-cloth paths must preserve cross-version simulation hashes');
assert.match(read('benchmarks/v1.7-v1.8-isolated.cjs'), /box3d-webgpu-v1\.7\.0-source\.tar\.gz/, 'v1.8 isolated benchmark must use the bundled reproducible v1.7 source baseline');
for (const modulePath of ['public/soft-kernels-simd.wasm', 'public/soft-kernels-scalar.wasm']) {
  const bytes = fs.readFileSync(path.join(root, modulePath));
  assert.ok(WebAssembly.validate(bytes), `${modulePath} must be a valid WebAssembly module`);
}

const effects = read('src/effects.ts');
for (const marker of ['shockwave', 'cameraShake', 'spawnExplosion', 'spawnProjectile', 'spawnRainFlash', 'ensureFrameCapacity', 'particleWrite', 'waveWrite']) {
  assert.ok(effects.includes(marker), `effects system missing ${marker}`);
}

const main = read('src/main.ts');
for (const marker of ['AAA_SHOWCASES', 'CinematicEffects', 'SoftSimulationSuite', 'SOFT_INSTANCE_BUDGET', 'maxTour', 'runBrowserSmokeTests', 'resolutionScale', 'uploadClothGrid']) {
  assert.ok(main.includes(marker), `main director missing ${marker}`);
}

assert.match(read('VALIDATION_REPORT.md'), /Browser-render validation boundary/, 'validation report must document browser-runtime boundary');
assert.match(read('THIRD_PARTY_NOTICES.md'), /Box3D/, 'third-party notice must identify Box3D');

const workflows = ['.github/workflows/ci.yml', '.github/workflows/pages.yml'];
for (const workflow of workflows) {
  assert.ok(fs.existsSync(path.join(root, workflow)), `missing ${workflow}`);
}
assert.match(read('.github/workflows/ci.yml'), /npm (run validate|test)/, 'CI must run validation/tests');
assert.match(read('.github/workflows/pages.yml'), /npm run build:pages/, 'Pages workflow must build the subpath-safe bundle');

console.log('✅ repository self-test passed: AAA renderer, GPU-resident cloth and water, WASM rope frames, four 100-experiment evidence sets, exact frame/upload caching, 30 hero sequences, 750-scene catalog, native bridge, workflows, and UI contracts');
