import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import ts from 'typescript';
import { create, globals } from 'webgpu';

Object.assign(globalThis, globals);
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const rendererSource = fs.readFileSync(path.join(root, 'src/webgpu/renderer.ts'), 'utf8');
const runtimeDir = path.join(root, '.test-build');
const runtimeWebgpuDir = path.join(runtimeDir, 'webgpu');
const runtimeAssetsDir = path.join(runtimeDir, 'assets');
fs.mkdirSync(runtimeWebgpuDir, { recursive: true });
fs.mkdirSync(runtimeAssetsDir, { recursive: true });
const runtimeModulePath = path.join(runtimeWebgpuDir, 'renderer-runtime.mjs');
let transpiledRenderer = ts.transpileModule(rendererSource, {
  compilerOptions: {
    target: ts.ScriptTarget.ES2022,
    module: ts.ModuleKind.ES2022,
    importsNotUsedAsValues: ts.ImportsNotUsedAsValues.Remove,
  },
  fileName: 'renderer.ts',
}).outputText;
transpiledRenderer = transpiledRenderer.replace('../assets/ktx2.js', '../assets/ktx2.mjs');
fs.writeFileSync(runtimeModulePath, transpiledRenderer);
const ktx2Source = fs.readFileSync(path.join(root, 'src/assets/ktx2.ts'), 'utf8');
const transpiledKtx2 = ts.transpileModule(ktx2Source, {
  compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ES2022 },
  fileName: 'ktx2.ts',
}).outputText;
fs.writeFileSync(path.join(runtimeAssetsDir, 'ktx2.mjs'), transpiledKtx2);

let gpu = create(['backend=null']);
Object.defineProperty(globalThis, 'navigator', {
  configurable: true,
  value: { gpu },
});
Object.defineProperty(globalThis, 'window', {
  configurable: true,
  value: { devicePixelRatio: 1 },
});
Object.defineProperty(globalThis, 'fetch', {
  configurable: true,
  value: async () => { throw new Error('Runtime test intentionally uses the procedural KTX2 fallback.'); },
});

let configuredDevice;
let configuredFormat;
let currentTexture;
const canvas = {
  clientWidth: 96,
  clientHeight: 64,
  width: 0,
  height: 0,
  getContext(kind) {
    return kind === 'webgpu' ? context : null;
  },
};
const context = {
  configure(options) {
    configuredDevice = options.device;
    configuredFormat = options.format;
  },
  getCurrentTexture() {
    currentTexture?.destroy();
    assert.ok(configuredDevice, 'canvas context must be configured before rendering');
    assert.ok(configuredFormat, 'canvas context must have a preferred format');
    currentTexture = configuredDevice.createTexture({
      label: 'AAA test swapchain texture',
      size: [Math.max(1, canvas.width), Math.max(1, canvas.height)],
      format: configuredFormat,
      usage: GPUTextureUsage.RENDER_ATTACHMENT | GPUTextureUsage.COPY_SRC,
    });
    return currentTexture;
  },
};

const { WebGPURenderer } = await import(`${pathToFileURL(runtimeModulePath).href}?v=${Date.now()}`);
const renderer = await WebGPURenderer.create(canvas, 8);
const runtimeErrors = [];
renderer.device.addEventListener?.('uncapturederror', (event) => {
  runtimeErrors.push(event.error?.message ?? String(event.error));
});
const identity = [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1];
const quality = {
  id: 'cinematic',
  label: 'Cinematic',
  exposure: 1.1,
  bloomStrength: 0.5,
  fogDensity: 0.006,
  shadowStrength: 1,
  effectBudget: 64,
  resolutionScale: 1,
};
renderer.writeSceneUniforms({
  viewProjection: identity,
  lightViewProjection: identity,
  cameraPosition: [0, 4, 8],
  lightDirection: [0.42, -0.84, 0.34],
  fogColor: [0.055, 0.085, 0.14],
  timeSeconds: 1,
  quality,
});
const heap = new Float32Array(20);
heap.set(identity, 0);
heap.set([0.8, 0.4, 0.2, 1], 16);
const source = {
  HEAPF32: heap,
  _b3w_matrices_ptr: () => 0,
  _b3w_colors_ptr: () => 16 * Float32Array.BYTES_PER_ELEMENT,
};
assert.equal(renderer.uploadInstances(source, 1), 20 * Float32Array.BYTES_PER_ELEMENT);
const firstRenderMs = renderer.render(1, [{
  ax: -1, ay: 0, az: 0,
  bx: 1, by: 0, bz: 0,
  r: 1, g: 0.5, b: 0.2, a: 0.8,
}]);
assert.ok(Number.isFinite(firstRenderMs) && firstRenderMs >= 0, 'actual renderer must submit the shadow/HDR/post frame');
await renderer.device.queue.onSubmittedWorkDone();
assert.deepEqual(renderer.viewport(), [96, 64]);
assert.ok(renderer.uploadedMegabytes() > 0, 'actual renderer must account for instance uploads');

const surfaceVertices = new Uint8Array(4 * 24);
const surfaceView = new DataView(surfaceVertices.buffer);
const surfacePositions = [[-1.5, 2.2, -1.5], [1.5, 2.2, -1.5], [-1.5, 2.2, 1.5], [1.5, 2.2, 1.5]];
for (let i = 0; i < surfacePositions.length; i++) {
  const offset = i * 24;
  surfaceView.setFloat32(offset, surfacePositions[i][0], true);
  surfaceView.setFloat32(offset + 4, surfacePositions[i][1], true);
  surfaceView.setFloat32(offset + 8, surfacePositions[i][2], true);
  surfaceView.setInt16(offset + 12, 0, true);
  surfaceView.setInt16(offset + 14, 0, true);
  surfaceView.setUint8(offset + 16, 30 + i * 20);
  surfaceView.setUint8(offset + 17, 110 + i * 20);
  surfaceView.setUint8(offset + 18, 225);
  surfaceView.setUint8(offset + 19, 64 + i * 40);
  surfaceView.setUint16(offset + 20, (i & 1) ? 65535 : 0, true);
  surfaceView.setUint16(offset + 22, (i > 1) ? 65535 : 0, true);
}
const surfaceIndices = new Uint16Array([0, 2, 1, 1, 2, 3]);
const clothBytes = renderer.uploadSurface({
  material: 'cloth',
  vertices: surfaceVertices,
  indices: surfaceIndices,
  vertexStride: 24,
  vertexCount: 4,
  indexCount: 6,
  topologyVersion: 1,
  frameVersion: 1,
});
assert.equal(clothBytes, surfaceVertices.byteLength + surfaceIndices.byteLength);
const repeatedClothBytes = renderer.uploadSurface({
  material: 'cloth',
  vertices: surfaceVertices,
  indices: surfaceIndices,
  vertexStride: 24,
  vertexCount: 4,
  indexCount: 6,
  topologyVersion: 1,
  frameVersion: 1,
});
assert.equal(repeatedClothBytes, 0, 'unchanged surface content and topology should not be uploaded twice');
const clothRenderMs = renderer.render(1, []);
assert.ok(Number.isFinite(clothRenderMs) && clothRenderMs >= 0, 'actual renderer must submit a cloth shadow/surface frame');
await renderer.device.queue.onSubmittedWorkDone();

renderer.uploadSurface(null);
const clothGridPositions = new Float32Array([
  -1.5, 2.2, -1.5,
   1.5, 2.2, -1.5,
  -1.5, 2.2,  1.5,
   1.5, 2.2,  1.5,
]);
const clothGridStrain = new Float32Array([0, 0.04, 0.08, 0.12]);
const clothGrid = {
  positions: clothGridPositions,
  strain: clothGridStrain,
  indices: surfaceIndices,
  cols: 2,
  rows: 2,
  verticalLayout: false,
  baseColorA: [0.08, 0.24, 0.62, 1],
  baseColorB: [0.84, 0.88, 0.96, 1],
  vertexCount: 4,
  indexCount: 6,
  topologyVersion: 2,
  frameVersion: 3,
};
const expectedClothGridBytes = clothGridPositions.byteLength + clothGridStrain.byteLength + surfaceIndices.byteLength + 64;
assert.equal(renderer.uploadClothGrid(clothGrid), expectedClothGridBytes, 'first GPU-cloth upload must include positions, strain, topology, and uniforms');
assert.equal(renderer.uploadClothGrid(clothGrid), 0, 'unchanged GPU-cloth state must not be uploaded twice');
const gpuClothRenderMs = renderer.render(1, []);
assert.ok(Number.isFinite(gpuClothRenderMs) && gpuClothRenderMs >= 0, 'actual renderer must submit a GPU-resident cloth frame');
await renderer.device.queue.onSubmittedWorkDone();
clothGridPositions[4] += 0.08;
clothGridStrain[1] += 0.03;
clothGrid.frameVersion++;
assert.equal(renderer.uploadClothGrid(clothGrid), clothGridPositions.byteLength + clothGridStrain.byteLength, 'changed GPU-cloth state must upload only positions and strain');
assert.equal(renderer.uploadClothGrid(clothGrid), 0, 'repeated changed GPU-cloth frame must be cached');
const gpuClothUpdateRenderMs = renderer.render(1, []);
assert.ok(Number.isFinite(gpuClothUpdateRenderMs) && gpuClothUpdateRenderMs >= 0, 'actual renderer must submit an updated GPU-cloth frame');
await renderer.device.queue.onSubmittedWorkDone();
renderer.uploadClothGrid(null);

const waterBytes = renderer.uploadSurface({
  material: 'water',
  vertices: surfaceVertices,
  indices: surfaceIndices,
  vertexStride: 24,
  vertexCount: 4,
  indexCount: 6,
  topologyVersion: 1,
  frameVersion: 1,
});
assert.equal(waterBytes, 0, 'material-only changes should reuse identical vertex and topology streams');
const waterRenderMs = renderer.render(1, []);
assert.ok(Number.isFinite(waterRenderMs) && waterRenderMs >= 0, 'actual renderer must submit a translucent legacy water frame');
await renderer.device.queue.onSubmittedWorkDone();

renderer.uploadSurface(null);
const waterEta = new Float32Array([0, 0.08, -0.03, 0.02, 0.12, -0.05, 0.03, 0, -0.02, 0.04, 0.09, -0.01, 0, -0.03, 0.02, 0.06]);
const waterU = new Float32Array([0, 0.1, 0, -0.1, 0.03, 0.12, -0.04, 0, 0, -0.08, 0.07, 0.02, -0.03, 0, 0.05, 0]);
const waterV = new Float32Array([0.05, 0, -0.04, 0, 0.08, -0.03, 0.06, 0, -0.02, 0.09, 0, -0.05, 0, 0.04, -0.01, 0.03]);
const waterGridIndices = [];
for (let z = 0; z < 3; z++) {
  for (let x = 0; x < 3; x++) {
    const i = z * 4 + x;
    waterGridIndices.push(i, i + 4, i + 1, i + 1, i + 4, i + 5);
  }
}
const waterGrid = {
  eta: waterEta,
  u: waterU,
  v: waterV,
  indices: new Uint16Array(waterGridIndices),
  cols: 4,
  rows: 4,
  width: 6,
  depth: 6,
  baseY: 1.25,
  invTwoDx: 0.25,
  invTwoDz: 0.25,
  vertexCount: 16,
  indexCount: waterGridIndices.length,
  topologyVersion: 3,
  frameVersion: 7,
};
const expectedGridBytes = waterEta.byteLength + waterU.byteLength + waterV.byteLength + waterGrid.indices.byteLength + 32;
assert.equal(renderer.uploadWaterGrid(waterGrid), expectedGridBytes, 'first GPU-water upload must include state, topology, and uniforms');
assert.equal(renderer.uploadWaterGrid(waterGrid), 0, 'unchanged GPU-water state must not be uploaded twice');
const gpuWaterRenderMs = renderer.render(1, []);
assert.ok(Number.isFinite(gpuWaterRenderMs) && gpuWaterRenderMs >= 0, 'actual renderer must submit a GPU-resident water frame');
await renderer.device.queue.onSubmittedWorkDone();
waterEta[5] += 0.02;
waterGrid.frameVersion++;
assert.equal(renderer.uploadWaterGrid(waterGrid), waterEta.byteLength + waterU.byteLength + waterV.byteLength, 'changed GPU-water state must upload only the three fields');
assert.equal(renderer.uploadWaterGrid(waterGrid), 0, 'repeated changed GPU-water frame must be cached');
const gpuWaterUpdateRenderMs = renderer.render(1, []);
assert.ok(Number.isFinite(gpuWaterUpdateRenderMs) && gpuWaterUpdateRenderMs >= 0, 'actual renderer must submit an updated GPU-water frame');
await renderer.device.queue.onSubmittedWorkDone();

renderer.writeSceneUniforms({
  viewProjection: identity,
  lightViewProjection: identity,
  cameraPosition: [0, 4, 8],
  lightDirection: [0.42, -0.84, 0.34],
  fogColor: [0.055, 0.085, 0.14],
  timeSeconds: 2,
  quality: { ...quality, id: 'performance', label: 'Performance', shadowStrength: 0, resolutionScale: 0.7 },
});
renderer.uploadSurface(null);
const secondRenderMs = renderer.render(0, []);
assert.ok(Number.isFinite(secondRenderMs) && secondRenderMs >= 0, 'actual renderer must submit a zero-instance/no-shadow frame');
await renderer.device.queue.onSubmittedWorkDone();
assert.deepEqual(renderer.viewport(), [67, 44]);
assert.deepEqual(runtimeErrors, [], 'actual WebGPURenderer emitted no uncaptured WebGPU errors');

console.log('✅ Actual WebGPURenderer runtime test passed: rigid shadows, indexed and GPU-resident cloth, legacy and GPU-resident water, upload caching, debug lines, resize, empty frame, and clean Dawn error stream');

currentTexture?.destroy();
renderer.device.destroy();
Object.defineProperty(globalThis, 'navigator', { configurable: true, value: {} });
gpu = null;
