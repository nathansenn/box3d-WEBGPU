#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

TMP="$(mktemp)"
trap 'rm -f "$TMP"' EXIT

find . -type f \
  ! -path './SOURCE_MANIFEST.sha256' \
  ! -path './node_modules/*' \
  ! -path './dist/*' \
  ! -path './build/*' \
  ! -path './third_party/*' \
  ! -path './.git/*' \
  ! -path '*/__pycache__/*' \
  ! -name '*.pyc' \
  ! -path './.test-build/*' \
  ! -path './.bench-build/*' \
  ! -path './.bench-baseline-*/*' \
  ! -name '*.log' \
  ! -path './public/box3d/box3d.js' \
  ! -path './public/box3d/box3d.wasm' \
  ! -path './public/box3d/box3d.worker.js' \
  -print0 \
  | sort -z \
  | xargs -0 sha256sum > "$TMP"

mv "$TMP" SOURCE_MANIFEST.sha256
trap - EXIT
printf 'Wrote SOURCE_MANIFEST.sha256 with %s files.\n' "$(wc -l < SOURCE_MANIFEST.sha256 | tr -d ' ')"
