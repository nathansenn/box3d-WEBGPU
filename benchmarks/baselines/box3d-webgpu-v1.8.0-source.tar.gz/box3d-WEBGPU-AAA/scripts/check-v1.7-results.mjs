import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = (name) => JSON.parse(fs.readFileSync(path.join(root, name), 'utf8'));
const tournament = read('benchmarks/results/v1.7-third-breakthrough-100.json');
assert.equal(tournament.summary.experimentCount, 100, 'v1.7 tournament must contain exactly 100 experiments');
assert.equal(tournament.experiments.length, 100, 'v1.7 experiment array must contain exactly 100 records');
assert.ok(tournament.summary.acceptedCount >= 70, `expected at least 70 accepted changed-path wins, received ${tournament.summary.acceptedCount}`);
assert.equal(tournament.summary['rejected-correctnessCount'], 0, 'no integrated v1.7 path may fail correctness');
assert.equal(tournament.summary.controlCount, 20, 'the tournament must retain exactly 20 unchanged-path controls');
assert.equal(tournament.summary.acceptedCount + tournament.summary.borderlineCount + tournament.summary.controlCount + tournament.summary['rejected-no-winCount'] + tournament.summary['rejected-correctnessCount'], 100, 'all 100 outcomes must be classified exactly once');
assert.ok(tournament.experiments.every((entry) => entry.correctness.passed), 'all integrated production-path experiments must pass correctness');
const categories = tournament.summary.categories;
assert.equal(categories['water-frame'].count, 25);
assert.equal(categories['water-full'].count, 20);
assert.equal(categories['rope-frame'].count, 20);
assert.equal(categories['rope-full'].count, 15);
assert.equal(categories['cloth-full-control'].count, 10);
assert.equal(categories['water-step-control'].count, 10);
assert.ok(categories['water-frame'].geometricMeanSpeedup >= 25, 'GPU-resident water handoff must clear 25× geometric mean');
assert.ok(categories['water-full'].geometricMeanSpeedup >= 1.7, 'complete water frames must clear 1.7× geometric mean');
assert.ok(categories['rope-frame'].geometricMeanSpeedup >= 2, 'WASM rope frame generation must clear 2× geometric mean');
assert.ok(categories['rope-full'].geometricMeanSpeedup >= 1.05, 'complete rope frames must retain a measurable win');
for (const entry of tournament.experiments.filter((item) => item.category.startsWith('water'))) {
  if (entry.payload.baselineDynamicVertexBytes > 0 && entry.payload.optimizedDynamicStateBytes > 0) {
    assert.ok(entry.payload.byteReduction >= 0.49, 'GPU water state upload must reduce dynamic bytes by approximately 50%');
  }
}

const isolated = read('benchmarks/results/v1.6-v1.7-isolated.json');
assert.equal(isolated.results.length, 10, 'fresh-process comparison must contain ten release workloads');
assert.ok(isolated.summary.changedGeometricMeanSpeedup >= 2, 'changed-path fresh-process geometric mean must clear 2×');
assert.ok(isolated.summary.dynamicGeometricMeanSpeedup >= 1.35, 'dynamic/mixed fresh-process geometric mean must clear 1.35×');
assert.ok(isolated.results.every((entry) => entry.baselineDeterministic && entry.optimizedDeterministic), 'fresh-process workloads must be deterministic');
assert.ok(isolated.results.every((entry) => entry.crossVersionHashMatch), 'frame-path optimizations must preserve cross-version simulation hashes');
const byId = Object.fromEntries(isolated.results.map((entry) => [entry.id, entry]));
assert.ok(byId['water-maximum-frame'].speedup >= 20, 'water frame handoff must clear 20× in isolated processes');
assert.ok(byId['water-wave-full'].speedup >= 2, 'water wave full frame must clear 2×');
assert.ok(byId['water-maximum-full'].speedup >= 2, 'maximum water full frame must clear 2×');
assert.ok(byId['rope-maximum-frame'].speedup >= 1.5, 'rope frame generation must clear 1.5×');
assert.ok(byId['rope-mooring-full'].crossVersionHashMatch, 'zero-length mooring correction must preserve simulation state');

for (const filename of ['public/soft-kernels-simd.wasm', 'public/soft-kernels-scalar.wasm']) {
  const module = new WebAssembly.Module(fs.readFileSync(path.join(root, filename)));
  const names = new Set(WebAssembly.Module.exports(module).map((entry) => entry.name));
  for (const symbol of ['memory', 'cloth_substep', 'rope_integrate', 'rope_solve', 'rope_instances', 'water_step', 'water_surface']) {
    assert.ok(names.has(symbol), `${filename} missing ${symbol}`);
  }
}
console.log(`✅ v1.7 evidence gate passed: 100 experiments, ${tournament.summary.acceptedCount} accepted, ${categories['water-full'].geometricMeanSpeedup.toFixed(2)}× water-full geometric mean, ${categories['rope-frame'].geometricMeanSpeedup.toFixed(2)}× rope-frame geometric mean, ${isolated.summary.changedGeometricMeanSpeedup.toFixed(2)}× isolated changed-path geometric mean`);
