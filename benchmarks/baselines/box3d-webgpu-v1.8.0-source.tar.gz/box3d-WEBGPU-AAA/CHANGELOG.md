# Changelog

## 1.8.0 — GPU-Resident Intact Cloth

- Added `ClothGridFrame`, exposing authoritative positions, strain, static topology, grid dimensions, palette, and frame revisions.
- Added storage-buffer GPU cloth pipelines for main HDR rendering and directional shadow rendering.
- Moved intact-cloth smooth-normal, UV, checker palette, stress color, and woven-material reconstruction out of the CPU frame builder.
- Preserved tearing cloth on the mutable topology-aware packed-surface path.
- Added compact legacy checker parity masks to reproduce the v1.7 palette exactly without per-vertex color uploads.
- Reduced steady intact-cloth dynamic traffic from 24 to 16 bytes per vertex (33.33%).
- Added exact state/topology/normal/color/UV equivalence gates against bundled v1.7 source.
- Added a fourth exactly-100 production-path tournament, five-sample fresh-process comparison, report generator, release gate, and sharded runner.
- Extended Dawn pipeline/runtime tests to cover GPU-cloth storage buffers, shadows, indexed draws, frame updates, and zero-upload caching.
- Updated the TurboQuant browser probe to include GPU-resident cloth positions and strain.

## 1.7.0 — GPU-Resident Water and WASM Rope Frames

- Ran a third exactly-100 production-path benchmark pass against a bundled v1.6 source baseline.
- Recorded 80 changed-path wins, 20 explicitly classified unchanged-path controls, and zero integrated correctness failures.
- Replaced normal water CPU mesh reconstruction with a GPU-resident storage-buffer path. The vertex shader reconstructs geometry, normals, foam, and material color from `eta`, `u`, and `v`.
- Reduced steady dynamic water state traffic from 24 to 12 bytes per cell and retained upload-once static topology.
- Added exact water state/topology/uniform upload caching and direct Dawn runtime assertions for zero-byte repeated frames.
- Moved rope segment matrices and tension colors into the persistent SIMD/scalar WebAssembly kernel arena.
- Fixed a benchmark-discovered zero-length rope connector edge case by separating raw tension length from clamped matrix length.
- Added a ninth directly validated WGSL module and full GPU-water storage-buffer pipeline coverage under Dawn.
- Added a bundled reproducible v1.6 source baseline, five-sample 100-workload results, and a seven-sample alternating-order fresh-process comparison with 10,000 paired bootstrap resamples.
- Measured a 1.947× geometric mean across 20 complete water workloads, 7.714× across 20 rope frame builders, 1.257× across 15 complete rope workloads, and a 2.517× changed-path fresh-process geometric mean in this environment.
- Added `bench:third:100`, `bench:v1.6-v1.7`, `bench:third:gate`, `bench:third`, `perf:v1.7:report`, and `validate:v1.7`.

## 1.6.0 — WebAssembly Soft-Kernel Breakthrough

- Ran a second independent exactly-100 experiment tournament across cloth, rope, shallow water, compiler modes, solver cadence, and unchanged-frame work.
- Recorded 75 accepted measured wins, eight borderline candidates, ten no-win rejections, and seven correctness/fidelity rejections.
- Added persistent-memory WebAssembly kernels for non-tearing cloth, rope, and shallow water, with SIMD-first loading, scalar WebAssembly fallback, and the existing JavaScript solver as the final fallback.
- Kept tearing cloth and discontinuous interaction bookkeeping on conservative JavaScript paths rather than forcing mutable topology into the optimized kernel.
- Added exact `frameVersion`-based memoization for unchanged cloth, rope, and water frames.
- Added renderer-side buffer identity, byte-offset, version, vertex-count, and topology-version checks so unchanged soft surfaces and instances are not uploaded again.
- Added packaged SIMD/scalar kernel runtime tests, stable-horizon cross-version fidelity checks, deterministic same-version action replays, finite-state checks, cache invalidation tests, and tearing-fallback coverage.
- Added dual JavaScript/SIMD execution of the complete 150-scene soft-system soak.
- Added a reproducible bundled v1.5 source baseline and a fresh-process v1.5 → v1.6 benchmark with alternating order and paired bootstrap intervals.
- Measured a 1.4708× dynamic geometric-mean speedup and 1.5317× dynamic median across seven production soft workloads in this environment.
- Measured 115.30–959.32× acceleration for unchanged soft-frame construction, with a 330.1× geometric mean, by eliminating redundant rebuilds rather than reducing output quality.
- Added `build:soft-kernels`, `test:soft-kernels`, `bench:second:100`, `bench:kernels:isolated`, `bench:second:gate`, and `validate:v1.6` commands.

## 1.5.0 — Breakthrough Performance Tournament

- Ran exactly 100 candidate benchmarks across rigid broadphase, cloth scheduling, cloth/rope impact coupling, dynamic surfaces, and cinematic effects.
- Integrated hierarchical cloth projection: structural constraints remain full-rate while shear and bend use measured cadences with stiffness compensation.
- Added particle-AABB and squared-distance broad rejection for cloth and rope projectile storms.
- Replaced the preview backend's quadratic pair scan with coherent longest-axis sweep-and-prune and a scalar in-place AABB resolver.
- Added O(vertices) central-difference normals for intact cloth while preserving topology-aware triangle normals for torn cloth.
- Added endianness-safe packed RGBA writes and persistent effect matrix/color/debug-line buffers.
- Added a bundled compiled v1.4 baseline, exactly-100 tournament harness, same-process comparison, fresh-process comparison, bootstrap confidence intervals, and a release evidence gate.
- Measured a 2.10× geometric-mean speedup across ten fresh-process complete workloads in the release environment; individual results range from parity for steady rope to 6.75× for cloth impact storms.
- Preserved exact v1.4 replay hashes for sphere/tear cloth, steady/storm rope, and water workloads. Non-tearing fast cloth remains deterministic with 0.0132–0.0346% representative relative position error.
- Rejected four candidates for correctness/visual-fidelity failures rather than enabling every apparent microbenchmark win.

## 1.4.0 — TurboQuant Transport Evaluation

- Added an independent blockwise TurboQuant-MSE codec with deterministic random orthogonal rotation, Gaussian Lloyd–Max codebooks, and specialized 2/3/4-bit packing.
- Added a structured randomized Walsh–Hadamard path inspired by Fast-TurboQuant for O(d log d) transforms.
- Added synchronized predictive state streams that quantize deltas from the prior reconstructed frame.
- Added real cloth, rope, and water benchmarks for size, encode/decode time, error, copy cost, worker transport, fan-out, and network break-even.
- Added a dynamically loaded in-browser TurboQuant probe for target-device measurements.
- Kept TurboQuant disabled on the authoritative solver and same-thread WebGPU upload path because local end-to-end measurements show a regression despite large byte reductions.
- Added `bench:turboquant`, `bench:turboquant:worker`, `bench:turboquant:all`, and `validate:turboquant` scripts.

## 1.2.0 — Performance Engineering Edition

- Added a reproducible 100-candidate optimization benchmark suite with raw JSON and CSV evidence.
- Added baseline-versus-optimized whole-project timing with medians and MAD noise reporting.
- Added allocation-free performance primitives, geometric capacity growth, and fixed ring-buffer utilities.
- Specialized side-effect-free vector-length and square operations in validated hot paths.
- Retained packed soft-body data layouts and cached cloth topology from the optimization branch.
- Added permanent `bench:100`, `bench:end-to-end`, `bench:all`, and `validate:performance` gates.
- Documented accepted, borderline, rejected, and future architectural candidates without multiplying unrelated benchmark ratios.

## 1.1.0 — cloth, rope, and interactive water edition

### Added

- 150 deterministic soft/fluid scenes: 50 cloth, 50 rope/rigging, and 50 water scenarios.
- Six directed hero demonstrations: Tempest Standard Protocol, Parachute Canopy Failure, Sky Crane Cable Failure, Suspension Cable Resonance, Tsunami Research Array, and Leviathan Impact Basin.
- Deterministic position-based cloth with structural, shear, and bend constraints; multiple pin layouts; wind; collision; strain visualization; controlled tearing; and topology holes.
- Deterministic rope/cable PBD with anchors, payloads, bend links, catenaries, cross-links, tension coloring, projectile severing, and controlled breakage.
- Interactive 2.5D linear shallow-water simulation with height/velocity fields, reflected boundaries, waves, wakes, fountains, rain, dam-break fronts, vortices, floaters, foam, and impact displacement.
- Indexed dynamic-surface upload path for cloth and water, including dedicated surface-shadow, woven-cloth, and translucent-water WebGPU pipelines.
- Soft-system command-deck telemetry for solver type, nodes, constraints/cells, broken links, energy, and combined replay hash.
- `npm run test:soft-soak` for all 150 soft/fluid scenes and paired deterministic deep replays.
- `npm run test:cbridge` for strict C17 bridge syntax/API-contract validation with warnings as errors.
- Detailed cloth/rope/water architecture and validation documentation.

### Changed

- Catalog expanded from 600 to 750 scenes and from 12 to 15 families.
- Hero director expanded from 24 to 30 authored sequences.
- Dawn validation expanded from five to eight WGSL modules and now covers indexed cloth/water draws.
- Renderer runtime test now uploads and renders real cloth and water surface frames.
- Soft solvers preallocate hot-path buffers and precompute constraint stiffness to avoid large per-frame allocation churn.
- Source-manifest verification now works with either GNU `sha256sum` or macOS `shasum`.

### Validation

- 11 deterministic Node suites pass.
- All 750 scenes construct and step; all 30 hero definitions validate.
- All 150 soft/fluid scenes pass finite-stream, topology, budget, action, and replay checks.
- Long-run preparation soaks covered 6,000 cloth, 9,000 rope, and 12,000 water frames without numerical corruption.
- Eight WGSL modules and the complete rigid/cloth/water frame graph pass Dawn validation with zero uncaptured errors.

## 1.0.2 — full WebGPU frame-validation hotfix

- Fixed a render-pass compatibility error discovered after the 1.0.1 shader correction: the atmospheric sky pipeline was used in a `depth24plus` render pass without declaring a matching depth/stencil state.
- Added `depthStencil: { format: 'depth24plus', depthWriteEnabled: false, depthCompare: 'always' }` to the sky pipeline so it shares the HDR pass safely without modifying depth.
- Added a Dawn-backed `npm run test:webgpu` gate using the null backend. It compiles all five WGSL modules, creates the shadow, sky, solid, line, RGBA post, and BGRA post pipelines, validates bind groups and attachments, and submits a complete offscreen shadow/HDR/post frame.
- Added a second Dawn test that transpiles and executes the actual `WebGPURenderer` class with a canvas-context shim, rendering one shadowed/debug-line frame and one resized no-shadow/zero-instance frame.
- Added a repository regression assertion for sky-pass depth compatibility.
- Fixed an illegal shadow-pass feedback loop: the writable depth map was also present in the scene sampling bind group. The shadow pass now uses a separate uniform-only layout and bind group.
- Added regression assertions that the shadow pass binds only the isolated shadow uniform group.
- Skipped zero-instance solid draw calls to remove Dawn diagnostics and avoid needless command encoding in empty scenes.
- Independently reproduced the original 1.0.0 `textureSampleCompare` failure in Dawn and confirmed that the 1.0.2 solid shader compiles with zero messages.

## 1.0.1 — WGSL shadow validation hotfix

- Fixed startup failure on strict WebGPU implementations where the PBR solid shader rejected `textureSampleCompare` in non-uniform fragment control flow.
- Replaced the shadow-map PCF lookup with `textureSampleCompareLevel`, which does not compute derivatives and has no uniform-control-flow requirement.
- Removed the per-fragment early return from the shadow lookup and masks out-of-bounds projections with `select`/`mix` after sampling.
- Added repository self-test assertions to prevent reintroducing derivative-sensitive `textureSampleCompare` in the solid shader path.

## 1.0.0 — 2026-07-10 — AAA Physics Lab Edition

### Added

- 24 directed hero demonstrations layered over the 600-scene capability catalog.
- Timed camera tracks, captions, impulses, projectiles, explosions, stress rain,
  time dilation, camera shake, and telemetry-lock beats.
- 2,048² PCF shadow mapping, four-sample MSAA, `rgba16float` HDR rendering,
  PBR-inspired GGX lighting, atmospheric sky/fog, emissive effects, bloom,
  tone mapping, vignette, and film grain.
- Performance, Balanced, Cinematic, and Ultra render profiles with real
  resolution, shadow, and effect-budget differences.
- Deterministic cinematic effects, authored scene dressing, and 624-scenario
  in-browser validation.
- A reproducible Box3D v0.1.0 Emscripten wrapper, stable C ABI, refreshed heap
  views after WASM memory growth, and safe GitHub publishing scripts.
- Detailed demo, renderer, native-port, test, publishing, and local browser
  validation documentation.
- MIT license and third-party notices.

### Corrected

- Camera elevation now uses positive pitch consistently, keeping catalog and
  cinematic cameras above their targets rather than below the ground plane.
- Non-uniform instance scaling now uses a normalized rotation basis for normal
  transformation, preventing distorted lighting on beams and slabs.
- Native build topology now wraps Box3D as a subproject rather than inheriting
  inappropriate top-level browser thread settings.
- Emscripten heap access now refreshes typed-array views after memory growth.

### Validation

- Strict TypeScript passed.
- Nine deterministic suites passed.
- All 600 catalog scenes constructed successfully.
- All 24 hero timelines passed camera/beat validation.
- Production and GitHub Pages builds passed.
- npm audit reported zero moderate-or-higher vulnerabilities.
- Native bridge passed strict C17 syntax checking with warnings as errors.
