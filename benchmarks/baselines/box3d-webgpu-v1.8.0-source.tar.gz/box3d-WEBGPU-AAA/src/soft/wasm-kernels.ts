/**
 * Optional high-throughput soft-simulation kernels.
 *
 * The authoritative state remains visible through normal TypedArray views. When
 * the module is available, the arrays are allocated directly in WebAssembly
 * linear memory so simulation, JavaScript interactions, surface generation,
 * and replay validation share one zero-copy state buffer.
 */

export type SoftKernelVariant = 'simd' | 'scalar' | 'javascript';

export type WasmSlice<T extends ArrayBufferView> = {
  readonly ptr: number;
  readonly view: T;
};

export type SoftKernelExports = {
  readonly memory: WebAssembly.Memory;
  readonly cloth_substep: (...args: number[]) => void;
  readonly rope_integrate: (...args: number[]) => void;
  readonly rope_solve: (...args: number[]) => number;
  readonly rope_instances: (...args: number[]) => number;
  readonly water_step: (...args: number[]) => void;
  readonly water_surface: (...args: number[]) => void;
};

let compiledModule: WebAssembly.Module | null = null;
let selectedVariant: SoftKernelVariant = 'javascript';
let statusMessage = 'JavaScript soft-simulation kernels active.';

function kernelUrl(filename: string): string {
  // document.baseURI naturally follows Vite's development root and a
  // GitHub-Pages subdirectory without making this module depend on
  // import.meta, which also keeps the exact runtime testable as CommonJS.
  if (typeof document !== 'undefined') return new URL(filename, document.baseURI).toString();
  return filename;
}

async function fetchModule(filename: string): Promise<WebAssembly.Module> {
  const response = await fetch(kernelUrl(filename));
  if (!response.ok) throw new Error(`${filename} returned HTTP ${response.status}`);
  return WebAssembly.compile(await response.arrayBuffer());
}

export async function initializeSoftKernels(): Promise<{
  variant: SoftKernelVariant;
  active: boolean;
  message: string;
}> {
  if (compiledModule) return { variant: selectedVariant, active: true, message: statusMessage };
  if (typeof WebAssembly === 'undefined') {
    statusMessage = 'WebAssembly unavailable; JavaScript soft-simulation kernels active.';
    return { variant: selectedVariant, active: false, message: statusMessage };
  }

  const failures: string[] = [];
  for (const candidate of [
    ['simd', 'soft-kernels-simd.wasm'],
    ['scalar', 'soft-kernels-scalar.wasm'],
  ] as const) {
    try {
      compiledModule = await fetchModule(candidate[1]);
      // Instantiate once during initialization so unsupported instructions or
      // malformed exports fail before the first scene is constructed.
      const probe = new WebAssembly.Instance(compiledModule, {});
      if (!(probe.exports.memory instanceof WebAssembly.Memory)) {
        throw new Error('module did not export linear memory');
      }
      selectedVariant = candidate[0];
      statusMessage = `${candidate[0].toUpperCase()} WebAssembly soft kernels active.`;
      return { variant: selectedVariant, active: true, message: statusMessage };
    } catch (error) {
      failures.push(`${candidate[1]}: ${error instanceof Error ? error.message : String(error)}`);
      compiledModule = null;
    }
  }

  selectedVariant = 'javascript';
  statusMessage = `JavaScript soft kernels active (${failures.join('; ')}).`;
  return { variant: selectedVariant, active: false, message: statusMessage };
}

/** Test-only/public harness hook. It allows Node validation to install the exact
 * packaged module without adding filesystem logic to browser runtime code. */
export function installSoftKernelModule(module: WebAssembly.Module | null, variant: SoftKernelVariant = 'simd'): void {
  compiledModule = module;
  selectedVariant = module ? variant : 'javascript';
  statusMessage = module ? `${variant.toUpperCase()} WebAssembly soft kernels active.` : 'JavaScript soft-simulation kernels active.';
}

export function softKernelStatus(): { variant: SoftKernelVariant; active: boolean; message: string } {
  return { variant: selectedVariant, active: compiledModule !== null, message: statusMessage };
}

export class SoftKernelArena {
  readonly exports: SoftKernelExports;
  readonly memory: WebAssembly.Memory;
  private top = 1024;

  constructor(module: WebAssembly.Module) {
    const instance = new WebAssembly.Instance(module, {});
    this.exports = instance.exports as unknown as SoftKernelExports;
    this.memory = this.exports.memory;
    if (!(this.memory instanceof WebAssembly.Memory)) throw new Error('Soft-kernel module has no exported memory.');
  }

  private reserve(byteLength: number, alignment: number): number {
    const mask = alignment - 1;
    this.top = (this.top + mask) & ~mask;
    const ptr = this.top;
    this.top += byteLength;
    if (this.top > this.memory.buffer.byteLength) {
      throw new RangeError(`Soft-kernel arena exceeded ${this.memory.buffer.byteLength} bytes.`);
    }
    return ptr;
  }

  float32(source: Float32Array): WasmSlice<Float32Array<ArrayBuffer>> {
    const ptr = this.reserve(source.byteLength, Float32Array.BYTES_PER_ELEMENT);
    const view = new Float32Array(this.memory.buffer, ptr, source.length) as Float32Array<ArrayBuffer>;
    view.set(source);
    return { ptr, view };
  }

  uint16(source: Uint16Array): WasmSlice<Uint16Array<ArrayBuffer>> {
    const ptr = this.reserve(source.byteLength, Uint16Array.BYTES_PER_ELEMENT);
    const view = new Uint16Array(this.memory.buffer, ptr, source.length) as Uint16Array<ArrayBuffer>;
    view.set(source);
    return { ptr, view };
  }

  uint8(source: Uint8Array): WasmSlice<Uint8Array<ArrayBuffer>> {
    const ptr = this.reserve(source.byteLength, 4);
    const view = new Uint8Array(this.memory.buffer, ptr, source.length) as Uint8Array<ArrayBuffer>;
    view.set(source);
    return { ptr, view };
  }
}

export function createSoftKernelArena(): SoftKernelArena | null {
  if (!compiledModule) return null;
  try {
    return new SoftKernelArena(compiledModule);
  } catch (error) {
    console.warn('[Soft kernels] Falling back to JavaScript:', error);
    return null;
  }
}
