/** Compact dynamic-surface layout shared by CPU simulation and WebGPU.
 *  0..11  : position.xyz as float32
 * 12..15  : octahedral normal.xy as snorm16
 * 16..19  : color/stress as unorm8x4
 * 20..23  : uv as unorm16x2
 */
export const PACKED_SURFACE_VERTEX_BYTES = 24;

/** JavaScript typed arrays use native byte order. WebGPU targets supported by
 * this project are little-endian in practice, but retain a byte-write fallback
 * so packed RGBA output remains correct on any conforming host. */
export const PACKED_SURFACE_LITTLE_ENDIAN = (() => {
  const probe = new ArrayBuffer(4);
  new Uint32Array(probe)[0] = 0x01020304;
  return new Uint8Array(probe)[0] === 0x04;
})();

export class PackedSurfaceBuffer {
  readonly buffer: ArrayBuffer;
  readonly data: Uint8Array;
  readonly u8: Uint8Array;
  readonly f32: Float32Array;
  readonly i16: Int16Array;
  readonly u16: Uint16Array;
  readonly u32: Uint32Array;

  constructor(vertexCount: number, buffer?: ArrayBuffer, byteOffset = 0) {
    const safeCount = Math.max(0, Math.floor(vertexCount));
    const byteLength = safeCount * PACKED_SURFACE_VERTEX_BYTES;
    this.buffer = buffer ?? new ArrayBuffer(byteLength);
    if (byteOffset < 0 || byteOffset + byteLength > this.buffer.byteLength) {
      throw new RangeError('Packed surface view exceeds its backing buffer.');
    }
    this.data = new Uint8Array(this.buffer, byteOffset, byteLength);
    this.u8 = this.data;
    this.f32 = new Float32Array(this.buffer, byteOffset, byteLength / Float32Array.BYTES_PER_ELEMENT);
    this.i16 = new Int16Array(this.buffer, byteOffset, byteLength / Int16Array.BYTES_PER_ELEMENT);
    this.u16 = new Uint16Array(this.buffer, byteOffset, byteLength / Uint16Array.BYTES_PER_ELEMENT);
    this.u32 = new Uint32Array(this.buffer, byteOffset, byteLength / Uint32Array.BYTES_PER_ELEMENT);
  }
}

export function packedSurfacePositionsAreFinite(data: Uint8Array, vertexCount: number): boolean {
  const safeCount = Math.max(0, Math.min(Math.floor(vertexCount), Math.floor(data.byteLength / PACKED_SURFACE_VERTEX_BYTES)));
  const f32 = new Float32Array(data.buffer, data.byteOffset, Math.floor(data.byteLength / 4));
  for (let i = 0; i < safeCount; i++) {
    const offset = i * (PACKED_SURFACE_VERTEX_BYTES / 4);
    if (!Number.isFinite(f32[offset]) || !Number.isFinite(f32[offset + 1]) || !Number.isFinite(f32[offset + 2])) {
      return false;
    }
  }
  return true;
}
