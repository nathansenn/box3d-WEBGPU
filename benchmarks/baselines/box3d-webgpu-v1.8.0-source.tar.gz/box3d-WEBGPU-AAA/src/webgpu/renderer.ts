import type { Mat4 } from '../math';
import type { ClothGridFrame, DebugLine, DynamicSurfaceFrame, InstanceBufferSource, SceneUniformState, WaterGridFrame } from '../types';
import { loadMaterialNoiseTexture, type MaterialNoiseTexture } from '../assets/ktx2.js';

const CUBE_VERTEX_COUNT = 36;
const MAX_DEBUG_LINE_VERTICES = 131072;
const SCENE_UNIFORM_FLOATS = 48;
const SCENE_UNIFORM_BYTES = SCENE_UNIFORM_FLOATS * Float32Array.BYTES_PER_ELEMENT;
const SHADOW_MAP_SIZE = 2048;
const MSAA_SAMPLE_COUNT = 4;
const HDR_FORMAT: GPUTextureFormat = 'rgba16float';
const MAX_DYNAMIC_SURFACE_VERTICES = 16384;
const MAX_DYNAMIC_SURFACE_INDICES = 98304;
const SURFACE_VERTEX_BYTES = 24;
const CLOTH_GRID_UNIFORM_BYTES = 64;
const WATER_GRID_UNIFORM_BYTES = 32;

const sceneUniformStruct = /* wgsl */ `
struct SceneUniforms {
  viewProj : mat4x4<f32>,
  lightViewProj : mat4x4<f32>,
  cameraPosTime : vec4<f32>,
  lightDirExposure : vec4<f32>,
  fogColorDensity : vec4<f32>,
  viewportBloomShadow : vec4<f32>,
};
`;

const packedSurfaceDecode = /* wgsl */ `
fn decodeOctNormal(encoded : vec2<f32>) -> vec3<f32> {
  var normal = vec3<f32>(encoded.x, encoded.y, 1.0 - abs(encoded.x) - abs(encoded.y));
  if (normal.z < 0.0) {
    let original = normal.xy;
    normal.x = (1.0 - abs(original.y)) * select(-1.0, 1.0, original.x >= 0.0);
    normal.y = (1.0 - abs(original.x)) * select(-1.0, 1.0, original.y >= 0.0);
  }
  return normalize(normal);
}
`;

const solidShader = /* wgsl */ `
${sceneUniformStruct}

@group(0) @binding(0)
var<uniform> scene : SceneUniforms;

@group(0) @binding(1)
var shadowMap : texture_depth_2d;

@group(0) @binding(2)
var shadowSampler : sampler_comparison;

@group(0) @binding(3)
var materialNoise : texture_2d<f32>;

@group(0) @binding(4)
var materialNoiseSampler : sampler;

struct VertexIn {
  @location(0) position : vec3<f32>,
  @location(1) normal : vec3<f32>,
  @location(2) m0 : vec4<f32>,
  @location(3) m1 : vec4<f32>,
  @location(4) m2 : vec4<f32>,
  @location(5) m3 : vec4<f32>,
  @location(6) color : vec4<f32>,
};

struct VertexOut {
  @builtin(position) clipPosition : vec4<f32>,
  @location(0) worldNormal : vec3<f32>,
  @location(1) color : vec4<f32>,
  @location(2) worldPos : vec3<f32>,
  @location(3) shadowPosition : vec4<f32>,
};

@vertex
fn vsMain(input : VertexIn) -> VertexOut {
  let model = mat4x4<f32>(input.m0, input.m1, input.m2, input.m3);
  let world = model * vec4<f32>(input.position, 1.0);

  var out : VertexOut;
  out.clipPosition = scene.viewProj * world;
  // Model columns contain rotation * non-uniform half-extents. Rebuild a
  // rotation-only basis so thin beams, slabs, and towers receive physically
  // plausible lighting instead of skewed normals.
  let normalBasis = mat3x3<f32>(
    normalize(input.m0.xyz),
    normalize(input.m1.xyz),
    normalize(input.m2.xyz)
  );
  out.worldNormal = normalize(normalBasis * input.normal);
  out.color = input.color;
  out.worldPos = world.xyz;
  out.shadowPosition = scene.lightViewProj * world;
  return out;
}

fn distributionGGX(nDotH : f32, roughness : f32) -> f32 {
  let a = roughness * roughness;
  let a2 = a * a;
  let denominator = nDotH * nDotH * (a2 - 1.0) + 1.0;
  return a2 / max(3.14159265 * denominator * denominator, 0.0001);
}

fn geometrySchlickGGX(nDotV : f32, roughness : f32) -> f32 {
  let r = roughness + 1.0;
  let k = (r * r) / 8.0;
  return nDotV / max(nDotV * (1.0 - k) + k, 0.0001);
}

fn fresnelSchlick(cosTheta : f32, f0 : vec3<f32>) -> vec3<f32> {
  return f0 + (vec3<f32>(1.0) - f0) * pow(1.0 - cosTheta, 5.0);
}

fn sampleShadow(shadowPosition : vec4<f32>, normal : vec3<f32>, lightDirection : vec3<f32>) -> f32 {
  let projected = shadowPosition.xyz / max(shadowPosition.w, 0.0001);
  let uvUnclamped = vec2<f32>(projected.x * 0.5 + 0.5, 0.5 - projected.y * 0.5);

  // Do not early-return before the shadow texture lookup. Some browsers reject
  // textureSampleCompare in per-fragment control flow. textureSampleCompareLevel
  // is explicitly derivative-free, and the out-of-bounds result is masked with
  // select() after sampling so the shader validates across stricter WebGPU
  // implementations.
  let inBounds = select(0.0, 1.0,
    uvUnclamped.x > 0.0 && uvUnclamped.x < 1.0 &&
    uvUnclamped.y > 0.0 && uvUnclamped.y < 1.0 &&
    projected.z > 0.0 && projected.z < 1.0
  );
  let uv = clamp(uvUnclamped, vec2<f32>(0.0015), vec2<f32>(0.9985));

  let dimensions = vec2<f32>(textureDimensions(shadowMap));
  let texel = vec2<f32>(1.0) / dimensions;
  let nDotL = max(dot(normal, -lightDirection), 0.0);
  let bias = max(0.00016, 0.0012 * (1.0 - nDotL));
  let referenceDepth = clamp(projected.z - bias, 0.0, 1.0);
  var visibility = 0.0;

  for (var x : i32 = -1; x <= 1; x = x + 1) {
    for (var y : i32 = -1; y <= 1; y = y + 1) {
      let offset = vec2<f32>(f32(x), f32(y)) * texel * 1.25;
      visibility = visibility + textureSampleCompareLevel(shadowMap, shadowSampler, uv + offset, referenceDepth);
    }
  }

  let sampledVisibility = visibility / 9.0;
  return mix(1.0, sampledVisibility, inBounds);
}

@fragment
fn fsMain(input : VertexOut) -> @location(0) vec4<f32> {
  let normal = normalize(input.worldNormal);
  let viewDirection = normalize(scene.cameraPosTime.xyz - input.worldPos);
  let lightDirection = normalize(scene.lightDirExposure.xyz);
  let toLight = -lightDirection;
  let halfVector = normalize(viewDirection + toLight);

  let encodedColor = clamp(input.color.rgb, vec3<f32>(0.0), vec3<f32>(1.0));
  let baseColor = pow(encodedColor, vec3<f32>(2.2));
  let maxChannel = max(baseColor.r, max(baseColor.g, baseColor.b));
  let minChannel = min(baseColor.r, min(baseColor.g, baseColor.b));
  let saturation = (maxChannel - minChannel) / max(maxChannel, 0.001);
  let luminance = dot(baseColor, vec3<f32>(0.2126, 0.7152, 0.0722));
  let metallic = clamp((1.0 - saturation) * 0.48 + smoothstep(0.45, 0.9, luminance) * 0.12, 0.03, 0.62);
  let noiseUv = input.worldPos.xz * 0.075 + vec2<f32>(input.worldPos.y * 0.021, -input.worldPos.y * 0.017);
  let microVariation = textureSample(materialNoise, materialNoiseSampler, noiseUv).r;
  let roughness = clamp(0.28 + (1.0 - saturation) * 0.28 + microVariation * 0.08, 0.2, 0.78);

  let nDotL = max(dot(normal, toLight), 0.0);
  let nDotV = max(dot(normal, viewDirection), 0.0);
  let nDotH = max(dot(normal, halfVector), 0.0);
  let vDotH = max(dot(viewDirection, halfVector), 0.0);

  let f0 = mix(vec3<f32>(0.04), baseColor, metallic);
  let fresnel = fresnelSchlick(vDotH, f0);
  let distribution = distributionGGX(nDotH, roughness);
  let geometry = geometrySchlickGGX(nDotV, roughness) * geometrySchlickGGX(nDotL, roughness);
  let specular = (distribution * geometry * fresnel) / max(4.0 * nDotV * nDotL, 0.001);
  let kD = (vec3<f32>(1.0) - fresnel) * (1.0 - metallic);

  let shadowVisibility = mix(1.0, sampleShadow(input.shadowPosition, normal, lightDirection), scene.viewportBloomShadow.w);
  let sunRadiance = vec3<f32>(5.8, 5.15, 4.55);
  let direct = (kD * baseColor / 3.14159265 + specular) * sunRadiance * nDotL * shadowVisibility;

  let skyAmbient = vec3<f32>(0.22, 0.34, 0.58) * (normal.y * 0.5 + 0.5);
  let groundAmbient = vec3<f32>(0.08, 0.065, 0.055) * (1.0 - max(normal.y, 0.0));
  let ambientOcclusionProxy = 0.58 + 0.42 * smoothstep(-0.5, 4.0, input.worldPos.y);
  let ambient = (skyAmbient + groundAmbient + vec3<f32>(0.035)) * baseColor * ambientOcclusionProxy;

  let rim = pow(1.0 - nDotV, 3.5) * vec3<f32>(0.08, 0.18, 0.34);
  let emissiveStrength = max(input.color.a - 1.0, 0.0);
  let emissive = baseColor * emissiveStrength * 2.2;
  var color = ambient + direct + rim + emissive;

  let distanceToCamera = length(scene.cameraPosTime.xyz - input.worldPos);
  let fogAmount = 1.0 - exp(-scene.fogColorDensity.w * distanceToCamera * distanceToCamera * 0.018);
  color = mix(color, scene.fogColorDensity.xyz, clamp(fogAmount, 0.0, 0.92));
  return vec4<f32>(color, 1.0);
}
`;

const shadowShader = /* wgsl */ `
${sceneUniformStruct}

@group(0) @binding(0)
var<uniform> scene : SceneUniforms;

struct VertexIn {
  @location(0) position : vec3<f32>,
  @location(1) normal : vec3<f32>,
  @location(2) m0 : vec4<f32>,
  @location(3) m1 : vec4<f32>,
  @location(4) m2 : vec4<f32>,
  @location(5) m3 : vec4<f32>,
  @location(6) color : vec4<f32>,
};

@vertex
fn vsMain(input : VertexIn) -> @builtin(position) vec4<f32> {
  let model = mat4x4<f32>(input.m0, input.m1, input.m2, input.m3);
  return scene.lightViewProj * model * vec4<f32>(input.position, 1.0);
}
`;

const surfaceShadowShader = /* wgsl */ `
${sceneUniformStruct}

@group(0) @binding(0)
var<uniform> scene : SceneUniforms;

struct VertexIn {
  @location(0) position : vec3<f32>,
  @location(1) normal : vec2<f32>,
  @location(2) color : vec4<f32>,
  @location(3) uv : vec2<f32>,
};

@vertex
fn vsMain(input : VertexIn) -> @builtin(position) vec4<f32> {
  return scene.lightViewProj * vec4<f32>(input.position, 1.0);
}
`;

const clothShader = /* wgsl */ `
${sceneUniformStruct}
${packedSurfaceDecode}

@group(0) @binding(0)
var<uniform> scene : SceneUniforms;

@group(0) @binding(1)
var shadowMap : texture_depth_2d;

@group(0) @binding(2)
var shadowSampler : sampler_comparison;

struct VertexIn {
  @location(0) position : vec3<f32>,
  @location(1) normal : vec2<f32>,
  @location(2) color : vec4<f32>,
  @location(3) uv : vec2<f32>,
};

struct VertexOut {
  @builtin(position) clipPosition : vec4<f32>,
  @location(0) worldNormal : vec3<f32>,
  @location(1) color : vec4<f32>,
  @location(2) worldPos : vec3<f32>,
  @location(3) shadowPosition : vec4<f32>,
  @location(4) uv : vec2<f32>,
};

@vertex
fn vsMain(input : VertexIn) -> VertexOut {
  var out : VertexOut;
  let world = vec4<f32>(input.position, 1.0);
  out.clipPosition = scene.viewProj * world;
  out.worldNormal = decodeOctNormal(input.normal);
  out.color = input.color;
  out.worldPos = input.position;
  out.shadowPosition = scene.lightViewProj * world;
  out.uv = input.uv;
  return out;
}

fn sampleSurfaceShadow(shadowPosition : vec4<f32>, normal : vec3<f32>, lightDirection : vec3<f32>) -> f32 {
  let projected = shadowPosition.xyz / max(shadowPosition.w, 0.0001);
  let uvUnclamped = vec2<f32>(projected.x * 0.5 + 0.5, 0.5 - projected.y * 0.5);
  let inBounds = select(0.0, 1.0,
    uvUnclamped.x > 0.0 && uvUnclamped.x < 1.0 &&
    uvUnclamped.y > 0.0 && uvUnclamped.y < 1.0 &&
    projected.z > 0.0 && projected.z < 1.0
  );
  let uv = clamp(uvUnclamped, vec2<f32>(0.0015), vec2<f32>(0.9985));
  let dimensions = vec2<f32>(textureDimensions(shadowMap));
  let texel = vec2<f32>(1.0) / dimensions;
  let nDotL = max(dot(normal, -lightDirection), 0.0);
  let bias = max(0.00018, 0.00145 * (1.0 - nDotL));
  let referenceDepth = clamp(projected.z - bias, 0.0, 1.0);
  var visibility = 0.0;
  for (var x : i32 = -1; x <= 1; x = x + 1) {
    for (var y : i32 = -1; y <= 1; y = y + 1) {
      let offset = vec2<f32>(f32(x), f32(y)) * texel * 1.2;
      visibility = visibility + textureSampleCompareLevel(shadowMap, shadowSampler, uv + offset, referenceDepth);
    }
  }
  return mix(1.0, visibility / 9.0, inBounds);
}

@fragment
fn fsMain(input : VertexOut, @builtin(front_facing) frontFacing : bool) -> @location(0) vec4<f32> {
  let geometricNormal = normalize(input.worldNormal);
  let normal = select(-geometricNormal, geometricNormal, frontFacing);
  let viewDirection = normalize(scene.cameraPosTime.xyz - input.worldPos);
  let lightDirection = normalize(scene.lightDirExposure.xyz);
  let toLight = -lightDirection;
  let halfVector = normalize(viewDirection + toLight);

  let warp = 0.5 + 0.5 * sin(input.uv.x * 1256.637 + input.uv.y * 7.0);
  let weft = 0.5 + 0.5 * sin(input.uv.y * 942.478 + input.uv.x * 5.0);
  let weave = mix(0.82, 1.12, warp * weft);
  let stress = clamp(input.color.a, 0.0, 1.0);
  let baseColor = pow(clamp(input.color.rgb * weave, vec3<f32>(0.0), vec3<f32>(1.0)), vec3<f32>(2.2));
  let nDotL = max(dot(normal, toLight), 0.0);
  let nDotV = max(dot(normal, viewDirection), 0.0);
  let nDotH = max(dot(normal, halfVector), 0.0);
  let visibility = mix(1.0, sampleSurfaceShadow(input.shadowPosition, normal, lightDirection), scene.viewportBloomShadow.w);

  let diffuse = baseColor * (vec3<f32>(0.16, 0.22, 0.34) + vec3<f32>(3.7, 3.35, 3.0) * nDotL * visibility);
  let fiberSpecular = pow(nDotH, mix(42.0, 115.0, warp)) * (0.16 + stress * 0.24) * visibility;
  let backLight = pow(max(dot(-normal, toLight), 0.0), 1.7) * baseColor * vec3<f32>(0.95, 0.38, 0.18) * 0.42;
  let rim = pow(1.0 - nDotV, 3.0) * mix(vec3<f32>(0.08, 0.22, 0.46), vec3<f32>(1.0, 0.12, 0.03), stress) * 0.65;
  let stressGlow = vec3<f32>(1.4, 0.05, 0.01) * pow(stress, 3.0) * 1.4;
  var color = diffuse + vec3<f32>(fiberSpecular) + backLight + rim + stressGlow;

  let distanceToCamera = length(scene.cameraPosTime.xyz - input.worldPos);
  let fogAmount = 1.0 - exp(-scene.fogColorDensity.w * distanceToCamera * distanceToCamera * 0.018);
  color = mix(color, scene.fogColorDensity.xyz, clamp(fogAmount, 0.0, 0.90));
  return vec4<f32>(color, 1.0);
}
`;

const clothGridShader = /* wgsl */ `
${sceneUniformStruct}

@group(0) @binding(0)
var<uniform> scene : SceneUniforms;

@group(0) @binding(1)
var shadowMap : texture_depth_2d;

@group(0) @binding(2)
var shadowSampler : sampler_comparison;

struct ClothGridUniforms {
  cols : u32,
  rows : u32,
  verticalLayout : u32,
  _padding0 : u32,
  baseColorA : vec4<f32>,
  baseColorB : vec4<f32>,
  checkerMaskX0 : u32,
  checkerMaskX1 : u32,
  checkerMaskY0 : u32,
  checkerMaskY1 : u32,
};

@group(1) @binding(0)
var<uniform> cloth : ClothGridUniforms;

@group(1) @binding(1)
var<storage, read> clothPositions : array<f32>;

@group(1) @binding(2)
var<storage, read> clothStrain : array<f32>;

fn positionAt(index : u32) -> vec3<f32> {
  let offset = index * 3u;
  return vec3<f32>(clothPositions[offset], clothPositions[offset + 1u], clothPositions[offset + 2u]);
}

fn uvAt(index : u32) -> vec2<f32> {
  let x = index % cloth.cols;
  let y = index / cloth.cols;
  return vec2<f32>(
    f32(x) / max(1.0, f32(cloth.cols - 1u)),
    f32(y) / max(1.0, f32(cloth.rows - 1u))
  );
}

fn normalAt(index : u32) -> vec3<f32> {
  let x = index % cloth.cols;
  let y = index / cloth.cols;
  let leftX = max(x, 1u) - 1u;
  let rightX = min(x + 1u, cloth.cols - 1u);
  let downY = max(y, 1u) - 1u;
  let upY = min(y + 1u, cloth.rows - 1u);
  let left = positionAt(y * cloth.cols + leftX);
  let right = positionAt(y * cloth.cols + rightX);
  let down = positionAt(downY * cloth.cols + x);
  let up = positionAt(upY * cloth.cols + x);
  var normal = cross(up - down, right - left);
  if (dot(normal, normal) <= 1e-18) {
    normal = select(vec3<f32>(0.0, 1.0, 0.0), vec3<f32>(0.0, 0.0, 1.0), cloth.verticalLayout != 0u);
  }
  return normalize(normal);
}

fn checkerMaskBit(first : u32, second : u32, index : u32) -> u32 {
  let word = select(first, second, index >= 32u);
  return (word >> (index & 31u)) & 1u;
}

fn colorAt(index : u32, uv : vec2<f32>) -> vec4<f32> {
  let x = index % cloth.cols;
  let y = index / cloth.cols;
  let checkerIndex = checkerMaskBit(cloth.checkerMaskX0, cloth.checkerMaskX1, x) ^
    checkerMaskBit(cloth.checkerMaskY0, cloth.checkerMaskY1, y);
  let checker = select(0.22, 0.78, checkerIndex != 0u);
  let base = mix(cloth.baseColorA.rgb, cloth.baseColorB.rgb, checker);
  let stress = clamp(clothStrain[index] * 3.2, 0.0, 1.0);
  let blend = stress * 0.72;
  return vec4<f32>(
    base.r + (1.0 - base.r) * blend,
    base.g + (0.14 - base.g) * blend,
    base.b + (0.03 - base.b) * blend,
    stress
  );
}

struct VertexOut {
  @builtin(position) clipPosition : vec4<f32>,
  @location(0) worldNormal : vec3<f32>,
  @location(1) color : vec4<f32>,
  @location(2) worldPos : vec3<f32>,
  @location(3) shadowPosition : vec4<f32>,
  @location(4) uv : vec2<f32>,
};

@vertex
fn vsMain(@builtin(vertex_index) vertexIndex : u32) -> VertexOut {
  let position = positionAt(vertexIndex);
  let world = vec4<f32>(position, 1.0);
  var out : VertexOut;
  out.clipPosition = scene.viewProj * world;
  out.worldNormal = normalAt(vertexIndex);
  out.color = colorAt(vertexIndex, uvAt(vertexIndex));
  out.worldPos = position;
  out.shadowPosition = scene.lightViewProj * world;
  out.uv = uvAt(vertexIndex);
  return out;
}

@vertex
fn vsShadow(@builtin(vertex_index) vertexIndex : u32) -> @builtin(position) vec4<f32> {
  return scene.lightViewProj * vec4<f32>(positionAt(vertexIndex), 1.0);
}

fn sampleSurfaceShadow(shadowPosition : vec4<f32>, normal : vec3<f32>, lightDirection : vec3<f32>) -> f32 {
  let projected = shadowPosition.xyz / max(shadowPosition.w, 0.0001);
  let uvUnclamped = vec2<f32>(projected.x * 0.5 + 0.5, 0.5 - projected.y * 0.5);
  let inBounds = select(0.0, 1.0,
    uvUnclamped.x > 0.0 && uvUnclamped.x < 1.0 &&
    uvUnclamped.y > 0.0 && uvUnclamped.y < 1.0 &&
    projected.z > 0.0 && projected.z < 1.0
  );
  let uv = clamp(uvUnclamped, vec2<f32>(0.0015), vec2<f32>(0.9985));
  let dimensions = vec2<f32>(textureDimensions(shadowMap));
  let texel = vec2<f32>(1.0) / dimensions;
  let nDotL = max(dot(normal, -lightDirection), 0.0);
  let bias = max(0.00018, 0.00145 * (1.0 - nDotL));
  let referenceDepth = clamp(projected.z - bias, 0.0, 1.0);
  var visibility = 0.0;
  for (var x : i32 = -1; x <= 1; x = x + 1) {
    for (var y : i32 = -1; y <= 1; y = y + 1) {
      let offset = vec2<f32>(f32(x), f32(y)) * texel * 1.2;
      visibility = visibility + textureSampleCompareLevel(shadowMap, shadowSampler, uv + offset, referenceDepth);
    }
  }
  return mix(1.0, visibility / 9.0, inBounds);
}

@fragment
fn fsMain(input : VertexOut, @builtin(front_facing) frontFacing : bool) -> @location(0) vec4<f32> {
  let geometricNormal = normalize(input.worldNormal);
  let normal = select(-geometricNormal, geometricNormal, frontFacing);
  let viewDirection = normalize(scene.cameraPosTime.xyz - input.worldPos);
  let lightDirection = normalize(scene.lightDirExposure.xyz);
  let toLight = -lightDirection;
  let halfVector = normalize(viewDirection + toLight);

  let warp = 0.5 + 0.5 * sin(input.uv.x * 1256.637 + input.uv.y * 7.0);
  let weft = 0.5 + 0.5 * sin(input.uv.y * 942.478 + input.uv.x * 5.0);
  let weave = mix(0.82, 1.12, warp * weft);
  let stress = clamp(input.color.a, 0.0, 1.0);
  let baseColor = pow(clamp(input.color.rgb * weave, vec3<f32>(0.0), vec3<f32>(1.0)), vec3<f32>(2.2));
  let nDotL = max(dot(normal, toLight), 0.0);
  let nDotV = max(dot(normal, viewDirection), 0.0);
  let nDotH = max(dot(normal, halfVector), 0.0);
  let visibility = mix(1.0, sampleSurfaceShadow(input.shadowPosition, normal, lightDirection), scene.viewportBloomShadow.w);

  let diffuse = baseColor * (vec3<f32>(0.16, 0.22, 0.34) + vec3<f32>(3.7, 3.35, 3.0) * nDotL * visibility);
  let fiberSpecular = pow(nDotH, mix(42.0, 115.0, warp)) * (0.16 + stress * 0.24) * visibility;
  let backLight = pow(max(dot(-normal, toLight), 0.0), 1.7) * baseColor * vec3<f32>(0.95, 0.38, 0.18) * 0.42;
  let rim = pow(1.0 - nDotV, 3.0) * mix(vec3<f32>(0.08, 0.22, 0.46), vec3<f32>(1.0, 0.12, 0.03), stress) * 0.65;
  let stressGlow = vec3<f32>(1.4, 0.05, 0.01) * pow(stress, 3.0) * 1.4;
  var color = diffuse + vec3<f32>(fiberSpecular) + backLight + rim + stressGlow;

  let distanceToCamera = length(scene.cameraPosTime.xyz - input.worldPos);
  let fogAmount = 1.0 - exp(-scene.fogColorDensity.w * distanceToCamera * distanceToCamera * 0.018);
  color = mix(color, scene.fogColorDensity.xyz, clamp(fogAmount, 0.0, 0.90));
  return vec4<f32>(color, 1.0);
}
`;

const waterShader = /* wgsl */ `
${sceneUniformStruct}
${packedSurfaceDecode}

@group(0) @binding(0)
var<uniform> scene : SceneUniforms;

@group(0) @binding(1)
var shadowMap : texture_depth_2d;

@group(0) @binding(2)
var shadowSampler : sampler_comparison;

struct VertexIn {
  @location(0) position : vec3<f32>,
  @location(1) normal : vec2<f32>,
  @location(2) color : vec4<f32>,
  @location(3) uv : vec2<f32>,
};

struct VertexOut {
  @builtin(position) clipPosition : vec4<f32>,
  @location(0) worldNormal : vec3<f32>,
  @location(1) color : vec4<f32>,
  @location(2) worldPos : vec3<f32>,
  @location(3) shadowPosition : vec4<f32>,
  @location(4) uv : vec2<f32>,
};

@vertex
fn vsMain(input : VertexIn) -> VertexOut {
  var out : VertexOut;
  let world = vec4<f32>(input.position, 1.0);
  out.clipPosition = scene.viewProj * world;
  out.worldNormal = decodeOctNormal(input.normal);
  out.color = input.color;
  out.worldPos = input.position;
  out.shadowPosition = scene.lightViewProj * world;
  out.uv = input.uv;
  return out;
}

fn sampleWaterShadow(shadowPosition : vec4<f32>, normal : vec3<f32>, lightDirection : vec3<f32>) -> f32 {
  let projected = shadowPosition.xyz / max(shadowPosition.w, 0.0001);
  let uvUnclamped = vec2<f32>(projected.x * 0.5 + 0.5, 0.5 - projected.y * 0.5);
  let inBounds = select(0.0, 1.0,
    uvUnclamped.x > 0.0 && uvUnclamped.x < 1.0 &&
    uvUnclamped.y > 0.0 && uvUnclamped.y < 1.0 &&
    projected.z > 0.0 && projected.z < 1.0
  );
  let uv = clamp(uvUnclamped, vec2<f32>(0.0015), vec2<f32>(0.9985));
  let dimensions = vec2<f32>(textureDimensions(shadowMap));
  let texel = vec2<f32>(1.0) / dimensions;
  let referenceDepth = clamp(projected.z - 0.00035, 0.0, 1.0);
  var visibility = 0.0;
  for (var x : i32 = -1; x <= 1; x = x + 1) {
    for (var y : i32 = -1; y <= 1; y = y + 1) {
      visibility = visibility + textureSampleCompareLevel(
        shadowMap,
        shadowSampler,
        uv + vec2<f32>(f32(x), f32(y)) * texel * 1.35,
        referenceDepth
      );
    }
  }
  return mix(1.0, visibility / 9.0, inBounds);
}

@fragment
fn fsMain(input : VertexOut, @builtin(front_facing) frontFacing : bool) -> @location(0) vec4<f32> {
  let geometricNormal = normalize(input.worldNormal);
  var normal = select(-geometricNormal, geometricNormal, frontFacing);
  let microA = sin(input.worldPos.x * 8.7 + scene.cameraPosTime.w * 1.3) * 0.018;
  let microB = cos(input.worldPos.z * 10.3 - scene.cameraPosTime.w * 1.1) * 0.018;
  normal = normalize(normal + vec3<f32>(microA, 0.0, microB));

  let viewDirection = normalize(scene.cameraPosTime.xyz - input.worldPos);
  let lightDirection = normalize(scene.lightDirExposure.xyz);
  let toLight = -lightDirection;
  let halfVector = normalize(viewDirection + toLight);
  let nDotV = max(dot(normal, viewDirection), 0.0);
  let nDotL = max(dot(normal, toLight), 0.0);
  let nDotH = max(dot(normal, halfVector), 0.0);
  let fresnel = 0.025 + 0.975 * pow(1.0 - nDotV, 5.0);
  let foam = clamp(input.color.a, 0.0, 1.0);
  let visibility = mix(1.0, sampleWaterShadow(input.shadowPosition, normal, lightDirection), scene.viewportBloomShadow.w * 0.7);

  let depthTint = pow(clamp(input.color.rgb, vec3<f32>(0.0), vec3<f32>(1.0)), vec3<f32>(2.2));
  let skyReflection = mix(vec3<f32>(0.05, 0.18, 0.34), vec3<f32>(0.34, 0.58, 0.92), clamp(normal.y * 0.5 + 0.5, 0.0, 1.0));
  let sunGlint = pow(nDotH, 230.0) * vec3<f32>(14.0, 10.5, 7.0) * visibility;
  let broadSpecular = pow(nDotH, 42.0) * vec3<f32>(1.4, 1.8, 2.4) * visibility;
  let subsurface = depthTint * (0.30 + 0.70 * nDotL) * vec3<f32>(0.26, 0.72, 0.86);
  let foamColor = vec3<f32>(0.82, 0.94, 1.0) * (0.75 + nDotL * 1.4);
  var color = mix(subsurface, skyReflection, fresnel) + sunGlint + broadSpecular;
  color = mix(color, foamColor, foam * 0.88);
  color = color + vec3<f32>(0.02, 0.16, 0.24) * (1.0 - nDotV) * 0.8;

  let distanceToCamera = length(scene.cameraPosTime.xyz - input.worldPos);
  let fogAmount = 1.0 - exp(-scene.fogColorDensity.w * distanceToCamera * distanceToCamera * 0.014);
  color = mix(color, scene.fogColorDensity.xyz, clamp(fogAmount, 0.0, 0.78));
  let alpha = clamp(0.56 + fresnel * 0.24 + foam * 0.20, 0.56, 0.96);
  return vec4<f32>(color, alpha);
}
`;

const waterGridShader = /* wgsl */ `
${sceneUniformStruct}

@group(0) @binding(0)
var<uniform> scene : SceneUniforms;

@group(0) @binding(1)
var shadowMap : texture_depth_2d;

@group(0) @binding(2)
var shadowSampler : sampler_comparison;

struct WaterGridUniforms {
  cols : u32,
  rows : u32,
  width : f32,
  depth : f32,
  baseY : f32,
  invTwoDx : f32,
  invTwoDz : f32,
  _padding : f32,
};

@group(1) @binding(0)
var<uniform> water : WaterGridUniforms;

@group(1) @binding(1)
var<storage, read> eta : array<f32>;

@group(1) @binding(2)
var<storage, read> velocityU : array<f32>;

@group(1) @binding(3)
var<storage, read> velocityV : array<f32>;

struct VertexOut {
  @builtin(position) clipPosition : vec4<f32>,
  @location(0) worldNormal : vec3<f32>,
  @location(1) color : vec4<f32>,
  @location(2) worldPos : vec3<f32>,
  @location(3) shadowPosition : vec4<f32>,
  @location(4) uv : vec2<f32>,
};

@vertex
fn vsMain(@builtin(vertex_index) vertexIndex : u32) -> VertexOut {
  let cols = max(water.cols, 2u);
  let rows = max(water.rows, 2u);
  let x = vertexIndex % cols;
  let z = min(vertexIndex / cols, rows - 1u);
  let xi = i32(x);
  let zi = i32(z);
  let maxX = i32(cols) - 1;
  let maxZ = i32(rows) - 1;
  let leftX = u32(max(xi - 1, 0));
  let rightX = u32(min(xi + 1, maxX));
  let downZ = u32(max(zi - 1, 0));
  let upZ = u32(min(zi + 1, maxZ));
  let row = z * cols;
  let i = row + x;
  let left = eta[row + leftX];
  let right = eta[row + rightX];
  let down = eta[downZ * cols + x];
  let up = eta[upZ * cols + x];
  let nx = -(right - left) * water.invTwoDx;
  let nz = -(up - down) * water.invTwoDz;
  let normal = normalize(vec3<f32>(nx, 1.0, nz));
  let laplacian = abs(left + right + down + up - 4.0 * eta[i]);
  let speed = length(vec2<f32>(velocityU[i], velocityV[i]));
  let foam = clamp(laplacian * 2.2 + speed * 0.22 - 0.08, 0.0, 1.0);
  let uv = vec2<f32>(f32(x) / f32(cols - 1u), f32(z) / f32(rows - 1u));
  let worldPosition = vec3<f32>(
    (uv.x - 0.5) * water.width,
    water.baseY + eta[i],
    (uv.y - 0.5) * water.depth
  );
  let world = vec4<f32>(worldPosition, 1.0);

  var out : VertexOut;
  out.clipPosition = scene.viewProj * world;
  out.worldNormal = normal;
  out.color = vec4<f32>(0.02 + foam * 0.38, 0.28 + foam * 0.55, 0.55 + foam * 0.42, foam);
  out.worldPos = worldPosition;
  out.shadowPosition = scene.lightViewProj * world;
  out.uv = uv;
  return out;
}

fn sampleWaterShadow(shadowPosition : vec4<f32>, normal : vec3<f32>, lightDirection : vec3<f32>) -> f32 {
  let projected = shadowPosition.xyz / max(shadowPosition.w, 0.0001);
  let uvUnclamped = vec2<f32>(projected.x * 0.5 + 0.5, 0.5 - projected.y * 0.5);
  let inBounds = select(0.0, 1.0,
    uvUnclamped.x > 0.0 && uvUnclamped.x < 1.0 &&
    uvUnclamped.y > 0.0 && uvUnclamped.y < 1.0 &&
    projected.z > 0.0 && projected.z < 1.0
  );
  let uv = clamp(uvUnclamped, vec2<f32>(0.0015), vec2<f32>(0.9985));
  let dimensions = vec2<f32>(textureDimensions(shadowMap));
  let texel = vec2<f32>(1.0) / dimensions;
  let referenceDepth = clamp(projected.z - 0.00035, 0.0, 1.0);
  var visibility = 0.0;
  for (var x : i32 = -1; x <= 1; x = x + 1) {
    for (var y : i32 = -1; y <= 1; y = y + 1) {
      visibility = visibility + textureSampleCompareLevel(
        shadowMap,
        shadowSampler,
        uv + vec2<f32>(f32(x), f32(y)) * texel * 1.35,
        referenceDepth
      );
    }
  }
  return mix(1.0, visibility / 9.0, inBounds);
}

@fragment
fn fsMain(input : VertexOut, @builtin(front_facing) frontFacing : bool) -> @location(0) vec4<f32> {
  let geometricNormal = normalize(input.worldNormal);
  var normal = select(-geometricNormal, geometricNormal, frontFacing);
  let microA = sin(input.worldPos.x * 8.7 + scene.cameraPosTime.w * 1.3) * 0.018;
  let microB = cos(input.worldPos.z * 10.3 - scene.cameraPosTime.w * 1.1) * 0.018;
  normal = normalize(normal + vec3<f32>(microA, 0.0, microB));

  let viewDirection = normalize(scene.cameraPosTime.xyz - input.worldPos);
  let lightDirection = normalize(scene.lightDirExposure.xyz);
  let toLight = -lightDirection;
  let halfVector = normalize(viewDirection + toLight);
  let nDotV = max(dot(normal, viewDirection), 0.0);
  let nDotL = max(dot(normal, toLight), 0.0);
  let nDotH = max(dot(normal, halfVector), 0.0);
  let fresnel = 0.025 + 0.975 * pow(1.0 - nDotV, 5.0);
  let foam = clamp(input.color.a, 0.0, 1.0);
  let visibility = mix(1.0, sampleWaterShadow(input.shadowPosition, normal, lightDirection), scene.viewportBloomShadow.w * 0.7);

  let depthTint = pow(clamp(input.color.rgb, vec3<f32>(0.0), vec3<f32>(1.0)), vec3<f32>(2.2));
  let skyReflection = mix(vec3<f32>(0.05, 0.18, 0.34), vec3<f32>(0.34, 0.58, 0.92), clamp(normal.y * 0.5 + 0.5, 0.0, 1.0));
  let sunGlint = pow(nDotH, 230.0) * vec3<f32>(14.0, 10.5, 7.0) * visibility;
  let broadSpecular = pow(nDotH, 42.0) * vec3<f32>(1.4, 1.8, 2.4) * visibility;
  let subsurface = depthTint * (0.30 + 0.70 * nDotL) * vec3<f32>(0.26, 0.72, 0.86);
  let foamColor = vec3<f32>(0.82, 0.94, 1.0) * (0.75 + nDotL * 1.4);
  var color = mix(subsurface, skyReflection, fresnel) + sunGlint + broadSpecular;
  color = mix(color, foamColor, foam * 0.88);
  color = color + vec3<f32>(0.02, 0.16, 0.24) * (1.0 - nDotV) * 0.8;

  let distanceToCamera = length(scene.cameraPosTime.xyz - input.worldPos);
  let fogAmount = 1.0 - exp(-scene.fogColorDensity.w * distanceToCamera * distanceToCamera * 0.014);
  color = mix(color, scene.fogColorDensity.xyz, clamp(fogAmount, 0.0, 0.78));
  let alpha = clamp(0.56 + fresnel * 0.24 + foam * 0.20, 0.56, 0.96);
  return vec4<f32>(color, alpha);
}
`;

const skyShader = /* wgsl */ `
${sceneUniformStruct}

@group(0) @binding(0)
var<uniform> scene : SceneUniforms;

struct VertexOut {
  @builtin(position) clipPosition : vec4<f32>,
  @location(0) uv : vec2<f32>,
};

@vertex
fn vsMain(@builtin(vertex_index) vertexIndex : u32) -> VertexOut {
  let positions = array<vec2<f32>, 3>(
    vec2<f32>(-1.0, -1.0),
    vec2<f32>(3.0, -1.0),
    vec2<f32>(-1.0, 3.0)
  );
  var out : VertexOut;
  let p = positions[vertexIndex];
  out.clipPosition = vec4<f32>(p, 0.9999, 1.0);
  out.uv = p * 0.5 + vec2<f32>(0.5);
  return out;
}

fn hash21(p : vec2<f32>) -> f32 {
  return fract(sin(dot(p, vec2<f32>(127.1, 311.7))) * 43758.5453123);
}

@fragment
fn fsMain(input : VertexOut) -> @location(0) vec4<f32> {
  let uv = input.uv;
  let top = vec3<f32>(0.006, 0.014, 0.035);
  let middle = vec3<f32>(0.035, 0.10, 0.19);
  let horizonColor = vec3<f32>(0.19, 0.25, 0.31);
  let vertical = clamp(uv.y, 0.0, 1.0);
  var color = mix(horizonColor, middle, smoothstep(0.0, 0.44, vertical));
  color = mix(color, top, smoothstep(0.42, 1.0, vertical));

  let lightDirection = normalize(scene.lightDirExposure.xyz);
  let sunPosition = vec2<f32>(0.68 - lightDirection.x * 0.22, 0.72 + lightDirection.y * 0.08);
  let sunDistance = distance(uv, sunPosition);
  let sunCore = exp(-sunDistance * sunDistance * 1400.0);
  let sunGlow = exp(-sunDistance * sunDistance * 42.0);
  color = color + vec3<f32>(8.0, 5.2, 2.6) * sunCore + vec3<f32>(0.55, 0.28, 0.12) * sunGlow;

  let starCell = floor(uv * vec2<f32>(1100.0, 620.0));
  let star = step(0.9978, hash21(starCell)) * smoothstep(0.5, 0.9, vertical);
  color = color + vec3<f32>(star * 1.8);

  let haze = pow(max(0.0, 1.0 - abs(vertical - 0.31) * 3.2), 4.0);
  color = color + vec3<f32>(0.12, 0.11, 0.09) * haze;
  return vec4<f32>(color, 1.0);
}
`;

const lineShader = /* wgsl */ `
${sceneUniformStruct}

@group(0) @binding(0)
var<uniform> scene : SceneUniforms;

struct VertexIn {
  @location(0) position : vec3<f32>,
  @location(1) color : vec4<f32>,
};

struct VertexOut {
  @builtin(position) clipPosition : vec4<f32>,
  @location(0) color : vec4<f32>,
};

@vertex
fn vsMain(input : VertexIn) -> VertexOut {
  var out : VertexOut;
  out.clipPosition = scene.viewProj * vec4<f32>(input.position, 1.0);
  out.color = input.color;
  return out;
}

@fragment
fn fsMain(input : VertexOut) -> @location(0) vec4<f32> {
  return vec4<f32>(input.color.rgb * 1.8, input.color.a);
}
`;

const postShader = /* wgsl */ `
${sceneUniformStruct}

@group(0) @binding(0)
var hdrTexture : texture_2d<f32>;

@group(0) @binding(1)
var hdrSampler : sampler;

@group(0) @binding(2)
var<uniform> scene : SceneUniforms;

struct VertexOut {
  @builtin(position) clipPosition : vec4<f32>,
  @location(0) uv : vec2<f32>,
};

@vertex
fn vsMain(@builtin(vertex_index) vertexIndex : u32) -> VertexOut {
  let positions = array<vec2<f32>, 3>(
    vec2<f32>(-1.0, -1.0),
    vec2<f32>(3.0, -1.0),
    vec2<f32>(-1.0, 3.0)
  );
  var out : VertexOut;
  let p = positions[vertexIndex];
  out.clipPosition = vec4<f32>(p, 0.0, 1.0);
  out.uv = p * 0.5 + vec2<f32>(0.5);
  return out;
}

fn acesFilm(x : vec3<f32>) -> vec3<f32> {
  let a = 2.51;
  let b = 0.03;
  let c = 2.43;
  let d = 0.59;
  let e = 0.14;
  return clamp((x * (a * x + vec3<f32>(b))) / (x * (c * x + vec3<f32>(d)) + vec3<f32>(e)), vec3<f32>(0.0), vec3<f32>(1.0));
}

fn hash21(p : vec2<f32>) -> f32 {
  return fract(sin(dot(p, vec2<f32>(127.1, 311.7))) * 43758.5453123);
}

@fragment
fn fsMain(input : VertexOut) -> @location(0) vec4<f32> {
  let uv = input.uv;
  let texel = vec2<f32>(1.0) / max(scene.viewportBloomShadow.xy, vec2<f32>(1.0));
  var color = textureSample(hdrTexture, hdrSampler, uv).rgb;

  let directions = array<vec2<f32>, 8>(
    vec2<f32>(1.0, 0.0), vec2<f32>(-1.0, 0.0),
    vec2<f32>(0.0, 1.0), vec2<f32>(0.0, -1.0),
    vec2<f32>(0.707, 0.707), vec2<f32>(-0.707, 0.707),
    vec2<f32>(0.707, -0.707), vec2<f32>(-0.707, -0.707)
  );

  var bloom = vec3<f32>(0.0);
  for (var i : i32 = 0; i < 8; i = i + 1) {
    let sampleColor = textureSample(hdrTexture, hdrSampler, uv + directions[i] * texel * 4.0).rgb;
    bloom = bloom + max(sampleColor - vec3<f32>(1.0), vec3<f32>(0.0));
  }
  bloom = bloom / 8.0;
  color = color + bloom * scene.viewportBloomShadow.z;
  color = color * scene.lightDirExposure.w;
  color = acesFilm(color);

  let centered = uv - vec2<f32>(0.5);
  let vignette = 1.0 - smoothstep(0.32, 0.78, length(centered)) * 0.34;
  color = color * vignette;

  let grain = (hash21(uv * scene.viewportBloomShadow.xy + scene.cameraPosTime.ww) - 0.5) * 0.018;
  color = clamp(color + vec3<f32>(grain), vec3<f32>(0.0), vec3<f32>(1.0));
  color = pow(color, vec3<f32>(1.0 / 2.2));
  return vec4<f32>(color, 1.0);
}
`;

function cubeVertexData(): Float32Array {
  return new Float32Array([
    1, -1, -1, 1, 0, 0,  1, 1, -1, 1, 0, 0,  1, 1, 1, 1, 0, 0,
    1, -1, -1, 1, 0, 0,  1, 1, 1, 1, 0, 0,  1, -1, 1, 1, 0, 0,
    -1, -1, 1, -1, 0, 0,  -1, 1, 1, -1, 0, 0,  -1, 1, -1, -1, 0, 0,
    -1, -1, 1, -1, 0, 0,  -1, 1, -1, -1, 0, 0,  -1, -1, -1, -1, 0, 0,
    -1, 1, -1, 0, 1, 0,  -1, 1, 1, 0, 1, 0,  1, 1, 1, 0, 1, 0,
    -1, 1, -1, 0, 1, 0,  1, 1, 1, 0, 1, 0,  1, 1, -1, 0, 1, 0,
    -1, -1, 1, 0, -1, 0,  -1, -1, -1, 0, -1, 0,  1, -1, -1, 0, -1, 0,
    -1, -1, 1, 0, -1, 0,  1, -1, -1, 0, -1, 0,  1, -1, 1, 0, -1, 0,
    1, -1, 1, 0, 0, 1,  1, 1, 1, 0, 0, 1,  -1, 1, 1, 0, 0, 1,
    1, -1, 1, 0, 0, 1,  -1, 1, 1, 0, 0, 1,  -1, -1, 1, 0, 0, 1,
    -1, -1, -1, 0, 0, -1,  -1, 1, -1, 0, 0, -1,  1, 1, -1, 0, 0, -1,
    -1, -1, -1, 0, 0, -1,  1, 1, -1, 0, 0, -1,  1, -1, -1, 0, 0, -1,
  ]);
}

function ptrToNumber(ptr: number | bigint): number {
  return typeof ptr === 'bigint' ? Number(ptr) : ptr;
}

function writeFloatBuffer(
  queue: GPUQueue,
  buffer: GPUBuffer,
  offset: number,
  data: Float32Array,
  floatCount = data.length,
  sourceFloatOffset = 0,
): void {
  const safeCount = Math.max(0, Math.min(floatCount, data.length - sourceFloatOffset));
  if (safeCount === 0) return;
  queue.writeBuffer(
    buffer,
    offset,
    data.buffer as unknown as BufferSource,
    data.byteOffset + sourceFloatOffset * Float32Array.BYTES_PER_ELEMENT,
    safeCount * Float32Array.BYTES_PER_ELEMENT,
  );
}

function writeByteBuffer(
  queue: GPUQueue,
  buffer: GPUBuffer,
  offset: number,
  data: ArrayBufferView,
  byteCount = data.byteLength,
  sourceByteOffset = 0,
): void {
  const safeCount = Math.max(0, Math.min(byteCount, data.byteLength - sourceByteOffset));
  if (safeCount === 0) return;
  queue.writeBuffer(buffer, offset, data.buffer as unknown as BufferSource, data.byteOffset + sourceByteOffset, safeCount);
}

function fillLineVertexData(lines: readonly DebugLine[], maxVertices: number, out: Float32Array): number {
  const maxFloats = Math.min(out.length, Math.min(maxVertices, lines.length * 2) * 7);
  let cursor = 0;
  for (let i = 0; i < lines.length && cursor + 14 <= maxFloats; i++) {
    const line = lines[i];
    out[cursor++] = line.ax;
    out[cursor++] = line.ay;
    out[cursor++] = line.az;
    out[cursor++] = line.r;
    out[cursor++] = line.g;
    out[cursor++] = line.b;
    out[cursor++] = line.a;
    out[cursor++] = line.bx;
    out[cursor++] = line.by;
    out[cursor++] = line.bz;
    out[cursor++] = line.r;
    out[cursor++] = line.g;
    out[cursor++] = line.b;
    out[cursor++] = line.a;
  }
  return cursor;
}

function instanceVertexBuffers(): GPUVertexBufferLayout[] {
  return [
    {
      arrayStride: 6 * 4,
      stepMode: 'vertex',
      attributes: [
        { shaderLocation: 0, offset: 0, format: 'float32x3' },
        { shaderLocation: 1, offset: 3 * 4, format: 'float32x3' },
      ],
    },
    {
      arrayStride: 16 * 4,
      stepMode: 'instance',
      attributes: [
        { shaderLocation: 2, offset: 0, format: 'float32x4' },
        { shaderLocation: 3, offset: 4 * 4, format: 'float32x4' },
        { shaderLocation: 4, offset: 8 * 4, format: 'float32x4' },
        { shaderLocation: 5, offset: 12 * 4, format: 'float32x4' },
      ],
    },
    {
      arrayStride: 4 * 4,
      stepMode: 'instance',
      attributes: [{ shaderLocation: 6, offset: 0, format: 'float32x4' }],
    },
  ];
}


function surfaceVertexBuffers(): GPUVertexBufferLayout[] {
  return [{
    arrayStride: SURFACE_VERTEX_BYTES,
    stepMode: 'vertex',
    attributes: [
      { shaderLocation: 0, offset: 0, format: 'float32x3' },
      { shaderLocation: 1, offset: 12, format: 'snorm16x2' },
      { shaderLocation: 2, offset: 16, format: 'unorm8x4' },
      { shaderLocation: 3, offset: 20, format: 'unorm16x2' },
    ],
  }];
}

async function validateShaderModule(module: GPUShaderModule, label: string): Promise<void> {
  if (!module.getCompilationInfo) return;
  const info = await module.getCompilationInfo();
  const errors = info.messages.filter((message) => message.type === 'error');
  const warnings = info.messages.filter((message) => message.type === 'warning');
  if (warnings.length > 0) {
    console.warn(`[WebGPU] ${label} warnings:
${warnings.map((message) => `${message.lineNum}:${message.linePos} ${message.message}`).join('\n')}`);
  }
  if (errors.length > 0) {
    throw new Error(`${label} failed WGSL validation:
${errors.map((message) => `${message.lineNum}:${message.linePos} ${message.message}`).join('\n')}`);
  }
}

export class WebGPURenderer {
  readonly canvas: HTMLCanvasElement;
  readonly device: GPUDevice;
  readonly context: GPUCanvasContext;
  readonly format: GPUTextureFormat;
  readonly maxInstances: number;

  private shadowPipeline: GPURenderPipeline;
  private surfaceShadowPipeline: GPURenderPipeline;
  private skyPipeline: GPURenderPipeline;
  private clothPipeline: GPURenderPipeline;
  private clothGridPipeline: GPURenderPipeline;
  private clothGridShadowPipeline: GPURenderPipeline;
  private waterPipeline: GPURenderPipeline;
  private waterGridPipeline: GPURenderPipeline;
  private solidPipeline: GPURenderPipeline;
  private linePipeline: GPURenderPipeline;
  private postPipeline: GPURenderPipeline;
  private shadowBindGroup: GPUBindGroup;
  private sceneBindGroup: GPUBindGroup;
  private clothGridBindGroup: GPUBindGroup;
  private waterGridBindGroup: GPUBindGroup;
  private postBindGroup: GPUBindGroup | null = null;
  private postBindGroupLayout: GPUBindGroupLayout;
  private uniformBuffer: GPUBuffer;
  private vertexBuffer: GPUBuffer;
  private matrixBuffer: GPUBuffer;
  private colorBuffer: GPUBuffer;
  private lineBuffer: GPUBuffer;
  private surfaceVertexBuffer: GPUBuffer;
  private surfaceIndexBuffer: GPUBuffer;
  private clothPositionBuffer: GPUBuffer;
  private clothStrainBuffer: GPUBuffer;
  private clothGridUniformBuffer: GPUBuffer;
  private clothGridIndexBuffer: GPUBuffer;
  private clothGridVertexCount = 0;
  private clothGridIndexCount = 0;
  private clothGridActive = false;
  private clothGridFrameVersion = -1;
  private clothGridTopologyVersion = -1;
  private clothGridPositionIdentity: ArrayBufferLike | null = null;
  private clothGridPositionByteOffset = -1;
  private clothGridStrainIdentity: ArrayBufferLike | null = null;
  private clothGridStrainByteOffset = -1;
  private clothGridIndexIdentity: ArrayBufferLike | null = null;
  private clothGridIndexByteOffset = -1;
  private clothGridCachedIndexCount = 0;
  private clothGridUniformKey = '';
  private waterEtaBuffer: GPUBuffer;
  private waterUBuffer: GPUBuffer;
  private waterVBuffer: GPUBuffer;
  private waterGridUniformBuffer: GPUBuffer;
  private waterGridIndexBuffer: GPUBuffer;
  private waterGridVertexCount = 0;
  private waterGridIndexCount = 0;
  private waterGridActive = false;
  private waterGridFrameVersion = -1;
  private waterGridTopologyVersion = -1;
  private waterGridEtaIdentity: ArrayBufferLike | null = null;
  private waterGridEtaByteOffset = -1;
  private waterGridUIdentity: ArrayBufferLike | null = null;
  private waterGridUByteOffset = -1;
  private waterGridVIdentity: ArrayBufferLike | null = null;
  private waterGridVByteOffset = -1;
  private waterGridIndexIdentity: ArrayBufferLike | null = null;
  private waterGridIndexByteOffset = -1;
  private waterGridCachedIndexCount = 0;
  private waterGridUniformKey = '';
  private surfaceVertexCount = 0;
  private surfaceIndexCount = 0;
  private surfaceMaterial: DynamicSurfaceFrame['material'] | null = null;
  private surfaceVertexBufferIdentity: ArrayBufferLike | null = null;
  private surfaceVertexByteOffset = -1;
  private surfaceFrameVersion = -1;
  private surfaceCachedVertexCount = 0;
  private surfaceIndexBufferIdentity: ArrayBufferLike | null = null;
  private surfaceIndexByteOffset = -1;
  private surfaceTopologyVersion = -1;
  private surfaceCachedIndexCount = 0;
  private shadowTexture: GPUTexture;
  private shadowView: GPUTextureView;
  private shadowSampler: GPUSampler;
  private linearSampler: GPUSampler;
  private materialNoiseTexture: GPUTexture;
  private materialNoiseInfo: Pick<MaterialNoiseTexture, 'compressed' | 'sourceBytes' | 'source'>;
  private depthTexture: GPUTexture | null = null;
  private depthView: GPUTextureView | null = null;
  private msaaTexture: GPUTexture | null = null;
  private msaaView: GPUTextureView | null = null;
  private hdrTexture: GPUTexture | null = null;
  private hdrView: GPUTextureView | null = null;
  private width = 0;
  private height = 0;
  private resolutionScale = 1;
  private lastUploadedBytes = 0;
  private uniformScratch = new Float32Array(SCENE_UNIFORM_FLOATS);
  private readonly lineScratch = new Float32Array(MAX_DEBUG_LINE_VERTICES * 7);
  private readonly surfaceIndexUploadScratch = new Uint8Array(MAX_DYNAMIC_SURFACE_INDICES * Uint16Array.BYTES_PER_ELEMENT + 4);
  private readonly clothGridUniformScratch = new ArrayBuffer(CLOTH_GRID_UNIFORM_BYTES);
  private readonly waterGridUniformScratch = new ArrayBuffer(WATER_GRID_UNIFORM_BYTES);

  private constructor(args: {
    canvas: HTMLCanvasElement;
    device: GPUDevice;
    context: GPUCanvasContext;
    format: GPUTextureFormat;
    maxInstances: number;
    shadowPipeline: GPURenderPipeline;
    surfaceShadowPipeline: GPURenderPipeline;
    skyPipeline: GPURenderPipeline;
    solidPipeline: GPURenderPipeline;
    clothPipeline: GPURenderPipeline;
    clothGridPipeline: GPURenderPipeline;
    clothGridShadowPipeline: GPURenderPipeline;
    waterPipeline: GPURenderPipeline;
    waterGridPipeline: GPURenderPipeline;
    linePipeline: GPURenderPipeline;
    postPipeline: GPURenderPipeline;
    shadowBindGroup: GPUBindGroup;
    sceneBindGroup: GPUBindGroup;
    clothGridBindGroup: GPUBindGroup;
    waterGridBindGroup: GPUBindGroup;
    postBindGroupLayout: GPUBindGroupLayout;
    uniformBuffer: GPUBuffer;
    vertexBuffer: GPUBuffer;
    matrixBuffer: GPUBuffer;
    colorBuffer: GPUBuffer;
    lineBuffer: GPUBuffer;
    surfaceVertexBuffer: GPUBuffer;
    surfaceIndexBuffer: GPUBuffer;
    clothPositionBuffer: GPUBuffer;
    clothStrainBuffer: GPUBuffer;
    clothGridUniformBuffer: GPUBuffer;
    clothGridIndexBuffer: GPUBuffer;
    waterEtaBuffer: GPUBuffer;
    waterUBuffer: GPUBuffer;
    waterVBuffer: GPUBuffer;
    waterGridUniformBuffer: GPUBuffer;
    waterGridIndexBuffer: GPUBuffer;
    shadowTexture: GPUTexture;
    shadowView: GPUTextureView;
    shadowSampler: GPUSampler;
    linearSampler: GPUSampler;
    materialNoise: MaterialNoiseTexture;
  }) {
    this.canvas = args.canvas;
    this.device = args.device;
    this.context = args.context;
    this.format = args.format;
    this.maxInstances = args.maxInstances;
    this.shadowPipeline = args.shadowPipeline;
    this.surfaceShadowPipeline = args.surfaceShadowPipeline;
    this.skyPipeline = args.skyPipeline;
    this.solidPipeline = args.solidPipeline;
    this.clothPipeline = args.clothPipeline;
    this.clothGridPipeline = args.clothGridPipeline;
    this.clothGridShadowPipeline = args.clothGridShadowPipeline;
    this.waterPipeline = args.waterPipeline;
    this.waterGridPipeline = args.waterGridPipeline;
    this.linePipeline = args.linePipeline;
    this.postPipeline = args.postPipeline;
    this.shadowBindGroup = args.shadowBindGroup;
    this.sceneBindGroup = args.sceneBindGroup;
    this.clothGridBindGroup = args.clothGridBindGroup;
    this.waterGridBindGroup = args.waterGridBindGroup;
    this.postBindGroupLayout = args.postBindGroupLayout;
    this.uniformBuffer = args.uniformBuffer;
    this.vertexBuffer = args.vertexBuffer;
    this.matrixBuffer = args.matrixBuffer;
    this.colorBuffer = args.colorBuffer;
    this.lineBuffer = args.lineBuffer;
    this.surfaceVertexBuffer = args.surfaceVertexBuffer;
    this.surfaceIndexBuffer = args.surfaceIndexBuffer;
    this.clothPositionBuffer = args.clothPositionBuffer;
    this.clothStrainBuffer = args.clothStrainBuffer;
    this.clothGridUniformBuffer = args.clothGridUniformBuffer;
    this.clothGridIndexBuffer = args.clothGridIndexBuffer;
    this.waterEtaBuffer = args.waterEtaBuffer;
    this.waterUBuffer = args.waterUBuffer;
    this.waterVBuffer = args.waterVBuffer;
    this.waterGridUniformBuffer = args.waterGridUniformBuffer;
    this.waterGridIndexBuffer = args.waterGridIndexBuffer;
    this.shadowTexture = args.shadowTexture;
    this.shadowView = args.shadowView;
    this.shadowSampler = args.shadowSampler;
    this.linearSampler = args.linearSampler;
    this.materialNoiseTexture = args.materialNoise.texture;
    this.materialNoiseInfo = { compressed: args.materialNoise.compressed, sourceBytes: args.materialNoise.sourceBytes, source: args.materialNoise.source };
  }

  static async create(canvas: HTMLCanvasElement, maxInstances: number): Promise<WebGPURenderer> {
    if (!navigator.gpu) {
      throw new Error('navigator.gpu is unavailable. Open this over localhost/HTTPS in a WebGPU-capable browser.');
    }

    const adapter = await navigator.gpu.requestAdapter({ powerPreference: 'high-performance' });
    if (!adapter) throw new Error('No WebGPU adapter was returned by the browser.');
    const supportsBc = adapter.features?.has('texture-compression-bc') ?? false;
    const device = await adapter.requestDevice({ requiredFeatures: supportsBc ? ['texture-compression-bc'] : [] });
    // Texture fetch/decode/upload is independent of buffer and shader setup.
    // Keep it in flight while the renderer builds its layouts and pipelines.
    const materialNoisePromise = loadMaterialNoiseTexture(device, supportsBc);
    const context = canvas.getContext('webgpu');
    if (!context) throw new Error('Could not create a webgpu canvas context.');

    const format = navigator.gpu.getPreferredCanvasFormat();
    context.configure({ device, format, alphaMode: 'opaque' });

    const cube = cubeVertexData();
    const vertexBuffer = device.createBuffer({ label: 'AAA cube vertices', size: cube.byteLength, usage: GPUBufferUsage.VERTEX | GPUBufferUsage.COPY_DST });
    writeFloatBuffer(device.queue, vertexBuffer, 0, cube);

    const matrixBuffer = device.createBuffer({ label: 'AAA model matrices', size: maxInstances * 16 * 4, usage: GPUBufferUsage.VERTEX | GPUBufferUsage.COPY_DST });
    const colorBuffer = device.createBuffer({ label: 'AAA instance colors/material tags', size: maxInstances * 4 * 4, usage: GPUBufferUsage.VERTEX | GPUBufferUsage.COPY_DST });
    const uniformBuffer = device.createBuffer({ label: 'AAA scene uniforms', size: SCENE_UNIFORM_BYTES, usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST });
    const lineBuffer = device.createBuffer({ label: 'AAA debug/effect lines', size: MAX_DEBUG_LINE_VERTICES * 7 * 4, usage: GPUBufferUsage.VERTEX | GPUBufferUsage.COPY_DST });
    const surfaceVertexBuffer = device.createBuffer({
      label: 'AAA dynamic cloth/water vertices',
      size: MAX_DYNAMIC_SURFACE_VERTICES * SURFACE_VERTEX_BYTES,
      usage: GPUBufferUsage.VERTEX | GPUBufferUsage.COPY_DST,
    });
    const surfaceIndexBuffer = device.createBuffer({
      label: 'AAA dynamic cloth/water indices',
      size: MAX_DYNAMIC_SURFACE_INDICES * Uint16Array.BYTES_PER_ELEMENT,
      usage: GPUBufferUsage.INDEX | GPUBufferUsage.COPY_DST,
    });
    const clothPositionBuffer = device.createBuffer({
      label: 'AAA GPU cloth positions',
      size: MAX_DYNAMIC_SURFACE_VERTICES * 3 * Float32Array.BYTES_PER_ELEMENT,
      usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_DST,
    });
    const clothStrainBuffer = device.createBuffer({
      label: 'AAA GPU cloth strain',
      size: MAX_DYNAMIC_SURFACE_VERTICES * Float32Array.BYTES_PER_ELEMENT,
      usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_DST,
    });
    const clothGridUniformBuffer = device.createBuffer({
      label: 'AAA GPU cloth grid uniforms',
      size: CLOTH_GRID_UNIFORM_BYTES,
      usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST,
    });
    const clothGridIndexBuffer = device.createBuffer({
      label: 'AAA GPU cloth static topology',
      size: MAX_DYNAMIC_SURFACE_INDICES * Uint16Array.BYTES_PER_ELEMENT,
      usage: GPUBufferUsage.INDEX | GPUBufferUsage.COPY_DST,
    });
    const waterEtaBuffer = device.createBuffer({
      label: 'AAA GPU water height field',
      size: MAX_DYNAMIC_SURFACE_VERTICES * Float32Array.BYTES_PER_ELEMENT,
      usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_DST,
    });
    const waterUBuffer = device.createBuffer({
      label: 'AAA GPU water X velocity',
      size: MAX_DYNAMIC_SURFACE_VERTICES * Float32Array.BYTES_PER_ELEMENT,
      usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_DST,
    });
    const waterVBuffer = device.createBuffer({
      label: 'AAA GPU water Z velocity',
      size: MAX_DYNAMIC_SURFACE_VERTICES * Float32Array.BYTES_PER_ELEMENT,
      usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_DST,
    });
    const waterGridUniformBuffer = device.createBuffer({
      label: 'AAA GPU water grid uniforms',
      size: WATER_GRID_UNIFORM_BYTES,
      usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST,
    });
    const waterGridIndexBuffer = device.createBuffer({
      label: 'AAA GPU water static topology',
      size: MAX_DYNAMIC_SURFACE_INDICES * Uint16Array.BYTES_PER_ELEMENT,
      usage: GPUBufferUsage.INDEX | GPUBufferUsage.COPY_DST,
    });

    const shadowTexture = device.createTexture({
      label: 'AAA 2048 shadow map',
      size: [SHADOW_MAP_SIZE, SHADOW_MAP_SIZE],
      format: 'depth32float',
      usage: GPUTextureUsage.RENDER_ATTACHMENT | GPUTextureUsage.TEXTURE_BINDING,
    });
    const shadowView = shadowTexture.createView();
    const shadowSampler = device.createSampler({
      label: 'AAA comparison sampler',
      compare: 'less',
      magFilter: 'linear',
      minFilter: 'linear',
      addressModeU: 'clamp-to-edge',
      addressModeV: 'clamp-to-edge',
    });
    const linearSampler = device.createSampler({
      label: 'AAA HDR linear sampler',
      magFilter: 'linear',
      minFilter: 'linear',
      addressModeU: 'clamp-to-edge',
      addressModeV: 'clamp-to-edge',
    });

    // The depth map cannot be sampled from the same synchronization scope in
    // which it is written. The shadow pass therefore gets a uniform-only bind
    // group instead of reusing the main scene bind group that contains the
    // shadow texture and comparison sampler.
    const shadowBindGroupLayout = device.createBindGroupLayout({
      label: 'AAA shadow uniform layout',
      entries: [
        { binding: 0, visibility: GPUShaderStage.VERTEX, buffer: { type: 'uniform' } },
      ],
    });
    const shadowBindGroup = device.createBindGroup({
      label: 'AAA shadow uniform bind group',
      layout: shadowBindGroupLayout,
      entries: [{ binding: 0, resource: { buffer: uniformBuffer } }],
    });
    const shadowLayout = device.createPipelineLayout({
      label: 'AAA shadow pipeline layout',
      bindGroupLayouts: [shadowBindGroupLayout],
    });

    const sceneBindGroupLayout = device.createBindGroupLayout({
      label: 'AAA scene layout',
      entries: [
        { binding: 0, visibility: GPUShaderStage.VERTEX | GPUShaderStage.FRAGMENT, buffer: { type: 'uniform' } },
        { binding: 1, visibility: GPUShaderStage.FRAGMENT, texture: { sampleType: 'depth', viewDimension: '2d' } },
        { binding: 2, visibility: GPUShaderStage.FRAGMENT, sampler: { type: 'comparison' } },
        { binding: 3, visibility: GPUShaderStage.FRAGMENT, texture: { sampleType: 'float', viewDimension: '2d' } },
        { binding: 4, visibility: GPUShaderStage.FRAGMENT, sampler: { type: 'filtering' } },
      ],
    });
    const sceneLayout = device.createPipelineLayout({ label: 'AAA scene pipeline layout', bindGroupLayouts: [sceneBindGroupLayout] });

    const clothGridBindGroupLayout = device.createBindGroupLayout({
      label: 'AAA GPU cloth grid layout',
      entries: [
        { binding: 0, visibility: GPUShaderStage.VERTEX, buffer: { type: 'uniform' } },
        { binding: 1, visibility: GPUShaderStage.VERTEX, buffer: { type: 'read-only-storage' } },
        { binding: 2, visibility: GPUShaderStage.VERTEX, buffer: { type: 'read-only-storage' } },
      ],
    });
    const clothGridLayout = device.createPipelineLayout({
      label: 'AAA GPU cloth pipeline layout',
      bindGroupLayouts: [sceneBindGroupLayout, clothGridBindGroupLayout],
    });
    const clothGridShadowLayout = device.createPipelineLayout({
      label: 'AAA GPU cloth shadow pipeline layout',
      bindGroupLayouts: [shadowBindGroupLayout, clothGridBindGroupLayout],
    });

    const waterGridBindGroupLayout = device.createBindGroupLayout({
      label: 'AAA GPU water grid layout',
      entries: [
        { binding: 0, visibility: GPUShaderStage.VERTEX, buffer: { type: 'uniform' } },
        { binding: 1, visibility: GPUShaderStage.VERTEX, buffer: { type: 'read-only-storage' } },
        { binding: 2, visibility: GPUShaderStage.VERTEX, buffer: { type: 'read-only-storage' } },
        { binding: 3, visibility: GPUShaderStage.VERTEX, buffer: { type: 'read-only-storage' } },
      ],
    });
    const waterGridLayout = device.createPipelineLayout({
      label: 'AAA GPU water pipeline layout',
      bindGroupLayouts: [sceneBindGroupLayout, waterGridBindGroupLayout],
    });

    const postBindGroupLayout = device.createBindGroupLayout({
      label: 'AAA post layout',
      entries: [
        { binding: 0, visibility: GPUShaderStage.FRAGMENT, texture: { sampleType: 'float', viewDimension: '2d' } },
        { binding: 1, visibility: GPUShaderStage.FRAGMENT, sampler: { type: 'filtering' } },
        { binding: 2, visibility: GPUShaderStage.VERTEX | GPUShaderStage.FRAGMENT, buffer: { type: 'uniform' } },
      ],
    });
    const postLayout = device.createPipelineLayout({ label: 'AAA post pipeline layout', bindGroupLayouts: [postBindGroupLayout] });

    const shadowModule = device.createShaderModule({ label: 'AAA shadow shader', code: shadowShader });
    const surfaceShadowModule = device.createShaderModule({ label: 'AAA dynamic surface shadow shader', code: surfaceShadowShader });
    const clothModule = device.createShaderModule({ label: 'AAA woven cloth shader', code: clothShader });
    const clothGridModule = device.createShaderModule({ label: 'AAA GPU-resident cloth shader', code: clothGridShader });
    const waterModule = device.createShaderModule({ label: 'AAA interactive water shader', code: waterShader });
    const waterGridModule = device.createShaderModule({ label: 'AAA GPU-resident water shader', code: waterGridShader });
    const skyModule = device.createShaderModule({ label: 'AAA atmospheric sky shader', code: skyShader });
    const solidModule = device.createShaderModule({ label: 'AAA PBR solid shader', code: solidShader });
    const lineModule = device.createShaderModule({ label: 'AAA line shader', code: lineShader });
    const postModule = device.createShaderModule({ label: 'AAA bloom and tone map shader', code: postShader });

    // Compilation diagnostics are independent. Resolve them in parallel, then
    // use asynchronous pipeline creation to avoid a first-frame compilation
    // stall. Browsers without the async method retain the validated sync path.
    await Promise.all([
      validateShaderModule(shadowModule, 'Shadow shader'),
      validateShaderModule(surfaceShadowModule, 'Dynamic surface shadow shader'),
      validateShaderModule(clothModule, 'Woven cloth shader'),
      validateShaderModule(clothGridModule, 'GPU-resident cloth shader'),
      validateShaderModule(waterModule, 'Interactive water shader'),
      validateShaderModule(waterGridModule, 'GPU-resident water shader'),
      validateShaderModule(skyModule, 'Atmospheric sky shader'),
      validateShaderModule(solidModule, 'PBR solid shader'),
      validateShaderModule(lineModule, 'Line shader'),
      validateShaderModule(postModule, 'Post-processing shader'),
    ]);

    const shadowDescriptor: GPURenderPipelineDescriptor = {
      label: 'AAA shadow map pipeline',
      layout: shadowLayout,
      vertex: { module: shadowModule, entryPoint: 'vsMain', buffers: instanceVertexBuffers() },
      primitive: { topology: 'triangle-list', cullMode: 'front' },
      depthStencil: { format: 'depth32float', depthWriteEnabled: true, depthCompare: 'less' },
    };
    const surfaceShadowDescriptor: GPURenderPipelineDescriptor = {
      label: 'AAA cloth surface shadow pipeline',
      layout: shadowLayout,
      vertex: { module: surfaceShadowModule, entryPoint: 'vsMain', buffers: surfaceVertexBuffers() },
      primitive: { topology: 'triangle-list', cullMode: 'none' },
      depthStencil: { format: 'depth32float', depthWriteEnabled: true, depthCompare: 'less' },
    };
    const clothDescriptor: GPURenderPipelineDescriptor = {
      label: 'AAA dynamic woven cloth pipeline',
      layout: sceneLayout,
      vertex: { module: clothModule, entryPoint: 'vsMain', buffers: surfaceVertexBuffers() },
      fragment: { module: clothModule, entryPoint: 'fsMain', targets: [{ format: HDR_FORMAT }] },
      primitive: { topology: 'triangle-list', cullMode: 'none' },
      depthStencil: { format: 'depth24plus', depthWriteEnabled: true, depthCompare: 'less-equal' },
      multisample: { count: MSAA_SAMPLE_COUNT },
    };
    const clothGridShadowDescriptor: GPURenderPipelineDescriptor = {
      label: 'AAA GPU cloth shadow pipeline',
      layout: clothGridShadowLayout,
      vertex: { module: clothGridModule, entryPoint: 'vsShadow' },
      primitive: { topology: 'triangle-list', cullMode: 'none' },
      depthStencil: { format: 'depth32float', depthWriteEnabled: true, depthCompare: 'less' },
    };
    const clothGridDescriptor: GPURenderPipelineDescriptor = {
      label: 'AAA GPU-resident woven cloth pipeline',
      layout: clothGridLayout,
      vertex: { module: clothGridModule, entryPoint: 'vsMain' },
      fragment: { module: clothGridModule, entryPoint: 'fsMain', targets: [{ format: HDR_FORMAT }] },
      primitive: { topology: 'triangle-list', cullMode: 'none' },
      depthStencil: { format: 'depth24plus', depthWriteEnabled: true, depthCompare: 'less-equal' },
      multisample: { count: MSAA_SAMPLE_COUNT },
    };
    const waterDescriptor: GPURenderPipelineDescriptor = {
      label: 'AAA interactive translucent water pipeline',
      layout: sceneLayout,
      vertex: { module: waterModule, entryPoint: 'vsMain', buffers: surfaceVertexBuffers() },
      fragment: {
        module: waterModule,
        entryPoint: 'fsMain',
        targets: [{
          format: HDR_FORMAT,
          blend: {
            color: { srcFactor: 'src-alpha', dstFactor: 'one-minus-src-alpha', operation: 'add' },
            alpha: { srcFactor: 'one', dstFactor: 'one-minus-src-alpha', operation: 'add' },
          },
        }],
      },
      primitive: { topology: 'triangle-list', cullMode: 'none' },
      depthStencil: { format: 'depth24plus', depthWriteEnabled: false, depthCompare: 'less-equal' },
      multisample: { count: MSAA_SAMPLE_COUNT },
    };
    const waterGridDescriptor: GPURenderPipelineDescriptor = {
      label: 'AAA GPU-resident interactive water pipeline',
      layout: waterGridLayout,
      vertex: { module: waterGridModule, entryPoint: 'vsMain' },
      fragment: {
        module: waterGridModule,
        entryPoint: 'fsMain',
        targets: [{
          format: HDR_FORMAT,
          blend: {
            color: { srcFactor: 'src-alpha', dstFactor: 'one-minus-src-alpha', operation: 'add' },
            alpha: { srcFactor: 'one', dstFactor: 'one-minus-src-alpha', operation: 'add' },
          },
        }],
      },
      primitive: { topology: 'triangle-list', cullMode: 'none' },
      depthStencil: { format: 'depth24plus', depthWriteEnabled: false, depthCompare: 'less-equal' },
      multisample: { count: MSAA_SAMPLE_COUNT },
    };
    const skyDescriptor: GPURenderPipelineDescriptor = {
      label: 'AAA atmospheric sky pipeline',
      layout: sceneLayout,
      vertex: { module: skyModule, entryPoint: 'vsMain' },
      fragment: { module: skyModule, entryPoint: 'fsMain', targets: [{ format: HDR_FORMAT }] },
      primitive: { topology: 'triangle-list' },
      // The sky is encoded in the same render pass as solid geometry. WebGPU
      // requires every pipeline used by that pass to declare a compatible
      // depth/stencil attachment state, even when the sky does not write depth.
      depthStencil: { format: 'depth24plus', depthWriteEnabled: false, depthCompare: 'always' },
      multisample: { count: MSAA_SAMPLE_COUNT },
    };
    const solidDescriptor: GPURenderPipelineDescriptor = {
      label: 'AAA instanced PBR cube pipeline',
      layout: sceneLayout,
      vertex: { module: solidModule, entryPoint: 'vsMain', buffers: instanceVertexBuffers() },
      fragment: { module: solidModule, entryPoint: 'fsMain', targets: [{ format: HDR_FORMAT }] },
      primitive: { topology: 'triangle-list', cullMode: 'back' },
      depthStencil: { format: 'depth24plus', depthWriteEnabled: true, depthCompare: 'less' },
      multisample: { count: MSAA_SAMPLE_COUNT },
    };
    const lineDescriptor: GPURenderPipelineDescriptor = {
      label: 'AAA diagnostic/effect line pipeline',
      layout: sceneLayout,
      vertex: {
        module: lineModule,
        entryPoint: 'vsMain',
        buffers: [{
          arrayStride: 7 * 4,
          stepMode: 'vertex',
          attributes: [
            { shaderLocation: 0, offset: 0, format: 'float32x3' },
            { shaderLocation: 1, offset: 3 * 4, format: 'float32x4' },
          ],
        }],
      },
      fragment: {
        module: lineModule,
        entryPoint: 'fsMain',
        targets: [{
          format: HDR_FORMAT,
          blend: {
            color: { srcFactor: 'src-alpha', dstFactor: 'one', operation: 'add' },
            alpha: { srcFactor: 'one', dstFactor: 'one-minus-src-alpha', operation: 'add' },
          },
        }],
      },
      primitive: { topology: 'line-list' },
      depthStencil: { format: 'depth24plus', depthWriteEnabled: false, depthCompare: 'less-equal' },
      multisample: { count: MSAA_SAMPLE_COUNT },
    };
    const postDescriptor: GPURenderPipelineDescriptor = {
      label: 'AAA post-processing pipeline',
      layout: postLayout,
      vertex: { module: postModule, entryPoint: 'vsMain' },
      fragment: { module: postModule, entryPoint: 'fsMain', targets: [{ format }] },
      primitive: { topology: 'triangle-list' },
    };

    const createPipeline = typeof device.createRenderPipelineAsync === 'function'
      ? (descriptor: GPURenderPipelineDescriptor) => device.createRenderPipelineAsync!(descriptor)
      : (descriptor: GPURenderPipelineDescriptor) => Promise.resolve(device.createRenderPipeline(descriptor));
    const pipelinePromise = Promise.all([
      createPipeline(shadowDescriptor),
      createPipeline(surfaceShadowDescriptor),
      createPipeline(clothDescriptor),
      createPipeline(clothGridShadowDescriptor),
      createPipeline(clothGridDescriptor),
      createPipeline(waterDescriptor),
      createPipeline(waterGridDescriptor),
      createPipeline(skyDescriptor),
      createPipeline(solidDescriptor),
      createPipeline(lineDescriptor),
      createPipeline(postDescriptor),
    ]);
    const [materialNoise, pipelines] = await Promise.all([materialNoisePromise, pipelinePromise]);
    const [
      shadowPipeline,
      surfaceShadowPipeline,
      clothPipeline,
      clothGridShadowPipeline,
      clothGridPipeline,
      waterPipeline,
      waterGridPipeline,
      skyPipeline,
      solidPipeline,
      linePipeline,
      postPipeline,
    ] = pipelines;
    const sceneBindGroup = device.createBindGroup({
      label: 'AAA scene bind group',
      layout: sceneBindGroupLayout,
      entries: [
        { binding: 0, resource: { buffer: uniformBuffer } },
        { binding: 1, resource: shadowView },
        { binding: 2, resource: shadowSampler },
        { binding: 3, resource: materialNoise.view },
        { binding: 4, resource: materialNoise.sampler },
      ],
    });

    const clothGridBindGroup = device.createBindGroup({
      label: 'AAA GPU cloth grid bind group',
      layout: clothGridBindGroupLayout,
      entries: [
        { binding: 0, resource: { buffer: clothGridUniformBuffer } },
        { binding: 1, resource: { buffer: clothPositionBuffer } },
        { binding: 2, resource: { buffer: clothStrainBuffer } },
      ],
    });

    const waterGridBindGroup = device.createBindGroup({
      label: 'AAA GPU water grid bind group',
      layout: waterGridBindGroupLayout,
      entries: [
        { binding: 0, resource: { buffer: waterGridUniformBuffer } },
        { binding: 1, resource: { buffer: waterEtaBuffer } },
        { binding: 2, resource: { buffer: waterUBuffer } },
        { binding: 3, resource: { buffer: waterVBuffer } },
      ],
    });

    const renderer = new WebGPURenderer({
      canvas,
      device,
      context,
      format,
      maxInstances,
      shadowPipeline,
      surfaceShadowPipeline,
      skyPipeline,
      solidPipeline,
      clothPipeline,
      clothGridPipeline,
      clothGridShadowPipeline,
      waterPipeline,
      waterGridPipeline,
      linePipeline,
      postPipeline,
      shadowBindGroup,
      sceneBindGroup,
      clothGridBindGroup,
      waterGridBindGroup,
      postBindGroupLayout,
      uniformBuffer,
      vertexBuffer,
      matrixBuffer,
      colorBuffer,
      lineBuffer,
      surfaceVertexBuffer,
      surfaceIndexBuffer,
      clothPositionBuffer,
      clothStrainBuffer,
      clothGridUniformBuffer,
      clothGridIndexBuffer,
      waterEtaBuffer,
      waterUBuffer,
      waterVBuffer,
      waterGridUniformBuffer,
      waterGridIndexBuffer,
      shadowTexture,
      shadowView,
      shadowSampler,
      linearSampler,
      materialNoise,
    });
    renderer.resize();
    return renderer;
  }

  resize(): void {
    const dpr = Math.min(2, (window.devicePixelRatio || 1) * this.resolutionScale);
    const width = Math.max(1, Math.floor(this.canvas.clientWidth * dpr));
    const height = Math.max(1, Math.floor(this.canvas.clientHeight * dpr));
    if (width === this.width && height === this.height) return;

    this.width = width;
    this.height = height;
    this.canvas.width = width;
    this.canvas.height = height;

    this.depthTexture?.destroy();
    this.msaaTexture?.destroy();
    this.hdrTexture?.destroy();

    this.depthTexture = this.device.createTexture({
      label: 'AAA multisampled depth',
      size: [width, height],
      sampleCount: MSAA_SAMPLE_COUNT,
      format: 'depth24plus',
      usage: GPUTextureUsage.RENDER_ATTACHMENT,
    });
    this.depthView = this.depthTexture.createView();

    this.msaaTexture = this.device.createTexture({
      label: 'AAA multisampled HDR color',
      size: [width, height],
      sampleCount: MSAA_SAMPLE_COUNT,
      format: HDR_FORMAT,
      usage: GPUTextureUsage.RENDER_ATTACHMENT,
    });
    this.msaaView = this.msaaTexture.createView();

    this.hdrTexture = this.device.createTexture({
      label: 'AAA resolved HDR color',
      size: [width, height],
      format: HDR_FORMAT,
      usage: GPUTextureUsage.RENDER_ATTACHMENT | GPUTextureUsage.TEXTURE_BINDING,
    });
    this.hdrView = this.hdrTexture.createView();

    this.postBindGroup = this.device.createBindGroup({
      label: 'AAA post bind group',
      layout: this.postBindGroupLayout,
      entries: [
        { binding: 0, resource: this.hdrView },
        { binding: 1, resource: this.linearSampler },
        { binding: 2, resource: { buffer: this.uniformBuffer } },
      ],
    });
  }

  writeSceneUniforms(state: SceneUniformState): void {
    this.resolutionScale = Math.max(0.5, Math.min(1.35, state.quality.resolutionScale));
    this.resize();
    const data = this.uniformScratch;
    data.set(state.viewProjection, 0);
    data.set(state.lightViewProjection, 16);
    data[32] = state.cameraPosition[0];
    data[33] = state.cameraPosition[1];
    data[34] = state.cameraPosition[2];
    data[35] = state.timeSeconds;
    data[36] = state.lightDirection[0];
    data[37] = state.lightDirection[1];
    data[38] = state.lightDirection[2];
    data[39] = state.quality.exposure;
    data[40] = state.fogColor[0];
    data[41] = state.fogColor[1];
    data[42] = state.fogColor[2];
    data[43] = state.quality.fogDensity;
    data[44] = this.width;
    data[45] = this.height;
    data[46] = state.quality.bloomStrength;
    data[47] = state.quality.shadowStrength;
    writeFloatBuffer(this.device.queue, this.uniformBuffer, 0, data);
  }

  uploadInstances(source: InstanceBufferSource, count: number): number {
    const safeCount = Math.max(0, Math.min(count, this.maxInstances));
    const matrixStart = ptrToNumber(source._b3w_matrices_ptr()) / 4;
    const colorStart = ptrToNumber(source._b3w_colors_ptr()) / 4;
    const matrixFloats = safeCount * 16;
    const colorFloats = safeCount * 4;
    writeFloatBuffer(this.device.queue, this.matrixBuffer, 0, source.HEAPF32, matrixFloats, matrixStart);
    writeFloatBuffer(this.device.queue, this.colorBuffer, 0, source.HEAPF32, colorFloats, colorStart);
    const bytes = (matrixFloats + colorFloats) * Float32Array.BYTES_PER_ELEMENT;
    this.lastUploadedBytes = bytes;
    return bytes;
  }

  uploadEffects(matrices: Float32Array, colors: Float32Array, baseInstance: number, count: number): number {
    const safeBase = Math.max(0, Math.min(baseInstance, this.maxInstances));
    const safeCount = Math.max(0, Math.min(count, this.maxInstances - safeBase));
    const matrixFloats = Math.min(safeCount * 16, matrices.length);
    const colorFloats = Math.min(safeCount * 4, colors.length);
    writeFloatBuffer(this.device.queue, this.matrixBuffer, safeBase * 16 * 4, matrices, matrixFloats);
    writeFloatBuffer(this.device.queue, this.colorBuffer, safeBase * 4 * 4, colors, colorFloats);
    const bytes = (matrixFloats + colorFloats) * Float32Array.BYTES_PER_ELEMENT;
    this.lastUploadedBytes += bytes;
    return bytes;
  }

  uploadClothGrid(grid: ClothGridFrame | null): number {
    this.clothGridActive = false;
    this.clothGridVertexCount = 0;
    this.clothGridIndexCount = 0;
    if (!grid || grid.vertexCount <= 0 || grid.indexCount <= 0) return 0;

    const safeVertexCount = Math.max(0, Math.min(
      grid.vertexCount,
      Math.floor(grid.positions.length / 3),
      grid.strain.length,
      MAX_DYNAMIC_SURFACE_VERTICES,
    ));
    let safeIndexCount = Math.max(0, Math.min(grid.indexCount, grid.indices.length, MAX_DYNAMIC_SURFACE_INDICES));
    safeIndexCount -= safeIndexCount % 3;
    if (safeVertexCount <= 0 || safeIndexCount <= 0 || grid.cols < 2 || grid.rows < 2) return 0;

    let bytes = 0;
    const stateChanged =
      this.clothGridFrameVersion !== grid.frameVersion ||
      this.clothGridPositionIdentity !== grid.positions.buffer ||
      this.clothGridPositionByteOffset !== grid.positions.byteOffset ||
      this.clothGridStrainIdentity !== grid.strain.buffer ||
      this.clothGridStrainByteOffset !== grid.strain.byteOffset;
    if (stateChanged) {
      writeFloatBuffer(this.device.queue, this.clothPositionBuffer, 0, grid.positions, safeVertexCount * 3);
      writeFloatBuffer(this.device.queue, this.clothStrainBuffer, 0, grid.strain, safeVertexCount);
      bytes += safeVertexCount * Float32Array.BYTES_PER_ELEMENT * 4;
      this.clothGridFrameVersion = grid.frameVersion;
      this.clothGridPositionIdentity = grid.positions.buffer;
      this.clothGridPositionByteOffset = grid.positions.byteOffset;
      this.clothGridStrainIdentity = grid.strain.buffer;
      this.clothGridStrainByteOffset = grid.strain.byteOffset;
    }

    const topologyChanged =
      this.clothGridTopologyVersion !== grid.topologyVersion ||
      this.clothGridIndexIdentity !== grid.indices.buffer ||
      this.clothGridIndexByteOffset !== grid.indices.byteOffset ||
      this.clothGridCachedIndexCount !== safeIndexCount;
    if (topologyChanged) {
      let maxIndex = 0;
      for (let i = 0; i < safeIndexCount; i++) {
        const index = grid.indices[i];
        if (index > maxIndex) maxIndex = index;
      }
      if (maxIndex >= safeVertexCount) {
        console.warn(`[WebGPU] Ignoring GPU cloth grid: index ${maxIndex} exceeds ${safeVertexCount} vertices.`);
        return 0;
      }
      const indexBytes = safeIndexCount * Uint16Array.BYTES_PER_ELEMENT;
      const alignedIndexBytes = (indexBytes + 3) & ~3;
      if (alignedIndexBytes === indexBytes) {
        writeByteBuffer(this.device.queue, this.clothGridIndexBuffer, 0, grid.indices, indexBytes);
      } else {
        const scratch = this.surfaceIndexUploadScratch;
        scratch.set(new Uint8Array(grid.indices.buffer, grid.indices.byteOffset, indexBytes), 0);
        scratch.fill(0, indexBytes, alignedIndexBytes);
        writeByteBuffer(this.device.queue, this.clothGridIndexBuffer, 0, scratch, alignedIndexBytes);
      }
      bytes += indexBytes;
      this.clothGridTopologyVersion = grid.topologyVersion;
      this.clothGridIndexIdentity = grid.indices.buffer;
      this.clothGridIndexByteOffset = grid.indices.byteOffset;
      this.clothGridCachedIndexCount = safeIndexCount;
    }

    const a = grid.baseColorA;
    const b = grid.baseColorB;
    const uniformKey = `${grid.cols}:${grid.rows}:${grid.verticalLayout ? 1 : 0}:${a.join(':')}:${b.join(':')}`;
    if (uniformKey !== this.clothGridUniformKey) {
      const view = new DataView(this.clothGridUniformScratch);
      view.setUint32(0, grid.cols >>> 0, true);
      view.setUint32(4, grid.rows >>> 0, true);
      view.setUint32(8, grid.verticalLayout ? 1 : 0, true);
      view.setUint32(12, 0, true);
      for (let i = 0; i < 4; i++) view.setFloat32(16 + i * 4, a[i], true);
      for (let i = 0; i < 4; i++) view.setFloat32(32 + i * 4, b[i], true);
      let checkerMaskX0 = 0;
      let checkerMaskX1 = 0;
      const invCols = 1 / Math.max(1, grid.cols - 1);
      for (let x = 0; x < grid.cols; x++) {
        if ((Math.floor(x * invCols * 10) & 1) === 0) continue;
        if (x < 32) checkerMaskX0 = (checkerMaskX0 | (1 << x)) >>> 0;
        else checkerMaskX1 = (checkerMaskX1 | (1 << (x - 32))) >>> 0;
      }
      let checkerMaskY0 = 0;
      let checkerMaskY1 = 0;
      const invRows = 1 / Math.max(1, grid.rows - 1);
      for (let y = 0; y < grid.rows; y++) {
        if ((Math.floor(y * invRows * 8) & 1) === 0) continue;
        if (y < 32) checkerMaskY0 = (checkerMaskY0 | (1 << y)) >>> 0;
        else checkerMaskY1 = (checkerMaskY1 | (1 << (y - 32))) >>> 0;
      }
      view.setUint32(48, checkerMaskX0, true);
      view.setUint32(52, checkerMaskX1, true);
      view.setUint32(56, checkerMaskY0, true);
      view.setUint32(60, checkerMaskY1, true);
      writeByteBuffer(this.device.queue, this.clothGridUniformBuffer, 0, new Uint8Array(this.clothGridUniformScratch));
      bytes += CLOTH_GRID_UNIFORM_BYTES;
      this.clothGridUniformKey = uniformKey;
    }

    this.clothGridActive = true;
    this.clothGridVertexCount = safeVertexCount;
    this.clothGridIndexCount = safeIndexCount;
    this.lastUploadedBytes += bytes;
    return bytes;
  }

  uploadWaterGrid(grid: WaterGridFrame | null): number {
    this.waterGridActive = false;
    this.waterGridVertexCount = 0;
    this.waterGridIndexCount = 0;
    if (!grid || grid.vertexCount <= 0 || grid.indexCount <= 0) return 0;

    const safeVertexCount = Math.max(0, Math.min(
      grid.vertexCount,
      grid.eta.length,
      grid.u.length,
      grid.v.length,
      MAX_DYNAMIC_SURFACE_VERTICES,
    ));
    let safeIndexCount = Math.max(0, Math.min(grid.indexCount, grid.indices.length, MAX_DYNAMIC_SURFACE_INDICES));
    safeIndexCount -= safeIndexCount % 3;
    if (safeVertexCount <= 0 || safeIndexCount <= 0 || grid.cols < 2 || grid.rows < 2) return 0;

    let bytes = 0;
    const stateChanged =
      this.waterGridFrameVersion !== grid.frameVersion ||
      this.waterGridEtaIdentity !== grid.eta.buffer ||
      this.waterGridEtaByteOffset !== grid.eta.byteOffset ||
      this.waterGridUIdentity !== grid.u.buffer ||
      this.waterGridUByteOffset !== grid.u.byteOffset ||
      this.waterGridVIdentity !== grid.v.buffer ||
      this.waterGridVByteOffset !== grid.v.byteOffset;
    if (stateChanged) {
      writeFloatBuffer(this.device.queue, this.waterEtaBuffer, 0, grid.eta, safeVertexCount);
      writeFloatBuffer(this.device.queue, this.waterUBuffer, 0, grid.u, safeVertexCount);
      writeFloatBuffer(this.device.queue, this.waterVBuffer, 0, grid.v, safeVertexCount);
      bytes += safeVertexCount * Float32Array.BYTES_PER_ELEMENT * 3;
      this.waterGridFrameVersion = grid.frameVersion;
      this.waterGridEtaIdentity = grid.eta.buffer;
      this.waterGridEtaByteOffset = grid.eta.byteOffset;
      this.waterGridUIdentity = grid.u.buffer;
      this.waterGridUByteOffset = grid.u.byteOffset;
      this.waterGridVIdentity = grid.v.buffer;
      this.waterGridVByteOffset = grid.v.byteOffset;
    }

    const topologyChanged =
      this.waterGridTopologyVersion !== grid.topologyVersion ||
      this.waterGridIndexIdentity !== grid.indices.buffer ||
      this.waterGridIndexByteOffset !== grid.indices.byteOffset ||
      this.waterGridCachedIndexCount !== safeIndexCount;
    if (topologyChanged) {
      let maxIndex = 0;
      for (let i = 0; i < safeIndexCount; i++) {
        const index = grid.indices[i];
        if (index > maxIndex) maxIndex = index;
      }
      if (maxIndex >= safeVertexCount) {
        console.warn(`[WebGPU] Ignoring GPU water grid: index ${maxIndex} exceeds ${safeVertexCount} cells.`);
        return 0;
      }
      const indexBytes = safeIndexCount * Uint16Array.BYTES_PER_ELEMENT;
      const alignedIndexBytes = (indexBytes + 3) & ~3;
      if (alignedIndexBytes === indexBytes) {
        writeByteBuffer(this.device.queue, this.waterGridIndexBuffer, 0, grid.indices, indexBytes);
      } else {
        const scratch = this.surfaceIndexUploadScratch;
        scratch.set(new Uint8Array(grid.indices.buffer, grid.indices.byteOffset, indexBytes), 0);
        scratch.fill(0, indexBytes, alignedIndexBytes);
        writeByteBuffer(this.device.queue, this.waterGridIndexBuffer, 0, scratch, alignedIndexBytes);
      }
      bytes += indexBytes;
      this.waterGridTopologyVersion = grid.topologyVersion;
      this.waterGridIndexIdentity = grid.indices.buffer;
      this.waterGridIndexByteOffset = grid.indices.byteOffset;
      this.waterGridCachedIndexCount = safeIndexCount;
    }

    const uniformKey = `${grid.cols}:${grid.rows}:${grid.width}:${grid.depth}:${grid.baseY}:${grid.invTwoDx}:${grid.invTwoDz}`;
    if (uniformKey !== this.waterGridUniformKey) {
      const view = new DataView(this.waterGridUniformScratch);
      view.setUint32(0, grid.cols >>> 0, true);
      view.setUint32(4, grid.rows >>> 0, true);
      view.setFloat32(8, grid.width, true);
      view.setFloat32(12, grid.depth, true);
      view.setFloat32(16, grid.baseY, true);
      view.setFloat32(20, grid.invTwoDx, true);
      view.setFloat32(24, grid.invTwoDz, true);
      view.setFloat32(28, 0, true);
      writeByteBuffer(this.device.queue, this.waterGridUniformBuffer, 0, new Uint8Array(this.waterGridUniformScratch));
      bytes += WATER_GRID_UNIFORM_BYTES;
      this.waterGridUniformKey = uniformKey;
    }

    this.waterGridActive = true;
    this.waterGridVertexCount = safeVertexCount;
    this.waterGridIndexCount = safeIndexCount;
    this.lastUploadedBytes += bytes;
    return bytes;
  }

  uploadSurface(surface: DynamicSurfaceFrame | null): number {
    this.surfaceVertexCount = 0;
    this.surfaceIndexCount = 0;
    this.surfaceMaterial = null;
    if (!surface || surface.vertexCount <= 0 || surface.indexCount <= 0) return 0;
    if (surface.vertexStride !== SURFACE_VERTEX_BYTES) {
      console.warn(`[WebGPU] Ignoring ${surface.material} surface with unsupported ${surface.vertexStride}-byte vertex stride.`);
      return 0;
    }

    const availableVertices = Math.floor(surface.vertices.byteLength / surface.vertexStride);
    const safeVertexCount = Math.max(0, Math.min(surface.vertexCount, availableVertices, MAX_DYNAMIC_SURFACE_VERTICES));
    let safeIndexCount = Math.max(0, Math.min(surface.indexCount, surface.indices.length, MAX_DYNAMIC_SURFACE_INDICES));
    safeIndexCount -= safeIndexCount % 3;
    if (safeVertexCount <= 0 || safeIndexCount <= 0) return 0;

    const vertexBytes = safeVertexCount * surface.vertexStride;
    const vertexChanged =
      this.surfaceVertexBufferIdentity !== surface.vertices.buffer ||
      this.surfaceVertexByteOffset !== surface.vertices.byteOffset ||
      this.surfaceFrameVersion !== surface.frameVersion ||
      this.surfaceCachedVertexCount !== safeVertexCount;
    let bytes = 0;
    if (vertexChanged) {
      writeByteBuffer(this.device.queue, this.surfaceVertexBuffer, 0, surface.vertices, vertexBytes);
      bytes += vertexBytes;
      this.surfaceVertexBufferIdentity = surface.vertices.buffer;
      this.surfaceVertexByteOffset = surface.vertices.byteOffset;
      this.surfaceFrameVersion = surface.frameVersion;
      this.surfaceCachedVertexCount = safeVertexCount;
    }

    const topologyChanged =
      this.surfaceIndexBufferIdentity !== surface.indices.buffer ||
      this.surfaceIndexByteOffset !== surface.indices.byteOffset ||
      this.surfaceTopologyVersion !== surface.topologyVersion ||
      this.surfaceCachedIndexCount !== safeIndexCount;
    if (topologyChanged) {
      let maxIndex = 0;
      for (let i = 0; i < safeIndexCount; i++) {
        const index = surface.indices[i];
        if (index > maxIndex) maxIndex = index;
      }
      if (maxIndex >= safeVertexCount) {
        console.warn(`[WebGPU] Ignoring ${surface.material} surface: index ${maxIndex} exceeds ${safeVertexCount} uploaded vertices.`);
        return 0;
      }
      const indexBytes = safeIndexCount * Uint16Array.BYTES_PER_ELEMENT;
      const alignedIndexBytes = (indexBytes + 3) & ~3;
      if (alignedIndexBytes === indexBytes) {
        writeByteBuffer(this.device.queue, this.surfaceIndexBuffer, 0, surface.indices, indexBytes);
      } else {
        const scratch = this.surfaceIndexUploadScratch;
        scratch.set(new Uint8Array(surface.indices.buffer, surface.indices.byteOffset, indexBytes), 0);
        scratch.fill(0, indexBytes, alignedIndexBytes);
        writeByteBuffer(this.device.queue, this.surfaceIndexBuffer, 0, scratch, alignedIndexBytes);
      }
      bytes += indexBytes;
      this.surfaceIndexBufferIdentity = surface.indices.buffer;
      this.surfaceIndexByteOffset = surface.indices.byteOffset;
      this.surfaceTopologyVersion = surface.topologyVersion;
      this.surfaceCachedIndexCount = safeIndexCount;
    }

    this.surfaceVertexCount = safeVertexCount;
    this.surfaceIndexCount = safeIndexCount;
    this.surfaceMaterial = surface.material;
    this.lastUploadedBytes += bytes;
    return bytes;
  }

  render(instanceCount: number, debugLines: readonly DebugLine[]): number {
    this.resize();
    if (!this.depthView || !this.msaaView || !this.hdrView || !this.postBindGroup) return 0;

    const safeCount = Math.max(0, Math.min(instanceCount, this.maxInstances));
    const lineFloatCount = fillLineVertexData(debugLines, MAX_DEBUG_LINE_VERTICES, this.lineScratch);
    if (lineFloatCount > 0) {
      writeFloatBuffer(this.device.queue, this.lineBuffer, 0, this.lineScratch, lineFloatCount);
    }

    const start = performance.now();
    const encoder = this.device.createCommandEncoder({ label: 'AAA frame encoder' });

    const clothCastsShadow = this.surfaceMaterial === 'cloth' && this.surfaceIndexCount > 0;
    const clothGridCastsShadow = this.clothGridActive && this.clothGridIndexCount > 0;
    if (this.uniformScratch[47] > 0.001 && (safeCount > 0 || clothCastsShadow || clothGridCastsShadow)) {
      const shadowPass = encoder.beginRenderPass({
        label: 'AAA shadow pass',
        colorAttachments: [],
        depthStencilAttachment: {
          view: this.shadowView,
          depthClearValue: 1,
          depthLoadOp: 'clear',
          depthStoreOp: 'store',
        },
      });
      shadowPass.setBindGroup(0, this.shadowBindGroup);
      if (safeCount > 0) {
        shadowPass.setPipeline(this.shadowPipeline);
        shadowPass.setVertexBuffer(0, this.vertexBuffer);
        shadowPass.setVertexBuffer(1, this.matrixBuffer);
        shadowPass.setVertexBuffer(2, this.colorBuffer);
        shadowPass.draw(CUBE_VERTEX_COUNT, safeCount);
      }
      if (clothCastsShadow) {
        shadowPass.setPipeline(this.surfaceShadowPipeline);
        shadowPass.setVertexBuffer(0, this.surfaceVertexBuffer);
        shadowPass.setIndexBuffer(this.surfaceIndexBuffer, 'uint16');
        shadowPass.drawIndexed(this.surfaceIndexCount, 1);
      }
      if (clothGridCastsShadow) {
        shadowPass.setPipeline(this.clothGridShadowPipeline);
        shadowPass.setBindGroup(1, this.clothGridBindGroup);
        shadowPass.setIndexBuffer(this.clothGridIndexBuffer, 'uint16');
        shadowPass.drawIndexed(this.clothGridIndexCount, 1);
      }
      shadowPass.end();
    }

    const mainPass = encoder.beginRenderPass({
      label: 'AAA HDR main pass',
      colorAttachments: [{
        view: this.msaaView,
        resolveTarget: this.hdrView,
        clearValue: { r: 0.003, g: 0.006, b: 0.015, a: 1 },
        loadOp: 'clear',
        storeOp: 'discard',
      }],
      depthStencilAttachment: {
        view: this.depthView,
        depthClearValue: 1,
        depthLoadOp: 'clear',
        depthStoreOp: 'store',
      },
    });

    mainPass.setPipeline(this.skyPipeline);
    mainPass.setBindGroup(0, this.sceneBindGroup);
    mainPass.draw(3, 1);

    if (safeCount > 0) {
      mainPass.setPipeline(this.solidPipeline);
      mainPass.setBindGroup(0, this.sceneBindGroup);
      mainPass.setVertexBuffer(0, this.vertexBuffer);
      mainPass.setVertexBuffer(1, this.matrixBuffer);
      mainPass.setVertexBuffer(2, this.colorBuffer);
      mainPass.draw(CUBE_VERTEX_COUNT, safeCount);
    }

    if (this.surfaceMaterial && this.surfaceIndexCount > 0) {
      mainPass.setPipeline(this.surfaceMaterial === 'cloth' ? this.clothPipeline : this.waterPipeline);
      mainPass.setBindGroup(0, this.sceneBindGroup);
      mainPass.setVertexBuffer(0, this.surfaceVertexBuffer);
      mainPass.setIndexBuffer(this.surfaceIndexBuffer, 'uint16');
      mainPass.drawIndexed(this.surfaceIndexCount, 1);
    }

    if (this.clothGridActive && this.clothGridIndexCount > 0) {
      mainPass.setPipeline(this.clothGridPipeline);
      mainPass.setBindGroup(0, this.sceneBindGroup);
      mainPass.setBindGroup(1, this.clothGridBindGroup);
      mainPass.setIndexBuffer(this.clothGridIndexBuffer, 'uint16');
      mainPass.drawIndexed(this.clothGridIndexCount, 1);
    }

    if (this.waterGridActive && this.waterGridIndexCount > 0) {
      mainPass.setPipeline(this.waterGridPipeline);
      mainPass.setBindGroup(0, this.sceneBindGroup);
      mainPass.setBindGroup(1, this.waterGridBindGroup);
      mainPass.setIndexBuffer(this.waterGridIndexBuffer, 'uint16');
      mainPass.drawIndexed(this.waterGridIndexCount, 1);
    }

    if (lineFloatCount > 0) {
      mainPass.setPipeline(this.linePipeline);
      mainPass.setBindGroup(0, this.sceneBindGroup);
      mainPass.setVertexBuffer(0, this.lineBuffer);
      mainPass.draw(lineFloatCount / 7, 1);
    }
    mainPass.end();

    const postPass = encoder.beginRenderPass({
      label: 'AAA tone mapping and bloom pass',
      colorAttachments: [{
        view: this.context.getCurrentTexture().createView(),
        clearValue: { r: 0, g: 0, b: 0, a: 1 },
        loadOp: 'clear',
        storeOp: 'store',
      }],
    });
    postPass.setPipeline(this.postPipeline);
    postPass.setBindGroup(0, this.postBindGroup);
    postPass.draw(3, 1);
    postPass.end();

    this.device.queue.submit([encoder.finish()]);
    return performance.now() - start;
  }

  uploadedMegabytes(): number {
    return this.lastUploadedBytes / (1024 * 1024);
  }

  viewport(): readonly [number, number] {
    return [this.width, this.height];
  }

  materialTextureInfo(): Readonly<Pick<MaterialNoiseTexture, 'compressed' | 'sourceBytes' | 'source'>> {
    return this.materialNoiseInfo;
  }
}
