import type { Mat4, Vec3 } from './math';
import type { ScenePreset } from './scenes';

export type InstanceBufferSource = {
  readonly HEAPF32: Float32Array;
  _b3w_matrices_ptr(): number | bigint;
  _b3w_colors_ptr(): number | bigint;
  _b3w_body_count(): number;
  _b3w_max_bodies(): number;
};

export type PhysicsBackend = InstanceBufferSource & {
  readonly name: string;
  readonly isWasm: boolean;
  readonly maxBodies: number;
  createScene(scene: ScenePreset, stressScale: number, seed: number): number;
  step(dt: number, subSteps: number): void;
  syncTransforms(): void;
  kick(strength: number): void;
  explode(centerX: number, centerY: number, centerZ: number, strength: number, radius: number): void;
  launchProjectile(x: number, y: number, z: number, vx: number, vy: number, vz: number, size: number): number;
  spawnRain(count: number, spread: number, height: number): number;
  bodyCount(): number;
  dynamicCount(): number;
  replayHash(): number;
  destroy(): void;
};


export type DynamicSurfaceMaterial = 'cloth' | 'water';

/** Packed dynamic-surface vertices: position3/f32, normal2/snorm16, color4/unorm8, uv2/unorm16. */
export type DynamicSurfaceFrame = {
  material: DynamicSurfaceMaterial;
  vertices: Uint8Array;
  indices: Uint16Array;
  vertexStride: number;
  vertexCount: number;
  indexCount: number;
  topologyVersion: number;
  /** Monotonic content revision. Equal revisions guarantee byte-identical
   * vertex data and allow the renderer to skip redundant queue writes. */
  frameVersion: number;
};

/** Raw shallow-water state rendered directly by the GPU. The solver remains
 * authoritative on the CPU/WASM side; WebGPU reconstructs positions, normals,
 * foam, and color in the vertex shader so the CPU no longer builds a 24-byte
 * vertex for every grid cell each frame. */
export type WaterGridFrame = {
  eta: Float32Array;
  u: Float32Array;
  v: Float32Array;
  indices: Uint16Array;
  cols: number;
  rows: number;
  width: number;
  depth: number;
  baseY: number;
  invTwoDx: number;
  invTwoDz: number;
  vertexCount: number;
  indexCount: number;
  topologyVersion: number;
  frameVersion: number;
};

/** Intact regular-grid cloth rendered directly from solver positions. WebGPU
 * reconstructs grid UVs, smooth normals, checker palette, and stress color in
 * the vertex shader. Tearing cloth keeps using DynamicSurfaceFrame because its
 * mutable topology needs triangle-aware CPU normals. */
export type ClothGridFrame = {
  positions: Float32Array;
  strain: Float32Array;
  indices: Uint16Array;
  cols: number;
  rows: number;
  verticalLayout: boolean;
  baseColorA: readonly [number, number, number, number];
  baseColorB: readonly [number, number, number, number];
  vertexCount: number;
  indexCount: number;
  topologyVersion: number;
  frameVersion: number;
};

export type DebugLine = {
  ax: number;
  ay: number;
  az: number;
  bx: number;
  by: number;
  bz: number;
  r: number;
  g: number;
  b: number;
  a: number;
};

export type CameraRig = {
  yaw: number;
  pitch: number;
  distance: number;
  target: Vec3;
};

export type FrameMetrics = {
  fps: number;
  simMs: number;
  renderSubmitMs: number;
  uploadMb: number;
  steps: number;
  hash: number;
};

export type RenderQualityId = 'performance' | 'balanced' | 'cinematic' | 'ultra';

export type RenderQuality = {
  id: RenderQualityId;
  label: string;
  exposure: number;
  bloomStrength: number;
  fogDensity: number;
  shadowStrength: number;
  effectBudget: number;
  resolutionScale: number;
};

export type SceneUniformState = {
  viewProjection: Mat4;
  lightViewProjection: Mat4;
  cameraPosition: Vec3;
  timeSeconds: number;
  lightDirection: Vec3;
  quality: RenderQuality;
  fogColor: Vec3;
};

export type EffectFrame = {
  matrices: Float32Array;
  colors: Float32Array;
  count: number;
  debugLines: readonly DebugLine[];
};

export type RendererFrameResult = {
  uploadedBytes: number;
  renderSubmitMs: number;
};
