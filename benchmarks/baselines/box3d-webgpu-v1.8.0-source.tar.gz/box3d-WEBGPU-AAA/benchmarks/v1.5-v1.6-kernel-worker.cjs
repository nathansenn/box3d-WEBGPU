'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { performance } = require('node:perf_hooks');

const root = path.resolve(process.argv[2]);
const variant = process.argv[3];
const workloadId = process.argv[4];
const build = path.join(root, '.test-build');
const { SCENES } = require(path.join(build, 'src/scenes.js'));
const { SoftSimulationSuite } = require(path.join(build, 'src/soft/simulations.js'));

if (variant === 'v1.6') {
  const kernels = require(path.join(build, 'src/soft/wasm-kernels.js'));
  const module = new WebAssembly.Module(fs.readFileSync(path.join(root, 'public/soft-kernels-simd.wasm')));
  kernels.installSoftKernelModule(module, 'simd');
}

const workloadDefinitions = {
  'cloth-standard-full': { sceneId: 640, warmup: 14, iterations: 90, operation: 'full' },
  'cloth-maximum-full': { sceneId: 649, warmup: 14, iterations: 90, operation: 'full' },
  'cloth-maximum-step': { sceneId: 649, warmup: 14, iterations: 110, operation: 'step' },
  'rope-maximum-full': { sceneId: 699, warmup: 18, iterations: 140, operation: 'full' },
  'rope-storm-full': { sceneId: 699, warmup: 4, iterations: 45, operation: 'full', rain: 96 },
  'water-wave-full': { sceneId: 745, warmup: 18, iterations: 180, operation: 'full' },
  'water-maximum-full': { sceneId: 749, warmup: 18, iterations: 180, operation: 'full' },
  'cloth-paused-frame': { sceneId: 649, warmup: 20, iterations: 5000, operation: 'frame' },
  'rope-paused-frame': { sceneId: 699, warmup: 20, iterations: 5000, operation: 'frame' },
  'water-paused-frame': { sceneId: 749, warmup: 20, iterations: 5000, operation: 'frame' },
};

const definition = workloadDefinitions[workloadId];
if (!definition) throw new Error(`unknown workload ${workloadId}`);
const suite = new SoftSimulationSuite();
if (!suite.createScene(SCENES[definition.sceneId], 5, 0x160000 + definition.sceneId)) {
  throw new Error(`failed to create scene ${definition.sceneId}`);
}
if (definition.rain) suite.spawnRain(definition.rain, 14, 24);

function operation() {
  if (definition.operation === 'step') {
    suite.step(1 / 60, 4);
  } else if (definition.operation === 'frame') {
    suite.buildFrame(false);
  } else {
    suite.step(1 / 60, 4);
    suite.buildFrame(false);
  }
}

// Seed frame cache once so the paused workloads measure the unchanged path.
if (definition.operation === 'frame') suite.buildFrame(false);
for (let i = 0; i < definition.warmup; i++) operation();
global.gc?.();
const started = performance.now();
for (let i = 0; i < definition.iterations; i++) operation();
const elapsedMs = performance.now() - started;
const frame = suite.buildFrame(false);
const active = suite.active;
const state = active.kind === 'water' ? active.eta : active.positions;
let sum = 0;
let sumSquares = 0;
let maxAbsolute = 0;
for (let i = 0; i < state.length; i++) {
  const value = state[i];
  sum += value;
  sumSquares += value * value;
  maxAbsolute = Math.max(maxAbsolute, Math.abs(value));
}

process.stdout.write(JSON.stringify({
  variant,
  workloadId,
  sceneId: definition.sceneId,
  iterations: definition.iterations,
  elapsedMs,
  msPerOperation: elapsedMs / definition.iterations,
  hash: suite.hash(),
  frameVersion: frame.frameVersion,
  nodeCount: frame.nodeCount,
  stateLength: state.length,
  stateSum: sum,
  stateSumSquares: sumSquares,
  stateMaxAbsolute: maxAbsolute,
}));
