#!/usr/bin/env python3
import json, pathlib, platform, datetime
root=pathlib.Path(__file__).resolve().parents[1]
results=root/'benchmarks'/'results'
t=json.loads((results/'v1.7-third-breakthrough-100.json').read_text())
i=json.loads((results/'v1.6-v1.7-isolated.json').read_text())
c=t['summary']['categories']
by={x['id']:x for x in i['results']}
lines=[
'# Box3D WebGPU AAA v1.7.0 — Third Breakthrough Performance Report','',
'## Executive result','',
'This pass ran exactly **100 scene-diverse production-path experiments** against the bundled v1.6 source, followed by ten alternating-order fresh-process comparisons. The integrated changes are GPU-resident shallow-water reconstruction and WebAssembly rope instance generation. Simulation authority and numerical state remain unchanged.','',
'### Measurement method','',
f"- Tournament samples per experiment: **{t['method']['samplesPerExperiment']}**",
f"- Tournament iteration scale: **{t['method']['iterationScale']}×** of each workload’s standard loop count (recorded in the raw JSON)",
'- Warm-up before timing: **yes**','- Baseline/optimized order: **alternated**','- Summary statistic: **median**, with median absolute deviation','- Tournament acceptance threshold: **1.05×**, plus finite-state and output-equivalence gates',
f"- Fresh-process samples per workload: **{i['method']['samples']}**",
f"- Paired bootstrap resamples: **{i['method']['bootstrapIterations']}**",
'- Process startup is excluded from timed regions.','- The very large water-frame ratios measure eliminated CPU frame reconstruction near the timer floor; the fresh-process 44.42× result is the preferred isolated handoff claim, not a whole-engine or GPU-frame claim.','',
'### 100-experiment tournament','',
f"- Accepted: **{t['summary']['acceptedCount']}**",
f"- Borderline changed-path results: **{t['summary']['borderlineCount']}**",
f"- Unchanged-path controls: **{t['summary']['controlCount']}**",
f"- Rejected, no speedup: **{t['summary']['rejected-no-winCount']}**",
f"- Correctness failures in integrated paths: **{t['summary']['rejected-correctnessCount']}**",'',
'| Category | Experiments | Geometric mean | Median | Accepted |','|---|---:|---:|---:|---:|']
for name in ['water-frame','water-full','rope-frame','rope-full','cloth-full-control','water-step-control']:
    v=c[name];lines.append(f"| {name} | {v['count']} | **{v['geometricMeanSpeedup']:.2f}×** | {v['medianSpeedup']:.2f}× | {v['accepted']} |")
lines += ['','### Fresh-process release comparison','',
f"- Changed-path geometric mean: **{i['summary']['changedGeometricMeanSpeedup']:.2f}×**",
f"- Dynamic/mixed geometric mean: **{i['summary']['dynamicGeometricMeanSpeedup']:.2f}×**",'',
'| Workload | v1.6 ms | v1.7 ms | Speedup | Paired 95% interval |','|---|---:|---:|---:|---:|']
for r in i['results']:
    lines.append(f"| {r['label']} | {r['baselineMedianMs']:.6f} | {r['optimizedMedianMs']:.6f} | **{r['speedup']:.2f}×** | {r['pairedBootstrap95'][0]:.2f}–{r['pairedBootstrap95'][1]:.2f}× |")
lines += ['','## Architecture changes','',
'### GPU-resident shallow-water reconstruction','',
'v1.6 built a 24-byte packed vertex for every water cell on the CPU after each solver step. v1.7 uploads the authoritative `eta`, `u`, and `v` fields (12 bytes per cell), keeps topology static, and reconstructs position, normal, foam, and material color in the WebGPU vertex shader. This removes the CPU mesh traversal and cuts steady dynamic water traffic by 50%.','',
'### WebAssembly rope instance generation','',
'Rope segment basis construction, tension coloring, and matrix packing now run in the persistent soft-kernel WebAssembly arena. Payloads and projectile instances remain in TypeScript. A zero-length connector edge case discovered by the benchmark was corrected by separating raw segment length from the clamped matrix length.','',
'## Correctness and limits','',
'- All 100 integrated experiments retained finite state and deterministic hashes.','- Cross-version state hashes match in every fresh-process workload.','- Rope matrices/colors are checked against v1.6 with bounded relative error.','- Dawn validates the GPU-water storage-buffer pipeline, bind groups, indexed draw, HDR/MSAA pass, and upload cache.','- CPU timing and command-submission validation in this environment do not substitute for physical-GPU timestamp measurements on the target Mac.','',
'## Reproduction','', '```bash','npm ci','npm run bench:third:100','npm run bench:v1.6-v1.7','npm run bench:third:gate','npm run validate:v1.7','```','',
'Raw evidence: `benchmarks/results/v1.7-third-breakthrough-100.json` and `benchmarks/results/v1.6-v1.7-isolated.json`.','']
(root/'docs'/'PERFORMANCE_V1.7.md').write_text('\n'.join(lines))
(root/'PERFORMANCE.md').write_text('\n'.join(['# Performance Edition v1.7.0','',f"Exactly 100 production-path comparisons found a {c['water-full']['geometricMeanSpeedup']:.2f}× geometric-mean improvement for complete water frames and a {c['rope-frame']['geometricMeanSpeedup']:.2f}× geometric-mean improvement for rope frame construction across the tested scene sets.",'',f"The isolated changed-path geometric mean is {i['summary']['changedGeometricMeanSpeedup']:.2f}× against the bundled v1.6 source.",'','See [docs/PERFORMANCE_V1.7.md](docs/PERFORMANCE_V1.7.md).','']))
print(root/'docs'/'PERFORMANCE_V1.7.md')
