#include <stdint.h>

static inline float fmaxf_local(float a,float b){return a>b?a:b;}

__attribute__((export_name("cloth_substep")))
void cloth_substep(
  float* pos, float* prev, const float* invMass, int count,
  const float* edge, const float* windCosA, const float* windSinA,
  const float* windCosB, const float* windSinB,
  const float* windCosZ, const float* windSinZ,
  float dt2, float drag, float gust, float zScale, int verticalFlag, float extraLift,
  float sinA, float cosA, float sinB, float cosB, float sinZ, float cosZ,
  const uint16_t* offA, const uint16_t* offB, const float* rest,
  const float* scaleA, const float* scaleB,
  const uint16_t* structural, int structuralCount,
  const uint16_t* shear, int shearCount,
  const uint16_t* bend, int bendCount,
  int iterations, int shearCadence, int bendCadence,
  float sphereX, float sphereY, float sphereZ, float sphereRadius,
  float* strain, const uint16_t* idxA, const uint16_t* idxB, const float* invRest, int recordStrain
){
  for(int i=0;i<count;i++){
    if(invMass[i]==0.0f) continue;
    int o=i*3;
    float x=pos[o], y=pos[o+1], z=pos[o+2];
    float vx=(x-prev[o])*drag, vy=(y-prev[o+1])*drag, vz=(z-prev[o+2])*drag;
    prev[o]=x; prev[o+1]=y; prev[o+2]=z;
    float ta=sinA*windCosA[i]+cosA*windSinA[i];
    float tb=sinB*windCosB[i]+cosB*windSinB[i];
    float turb=ta+0.45f*tb;
    float windX=gust*edge[i]*(0.78f+turb*0.18f);
    float windOsc=sinZ*windCosZ[i]+cosZ*windSinZ[i];
    float windZ=gust*zScale*windOsc;
    float lift=verticalFlag ? turb*0.25f : fmaxf_local(0.0f,turb)*0.55f+extraLift;
    pos[o]=x+vx+windX*dt2;
    pos[o+1]=y+vy+(-9.81f+lift)*dt2;
    pos[o+2]=z+vz+windZ*dt2;
  }
  float target=sphereRadius+0.08f;
  float target2=target*target;
  for(int it=0;it<iterations;it++){
    const uint16_t* lists[3]={structural,shear,bend};
    int lens[3]={structuralCount, ((it%shearCadence)==0||it==iterations-1)?shearCount:0, ((it%bendCadence)==0||it==iterations-1)?bendCount:0};
    for(int k=0;k<3;k++){
      const uint16_t* list=lists[k]; int n=lens[k];
      for(int li=0;li<n;li++){
        int ci=list[li], ao=offA[ci], bo=offB[ci];
        float dx=pos[bo]-pos[ao], dy=pos[bo+1]-pos[ao+1], dz=pos[bo+2]-pos[ao+2];
        float d2=dx*dx+dy*dy+dz*dz;
        if(d2<1e-14f) continue;
        float dist=__builtin_sqrtf(d2);
        if(recordStrain && it==iterations-1){
          float sv=dist*invRest[ci]-1.0f; if(sv<0.0f) sv=-sv;
          int ia=idxA[ci], ib=idxB[ci];
          if(sv>strain[ia]) strain[ia]=sv; if(sv>strain[ib]) strain[ib]=sv;
        }
        float corr=(dist-rest[ci])/dist;
        float sa=corr*scaleA[ci], sb=corr*scaleB[ci];
        pos[ao]+=dx*sa; pos[ao+1]+=dy*sa; pos[ao+2]+=dz*sa;
        pos[bo]-=dx*sb; pos[bo+1]-=dy*sb; pos[bo+2]-=dz*sb;
      }
    }
    for(int i=0;i<count;i++){
      if(invMass[i]==0.0f) continue;
      int o=i*3;
      if(pos[o+1]<0.12f){
        pos[o+1]=0.12f;
        prev[o]=pos[o]-(pos[o]-prev[o])*0.72f;
        prev[o+2]=pos[o+2]-(pos[o+2]-prev[o+2])*0.72f;
      }
      if(sphereRadius>0.0f){
        float dx=pos[o]-sphereX, dy=pos[o+1]-sphereY, dz=pos[o+2]-sphereZ;
        float d2=dx*dx+dy*dy+dz*dz;
        if(d2<target2 && d2>1e-12f){
          float s=target/__builtin_sqrtf(d2);
          pos[o]=sphereX+dx*s; pos[o+1]=sphereY+dy*s; pos[o+2]=sphereZ+dz*s;
        }
      }
    }
  }
}

static int rope_solve_internal(
  float* pos, float* prev, const float* invMass, int particleCount,
  const uint16_t* aIdx, const uint16_t* bIdx, const float* rest,
  const float* invRest, const float* scaleA, const float* scaleB,
  uint8_t* broken, const uint8_t* render, const float* breakThreshold,
  int constraintCount, int iterations, int breakBudget
){
  int originalBudget=breakBudget;
  for(int it=0;it<iterations;it++){
    for(int ci=0;ci<constraintCount;ci++){
      if(broken[ci]) continue;
      int ao=(int)aIdx[ci]*3, bo=(int)bIdx[ci]*3;
      float dx=pos[bo]-pos[ao], dy=pos[bo+1]-pos[ao+1], dz=pos[bo+2]-pos[ao+2];
      float d2=dx*dx+dy*dy+dz*dz;
      if(d2<1e-14f) continue;
      float dist=__builtin_sqrtf(d2);
      if(render[ci] && breakBudget>0 && dist*invRest[ci]>breakThreshold[ci]){
        broken[ci]=1; breakBudget--; continue;
      }
      float corr=(dist-rest[ci])/dist;
      float sa=corr*scaleA[ci], sb=corr*scaleB[ci];
      pos[ao]+=dx*sa; pos[ao+1]+=dy*sa; pos[ao+2]+=dz*sa;
      pos[bo]-=dx*sb; pos[bo+1]-=dy*sb; pos[bo+2]-=dz*sb;
    }
    for(int i=0;i<particleCount;i++){
      if(invMass[i]==0.0f) continue;
      int o=i*3;
      if(pos[o+1]<0.16f){
        pos[o+1]=0.16f;
        prev[o]=pos[o]-(pos[o]-prev[o])*0.65f;
        prev[o+2]=pos[o+2]-(pos[o+2]-prev[o+2])*0.65f;
      }
      if(pos[o]<-42.0f)pos[o]=-42.0f; else if(pos[o]>42.0f)pos[o]=42.0f;
      if(pos[o+2]<-42.0f)pos[o+2]=-42.0f; else if(pos[o+2]>42.0f)pos[o+2]=42.0f;
    }
  }
  return originalBudget-breakBudget;
}

__attribute__((export_name("rope_integrate")))
void rope_integrate(
  float* pos,float* prev,const float* invMass,int count,
  const float* windCosA,const float* windSinA,const float* windCosZ,const float* windSinZ,
  float dt2,float sinA,float cosA,float sinZ,float cosZ,float windScale
){
  for(int i=0;i<count;i++){
    if(invMass[i]==0.0f)continue;
    int o=i*3; float x=pos[o],y=pos[o+1],z=pos[o+2];
    float vx=(x-prev[o])*0.994f,vy=(y-prev[o+1])*0.994f,vz=(z-prev[o+2])*0.994f;
    prev[o]=x;prev[o+1]=y;prev[o+2]=z;
    float wind=(sinA*windCosA[i]+cosA*windSinA[i])*windScale;
    float cross=(cosZ*windCosZ[i]-sinZ*windSinZ[i])*0.38f;
    pos[o]=x+vx+wind*dt2;pos[o+1]=y+vy-9.81f*dt2;pos[o+2]=z+vz+cross*dt2;
  }
}

__attribute__((export_name("rope_solve")))
int rope_solve(
  float* pos,float* prev,const float* invMass,int particleCount,
  const uint16_t* aIdx,const uint16_t* bIdx,const float* rest,const float* invRest,
  const float* scaleA,const float* scaleB,uint8_t* broken,const uint8_t* render,
  const float* breakThreshold,int constraintCount,int iterations,int breakBudget
){return rope_solve_internal(pos,prev,invMass,particleCount,aIdx,bIdx,rest,invRest,scaleA,scaleB,broken,render,breakThreshold,constraintCount,iterations,breakBudget);}

__attribute__((export_name("water_step")))
void water_step(
  const float* eta,const float* u,const float* v,
  float* nextEta,float* nextU,float* nextV,
  int cols,int rows,float velocityDecay,float pressureX,float pressureZ,float continuityX,float continuityZ
){
  for(int z=1;z<rows-1;z++){
    int row=z*cols,end=row+cols-1;
    for(int i=row+1;i<end;i++){
      nextU[i]=u[i]*velocityDecay-(eta[i+1]-eta[i-1])*pressureX;
      nextV[i]=v[i]*velocityDecay-(eta[i+cols]-eta[i-cols])*pressureZ;
    }
  }
  for(int z=1;z<rows-1;z++){
    int row=z*cols,end=row+cols-1;
    for(int i=row+1;i<end;i++){
      float n=eta[i]-(nextU[i+1]-nextU[i-1])*continuityX-(nextV[i+cols]-nextV[i-cols])*continuityZ;
      nextEta[i]=n<-1.65f?-1.65f:(n>1.65f?1.65f:n);
    }
  }
  int bottom=(rows-1)*cols,innerBottom=(rows-2)*cols;
  for(int x=0;x<cols;x++){
    nextEta[x]=nextEta[cols+x]*0.92f;nextU[x]=nextU[cols+x]*0.78f;nextV[x]=-nextV[cols+x]*0.18f;
    int b=bottom+x,in=innerBottom+x;
    nextEta[b]=nextEta[in]*0.92f;nextU[b]=nextU[in]*0.78f;nextV[b]=-nextV[in]*0.18f;
  }
  for(int z=0;z<rows;z++){
    int row=z*cols,li=row+1,r=row+cols-1,ri=r-1;
    nextEta[row]=nextEta[li]*0.92f;nextU[row]=-nextU[li]*0.18f;nextV[row]=nextV[li]*0.78f;
    nextEta[r]=nextEta[ri]*0.92f;nextU[r]=-nextU[ri]*0.18f;nextV[r]=nextV[ri]*0.78f;
  }
}

static inline int16_t clamp_snorm16(float x){if(x<-1.0f)x=-1.0f;else if(x>1.0f)x=1.0f;return (int16_t)(x*32767.0f);}
__attribute__((export_name("water_surface")))
void water_surface(
  const float* eta,const float* u,const float* v,uint8_t* vertices,
  int cols,int rows,float baseY,float invTwoDx,float invTwoDz
){
  for(int z=0;z<rows;z++){
    int row=z*cols,dr=(z>0?z-1:z)*cols,ur=(z+1<rows?z+1:z)*cols;
    for(int x=0;x<cols;x++){
      int i=row+x; float left=eta[row+(x>0?x-1:x)],right=eta[row+(x+1<cols?x+1:x)];
      float down=eta[dr+x],up=eta[ur+x];
      float nx=-(right-left)*invTwoDx,nz=-(up-down)*invTwoDz;
      float invL1=1.0f/( __builtin_fabsf(nx)+1.0f+__builtin_fabsf(nz) > 1e-12f ? __builtin_fabsf(nx)+1.0f+__builtin_fabsf(nz) : 1e-12f);
      float ox=nx*invL1,oy=invL1;
      if(nz<0.0f){float old=ox;ox=(1.0f-__builtin_fabsf(oy))*(old<0.0f?-1.0f:1.0f);oy=(1.0f-__builtin_fabsf(old))*(oy<0.0f?-1.0f:1.0f);}
      float lap=__builtin_fabsf(left+right+down+up-4.0f*eta[i]);
      float speed=__builtin_sqrtf(u[i]*u[i]+v[i]*v[i]);
      float foam=lap*2.2f+speed*0.22f-0.08f;if(foam<0.0f)foam=0.0f;else if(foam>1.0f)foam=1.0f;
      uint8_t* p=vertices+i*24;
      *(float*)(p+4)=baseY+eta[i];
      *(int16_t*)(p+12)=clamp_snorm16(ox);*(int16_t*)(p+14)=clamp_snorm16(oy);
      uint32_t r=(uint32_t)((0.02f+foam*0.38f)*255.0f),g=(uint32_t)((0.28f+foam*0.55f)*255.0f),b=(uint32_t)((0.55f+foam*0.42f)*255.0f),a=(uint32_t)(foam*255.0f);
      *(uint32_t*)(p+16)=r|(g<<8)|(b<<16)|(a<<24);
    }
  }
}
