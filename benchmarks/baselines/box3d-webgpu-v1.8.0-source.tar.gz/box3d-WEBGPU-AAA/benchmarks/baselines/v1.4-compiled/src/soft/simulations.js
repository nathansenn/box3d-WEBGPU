"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EMPTY_SURFACE = exports.SOFT_SURFACE_VERTEX_BYTES = exports.SOFT_INSTANCE_BUDGET = exports.SoftSimulationSuite = void 0;
const math_1 = require("../math");
const packed_surface_1 = require("./packed-surface");
const EMPTY_FLOAT32 = new Float32Array(0);
const EMPTY_UINT16 = new Uint16Array(0);
const EMPTY_UINT8 = new Uint8Array(0);
const MAX_SOFT_INSTANCES = 2048;
const MAX_WATER_DROPLETS = 768;
const TELEMETRY_INTERVAL_STEPS = 12;
const SURFACE_VERTEX_BYTES = packed_surface_1.PACKED_SURFACE_VERTEX_BYTES;
function softFamily(family) {
    return family === 'cloth' || family === 'rope' || family === 'water';
}
function quantizedHash(values, count = values.length) {
    let hash = 2166136261 >>> 0;
    const safeCount = Math.min(count, values.length);
    for (let i = 0; i < safeCount; i++) {
        const q = Math.trunc(values[i] * 1000) | 0;
        hash ^= q & 0xff;
        hash = Math.imul(hash, 16777619) >>> 0;
        hash ^= (q >>> 8) & 0xff;
        hash = Math.imul(hash, 16777619) >>> 0;
        hash ^= (q >>> 16) & 0xff;
        hash = Math.imul(hash, 16777619) >>> 0;
        hash ^= (q >>> 24) & 0xff;
        hash = Math.imul(hash, 16777619) >>> 0;
    }
    return hash >>> 0;
}
function mixColor(a, b, t) {
    const u = (0, math_1.clamp)(t, 0, 1);
    return [
        a[0] + (b[0] - a[0]) * u,
        a[1] + (b[1] - a[1]) * u,
        a[2] + (b[2] - a[2]) * u,
        a[3] + (b[3] - a[3]) * u,
    ];
}
function writeSegmentMatrixFromPositions(out, offset, positions, ao, bo, radius) {
    const ax = positions[ao];
    const ay = positions[ao + 1];
    const az = positions[ao + 2];
    const bx = positions[bo];
    const by = positions[bo + 1];
    const bz = positions[bo + 2];
    const dx = bx - ax;
    const dy = by - ay;
    const dz = bz - az;
    const length = Math.max(0.0001, Math.sqrt(dx * dx + dy * dy + dz * dz));
    const yx = dx / length;
    const yy = dy / length;
    const yz = dz / length;
    // x = normalize(cross(reference, y)); choose a stable reference without
    // allocating temporary vectors.
    let xx;
    let xy;
    let xz;
    if (Math.abs(yy) < 0.92) {
        xx = yz;
        xy = 0;
        xz = -yx;
    }
    else {
        xx = -yy;
        xy = yx;
        xz = 0;
    }
    const xLength = Math.max(1e-6, Math.sqrt(xx * xx + xy * xy + xz * xz));
    xx /= xLength;
    xy /= xLength;
    xz /= xLength;
    const zx = yy * xz - yz * xy;
    const zy = yz * xx - yx * xz;
    const zz = yx * xy - yy * xx;
    out[offset] = xx * radius;
    out[offset + 1] = xy * radius;
    out[offset + 2] = xz * radius;
    out[offset + 3] = 0;
    out[offset + 4] = yx * length * 0.5;
    out[offset + 5] = yy * length * 0.5;
    out[offset + 6] = yz * length * 0.5;
    out[offset + 7] = 0;
    out[offset + 8] = zx * radius;
    out[offset + 9] = zy * radius;
    out[offset + 10] = zz * radius;
    out[offset + 11] = 0;
    out[offset + 12] = (ax + bx) * 0.5;
    out[offset + 13] = (ay + by) * 0.5;
    out[offset + 14] = (az + bz) * 0.5;
    out[offset + 15] = 1;
}
function setColor(out, index, color) {
    const offset = index * 4;
    out[offset + 0] = color[0];
    out[offset + 1] = color[1];
    out[offset + 2] = color[2];
    out[offset + 3] = color[3];
}
function readPosition(array, index) {
    const offset = index * 3;
    return [array[offset], array[offset + 1], array[offset + 2]];
}
function writePosition(array, index, value) {
    const offset = index * 3;
    array[offset] = value[0];
    array[offset + 1] = value[1];
    array[offset + 2] = value[2];
}
function distance(array, a, b) {
    const ao = a * 3;
    const bo = b * 3;
    return Math.hypot(array[bo] - array[ao], array[bo + 1] - array[ao + 1], array[bo + 2] - array[ao + 2]);
}
class ClothSimulation {
    kind = 'cloth';
    label;
    cols;
    rows;
    count;
    positions;
    previous;
    invMass;
    strain;
    normals;
    constraints = [];
    constraintA = EMPTY_UINT16;
    constraintB = EMPTY_UINT16;
    constraintRest = EMPTY_FLOAT32;
    constraintInvRest = EMPTY_FLOAT32;
    constraintScaleA = EMPTY_FLOAT32;
    constraintScaleB = EMPTY_FLOAT32;
    constraintBreakThreshold = EMPTY_FLOAT32;
    constraintBroken = EMPTY_UINT8;
    constraintEdgeType = EMPTY_UINT8;
    constraintEdgeIndex = new Int32Array(0);
    constraintCountValue = 0;
    horizontalBroken;
    verticalBroken;
    vertices;
    indexScratch;
    edgeFactors;
    windSinA;
    windCosA;
    windSinB;
    windCosB;
    windSinZ;
    windCosZ;
    uvU;
    uvV;
    baseRgb;
    topologyDirty = true;
    topologyVersion = 1;
    cachedIndexCount = 0;
    instanceMatrices = new Float32Array(MAX_SOFT_INSTANCES * 16);
    instanceColors = new Float32Array(MAX_SOFT_INSTANCES * 4);
    debugLines = [];
    surfaceResult;
    frameResult;
    projectiles = [];
    rng;
    stress;
    variant;
    mode;
    iterations;
    windStrength;
    sphereCenter;
    sphereRadius;
    verticalLayout;
    tearingEnabled;
    baseColorA;
    baseColorB;
    time = 0;
    brokenCountValue = 0;
    energyValue = 0;
    hashValue = 0;
    hashCountdown = TELEMETRY_INTERVAL_STEPS;
    constructor(scene, stress, seed) {
        this.variant = scene.variant;
        this.mode = scene.mode;
        this.stress = stress;
        this.tearingEnabled = this.variant === 6 || (this.mode >= 3 && this.variant === 7);
        this.cols = Math.min(52, 24 + stress * 4 + (scene.mode >= 3 ? 4 : 0) + (scene.variant % 2) * 2);
        this.rows = Math.min(36, 16 + stress * 3 + (scene.mode === 4 ? 3 : 0));
        this.count = this.cols * this.rows;
        this.positions = new Float32Array(this.count * 3);
        this.previous = new Float32Array(this.count * 3);
        this.invMass = new Float32Array(this.count);
        this.strain = new Float32Array(this.count);
        this.normals = new Float32Array(this.count * 3);
        this.horizontalBroken = new Uint8Array(this.rows * Math.max(0, this.cols - 1));
        this.verticalBroken = new Uint8Array(Math.max(0, this.rows - 1) * this.cols);
        this.vertices = new packed_surface_1.PackedSurfaceBuffer(this.count);
        this.indexScratch = new Uint16Array(Math.max(0, (this.cols - 1) * (this.rows - 1) * 6));
        this.edgeFactors = new Float32Array(this.count);
        this.windSinA = new Float32Array(this.count);
        this.windCosA = new Float32Array(this.count);
        this.windSinB = new Float32Array(this.count);
        this.windCosB = new Float32Array(this.count);
        this.windSinZ = new Float32Array(this.count);
        this.windCosZ = new Float32Array(this.count);
        this.uvU = new Float32Array(this.count);
        this.uvV = new Float32Array(this.count);
        this.baseRgb = new Float32Array(this.count * 3);
        // PBD quality is driven by both substeps and solver iterations. Keep the
        // total pass count bounded so maximum cloth scenes remain interactive in
        // JavaScript while retaining enough projection passes for stable folds.
        this.iterations = 5 + stress + (scene.mode >= 3 ? 2 : 0);
        this.windStrength = 3.5 + stress * 1.35 + scene.mode * 0.45;
        this.rng = new math_1.LcgRng(seed ^ 0xc10f7a);
        this.label = `${scene.title.replace(/\s+—.*$/, '')} · PBD cloth ${this.cols}×${this.rows}`;
        this.verticalLayout = [0, 1, 5, 6, 8].includes(this.variant);
        this.sphereCenter = this.variant === 7 ? [0, 4.2, 0] : this.variant === 3 ? [0, 4.5, 0] : [0, -100, 0];
        this.sphereRadius = this.variant === 7 ? 3.1 : this.variant === 3 ? 1.6 : 0;
        const palettes = [
            [[0.04, 0.52, 0.72, 1], [0.92, 0.17, 0.23, 1]],
            [[0.12, 0.26, 0.56, 1], [0.98, 0.76, 0.24, 1]],
            [[0.22, 0.70, 0.62, 1], [0.08, 0.24, 0.42, 1]],
            [[0.78, 0.14, 0.52, 1], [0.18, 0.82, 0.90, 1]],
            [[0.86, 0.38, 0.08, 1], [0.98, 0.88, 0.45, 1]],
        ];
        [this.baseColorA, this.baseColorB] = palettes[this.variant % palettes.length];
        this.initializeParticles();
        this.initializeRenderCaches();
        this.initializeConstraints();
        this.packConstraints();
        this.previous.set(this.positions);
        this.hashValue = quantizedHash(this.positions, Math.min(this.positions.length, 4096));
        this.surfaceResult = {
            material: 'cloth', vertices: this.vertices.data, indices: this.indexScratch,
            vertexStride: packed_surface_1.PACKED_SURFACE_VERTEX_BYTES, vertexCount: this.count,
            indexCount: 0, topologyVersion: this.topologyVersion,
        };
        this.frameResult = {
            kind: this.kind, label: this.label, matrices: this.instanceMatrices,
            colors: this.instanceColors, instanceCount: 0, surface: this.surfaceResult,
            debugLines: this.debugLines, nodeCount: this.count,
            constraintCount: this.constraintCountValue, brokenCount: 0, energy: 0, hash: this.hashValue,
        };
        this.buildSurface();
    }
    index(x, y) { return y * this.cols + x; }
    initializeParticles() {
        const vertical = this.verticalLayout;
        const width = this.variant === 4 ? 15 : 14 + this.variant * 0.16;
        const height = this.variant === 4 ? 4.5 : 8.5 + (this.variant % 3) * 0.5;
        const baseY = vertical ? 2.0 : (this.variant === 2 ? 10.5 : this.variant === 9 ? 5.8 : 8.4);
        for (let y = 0; y < this.rows; y++) {
            const v = y / Math.max(1, this.rows - 1);
            for (let x = 0; x < this.cols; x++) {
                const u = x / Math.max(1, this.cols - 1);
                const i = this.index(x, y);
                let p;
                if (vertical) {
                    const flutter = Math.sin(u * Math.PI) * Math.sin(v * Math.PI) * 0.18;
                    p = [(u - 0.5) * width, baseY + (1 - v) * height, flutter];
                    if (this.variant === 0 || this.variant === 5)
                        p[0] -= width * 0.44;
                    if (this.variant === 6)
                        p[2] += Math.sin(u * 8 + v * 3) * 0.05;
                }
                else {
                    const xw = (u - 0.5) * width;
                    const zw = (v - 0.5) * (this.variant === 4 ? 5.2 : 10.5);
                    let yw = baseY;
                    if (this.variant === 2) {
                        const nx = (u - 0.5) * 2;
                        const nz = (v - 0.5) * 2;
                        yw += Math.max(0, 1 - nx * nx - nz * nz) * 2.4;
                    }
                    else if (this.variant === 3 || this.variant === 4) {
                        yw -= Math.sin(u * Math.PI) * Math.sin(v * Math.PI) * (this.variant === 4 ? 1.6 : 0.9);
                    }
                    else if (this.variant === 7) {
                        yw += Math.sin(u * Math.PI) * Math.sin(v * Math.PI) * 0.12;
                    }
                    else if (this.variant === 9) {
                        yw += Math.sin(u * Math.PI * 2) * Math.sin(v * Math.PI * 2) * 0.08;
                    }
                    p = [xw, yw, zw];
                }
                writePosition(this.positions, i, p);
                this.invMass[i] = 1;
            }
        }
        const pin = (x, y) => { this.invMass[this.index(x, y)] = 0; };
        const pinTopRow = () => { for (let x = 0; x < this.cols; x++)
            pin(x, 0); };
        const pinPerimeter = () => {
            for (let x = 0; x < this.cols; x++) {
                pin(x, 0);
                pin(x, this.rows - 1);
            }
            for (let y = 0; y < this.rows; y++) {
                pin(0, y);
                pin(this.cols - 1, y);
            }
        };
        switch (this.variant) {
            case 0:
            case 5:
                for (let y = 0; y < this.rows; y++)
                    pin(0, y);
                break;
            case 1:
            case 8:
                pinTopRow();
                break;
            case 2:
            case 3:
            case 7:
                pin(0, 0);
                pin(this.cols - 1, 0);
                pin(0, this.rows - 1);
                pin(this.cols - 1, this.rows - 1);
                break;
            case 4:
                for (let y = 0; y < this.rows; y++) {
                    pin(0, y);
                    pin(this.cols - 1, y);
                }
                break;
            case 6:
                for (let x = 0; x < this.cols; x += 3)
                    pin(x, 0);
                pin(this.cols - 1, 0);
                break;
            case 9:
                pinPerimeter();
                break;
            default:
                pinTopRow();
                break;
        }
    }
    initializeRenderCaches() {
        const invCols = 1 / Math.max(1, this.cols - 1);
        const invRows = 1 / Math.max(1, this.rows - 1);
        for (let y = 0; y < this.rows; y++) {
            const v = y * invRows;
            for (let x = 0; x < this.cols; x++) {
                const u = x * invCols;
                const i = y * this.cols + x;
                const o = i * 3;
                const px = this.positions[o];
                const py = this.positions[o + 1];
                const pz = this.positions[o + 2];
                const phaseA = px * 0.48 + py * 0.22 + pz * 0.31;
                const phaseB = -px * 0.27 + py * 0.39;
                const phaseZ = px * 0.17;
                this.windSinA[i] = Math.sin(phaseA);
                this.windCosA[i] = Math.cos(phaseA);
                this.windSinB[i] = Math.sin(phaseB);
                this.windCosB[i] = Math.cos(phaseB);
                this.windSinZ[i] = Math.sin(phaseZ);
                this.windCosZ[i] = Math.cos(phaseZ);
                this.edgeFactors[i] = 0.55 + 0.45 * Math.sin(u * Math.PI);
                this.uvU[i] = u;
                this.uvV[i] = v;
                const packedOffset = i * 12;
                this.vertices.u16[packedOffset + 10] = Math.round(u * 65535);
                this.vertices.u16[packedOffset + 11] = Math.round(v * 65535);
                const checker = ((Math.floor(u * 10) + Math.floor(v * 8)) & 1) === 0 ? 0.22 : 0.78;
                this.baseRgb[o] = this.baseColorA[0] + (this.baseColorB[0] - this.baseColorA[0]) * checker;
                this.baseRgb[o + 1] = this.baseColorA[1] + (this.baseColorB[1] - this.baseColorA[1]) * checker;
                this.baseRgb[o + 2] = this.baseColorA[2] + (this.baseColorB[2] - this.baseColorA[2]) * checker;
            }
        }
    }
    addConstraint(a, b, stiffness, breakThreshold, edgeType = 0, edgeIndex = -1) {
        this.constraints.push({
            a,
            b,
            rest: distance(this.positions, a, b),
            solveStiffness: 1 - Math.pow(1 - stiffness, 1 / this.iterations),
            breakThreshold,
            broken: false,
            edgeType,
            edgeIndex,
        });
    }
    initializeConstraints() {
        const structuralBreak = this.tearingEnabled ? 1.34 + this.stress * 0.035 : 4.5;
        const shearBreak = this.tearingEnabled ? structuralBreak * 1.08 : 4.8;
        for (let y = 0; y < this.rows; y++) {
            for (let x = 0; x < this.cols; x++) {
                const i = this.index(x, y);
                if (x + 1 < this.cols) {
                    this.addConstraint(i, this.index(x + 1, y), 0.98, structuralBreak, 1, y * (this.cols - 1) + x);
                }
                if (y + 1 < this.rows) {
                    this.addConstraint(i, this.index(x, y + 1), 0.98, structuralBreak, 2, y * this.cols + x);
                }
                if (x + 1 < this.cols && y + 1 < this.rows) {
                    this.addConstraint(i, this.index(x + 1, y + 1), 0.88, shearBreak, 0, -1);
                    this.addConstraint(this.index(x + 1, y), this.index(x, y + 1), 0.88, shearBreak, 0, -1);
                }
                if (x + 2 < this.cols)
                    this.addConstraint(i, this.index(x + 2, y), 0.48, 8, 0, -1);
                if (y + 2 < this.rows)
                    this.addConstraint(i, this.index(x, y + 2), 0.48, 8, 0, -1);
            }
        }
    }
    packConstraints() {
        // Convert construction-time objects into structure-of-arrays storage. The
        // solver touches every constraint many times per frame, so contiguous
        // typed arrays dramatically reduce property lookups and cache misses.
        const active = this.constraints.filter((constraint) => {
            const weight = this.invMass[constraint.a] + this.invMass[constraint.b];
            return weight > 0;
        });
        const count = active.length;
        this.constraintA = new Uint16Array(count);
        this.constraintB = new Uint16Array(count);
        this.constraintRest = new Float32Array(count);
        this.constraintInvRest = new Float32Array(count);
        this.constraintScaleA = new Float32Array(count);
        this.constraintScaleB = new Float32Array(count);
        this.constraintBreakThreshold = new Float32Array(count);
        this.constraintBroken = new Uint8Array(count);
        this.constraintEdgeType = new Uint8Array(count);
        this.constraintEdgeIndex = new Int32Array(count);
        for (let i = 0; i < count; i++) {
            const constraint = active[i];
            const wa = this.invMass[constraint.a];
            const wb = this.invMass[constraint.b];
            const inverseWeight = 1 / (wa + wb);
            this.constraintA[i] = constraint.a;
            this.constraintB[i] = constraint.b;
            this.constraintRest[i] = constraint.rest;
            this.constraintInvRest[i] = 1 / Math.max(1e-8, constraint.rest);
            this.constraintScaleA[i] = constraint.solveStiffness * wa * inverseWeight;
            this.constraintScaleB[i] = constraint.solveStiffness * wb * inverseWeight;
            this.constraintBreakThreshold[i] = constraint.breakThreshold;
            this.constraintEdgeType[i] = constraint.edgeType;
            this.constraintEdgeIndex[i] = constraint.edgeIndex;
        }
        this.constraintCountValue = count;
        this.constraints.length = 0;
    }
    step(dt, subSteps) {
        if (!Number.isFinite(dt) || dt <= 0)
            return;
        // Two position-integration substeps plus the bounded projection loop are
        // substantially faster than blindly mirroring the rigid-body substep
        // count, and avoid doing 70+ complete constraint sweeps per frame.
        const steps = Math.min(2, (0, math_1.clamp)(Math.round(subSteps), 1, 8));
        const subDt = Math.min(dt, 1 / 30) / steps;
        this.strain.fill(0);
        for (let sub = 0; sub < steps; sub++) {
            this.time += subDt;
            this.integrateProjectiles(subDt);
            this.integrateParticles(subDt);
            this.collideProjectiles();
            let tearBudget = this.variant === 6 ? 8 : this.mode >= 3 ? 3 : 1;
            for (let iteration = 0; iteration < this.iterations; iteration++) {
                const recordStrain = sub === steps - 1 && iteration === this.iterations - 1;
                tearBudget = this.solveConstraints(tearBudget, recordStrain);
                this.solveCollisions();
            }
        }
        this.computeEnergy(dt);
        if (--this.hashCountdown <= 0) {
            this.hashValue = quantizedHash(this.positions, Math.min(this.positions.length, 4096));
            this.hashCountdown = TELEMETRY_INTERVAL_STEPS;
        }
    }
    integrateParticles(dt) {
        const dt2 = dt * dt;
        const drag = 0.992 - this.stress * 0.0004;
        const gust = this.windStrength * (0.72 + 0.28 * Math.sin(this.time * 1.7));
        const vertical = this.verticalLayout;
        // Phase-cache the deterministic wind field. The old implementation called
        // Math.sin three times per moving particle per substep. Angle addition
        // keeps the same periodic frequencies with six trigonometric calls total.
        const timeA = this.time * 3.1;
        const timeB = this.time * 7.3;
        const timeZ = this.time * 1.3;
        const sinA = Math.sin(timeA);
        const cosA = Math.cos(timeA);
        const sinB = Math.sin(timeB);
        const cosB = Math.cos(timeB);
        const sinZ = Math.sin(timeZ);
        const cosZ = Math.cos(timeZ);
        const zScale = vertical ? 0.28 : 0.52;
        for (let i = 0; i < this.count; i++) {
            if (this.invMass[i] === 0)
                continue;
            const o = i * 3;
            const x = this.positions[o];
            const y = this.positions[o + 1];
            const z = this.positions[o + 2];
            const vx = (x - this.previous[o]) * drag;
            const vy = (y - this.previous[o + 1]) * drag;
            const vz = (z - this.previous[o + 2]) * drag;
            this.previous[o] = x;
            this.previous[o + 1] = y;
            this.previous[o + 2] = z;
            const turbulenceA = sinA * this.windCosA[i] + cosA * this.windSinA[i];
            const turbulenceB = sinB * this.windCosB[i] + cosB * this.windSinB[i];
            const turbulence = turbulenceA + 0.45 * turbulenceB;
            const windX = gust * this.edgeFactors[i] * (0.78 + turbulence * 0.18);
            const windOscillation = sinZ * this.windCosZ[i] + cosZ * this.windSinZ[i];
            const windZ = gust * zScale * windOscillation;
            const lift = vertical ? turbulence * 0.25 : Math.max(0, turbulence) * 0.55 + (this.variant === 2 ? 1.2 : 0);
            this.positions[o] = x + vx + windX * dt2;
            this.positions[o + 1] = y + vy + (-9.81 + lift) * dt2;
            this.positions[o + 2] = z + vz + windZ * dt2;
        }
    }
    solveConstraints(tearBudget, recordStrain) {
        const positions = this.positions;
        const count = this.constraintCountValue;
        const aIndices = this.constraintA;
        const bIndices = this.constraintB;
        const rests = this.constraintRest;
        const scaleAValues = this.constraintScaleA;
        const scaleBValues = this.constraintScaleB;
        // The overwhelming majority of projection passes do not record strain and
        // most cloth recipes cannot tear. Keep that common path branch-light.
        if (!this.tearingEnabled && !recordStrain) {
            for (let ci = 0; ci < count; ci++) {
                const a = aIndices[ci];
                const b = bIndices[ci];
                const ao = a * 3;
                const bo = b * 3;
                const dx = positions[bo] - positions[ao];
                const dy = positions[bo + 1] - positions[ao + 1];
                const dz = positions[bo + 2] - positions[ao + 2];
                const distanceSquared = dx * dx + dy * dy + dz * dz;
                if (distanceSquared < 1e-14)
                    continue;
                const dist = Math.sqrt(distanceSquared);
                const correction = (dist - rests[ci]) / dist;
                const scaleA = correction * scaleAValues[ci];
                const scaleB = correction * scaleBValues[ci];
                positions[ao] += dx * scaleA;
                positions[ao + 1] += dy * scaleA;
                positions[ao + 2] += dz * scaleA;
                positions[bo] -= dx * scaleB;
                positions[bo + 1] -= dy * scaleB;
                positions[bo + 2] -= dz * scaleB;
            }
            return tearBudget;
        }
        const strainValues = this.strain;
        const invRests = this.constraintInvRest;
        const breakThresholds = this.constraintBreakThreshold;
        const broken = this.constraintBroken;
        const edgeTypes = this.constraintEdgeType;
        const edgeIndices = this.constraintEdgeIndex;
        const canTear = this.tearingEnabled;
        for (let ci = 0; ci < count; ci++) {
            const edgeType = edgeTypes[ci];
            if (canTear && edgeType !== 0 && broken[ci] !== 0)
                continue;
            const a = aIndices[ci];
            const b = bIndices[ci];
            const ao = a * 3;
            const bo = b * 3;
            const dx = positions[bo] - positions[ao];
            const dy = positions[bo + 1] - positions[ao + 1];
            const dz = positions[bo + 2] - positions[ao + 2];
            const distanceSquared = dx * dx + dy * dy + dz * dz;
            if (distanceSquared < 1e-14)
                continue;
            const dist = Math.sqrt(distanceSquared);
            const ratio = dist * invRests[ci];
            if (recordStrain) {
                const strain = Math.abs(ratio - 1);
                if (strain > strainValues[a])
                    strainValues[a] = strain;
                if (strain > strainValues[b])
                    strainValues[b] = strain;
            }
            if (canTear && ratio > breakThresholds[ci] && tearBudget > 0 && edgeType !== 0) {
                broken[ci] = 1;
                tearBudget--;
                this.brokenCountValue++;
                this.topologyDirty = true;
                this.topologyVersion++;
                const edgeIndex = edgeIndices[ci];
                if (edgeType === 1 && edgeIndex >= 0)
                    this.horizontalBroken[edgeIndex] = 1;
                if (edgeType === 2 && edgeIndex >= 0)
                    this.verticalBroken[edgeIndex] = 1;
                continue;
            }
            const correction = (dist - rests[ci]) / dist;
            const scaleA = correction * scaleAValues[ci];
            const scaleB = correction * scaleBValues[ci];
            positions[ao] += dx * scaleA;
            positions[ao + 1] += dy * scaleA;
            positions[ao + 2] += dz * scaleA;
            positions[bo] -= dx * scaleB;
            positions[bo + 1] -= dy * scaleB;
            positions[bo + 2] -= dz * scaleB;
        }
        return tearBudget;
    }
    solveCollisions() {
        for (let i = 0; i < this.count; i++) {
            if (this.invMass[i] === 0)
                continue;
            const o = i * 3;
            if (this.positions[o + 1] < 0.12) {
                this.positions[o + 1] = 0.12;
                this.previous[o] = this.positions[o] - (this.positions[o] - this.previous[o]) * 0.72;
                this.previous[o + 2] = this.positions[o + 2] - (this.positions[o + 2] - this.previous[o + 2]) * 0.72;
            }
            if (this.sphereRadius > 0) {
                const dx = this.positions[o] - this.sphereCenter[0];
                const dy = this.positions[o + 1] - this.sphereCenter[1];
                const dz = this.positions[o + 2] - this.sphereCenter[2];
                const dist = Math.hypot(dx, dy, dz);
                const target = this.sphereRadius + 0.08;
                if (dist < target && dist > 1e-6) {
                    const scale = target / dist;
                    this.positions[o] = this.sphereCenter[0] + dx * scale;
                    this.positions[o + 1] = this.sphereCenter[1] + dy * scale;
                    this.positions[o + 2] = this.sphereCenter[2] + dz * scale;
                }
            }
        }
    }
    integrateProjectiles(dt) {
        for (const projectile of this.projectiles) {
            projectile.life -= dt;
            projectile.velocity[1] -= 9.81 * dt;
            projectile.position[0] += projectile.velocity[0] * dt;
            projectile.position[1] += projectile.velocity[1] * dt;
            projectile.position[2] += projectile.velocity[2] * dt;
            if (projectile.position[1] < projectile.radius) {
                projectile.position[1] = projectile.radius;
                projectile.velocity[1] = Math.abs(projectile.velocity[1]) * 0.22;
                projectile.velocity[0] *= 0.72;
                projectile.velocity[2] *= 0.72;
            }
        }
        let write = 0;
        for (let read = 0; read < this.projectiles.length; read++) {
            const projectile = this.projectiles[read];
            if (projectile.life > 0)
                this.projectiles[write++] = projectile;
        }
        this.projectiles.length = write;
    }
    collideProjectiles() {
        for (const projectile of this.projectiles) {
            const speed = Math.hypot(projectile.velocity[0], projectile.velocity[1], projectile.velocity[2]);
            for (let i = 0; i < this.count; i++) {
                if (this.invMass[i] === 0)
                    continue;
                const o = i * 3;
                const dx = this.positions[o] - projectile.position[0];
                const dy = this.positions[o + 1] - projectile.position[1];
                const dz = this.positions[o + 2] - projectile.position[2];
                const dist = Math.hypot(dx, dy, dz);
                const target = projectile.radius + 0.16;
                if (dist >= target || dist < 1e-6)
                    continue;
                const nx = dx / dist;
                const ny = dy / dist;
                const nz = dz / dist;
                const push = (target - dist) + speed * 0.008;
                this.positions[o] += nx * push;
                this.positions[o + 1] += ny * push;
                this.positions[o + 2] += nz * push;
                this.previous[o] -= projectile.velocity[0] * 0.009;
                this.previous[o + 1] -= projectile.velocity[1] * 0.009;
                this.previous[o + 2] -= projectile.velocity[2] * 0.009;
            }
        }
    }
    computeEnergy(dt) {
        let energy = 0;
        const invDt = 1 / Math.max(dt, 1e-5);
        for (let i = 0; i < this.count; i++) {
            const o = i * 3;
            const vx = (this.positions[o] - this.previous[o]) * invDt;
            const vy = (this.positions[o + 1] - this.previous[o + 1]) * invDt;
            const vz = (this.positions[o + 2] - this.previous[o + 2]) * invDt;
            energy += vx * vx + vy * vy + vz * vz;
        }
        this.energyValue = energy / Math.max(1, this.count);
    }
    kick(strength) {
        const impulse = Math.max(1, strength) * 0.018;
        for (let i = 0; i < this.count; i++) {
            if (this.invMass[i] === 0)
                continue;
            const o = i * 3;
            const wave = 0.35 + 0.65 * ((i % this.cols) / Math.max(1, this.cols - 1));
            this.previous[o] -= impulse * wave;
            this.previous[o + 1] += this.rng.signed(impulse * 0.2);
            this.previous[o + 2] -= this.rng.signed(impulse * 0.45);
        }
    }
    explode(center, strength, radius) {
        const r = Math.max(0.5, radius);
        for (let i = 0; i < this.count; i++) {
            if (this.invMass[i] === 0)
                continue;
            const o = i * 3;
            const dx = this.positions[o] - center[0];
            const dy = this.positions[o + 1] - center[1];
            const dz = this.positions[o + 2] - center[2];
            const dist = Math.hypot(dx, dy, dz);
            if (dist >= r || dist < 1e-6)
                continue;
            const falloff = 1 - dist / r;
            const impulse = strength * falloff * 0.012;
            this.previous[o] -= (dx / dist) * impulse;
            this.previous[o + 1] -= (dy / dist + 0.35) * impulse;
            this.previous[o + 2] -= (dz / dist) * impulse;
        }
    }
    launchProjectile(position, velocity, size) {
        if (this.projectiles.length >= 24)
            return -1;
        this.projectiles.push({
            position: [...position],
            velocity: [...velocity],
            radius: (0, math_1.clamp)(size, 0.18, 1.6),
            life: 8,
            color: [1, 0.62, 0.13, 2.1],
        });
        return this.projectiles.length - 1;
    }
    spawnRain(count, spread, height) {
        const allowed = Math.max(0, Math.min(Math.max(0, Math.round(count)), 160 - this.projectiles.length));
        for (let i = 0; i < allowed; i++) {
            this.projectiles.push({
                position: [this.rng.signed(spread), height + this.rng.range(0, 10), this.rng.signed(spread * 0.65)],
                velocity: [this.rng.signed(0.6), this.rng.range(-12, -7), this.rng.signed(0.6)],
                radius: this.rng.range(0.055, 0.12),
                life: 5,
                color: [0.25, 0.78, 1, 1.8],
            });
        }
        return allowed;
    }
    rebuildTopology() {
        if (!this.topologyDirty)
            return;
        let indexCount = 0;
        const cols = this.cols;
        const rows = this.rows;
        const horizontal = this.horizontalBroken;
        const vertical = this.verticalBroken;
        const indices = this.indexScratch;
        const horizontalStride = cols - 1;
        for (let y = 0; y < rows - 1; y++) {
            const row = y * cols;
            const nextRow = row + cols;
            const horizontalRow = y * horizontalStride;
            const horizontalNext = horizontalRow + horizontalStride;
            const verticalRow = y * cols;
            for (let x = 0; x < cols - 1; x++) {
                if (horizontal[horizontalRow + x] !== 0 ||
                    horizontal[horizontalNext + x] !== 0 ||
                    vertical[verticalRow + x] !== 0 ||
                    vertical[verticalRow + x + 1] !== 0)
                    continue;
                const i0 = row + x;
                const i1 = i0 + 1;
                const i2 = nextRow + x;
                const i3 = i2 + 1;
                if (((x + y) & 1) === 0) {
                    indices[indexCount++] = i0;
                    indices[indexCount++] = i2;
                    indices[indexCount++] = i1;
                    indices[indexCount++] = i1;
                    indices[indexCount++] = i2;
                    indices[indexCount++] = i3;
                }
                else {
                    indices[indexCount++] = i0;
                    indices[indexCount++] = i2;
                    indices[indexCount++] = i3;
                    indices[indexCount++] = i0;
                    indices[indexCount++] = i3;
                    indices[indexCount++] = i1;
                }
            }
        }
        this.cachedIndexCount = indexCount;
        this.topologyDirty = false;
    }
    buildSurface() {
        this.rebuildTopology();
        const indexCount = this.cachedIndexCount;
        const normals = this.normals;
        const positions = this.positions;
        const indices = this.indexScratch;
        normals.fill(0);
        // Allocation-free triangle normal accumulation.
        for (let i = 0; i < indexCount; i += 3) {
            const ia = indices[i];
            const ib = indices[i + 1];
            const ic = indices[i + 2];
            const ao = ia * 3;
            const bo = ib * 3;
            const co = ic * 3;
            const abx = positions[bo] - positions[ao];
            const aby = positions[bo + 1] - positions[ao + 1];
            const abz = positions[bo + 2] - positions[ao + 2];
            const acx = positions[co] - positions[ao];
            const acy = positions[co + 1] - positions[ao + 1];
            const acz = positions[co + 2] - positions[ao + 2];
            const nx = aby * acz - abz * acy;
            const ny = abz * acx - abx * acz;
            const nz = abx * acy - aby * acx;
            normals[ao] += nx;
            normals[ao + 1] += ny;
            normals[ao + 2] += nz;
            normals[bo] += nx;
            normals[bo + 1] += ny;
            normals[bo + 2] += nz;
            normals[co] += nx;
            normals[co + 1] += ny;
            normals[co + 2] += nz;
        }
        const writer = this.vertices;
        const f32 = writer.f32;
        const i16 = writer.i16;
        const u8 = writer.u8;
        const baseRgb = this.baseRgb;
        for (let i = 0; i < this.count; i++) {
            const o = i * 3;
            let nx = normals[o];
            let ny = normals[o + 1];
            let nz = normals[o + 2];
            if (Math.abs(nx) + Math.abs(ny) + Math.abs(nz) <= 1e-12) {
                if (this.verticalLayout) {
                    nx = 0;
                    ny = 0;
                    nz = 1;
                }
                else {
                    nx = 0;
                    ny = 1;
                    nz = 0;
                }
            }
            // Octahedral encoding is homogeneous: L1 normalization below preserves
            // direction, so a prior Euclidean sqrt/normalize pass was redundant.
            const inverseL1 = 1 / Math.max(1e-12, Math.abs(nx) + Math.abs(ny) + Math.abs(nz));
            let ox = nx * inverseL1;
            let oy = ny * inverseL1;
            if (nz < 0) {
                const oldX = ox;
                ox = (1 - Math.abs(oy)) * (oldX < 0 ? -1 : 1);
                oy = (1 - Math.abs(oldX)) * (oy < 0 ? -1 : 1);
            }
            let stress = this.strain[i] * 3.2;
            stress = stress < 0 ? 0 : stress > 1 ? 1 : stress;
            const blend = stress * 0.72;
            const baseR = baseRgb[o];
            const baseG = baseRgb[o + 1];
            const baseB = baseRgb[o + 2];
            const f = i * 6;
            const h = i * 12;
            const byte = i * packed_surface_1.PACKED_SURFACE_VERTEX_BYTES;
            f32[f] = positions[o];
            f32[f + 1] = positions[o + 1];
            f32[f + 2] = positions[o + 2];
            i16[h + 6] = Math.round((ox < -1 ? -1 : ox > 1 ? 1 : ox) * 32767);
            i16[h + 7] = Math.round((oy < -1 ? -1 : oy > 1 ? 1 : oy) * 32767);
            u8[byte + 16] = Math.round((baseR + (1 - baseR) * blend) * 255);
            u8[byte + 17] = Math.round((baseG + (0.14 - baseG) * blend) * 255);
            u8[byte + 18] = Math.round((baseB + (0.03 - baseB) * blend) * 255);
            u8[byte + 19] = Math.round(stress * 255);
        }
        const surface = this.surfaceResult;
        surface.indexCount = indexCount;
        surface.topologyVersion = this.topologyVersion;
        return surface;
    }
    buildFrame(debug) {
        const matrices = this.instanceMatrices;
        const colors = this.instanceColors;
        let instanceCount = 0;
        if (this.sphereRadius > 0 && instanceCount < MAX_SOFT_INSTANCES) {
            (0, math_1.writeModelMatrixFromEuler)(matrices, instanceCount * 16, this.sphereCenter, [0, 0, 0], [this.sphereRadius, this.sphereRadius, this.sphereRadius]);
            setColor(colors, instanceCount, [0.12, 0.18, 0.28, 1]);
            instanceCount++;
        }
        for (const projectile of this.projectiles) {
            if (instanceCount >= MAX_SOFT_INSTANCES)
                break;
            (0, math_1.writeModelMatrixFromEuler)(matrices, instanceCount * 16, projectile.position, [this.time, this.time * 0.7, 0], [projectile.radius, projectile.radius, projectile.radius]);
            setColor(colors, instanceCount, projectile.color);
            instanceCount++;
        }
        const debugLines = this.debugLines;
        debugLines.length = 0;
        if (debug) {
            const count = this.constraintCountValue;
            const stride = Math.max(1, Math.floor(count / 420));
            const positions = this.positions;
            for (let i = 0; i < count; i += stride) {
                if (this.constraintBroken[i] !== 0)
                    continue;
                const a = this.constraintA[i];
                const b = this.constraintB[i];
                const ao = a * 3;
                const bo = b * 3;
                const dx = positions[bo] - positions[ao];
                const dy = positions[bo + 1] - positions[ao + 1];
                const dz = positions[bo + 2] - positions[ao + 2];
                const ratio = Math.sqrt(dx * dx + dy * dy + dz * dz) * this.constraintInvRest[i];
                const tension = (0, math_1.clamp)((ratio - 1) * 5, 0, 1);
                debugLines.push({
                    ax: positions[ao], ay: positions[ao + 1], az: positions[ao + 2],
                    bx: positions[bo], by: positions[bo + 1], bz: positions[bo + 2],
                    r: 0.2 + tension * 0.8, g: 0.8 - tension * 0.65, b: 1 - tension * 0.8, a: 0.22,
                });
            }
        }
        const frame = this.frameResult;
        frame.instanceCount = instanceCount;
        frame.surface = this.buildSurface();
        frame.brokenCount = this.brokenCountValue;
        frame.energy = this.energyValue;
        frame.hash = this.hashValue;
        return frame;
    }
    currentHash() {
        return quantizedHash(this.positions, Math.min(this.positions.length, 4096));
    }
    destroy() {
        this.projectiles.length = 0;
    }
}
class RopeSimulation {
    kind = 'rope';
    label;
    positions;
    previous;
    invMass;
    constraints = [];
    ropeA = EMPTY_UINT16;
    ropeB = EMPTY_UINT16;
    ropeRest = EMPTY_FLOAT32;
    ropeInvRest = EMPTY_FLOAT32;
    ropeScaleA = EMPTY_FLOAT32;
    ropeScaleB = EMPTY_FLOAT32;
    ropeBreakThreshold = EMPTY_FLOAT32;
    ropeBroken = EMPTY_UINT8;
    ropeRender = EMPTY_UINT8;
    ropeRadius = EMPTY_FLOAT32;
    ropeColor = EMPTY_FLOAT32;
    ropeConstraintCount = 0;
    payloads = [];
    projectiles = [];
    instanceMatrices = new Float32Array(MAX_SOFT_INSTANCES * 16);
    instanceColors = new Float32Array(MAX_SOFT_INSTANCES * 4);
    debugLines = [];
    frameResult;
    rng;
    stress;
    variant;
    mode;
    iterations;
    windSinA = EMPTY_FLOAT32;
    windCosA = EMPTY_FLOAT32;
    windSinZ = EMPTY_FLOAT32;
    windCosZ = EMPTY_FLOAT32;
    time = 0;
    brokenCountValue = 0;
    energyValue = 0;
    hashValue = 0;
    hashCountdown = TELEMETRY_INTERVAL_STEPS;
    constructor(scene, stress, seed) {
        this.stress = stress;
        this.variant = scene.variant;
        this.mode = scene.mode;
        this.iterations = 6 + stress + (scene.mode >= 3 ? 2 : 0);
        this.rng = new math_1.LcgRng(seed ^ 0x70e5a11);
        this.label = `${scene.title.replace(/\s+—.*$/, '')} · PBD rope/cable solver`;
        const positions = [];
        const invMass = [];
        const addParticle = (p, mass = 1) => {
            const index = invMass.length;
            positions.push(p[0], p[1], p[2]);
            invMass.push(mass <= 0 ? 0 : 1 / mass);
            return index;
        };
        const addConstraint = (a, b, stiffness, breakThreshold, render, radius, color) => {
            const ao = a * 3;
            const bo = b * 3;
            const rest = Math.hypot(positions[bo] - positions[ao], positions[bo + 1] - positions[ao + 1], positions[bo + 2] - positions[ao + 2]);
            this.constraints.push({
                a,
                b,
                rest,
                solveStiffness: 1 - Math.pow(1 - stiffness, 1 / this.iterations),
                breakThreshold,
                broken: false,
                render,
                radius,
                color,
            });
        };
        const addChain = (start, end, segments, sag, pinStart, pinEnd, radius, color, breakThreshold = 1.65) => {
            const chain = [];
            for (let i = 0; i <= segments; i++) {
                const t = i / segments;
                const p = [
                    start[0] + (end[0] - start[0]) * t,
                    start[1] + (end[1] - start[1]) * t - Math.sin(Math.PI * t) * sag,
                    start[2] + (end[2] - start[2]) * t,
                ];
                const pinned = (i === 0 && pinStart) || (i === segments && pinEnd);
                chain.push(addParticle(p, pinned ? 0 : 1));
            }
            for (let i = 0; i < chain.length - 1; i++) {
                addConstraint(chain[i], chain[i + 1], 0.99, breakThreshold, true, radius, color);
            }
            for (let i = 0; i < chain.length - 2; i++) {
                addConstraint(chain[i], chain[i + 2], 0.42, breakThreshold * 1.75, false, radius, color);
            }
            return chain;
        };
        const gold = [0.94, 0.62, 0.16, 1];
        const steel = [0.45, 0.62, 0.76, 1];
        const red = [0.84, 0.18, 0.18, 1];
        const teal = [0.08, 0.65, 0.72, 1];
        const segments = 28 + stress * 7 + (scene.mode >= 3 ? 6 : 0);
        const weak = this.variant === 5 || this.variant === 8 ? 1.27 + stress * 0.03 : 1.58 + stress * 0.04;
        if (this.variant === 0) {
            const chain = addChain([0, 17, 0], [0, 5.2, 0], segments, 0.3, true, false, 0.10, gold, weak);
            this.payloads.push({ particle: chain[chain.length - 1], half: [1.6, 0.65, 1.0], color: [1, 0.62, 0.12, 1] });
            invMass[chain[chain.length - 1]] = 1 / 8;
        }
        else if (this.variant === 1) {
            const left = addChain([-16, 9.5, -1.7], [16, 9.5, -1.7], segments, 4.3, true, true, 0.09, teal, weak);
            const right = addChain([-16, 9.5, 1.7], [16, 9.5, 1.7], segments, 4.3, true, true, 0.09, teal, weak);
            for (let i = 0; i < left.length; i += 2) {
                addConstraint(left[i], right[i], 0.95, 1.8, true, 0.13, steel);
            }
        }
        else if (this.variant === 2) {
            const chain = addChain([0, 17, 0], [8, 5, 0], segments, 1.4, true, false, 0.11, red, weak);
            this.payloads.push({ particle: chain[chain.length - 1], half: [1.2, 1.2, 1.2], color: [0.86, 0.18, 0.12, 1] });
            invMass[chain[chain.length - 1]] = 1 / 11;
        }
        else if (this.variant === 3) {
            const left = addChain([-2.2, 16, 0], [-2.2, 2.3, 0], segments, 0.3, true, false, 0.075, gold, weak);
            const right = addChain([2.2, 16, 0], [2.2, 2.3, 0], segments, 0.3, true, false, 0.075, gold, weak);
            for (let i = 2; i < Math.min(left.length, right.length); i += 3) {
                addConstraint(left[i], right[i], 0.98, 2.0, true, 0.11, steel);
            }
        }
        else if (this.variant === 4) {
            const center = addParticle([0, 5.5, 0], 12);
            this.payloads.push({ particle: center, half: [1.4, 0.45, 1.4], color: [0.12, 0.72, 0.82, 1] });
            const anchors = [[-14, 10, -10], [14, 10, -10], [-14, 10, 10], [14, 10, 10]];
            for (const anchor of anchors) {
                const chain = addChain(anchor, [0, 5.5, 0], Math.max(14, Math.floor(segments * 0.55)), 1.2, true, false, 0.08, teal, weak);
                const end = chain[chain.length - 1];
                addConstraint(end, center, 0.99, weak, true, 0.1, teal);
            }
        }
        else if (this.variant === 5) {
            for (let lane = -4; lane <= 4; lane++) {
                addChain([lane * 2.2, 16, 0], [lane * 2.2, 1.2, this.rng.signed(0.8)], Math.max(18, Math.floor(segments * 0.65)), 0.2, true, false, 0.055, lane % 2 ? gold : red, weak);
            }
        }
        else if (this.variant === 6) {
            const chain = addChain([-16, 13, -4], [16, 7, 4], segments, 2.5, true, true, 0.105, teal, weak);
            const riderIndex = chain[Math.floor(chain.length * 0.38)];
            this.payloads.push({ particle: riderIndex, half: [0.7, 1.0, 0.55], color: [0.96, 0.74, 0.18, 1] });
            invMass[riderIndex] = 1 / 6;
        }
        else if (this.variant === 7) {
            const chain = addChain([-18, 6, 0], [14, 12, 0], segments, 2.0, true, true, 0.09, red, weak);
            this.payloads.push({ particle: chain[Math.floor(chain.length * 0.62)], half: [0.8, 0.55, 0.8], color: [0.22, 0.72, 0.44, 1] });
        }
        else if (this.variant === 8) {
            const payload = addParticle([0, 5.4, 0], 18);
            this.payloads.push({ particle: payload, half: [2.4, 0.7, 1.5], color: [1, 0.52, 0.1, 1] });
            const anchors = [[-7, 16, -5], [7, 16, -5], [-7, 16, 5], [7, 16, 5]];
            for (const anchor of anchors) {
                const chain = addChain(anchor, [0, 5.4, 0], Math.max(16, Math.floor(segments * 0.58)), 0.8, true, false, 0.09, gold, weak);
                addConstraint(chain[chain.length - 1], payload, 0.99, weak, true, 0.11, gold);
            }
        }
        else {
            const horizontal = [];
            for (let row = -3; row <= 3; row++) {
                horizontal.push(addChain([-13, 11 + row * 0.55, -4], [13, 11 + row * 0.55, 4], Math.max(18, Math.floor(segments * 0.7)), 2.8, true, true, 0.055, row % 2 ? teal : gold, weak));
            }
            for (let c = 0; c < horizontal[0].length; c += 4) {
                for (let r = 0; r < horizontal.length - 1; r++) {
                    addConstraint(horizontal[r][c], horizontal[r + 1][c], 0.9, 1.8, true, 0.045, steel);
                }
            }
        }
        this.positions = new Float32Array(positions);
        this.previous = new Float32Array(positions);
        this.invMass = new Float32Array(invMass);
        const particleCount = this.invMass.length;
        this.windSinA = new Float32Array(particleCount);
        this.windCosA = new Float32Array(particleCount);
        this.windSinZ = new Float32Array(particleCount);
        this.windCosZ = new Float32Array(particleCount);
        for (let i = 0; i < particleCount; i++) {
            const o = i * 3;
            const phaseA = this.positions[o + 1] * 0.32 + this.positions[o + 2] * 0.19;
            const phaseZ = this.positions[o] * 0.2;
            this.windSinA[i] = Math.sin(phaseA);
            this.windCosA[i] = Math.cos(phaseA);
            this.windSinZ[i] = Math.sin(phaseZ);
            this.windCosZ[i] = Math.cos(phaseZ);
        }
        this.packConstraints();
        this.hashValue = quantizedHash(this.positions, Math.min(this.positions.length, 4096));
        this.frameResult = {
            kind: this.kind, label: this.label, matrices: this.instanceMatrices,
            colors: this.instanceColors, instanceCount: 0, surface: null,
            debugLines: this.debugLines, nodeCount: this.invMass.length,
            constraintCount: this.ropeConstraintCount, brokenCount: 0, energy: 0, hash: this.hashValue,
        };
        this.buildFrame(false);
    }
    packConstraints() {
        const active = this.constraints.filter((constraint) => {
            return this.invMass[constraint.a] + this.invMass[constraint.b] > 0;
        });
        const count = active.length;
        this.ropeA = new Uint16Array(count);
        this.ropeB = new Uint16Array(count);
        this.ropeRest = new Float32Array(count);
        this.ropeInvRest = new Float32Array(count);
        this.ropeScaleA = new Float32Array(count);
        this.ropeScaleB = new Float32Array(count);
        this.ropeBreakThreshold = new Float32Array(count);
        this.ropeBroken = new Uint8Array(count);
        this.ropeRender = new Uint8Array(count);
        this.ropeRadius = new Float32Array(count);
        this.ropeColor = new Float32Array(count * 4);
        for (let i = 0; i < count; i++) {
            const constraint = active[i];
            const wa = this.invMass[constraint.a];
            const wb = this.invMass[constraint.b];
            const inverseWeight = 1 / (wa + wb);
            this.ropeA[i] = constraint.a;
            this.ropeB[i] = constraint.b;
            this.ropeRest[i] = constraint.rest;
            this.ropeInvRest[i] = 1 / Math.max(1e-8, constraint.rest);
            this.ropeScaleA[i] = constraint.solveStiffness * wa * inverseWeight;
            this.ropeScaleB[i] = constraint.solveStiffness * wb * inverseWeight;
            this.ropeBreakThreshold[i] = constraint.breakThreshold;
            this.ropeRender[i] = constraint.render ? 1 : 0;
            this.ropeRadius[i] = constraint.radius;
            const co = i * 4;
            this.ropeColor[co] = constraint.color[0];
            this.ropeColor[co + 1] = constraint.color[1];
            this.ropeColor[co + 2] = constraint.color[2];
            this.ropeColor[co + 3] = constraint.color[3];
        }
        this.ropeConstraintCount = count;
        this.constraints.length = 0;
    }
    step(dt, subSteps) {
        if (!Number.isFinite(dt) || dt <= 0)
            return;
        const steps = Math.min(3, (0, math_1.clamp)(Math.round(subSteps), 1, 8));
        const subDt = Math.min(dt, 1 / 30) / steps;
        for (let sub = 0; sub < steps; sub++) {
            this.time += subDt;
            this.integrateProjectiles(subDt);
            this.integrate(subDt);
            this.collideProjectiles();
            let breakBudget = this.mode >= 3 ? 4 : 1;
            for (let iteration = 0; iteration < this.iterations; iteration++) {
                breakBudget = this.solveConstraints(breakBudget);
                this.solveCollisions();
            }
        }
        this.computeEnergy(dt);
        if (--this.hashCountdown <= 0) {
            this.hashValue = quantizedHash(this.positions, Math.min(this.positions.length, 4096));
            this.hashCountdown = TELEMETRY_INTERVAL_STEPS;
        }
    }
    integrate(dt) {
        const dt2 = dt * dt;
        const timeA = this.time * 1.8;
        const timeZ = this.time * 1.1;
        const sinA = Math.sin(timeA);
        const cosA = Math.cos(timeA);
        const sinZ = Math.sin(timeZ);
        const cosZ = Math.cos(timeZ);
        const windScale = 0.8 + this.stress * 0.2;
        for (let i = 0; i < this.invMass.length; i++) {
            if (this.invMass[i] === 0)
                continue;
            const o = i * 3;
            const x = this.positions[o];
            const y = this.positions[o + 1];
            const z = this.positions[o + 2];
            const vx = (x - this.previous[o]) * 0.994;
            const vy = (y - this.previous[o + 1]) * 0.994;
            const vz = (z - this.previous[o + 2]) * 0.994;
            this.previous[o] = x;
            this.previous[o + 1] = y;
            this.previous[o + 2] = z;
            const wind = (sinA * this.windCosA[i] + cosA * this.windSinA[i]) * windScale;
            const crossWind = (cosZ * this.windCosZ[i] - sinZ * this.windSinZ[i]) * 0.38;
            this.positions[o] = x + vx + wind * dt2;
            this.positions[o + 1] = y + vy - 9.81 * dt2;
            this.positions[o + 2] = z + vz + crossWind * dt2;
        }
    }
    solveConstraints(breakBudget) {
        const positions = this.positions;
        const count = this.ropeConstraintCount;
        const aIndices = this.ropeA;
        const bIndices = this.ropeB;
        const rests = this.ropeRest;
        const invRests = this.ropeInvRest;
        const scaleAValues = this.ropeScaleA;
        const scaleBValues = this.ropeScaleB;
        const broken = this.ropeBroken;
        const render = this.ropeRender;
        const breakThresholds = this.ropeBreakThreshold;
        for (let ci = 0; ci < count; ci++) {
            if (broken[ci] !== 0)
                continue;
            const a = aIndices[ci];
            const b = bIndices[ci];
            const ao = a * 3;
            const bo = b * 3;
            const dx = positions[bo] - positions[ao];
            const dy = positions[bo + 1] - positions[ao + 1];
            const dz = positions[bo + 2] - positions[ao + 2];
            const distanceSquared = dx * dx + dy * dy + dz * dz;
            if (distanceSquared < 1e-14)
                continue;
            const dist = Math.sqrt(distanceSquared);
            if (render[ci] !== 0 && breakBudget > 0 && dist * invRests[ci] > breakThresholds[ci]) {
                broken[ci] = 1;
                this.brokenCountValue++;
                breakBudget--;
                continue;
            }
            const correction = (dist - rests[ci]) / dist;
            const scaleA = correction * scaleAValues[ci];
            const scaleB = correction * scaleBValues[ci];
            positions[ao] += dx * scaleA;
            positions[ao + 1] += dy * scaleA;
            positions[ao + 2] += dz * scaleA;
            positions[bo] -= dx * scaleB;
            positions[bo + 1] -= dy * scaleB;
            positions[bo + 2] -= dz * scaleB;
        }
        return breakBudget;
    }
    solveCollisions() {
        for (let i = 0; i < this.invMass.length; i++) {
            if (this.invMass[i] === 0)
                continue;
            const o = i * 3;
            if (this.positions[o + 1] < 0.16) {
                this.positions[o + 1] = 0.16;
                this.previous[o] = this.positions[o] - (this.positions[o] - this.previous[o]) * 0.65;
                this.previous[o + 2] = this.positions[o + 2] - (this.positions[o + 2] - this.previous[o + 2]) * 0.65;
            }
            this.positions[o] = (0, math_1.clamp)(this.positions[o], -42, 42);
            this.positions[o + 2] = (0, math_1.clamp)(this.positions[o + 2], -42, 42);
        }
    }
    integrateProjectiles(dt) {
        for (const projectile of this.projectiles) {
            projectile.life -= dt;
            projectile.velocity[1] -= 9.81 * dt;
            projectile.position[0] += projectile.velocity[0] * dt;
            projectile.position[1] += projectile.velocity[1] * dt;
            projectile.position[2] += projectile.velocity[2] * dt;
        }
        let write = 0;
        for (let read = 0; read < this.projectiles.length; read++) {
            const projectile = this.projectiles[read];
            if (projectile.life > 0 && projectile.position[1] >= -4)
                this.projectiles[write++] = projectile;
        }
        this.projectiles.length = write;
    }
    collideProjectiles() {
        for (const projectile of this.projectiles) {
            const speed = Math.hypot(projectile.velocity[0], projectile.velocity[1], projectile.velocity[2]);
            for (let i = 0; i < this.invMass.length; i++) {
                if (this.invMass[i] === 0)
                    continue;
                const o = i * 3;
                const dx = this.positions[o] - projectile.position[0];
                const dy = this.positions[o + 1] - projectile.position[1];
                const dz = this.positions[o + 2] - projectile.position[2];
                const d = Math.hypot(dx, dy, dz);
                if (d > projectile.radius + 0.22 || d < 1e-6)
                    continue;
                const impulse = speed * 0.012;
                this.previous[o] -= projectile.velocity[0] * 0.012;
                this.previous[o + 1] -= projectile.velocity[1] * 0.012;
                this.previous[o + 2] -= projectile.velocity[2] * 0.012;
                if (speed > 14)
                    this.breakNearestConstraint(projectile.position, projectile.radius + 0.9);
                this.positions[o] += (dx / d) * impulse;
                this.positions[o + 1] += (dy / d) * impulse;
                this.positions[o + 2] += (dz / d) * impulse;
            }
        }
    }
    breakNearestConstraint(center, radius) {
        let best = -1;
        let bestDistanceSquared = radius * radius;
        const positions = this.positions;
        for (let i = 0; i < this.ropeConstraintCount; i++) {
            if (this.ropeRender[i] === 0 || this.ropeBroken[i] !== 0)
                continue;
            const ao = this.ropeA[i] * 3;
            const bo = this.ropeB[i] * 3;
            const dx = (positions[ao] + positions[bo]) * 0.5 - center[0];
            const dy = (positions[ao + 1] + positions[bo + 1]) * 0.5 - center[1];
            const dz = (positions[ao + 2] + positions[bo + 2]) * 0.5 - center[2];
            const distanceSquared = dx * dx + dy * dy + dz * dz;
            if (distanceSquared < bestDistanceSquared) {
                bestDistanceSquared = distanceSquared;
                best = i;
            }
        }
        if (best < 0)
            return false;
        this.ropeBroken[best] = 1;
        this.brokenCountValue++;
        return true;
    }
    computeEnergy(dt) {
        const invDt = 1 / Math.max(1e-5, dt);
        let energy = 0;
        for (let i = 0; i < this.invMass.length; i++) {
            const o = i * 3;
            const vx = (this.positions[o] - this.previous[o]) * invDt;
            const vy = (this.positions[o + 1] - this.previous[o + 1]) * invDt;
            const vz = (this.positions[o + 2] - this.previous[o + 2]) * invDt;
            energy += vx * vx + vy * vy + vz * vz;
        }
        this.energyValue = energy / Math.max(1, this.invMass.length);
    }
    kick(strength) {
        const scale = Math.max(1, strength) * 0.026;
        for (let i = 0; i < this.invMass.length; i++) {
            if (this.invMass[i] === 0)
                continue;
            const o = i * 3;
            this.previous[o] -= scale * (0.6 + this.rng.next01() * 0.5);
            this.previous[o + 1] += this.rng.signed(scale * 0.18);
            this.previous[o + 2] -= this.rng.signed(scale * 0.55);
        }
    }
    explode(center, strength, radius) {
        const r = Math.max(1, radius);
        for (let i = 0; i < this.invMass.length; i++) {
            if (this.invMass[i] === 0)
                continue;
            const o = i * 3;
            const dx = this.positions[o] - center[0];
            const dy = this.positions[o + 1] - center[1];
            const dz = this.positions[o + 2] - center[2];
            const d = Math.hypot(dx, dy, dz);
            if (d >= r || d < 1e-6)
                continue;
            const impulse = (1 - d / r) * strength * 0.018;
            this.previous[o] -= (dx / d) * impulse;
            this.previous[o + 1] -= (dy / d + 0.25) * impulse;
            this.previous[o + 2] -= (dz / d) * impulse;
        }
        if (strength > 15) {
            for (let i = 0; i < Math.min(4, Math.floor(strength / 8)); i++)
                this.breakNearestConstraint(center, r * 0.75);
        }
    }
    launchProjectile(position, velocity, size) {
        if (this.projectiles.length >= 16)
            return -1;
        this.projectiles.push({
            position: [...position],
            velocity: [...velocity],
            radius: (0, math_1.clamp)(size, 0.2, 1.5),
            life: 8,
            color: [1, 0.42, 0.08, 2.4],
        });
        return this.projectiles.length - 1;
    }
    spawnRain(count, spread, height) {
        const allowed = Math.max(0, Math.min(Math.max(0, Math.round(count)), 96 - this.projectiles.length));
        for (let i = 0; i < allowed; i++) {
            this.projectiles.push({
                position: [this.rng.signed(spread), height + this.rng.range(0, 12), this.rng.signed(spread)],
                velocity: [this.rng.signed(1), this.rng.range(-14, -8), this.rng.signed(1)],
                radius: this.rng.range(0.08, 0.18),
                life: 5,
                color: [0.2, 0.72, 1, 1.8],
            });
        }
        return allowed;
    }
    buildFrame(debug) {
        const maxCount = MAX_SOFT_INSTANCES;
        const matrices = this.instanceMatrices;
        const colors = this.instanceColors;
        let instanceCount = 0;
        const positions = this.positions;
        for (let i = 0; i < this.ropeConstraintCount; i++) {
            if (this.ropeRender[i] === 0 || this.ropeBroken[i] !== 0)
                continue;
            if (instanceCount >= maxCount)
                break;
            const ao = this.ropeA[i] * 3;
            const bo = this.ropeB[i] * 3;
            const dx = positions[bo] - positions[ao];
            const dy = positions[bo + 1] - positions[ao + 1];
            const dz = positions[bo + 2] - positions[ao + 2];
            const ratio = Math.sqrt(dx * dx + dy * dy + dz * dz) * this.ropeInvRest[i];
            const tension = (0, math_1.clamp)((ratio - 1) * 4.2, 0, 1);
            writeSegmentMatrixFromPositions(matrices, instanceCount * 16, positions, ao, bo, this.ropeRadius[i] * (1 - tension * 0.2));
            const source = i * 4;
            const target = instanceCount * 4;
            colors[target] = this.ropeColor[source] + (1 - this.ropeColor[source]) * tension;
            colors[target + 1] = this.ropeColor[source + 1] + (0.06 - this.ropeColor[source + 1]) * tension;
            colors[target + 2] = this.ropeColor[source + 2] + (0.02 - this.ropeColor[source + 2]) * tension;
            colors[target + 3] = this.ropeColor[source + 3] + (2.2 - this.ropeColor[source + 3]) * tension;
            instanceCount++;
        }
        for (const payload of this.payloads) {
            if (instanceCount >= maxCount)
                break;
            const p = readPosition(this.positions, payload.particle);
            const o = payload.particle * 3;
            const vx = this.positions[o] - this.previous[o];
            const vz = this.positions[o + 2] - this.previous[o + 2];
            (0, math_1.writeModelMatrixFromEuler)(matrices, instanceCount * 16, p, [vz * 0.8, 0, -vx * 0.8], payload.half);
            setColor(colors, instanceCount, payload.color);
            instanceCount++;
        }
        for (const projectile of this.projectiles) {
            if (instanceCount >= maxCount)
                break;
            (0, math_1.writeModelMatrixFromEuler)(matrices, instanceCount * 16, projectile.position, [this.time * 1.8, this.time, 0], [projectile.radius, projectile.radius, projectile.radius]);
            setColor(colors, instanceCount, projectile.color);
            instanceCount++;
        }
        const debugLines = this.debugLines;
        debugLines.length = 0;
        if (debug) {
            for (let i = 0; i < this.invMass.length; i += Math.max(1, Math.floor(this.invMass.length / 160))) {
                const p = readPosition(this.positions, i);
                const pinned = this.invMass[i] === 0;
                debugLines.push({
                    ax: p[0] - 0.12, ay: p[1], az: p[2], bx: p[0] + 0.12, by: p[1], bz: p[2],
                    r: pinned ? 1 : 0.2, g: pinned ? 0.72 : 0.85, b: pinned ? 0.12 : 1, a: 0.7,
                });
            }
        }
        const frame = this.frameResult;
        frame.instanceCount = instanceCount;
        frame.nodeCount = this.invMass.length;
        frame.constraintCount = this.ropeConstraintCount;
        frame.brokenCount = this.brokenCountValue;
        frame.energy = this.energyValue;
        frame.hash = this.hashValue;
        return frame;
    }
    currentHash() {
        return quantizedHash(this.positions, Math.min(this.positions.length, 4096));
    }
    destroy() {
        this.constraints = [];
        this.ropeA = EMPTY_UINT16;
        this.ropeB = EMPTY_UINT16;
        this.ropeRest = EMPTY_FLOAT32;
        this.ropeInvRest = EMPTY_FLOAT32;
        this.ropeScaleA = EMPTY_FLOAT32;
        this.ropeScaleB = EMPTY_FLOAT32;
        this.ropeBreakThreshold = EMPTY_FLOAT32;
        this.ropeBroken = EMPTY_UINT8;
        this.ropeRender = EMPTY_UINT8;
        this.ropeRadius = EMPTY_FLOAT32;
        this.ropeColor = EMPTY_FLOAT32;
        this.ropeConstraintCount = 0;
        this.payloads = [];
        this.projectiles = [];
        this.positions = EMPTY_FLOAT32;
        this.previous = EMPTY_FLOAT32;
        this.invMass = EMPTY_FLOAT32;
        this.windSinA = EMPTY_FLOAT32;
        this.windCosA = EMPTY_FLOAT32;
        this.windSinZ = EMPTY_FLOAT32;
        this.windCosZ = EMPTY_FLOAT32;
    }
}
class WaterSimulation {
    kind = 'water';
    label;
    cols;
    rows;
    count;
    width;
    depth;
    dx;
    dz;
    baseY;
    eta;
    u;
    v;
    nextEta;
    nextU;
    nextV;
    vertices;
    indices;
    worldX;
    worldZ;
    uvU;
    uvV;
    invTwoDx;
    invTwoDz;
    sampleHeight = 0;
    sampleVelocityX = 0;
    sampleVelocityZ = 0;
    instanceMatrices = new Float32Array(MAX_SOFT_INSTANCES * 16);
    instanceColors = new Float32Array(MAX_SOFT_INSTANCES * 4);
    debugLines = [];
    surfaceResult;
    frameResult;
    droplets = [];
    floaters = [];
    rng;
    stress;
    variant;
    mode;
    time = 0;
    energyValue = 0;
    hashValue = 0;
    hashCountdown = TELEMETRY_INTERVAL_STEPS;
    constructor(scene, stress, seed) {
        this.stress = stress;
        this.variant = scene.variant;
        this.mode = scene.mode;
        this.cols = Math.min(96, 44 + stress * 8 + (scene.mode >= 3 ? 8 : 0));
        this.rows = Math.min(80, 34 + stress * 6 + (scene.mode === 4 ? 6 : 0));
        this.count = this.cols * this.rows;
        this.width = 34;
        this.depth = 24;
        this.dx = this.width / Math.max(1, this.cols - 1);
        this.dz = this.depth / Math.max(1, this.rows - 1);
        this.baseY = 1.45;
        this.eta = new Float32Array(this.count);
        this.u = new Float32Array(this.count);
        this.v = new Float32Array(this.count);
        this.nextEta = new Float32Array(this.count);
        this.nextU = new Float32Array(this.count);
        this.nextV = new Float32Array(this.count);
        this.vertices = new packed_surface_1.PackedSurfaceBuffer(this.count);
        this.indices = new Uint16Array(Math.max(0, (this.cols - 1) * (this.rows - 1) * 6));
        this.worldX = new Float32Array(this.cols);
        this.worldZ = new Float32Array(this.rows);
        this.uvU = new Float32Array(this.cols);
        this.uvV = new Float32Array(this.rows);
        this.invTwoDx = 1 / (2 * this.dx);
        this.invTwoDz = 1 / (2 * this.dz);
        this.rng = new math_1.LcgRng(seed ^ 0x57a7e12);
        this.label = `${scene.title.replace(/\s+—.*$/, '')} · linear shallow-water ${this.cols}×${this.rows}`;
        this.initializeSurface();
        this.initializeGridCache();
        this.initializeVariants();
        this.hashValue = quantizedHash(this.eta, Math.min(this.eta.length, 4096));
        this.surfaceResult = {
            material: 'water', vertices: this.vertices.data, indices: this.indices,
            vertexStride: packed_surface_1.PACKED_SURFACE_VERTEX_BYTES, vertexCount: this.count,
            indexCount: this.indices.length, topologyVersion: 1,
        };
        this.frameResult = {
            kind: this.kind, label: this.label, matrices: this.instanceMatrices,
            colors: this.instanceColors, instanceCount: 0, surface: this.surfaceResult,
            debugLines: this.debugLines, nodeCount: this.count,
            constraintCount: Math.max(0, (this.cols - 2) * (this.rows - 2) * 3),
            brokenCount: 0, energy: 0, hash: this.hashValue,
        };
        this.buildSurface();
    }
    index(x, z) { return z * this.cols + x; }
    worldToGrid(x, z) {
        return [
            (x / this.width + 0.5) * (this.cols - 1),
            (z / this.depth + 0.5) * (this.rows - 1),
        ];
    }
    gridToWorld(x, z) {
        return [
            (x / Math.max(1, this.cols - 1) - 0.5) * this.width,
            (z / Math.max(1, this.rows - 1) - 0.5) * this.depth,
        ];
    }
    initializeGridCache() {
        const invCols = 1 / Math.max(1, this.cols - 1);
        const invRows = 1 / Math.max(1, this.rows - 1);
        for (let x = 0; x < this.cols; x++) {
            const u = x * invCols;
            this.uvU[x] = u;
            this.worldX[x] = (u - 0.5) * this.width;
        }
        for (let z = 0; z < this.rows; z++) {
            const v = z * invRows;
            this.uvV[z] = v;
            this.worldZ[z] = (v - 0.5) * this.depth;
        }
        // X/Z coordinates and UVs never change. Seed those packed lanes once so
        // the per-frame water mesh only writes height, normal, and foam/color.
        const f32 = this.vertices.f32;
        const u16 = this.vertices.u16;
        for (let z = 0; z < this.rows; z++) {
            const row = z * this.cols;
            const wz = this.worldZ[z];
            const packedV = Math.round(this.uvV[z] * 65535);
            for (let x = 0; x < this.cols; x++) {
                const i = row + x;
                const f = i * 6;
                const h = i * 12;
                f32[f] = this.worldX[x];
                f32[f + 2] = wz;
                u16[h + 10] = Math.round(this.uvU[x] * 65535);
                u16[h + 11] = packedV;
            }
        }
    }
    initializeSurface() {
        let cursor = 0;
        for (let z = 0; z < this.rows - 1; z++) {
            for (let x = 0; x < this.cols - 1; x++) {
                const i0 = this.index(x, z);
                const i1 = this.index(x + 1, z);
                const i2 = this.index(x, z + 1);
                const i3 = this.index(x + 1, z + 1);
                this.indices[cursor++] = i0;
                this.indices[cursor++] = i2;
                this.indices[cursor++] = i1;
                this.indices[cursor++] = i1;
                this.indices[cursor++] = i2;
                this.indices[cursor++] = i3;
            }
        }
    }
    initializeVariants() {
        if (this.variant === 0) {
            this.disturb(0, 0, 0.9, 2.2, 1.4);
            this.disturb(-7, 3, 0.45, 1.2, 0.6);
        }
        else if (this.variant === 1) {
            for (let z = 0; z < this.rows; z++) {
                for (let x = 0; x < Math.floor(this.cols * 0.18); x++) {
                    this.eta[this.index(x, z)] = 1.2 * (1 - x / Math.max(1, this.cols * 0.18));
                    this.u[this.index(x, z)] = 1.8;
                }
            }
        }
        else if (this.variant === 2) {
            for (let z = 0; z < this.rows; z++) {
                for (let x = 0; x < this.cols; x++) {
                    const [wx, wz] = this.gridToWorld(x, z);
                    this.eta[this.index(x, z)] = Math.sin(wx * 0.55) * 0.12 + Math.cos(wz * 0.72) * 0.09 + this.rng.signed(0.025);
                    this.u[this.index(x, z)] = Math.sin(wz * 0.4) * 0.35;
                    this.v[this.index(x, z)] = Math.cos(wx * 0.32) * 0.28;
                }
            }
        }
        else if (this.variant === 3) {
            this.floaters.push({ position: [-12, this.baseY + 0.7, 0], velocity: [2.2, 0, 0.45], half: [1.8, 0.42, 0.75], color: [0.95, 0.42, 0.08, 1], mass: 4 });
        }
        else if (this.variant === 4) {
            this.disturb(0, 0, 1.2, 1.6, 2.2);
        }
        else if (this.variant === 5) {
            this.spawnRain(80 + this.stress * 30, 15, 11);
        }
        else if (this.variant === 6) {
            for (let z = 0; z < this.rows; z++) {
                for (let x = 0; x < this.cols; x++) {
                    if (x < this.cols * 0.42)
                        this.eta[this.index(x, z)] = 0.75;
                }
            }
        }
        else if (this.variant === 7) {
            for (let z = 0; z < this.rows; z++) {
                for (let x = 0; x < this.cols; x++) {
                    const [wx, wz] = this.gridToWorld(x, z);
                    const r = Math.hypot(wx, wz) + 0.3;
                    this.u[this.index(x, z)] = -wz / r * 1.2;
                    this.v[this.index(x, z)] = wx / r * 1.2;
                    this.eta[this.index(x, z)] = -Math.exp(-r * 0.24) * 0.45;
                }
            }
        }
        else if (this.variant === 8) {
            this.floaters.push({ position: [-6, this.baseY + 0.5, -2], velocity: [0.3, 0, 0.1], half: [1.2, 0.35, 0.8], color: [0.18, 0.48, 0.78, 1], mass: 3 });
            this.floaters.push({ position: [5, this.baseY + 0.45, 3], velocity: [-0.2, 0, -0.1], half: [0.8, 0.3, 0.6], color: [0.92, 0.72, 0.22, 1], mass: 2 });
        }
        else {
            this.floaters.push({ position: [0, this.baseY + 2.4, 0], velocity: [0, -1, 0], half: [1.3, 1.3, 1.3], color: [0.82, 0.18, 0.12, 1], mass: 12 });
            this.disturb(0, 0, 1.6, 2.5, 2.6);
        }
    }
    step(dt, subSteps) {
        if (!Number.isFinite(dt) || dt <= 0)
            return;
        const steps = (0, math_1.clamp)(Math.round(subSteps), 1, 8);
        const subDt = Math.min(dt, 1 / 30) / steps;
        for (let sub = 0; sub < steps; sub++) {
            this.time += subDt;
            this.applyAutomaticForcing();
            this.solveShallowWater(subDt);
            this.updateDroplets(subDt);
            this.updateFloaters(subDt);
        }
        if (--this.hashCountdown <= 0) {
            this.computeEnergy();
            this.hashValue = quantizedHash(this.eta, Math.min(this.eta.length, 4096));
            this.hashCountdown = TELEMETRY_INTERVAL_STEPS;
        }
    }
    applyAutomaticForcing() {
        if (this.variant === 0 && Math.floor(this.time * 2.2) !== Math.floor((this.time - 1 / 60) * 2.2)) {
            this.disturb(this.rng.signed(11), this.rng.signed(7), this.rng.range(0.2, 0.55), this.rng.range(0.7, 1.5), 0.7);
        }
        else if (this.variant === 2) {
            const z = Math.sin(this.time * 0.45) * 8;
            this.disturb(-16, z, Math.sin(this.time * 2.4) * 0.035, 1.4, 0.12);
        }
        else if (this.variant === 3) {
            const x = -14 + (this.time * 3.1) % 28;
            const z = Math.sin(this.time * 0.9) * 3.8;
            this.disturb(x, z, -0.055, 0.8, 0.35);
            this.disturb(x - 1.2, z + 0.8, 0.045, 0.7, 0.24);
            this.disturb(x - 1.2, z - 0.8, 0.045, 0.7, 0.24);
        }
        else if (this.variant === 4) {
            this.disturb(0, 0, Math.sin(this.time * 5.2) * 0.045, 1.0, 0.16);
        }
        else if (this.variant === 7) {
            const angle = this.time * 1.4;
            this.disturb(Math.cos(angle) * 4, Math.sin(angle) * 4, -0.035, 1.1, 0.28);
        }
    }
    solveShallowWater(dt) {
        const gravity = 9.81;
        const meanDepth = 1.35 + this.stress * 0.05;
        const drag = 0.28 + this.mode * 0.025;
        const cols = this.cols;
        const rows = this.rows;
        const eta = this.eta;
        const u = this.u;
        const v = this.v;
        const nextEta = this.nextEta;
        const nextU = this.nextU;
        const nextV = this.nextV;
        const velocityDecay = 1 - drag * dt;
        const pressureX = gravity * dt * this.invTwoDx;
        const pressureZ = gravity * dt * this.invTwoDz;
        const continuityX = meanDepth * dt * this.invTwoDx;
        const continuityZ = meanDepth * dt * this.invTwoDz;
        // Every destination cell is written below, so copying three complete grids
        // with TypedArray.set() is unnecessary bandwidth. Pre-fold timestep and
        // grid constants to remove six multiplications per cell.
        for (let z = 1; z < rows - 1; z++) {
            const row = z * cols;
            const rowEnd = row + cols - 1;
            for (let i = row + 1; i < rowEnd; i++) {
                nextU[i] = u[i] * velocityDecay - (eta[i + 1] - eta[i - 1]) * pressureX;
                nextV[i] = v[i] * velocityDecay - (eta[i + cols] - eta[i - cols]) * pressureZ;
            }
        }
        for (let z = 1; z < rows - 1; z++) {
            const row = z * cols;
            const rowEnd = row + cols - 1;
            for (let i = row + 1; i < rowEnd; i++) {
                const next = eta[i]
                    - (nextU[i + 1] - nextU[i - 1]) * continuityX
                    - (nextV[i + cols] - nextV[i - cols]) * continuityZ;
                nextEta[i] = next < -1.65 ? -1.65 : next > 1.65 ? 1.65 : next;
            }
        }
        const bottomRow = (rows - 1) * cols;
        const innerBottom = (rows - 2) * cols;
        for (let x = 0; x < cols; x++) {
            nextEta[x] = nextEta[cols + x] * 0.92;
            nextU[x] = nextU[cols + x] * 0.78;
            nextV[x] = -nextV[cols + x] * 0.18;
            const bottom = bottomRow + x;
            const inner = innerBottom + x;
            nextEta[bottom] = nextEta[inner] * 0.92;
            nextU[bottom] = nextU[inner] * 0.78;
            nextV[bottom] = -nextV[inner] * 0.18;
        }
        for (let z = 0; z < rows; z++) {
            const row = z * cols;
            const leftInner = row + 1;
            const right = row + cols - 1;
            const rightInner = right - 1;
            nextEta[row] = nextEta[leftInner] * 0.92;
            nextU[row] = -nextU[leftInner] * 0.18;
            nextV[row] = nextV[leftInner] * 0.78;
            nextEta[right] = nextEta[rightInner] * 0.92;
            nextU[right] = -nextU[rightInner] * 0.18;
            nextV[right] = nextV[rightInner] * 0.78;
        }
        this.eta = nextEta;
        this.nextEta = eta;
        this.u = nextU;
        this.nextU = u;
        this.v = nextV;
        this.nextV = v;
    }
    disturb(x, z, amplitude, radius, radialVelocity) {
        const gx = (x / this.width + 0.5) * (this.cols - 1);
        const gz = (z / this.depth + 0.5) * (this.rows - 1);
        const rx = Math.ceil(radius / this.dx) + 1;
        const rz = Math.ceil(radius / this.dz) + 1;
        const minX = Math.max(1, Math.floor(gx) - rx);
        const maxX = Math.min(this.cols - 2, Math.ceil(gx) + rx);
        const minZ = Math.max(1, Math.floor(gz) - rz);
        const maxZ = Math.min(this.rows - 2, Math.ceil(gz) + rz);
        const radiusSquared = radius * radius;
        const inverseRadius = 1 / Math.max(0.001, radius);
        const cols = this.cols;
        for (let iz = minZ; iz <= maxZ; iz++) {
            const wz = this.worldZ[iz];
            const row = iz * cols;
            for (let ix = minX; ix <= maxX; ix++) {
                const dx = this.worldX[ix] - x;
                const dz = wz - z;
                const distanceSquared = dx * dx + dz * dz;
                if (distanceSquared > radiusSquared)
                    continue;
                const distance = Math.sqrt(distanceSquared);
                const falloff = 0.5 + 0.5 * Math.cos(distance * inverseRadius * Math.PI);
                const i = row + ix;
                const nextHeight = this.eta[i] + amplitude * falloff;
                this.eta[i] = nextHeight < -1.65 ? -1.65 : nextHeight > 1.65 ? 1.65 : nextHeight;
                if (distance > 1e-5) {
                    const radialScale = radialVelocity * falloff / distance;
                    this.u[i] += dx * radialScale;
                    this.v[i] += dz * radialScale;
                }
            }
        }
    }
    sampleIntoScratch(x, z) {
        let gx = (x / this.width + 0.5) * (this.cols - 1);
        let gz = (z / this.depth + 0.5) * (this.rows - 1);
        const maxX = this.cols - 1.001;
        const maxZ = this.rows - 1.001;
        gx = gx < 0 ? 0 : gx > maxX ? maxX : gx;
        gz = gz < 0 ? 0 : gz > maxZ ? maxZ : gz;
        const x0 = Math.floor(gx);
        const z0 = Math.floor(gz);
        const x1 = x0 + 1;
        const z1 = z0 + 1;
        const tx = gx - x0;
        const tz = gz - z0;
        const oneMinusX = 1 - tx;
        const oneMinusZ = 1 - tz;
        const i00 = z0 * this.cols + x0;
        const i10 = i00 + 1;
        const i01 = z1 * this.cols + x0;
        const i11 = i01 + 1;
        const etaA = this.eta[i00] * oneMinusX + this.eta[i10] * tx;
        const etaB = this.eta[i01] * oneMinusX + this.eta[i11] * tx;
        const uA = this.u[i00] * oneMinusX + this.u[i10] * tx;
        const uB = this.u[i01] * oneMinusX + this.u[i11] * tx;
        const vA = this.v[i00] * oneMinusX + this.v[i10] * tx;
        const vB = this.v[i01] * oneMinusX + this.v[i11] * tx;
        this.sampleHeight = this.baseY + etaA * oneMinusZ + etaB * tz;
        this.sampleVelocityX = uA * oneMinusZ + uB * tz;
        this.sampleVelocityZ = vA * oneMinusZ + vB * tz;
    }
    updateDroplets(dt) {
        for (const droplet of this.droplets) {
            droplet.life -= dt;
            droplet.velocity[1] -= 9.81 * dt;
            droplet.position[0] += droplet.velocity[0] * dt;
            droplet.position[1] += droplet.velocity[1] * dt;
            droplet.position[2] += droplet.velocity[2] * dt;
            this.sampleIntoScratch(droplet.position[0], droplet.position[2]);
            if (droplet.position[1] <= this.sampleHeight && droplet.life > 0) {
                const speed = Math.abs(droplet.velocity[1]);
                this.disturb(droplet.position[0], droplet.position[2], (0, math_1.clamp)(speed * 0.025, 0.04, 0.36), (0, math_1.clamp)(droplet.radius * 5, 0.5, 1.6), speed * 0.025);
                droplet.life = 0;
            }
        }
        let write = 0;
        for (let read = 0; read < this.droplets.length; read++) {
            const droplet = this.droplets[read];
            if (droplet.life > 0)
                this.droplets[write++] = droplet;
        }
        this.droplets.length = write;
    }
    updateFloaters(dt) {
        for (const floater of this.floaters) {
            this.sampleIntoScratch(floater.position[0], floater.position[2]);
            const bottom = floater.position[1] - floater.half[1];
            const submergence = (0, math_1.clamp)((this.sampleHeight - bottom) / Math.max(0.1, floater.half[1] * 2), 0, 1.4);
            const buoyancy = 15.5 * submergence / Math.max(0.5, floater.mass * 0.35);
            floater.velocity[1] += (-9.81 + buoyancy) * dt;
            floater.velocity[0] += (this.sampleVelocityX - floater.velocity[0]) * submergence * dt * 1.8;
            floater.velocity[2] += (this.sampleVelocityZ - floater.velocity[2]) * submergence * dt * 1.8;
            floater.velocity[0] *= 0.998;
            floater.velocity[1] *= 0.995;
            floater.velocity[2] *= 0.998;
            floater.position[0] += floater.velocity[0] * dt;
            floater.position[1] += floater.velocity[1] * dt;
            floater.position[2] += floater.velocity[2] * dt;
            if (floater.position[1] - floater.half[1] < 0.15) {
                floater.position[1] = floater.half[1] + 0.15;
                floater.velocity[1] = Math.abs(floater.velocity[1]) * 0.18;
            }
            if (Math.abs(floater.position[0]) > this.width * 0.47)
                floater.velocity[0] *= -0.55;
            if (Math.abs(floater.position[2]) > this.depth * 0.47)
                floater.velocity[2] *= -0.55;
            this.disturb(floater.position[0], floater.position[2], -submergence * 0.006, Math.max(floater.half[0], floater.half[2]) * 1.6, submergence * 0.015);
        }
    }
    computeEnergy() {
        let energy = 0;
        for (let i = 0; i < this.count; i++) {
            energy += this.eta[i] * this.eta[i] * 9.81 + this.u[i] * this.u[i] + this.v[i] * this.v[i];
        }
        this.energyValue = energy / Math.max(1, this.count);
    }
    kick(strength) {
        const amplitude = (0, math_1.clamp)(strength * 0.08, 0.2, 1.2);
        this.disturb(-this.width * 0.36, 0, amplitude, 3.2, strength * 0.08);
        for (let z = 1; z < this.rows - 1; z++) {
            const i = this.index(2, z);
            this.u[i] += strength * 0.14;
        }
    }
    explode(center, strength, radius) {
        this.disturb(center[0], center[2], (0, math_1.clamp)(strength * 0.07, 0.35, 1.65), (0, math_1.clamp)(radius * 0.32, 1.2, 5.2), strength * 0.09);
        this.sampleIntoScratch(center[0], center[2]);
        const splashHeight = this.sampleHeight;
        const splashCount = Math.max(0, Math.min(180, Math.max(20, Math.round(strength * 5)), MAX_WATER_DROPLETS - this.droplets.length));
        const speedScale = Math.sqrt(Math.max(1, strength) / 12);
        for (let i = 0; i < splashCount; i++) {
            const angle = this.rng.range(0, Math.PI * 2);
            const cosine = Math.cos(angle);
            const sine = Math.sin(angle);
            const speed = this.rng.range(2, 7) * speedScale;
            this.droplets.push({
                position: [center[0] + cosine * this.rng.range(0, 1.2), splashHeight + this.rng.range(0.1, 0.5), center[2] + sine * this.rng.range(0, 1.2)],
                velocity: [cosine * speed, this.rng.range(4, 10), sine * speed],
                radius: this.rng.range(0.04, 0.11),
                life: this.rng.range(1, 3),
            });
        }
    }
    launchProjectile(position, velocity, size) {
        if (this.floaters.length >= 20)
            return -1;
        this.floaters.push({
            position: [...position],
            velocity: [...velocity],
            half: [size, size, size],
            color: [1, 0.46, 0.08, 2.1],
            mass: 8 + size * 8,
        });
        return this.floaters.length - 1;
    }
    spawnRain(count, spread, height) {
        const allowed = Math.max(0, Math.min(Math.max(0, Math.round(count)), MAX_WATER_DROPLETS - this.droplets.length));
        for (let i = 0; i < allowed; i++) {
            this.droplets.push({
                position: [this.rng.signed(Math.min(spread, this.width * 0.48)), height + this.rng.range(0, 10), this.rng.signed(Math.min(spread, this.depth * 0.48))],
                velocity: [this.rng.signed(0.45), this.rng.range(-12, -7), this.rng.signed(0.45)],
                radius: this.rng.range(0.025, 0.075),
                life: 4,
            });
        }
        return allowed;
    }
    buildSurface() {
        const cols = this.cols;
        const rows = this.rows;
        const eta = this.eta;
        const uVelocity = this.u;
        const vVelocity = this.v;
        const f32 = this.vertices.f32;
        const i16 = this.vertices.i16;
        const u8 = this.vertices.u8;
        for (let z = 0; z < rows; z++) {
            const row = z * cols;
            const downRow = (z > 0 ? z - 1 : z) * cols;
            const upRow = (z + 1 < rows ? z + 1 : z) * cols;
            for (let x = 0; x < cols; x++) {
                const i = row + x;
                const left = eta[row + (x > 0 ? x - 1 : x)];
                const right = eta[row + (x + 1 < cols ? x + 1 : x)];
                const down = eta[downRow + x];
                const up = eta[upRow + x];
                const nx = -(right - left) * this.invTwoDx;
                const nz = -(up - down) * this.invTwoDz;
                // Octahedral encoding normalizes by L1 length, so Euclidean
                // normalization was redundant. The shader reconstructs and normalizes
                // the direction after unpacking.
                const inverseL1 = 1 / Math.max(1e-12, Math.abs(nx) + 1 + Math.abs(nz));
                let ox = nx * inverseL1;
                let oy = inverseL1;
                if (nz < 0) {
                    const oldX = ox;
                    ox = (1 - Math.abs(oy)) * (oldX < 0 ? -1 : 1);
                    oy = (1 - Math.abs(oldX)) * (oy < 0 ? -1 : 1);
                }
                const laplacian = Math.abs(left + right + down + up - 4 * eta[i]);
                const speed = Math.sqrt(uVelocity[i] * uVelocity[i] + vVelocity[i] * vVelocity[i]);
                let foam = laplacian * 2.2 + speed * 0.22 - 0.08;
                foam = foam < 0 ? 0 : foam > 1 ? 1 : foam;
                const f = i * 6;
                const h = i * 12;
                const byte = i * packed_surface_1.PACKED_SURFACE_VERTEX_BYTES;
                f32[f + 1] = this.baseY + eta[i];
                i16[h + 6] = Math.round((ox < -1 ? -1 : ox > 1 ? 1 : ox) * 32767);
                i16[h + 7] = Math.round((oy < -1 ? -1 : oy > 1 ? 1 : oy) * 32767);
                u8[byte + 16] = Math.round((0.02 + foam * 0.38) * 255);
                u8[byte + 17] = Math.round((0.28 + foam * 0.55) * 255);
                u8[byte + 18] = Math.round((0.55 + foam * 0.42) * 255);
                u8[byte + 19] = Math.round(foam * 255);
            }
        }
        return this.surfaceResult;
    }
    buildFrame(debug) {
        const maxCount = MAX_SOFT_INSTANCES;
        const matrices = this.instanceMatrices;
        const colors = this.instanceColors;
        let instanceCount = 0;
        for (const floater of this.floaters) {
            if (instanceCount >= maxCount)
                break;
            this.sampleIntoScratch(floater.position[0], floater.position[2]);
            const pitch = (0, math_1.clamp)((this.sampleVelocityZ - floater.velocity[2]) * 0.08, -0.35, 0.35);
            const roll = (0, math_1.clamp)((floater.velocity[0] - this.sampleVelocityX) * 0.08, -0.35, 0.35);
            (0, math_1.writeModelMatrixFromEuler)(matrices, instanceCount * 16, floater.position, [pitch, 0, roll], floater.half);
            setColor(colors, instanceCount, floater.color);
            instanceCount++;
        }
        for (const droplet of this.droplets) {
            if (instanceCount >= maxCount)
                break;
            (0, math_1.writeModelMatrixFromEuler)(matrices, instanceCount * 16, droplet.position, [0, 0, 0], [droplet.radius, droplet.radius * 1.9, droplet.radius]);
            setColor(colors, instanceCount, [0.18, 0.68, 1, 1.7]);
            instanceCount++;
        }
        const debugLines = this.debugLines;
        debugLines.length = 0;
        if (debug) {
            const stepX = Math.max(3, Math.floor(this.cols / 12));
            const stepZ = Math.max(3, Math.floor(this.rows / 9));
            for (let z = stepZ; z < this.rows - stepZ; z += stepZ) {
                for (let x = stepX; x < this.cols - stepX; x += stepX) {
                    const i = this.index(x, z);
                    const [wx, wz] = this.gridToWorld(x, z);
                    const y = this.baseY + this.eta[i] + 0.05;
                    debugLines.push({
                        ax: wx, ay: y, az: wz,
                        bx: wx + this.u[i] * 0.55, by: y, bz: wz + this.v[i] * 0.55,
                        r: 0.18, g: 0.82, b: 1, a: 0.55,
                    });
                }
            }
        }
        const frame = this.frameResult;
        frame.instanceCount = instanceCount;
        frame.surface = this.buildSurface();
        frame.nodeCount = this.count + this.droplets.length + this.floaters.length;
        frame.energy = this.energyValue;
        frame.hash = this.hashValue;
        return frame;
    }
    currentHash() {
        return quantizedHash(this.eta, Math.min(this.eta.length, 4096));
    }
    destroy() {
        this.droplets.length = 0;
        this.floaters.length = 0;
        this.eta = EMPTY_FLOAT32;
        this.u = EMPTY_FLOAT32;
        this.v = EMPTY_FLOAT32;
        this.nextEta = EMPTY_FLOAT32;
        this.nextU = EMPTY_FLOAT32;
        this.nextV = EMPTY_FLOAT32;
    }
}
const EMPTY_FRAME = {
    kind: 'none',
    label: 'Rigid-body only',
    matrices: EMPTY_FLOAT32,
    colors: EMPTY_FLOAT32,
    instanceCount: 0,
    surface: null,
    debugLines: [],
    nodeCount: 0,
    constraintCount: 0,
    brokenCount: 0,
    energy: 0,
    hash: 0,
};
class SoftSimulationSuite {
    active = null;
    lastScene = null;
    lastStress = 1;
    lastSeed = 0;
    createScene(scene, stress, seed) {
        this.active?.destroy();
        this.active = null;
        this.lastScene = scene;
        this.lastStress = (0, math_1.clamp)(Math.round(stress), 1, 5);
        this.lastSeed = seed >>> 0;
        if (!softFamily(scene.family))
            return false;
        if (scene.family === 'cloth')
            this.active = new ClothSimulation(scene, this.lastStress, this.lastSeed);
        else if (scene.family === 'rope')
            this.active = new RopeSimulation(scene, this.lastStress, this.lastSeed);
        else
            this.active = new WaterSimulation(scene, this.lastStress, this.lastSeed);
        return true;
    }
    reset() {
        if (this.lastScene)
            this.createScene(this.lastScene, this.lastStress, this.lastSeed);
    }
    isActive() { return this.active !== null; }
    kind() { return this.active?.kind ?? 'none'; }
    label() { return this.active?.label ?? EMPTY_FRAME.label; }
    step(dt, subSteps) { this.active?.step(dt, subSteps); }
    kick(strength) { this.active?.kick(strength); }
    explode(center, strength, radius) { this.active?.explode(center, strength, radius); }
    launchProjectile(position, velocity, size) { return this.active?.launchProjectile(position, velocity, size) ?? -1; }
    spawnRain(count, spread, height) { return this.active?.spawnRain(count, spread, height) ?? 0; }
    buildFrame(debug = false) { return this.active?.buildFrame(debug) ?? EMPTY_FRAME; }
    hash() { return this.active?.currentHash() ?? 0; }
    destroy() {
        this.active?.destroy();
        this.active = null;
    }
    validate() {
        const frame = this.buildFrame(false);
        if (frame.kind === 'none')
            return { ok: true, message: 'No soft simulation active.' };
        if (frame.instanceCount < 0 || frame.instanceCount > MAX_SOFT_INSTANCES) {
            return { ok: false, message: `${frame.kind} exceeded the ${MAX_SOFT_INSTANCES}-instance soft simulation budget.` };
        }
        if (frame.matrices.length < frame.instanceCount * 16 || frame.colors.length < frame.instanceCount * 4) {
            return { ok: false, message: `${frame.kind} instance stream lengths do not match the declared instance count.` };
        }
        if (!(0, math_1.isFiniteArray)(frame.matrices) || !(0, math_1.isFiniteArray)(frame.colors)) {
            return { ok: false, message: `${frame.kind} instance stream contains non-finite values.` };
        }
        if (!Number.isFinite(frame.energy) || frame.energy < 0 || !Number.isInteger(frame.hash)) {
            return { ok: false, message: `${frame.kind} telemetry contains invalid energy or replay-hash values.` };
        }
        if (frame.surface) {
            if (frame.surface.vertexCount <= 0 || frame.surface.indexCount <= 0) {
                return { ok: false, message: `${frame.kind} surface topology is empty.` };
            }
            if (frame.surface.vertexStride !== packed_surface_1.PACKED_SURFACE_VERTEX_BYTES ||
                frame.surface.vertices.byteLength !== frame.surface.vertexCount * frame.surface.vertexStride) {
                return { ok: false, message: `${frame.kind} packed surface vertex stride/count is inconsistent.` };
            }
            if (!(0, packed_surface_1.packedSurfacePositionsAreFinite)(frame.surface.vertices, frame.surface.vertexCount) ||
                frame.surface.indices.length < frame.surface.indexCount) {
                return { ok: false, message: `${frame.kind} packed surface stream is invalid.` };
            }
            for (let i = 0; i < frame.surface.indexCount; i++) {
                if (frame.surface.indices[i] >= frame.surface.vertexCount) {
                    return { ok: false, message: `${frame.kind} surface index ${frame.surface.indices[i]} is out of range.` };
                }
            }
        }
        if (frame.nodeCount <= 0 || frame.hash === 0)
            return { ok: false, message: `${frame.kind} telemetry did not initialize.` };
        return { ok: true, message: `${frame.kind} validated: ${frame.nodeCount} nodes, ${frame.constraintCount} constraints.` };
    }
}
exports.SoftSimulationSuite = SoftSimulationSuite;
exports.SOFT_INSTANCE_BUDGET = MAX_SOFT_INSTANCES;
exports.SOFT_SURFACE_VERTEX_BYTES = SURFACE_VERTEX_BYTES;
exports.EMPTY_SURFACE = {
    material: 'cloth',
    vertices: EMPTY_UINT8,
    indices: EMPTY_UINT16,
    vertexStride: packed_surface_1.PACKED_SURFACE_VERTEX_BYTES,
    vertexCount: 0,
    indexCount: 0,
    topologyVersion: 0,
};
