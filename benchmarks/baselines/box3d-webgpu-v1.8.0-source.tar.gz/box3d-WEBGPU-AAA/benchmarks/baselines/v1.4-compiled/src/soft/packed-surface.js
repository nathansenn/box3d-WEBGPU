"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PackedSurfaceBuffer = exports.PACKED_SURFACE_VERTEX_BYTES = void 0;
exports.packedSurfacePositionsAreFinite = packedSurfacePositionsAreFinite;
/** Compact dynamic-surface layout shared by CPU simulation and WebGPU.
 *  0..11  : position.xyz as float32
 * 12..15  : octahedral normal.xy as snorm16
 * 16..19  : color/stress as unorm8x4
 * 20..23  : uv as unorm16x2
 */
exports.PACKED_SURFACE_VERTEX_BYTES = 24;
class PackedSurfaceBuffer {
    buffer;
    data;
    u8;
    f32;
    i16;
    u16;
    constructor(vertexCount) {
        const safeCount = Math.max(0, Math.floor(vertexCount));
        this.buffer = new ArrayBuffer(safeCount * exports.PACKED_SURFACE_VERTEX_BYTES);
        this.data = new Uint8Array(this.buffer);
        this.u8 = this.data;
        this.f32 = new Float32Array(this.buffer);
        this.i16 = new Int16Array(this.buffer);
        this.u16 = new Uint16Array(this.buffer);
    }
}
exports.PackedSurfaceBuffer = PackedSurfaceBuffer;
function packedSurfacePositionsAreFinite(data, vertexCount) {
    const safeCount = Math.max(0, Math.min(Math.floor(vertexCount), Math.floor(data.byteLength / exports.PACKED_SURFACE_VERTEX_BYTES)));
    const f32 = new Float32Array(data.buffer, data.byteOffset, Math.floor(data.byteLength / 4));
    for (let i = 0; i < safeCount; i++) {
        const offset = i * (exports.PACKED_SURFACE_VERTEX_BYTES / 4);
        if (!Number.isFinite(f32[offset]) || !Number.isFinite(f32[offset + 1]) || !Number.isFinite(f32[offset + 2])) {
            return false;
        }
    }
    return true;
}
