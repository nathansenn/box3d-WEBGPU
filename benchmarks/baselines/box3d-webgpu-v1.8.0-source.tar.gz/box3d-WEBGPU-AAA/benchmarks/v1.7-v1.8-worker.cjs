'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { performance } = require('node:perf_hooks');

const root = path.resolve(process.argv[2]);
const variant = process.argv[3];
const workloadId = process.argv[4];
const build = path.join(root, '.test-build');
const { SCENES } = require(path.join(build, 'src/scenes.js'));
const { SoftSimulationSuite } = require(path.join(build, 'src/soft/simulations.js'));
const kernels = require(path.join(build, 'src/soft/wasm-kernels.js'));
kernels.installSoftKernelModule(new WebAssembly.Module(fs.readFileSync(path.join(root, 'public/soft-kernels-simd.wasm'))), `${variant}-simd`);

const definitions = {
  'cloth-standard-frame': { sceneIds: [609], warmup: 40, iterations: 6000, operation: 'frame' },
  'cloth-maximum-frame': { sceneIds: [649], warmup: 40, iterations: 6000, operation: 'frame' },
  'cloth-standard-full': { sceneIds: [609], warmup: 18, iterations: 140, operation: 'full' },
  'cloth-maximum-full': { sceneIds: [649], warmup: 18, iterations: 120, operation: 'full' },
  'cloth-sphere-full': { sceneIds: [627], warmup: 16, iterations: 110, operation: 'full' },
  'cloth-storm-full': { sceneIds: [649], warmup: 7, iterations: 70, operation: 'full', rain: 120 },
  'cloth-banner-storm': { sceneIds: [641], warmup: 7, iterations: 70, operation: 'full', rain: 120 },
  'cloth-tearing-control': { sceneIds: [646], warmup: 12, iterations: 75, operation: 'full' },
  'water-control': { sceneIds: [749], warmup: 18, iterations: 260, operation: 'full' },
  'mixed-maximum': { sceneIds: [649, 699, 749], warmup: 12, iterations: 90, operation: 'full' },
};
const definition = definitions[workloadId];
if (!definition) throw new Error(`unknown workload ${workloadId}`);
const suites = definition.sceneIds.map((sceneId) => {
  const suite = new SoftSimulationSuite();
  if (!suite.createScene(SCENES[sceneId], 5, 0x181800 + sceneId)) throw new Error(`failed scene ${sceneId}`);
  if (definition.rain && sceneId >= 600 && sceneId < 650) suite.spawnRain(definition.rain, 14, 24);
  return suite;
});
function op() {
  for (const suite of suites) {
    if (definition.operation === 'frame') {
      suite.active.frameDirty = true;
      suite.buildFrame(false);
    } else if (definition.operation === 'step') {
      suite.step(1 / 60, 4);
    } else {
      suite.step(1 / 60, 4);
      suite.buildFrame(false);
    }
  }
}
for (let i = 0; i < definition.warmup; i++) op();
global.gc?.();
const started = performance.now();
for (let i = 0; i < definition.iterations; i++) op();
const elapsedMs = performance.now() - started;
let combinedHash = 2166136261 >>> 0;
let nodes = 0;
let constraints = 0;
let instances = 0;
let surfaceBytes = 0;
let clothGridBytes = 0;
let waterBytes = 0;
for (const suite of suites) {
  const frame = suite.buildFrame(false);
  combinedHash ^= suite.hash(); combinedHash = Math.imul(combinedHash, 16777619) >>> 0;
  nodes += frame.nodeCount;
  constraints += frame.constraintCount;
  instances += frame.instanceCount;
  if (frame.surface) surfaceBytes += frame.surface.vertexCount * frame.surface.vertexStride;
  if (frame.clothGrid) clothGridBytes += frame.clothGrid.vertexCount * 16;
  if (frame.waterGrid) waterBytes += frame.waterGrid.vertexCount * 12;
}
process.stdout.write(JSON.stringify({
  variant, workloadId, elapsedMs, iterations: definition.iterations,
  msPerOperation: elapsedMs / definition.iterations,
  hash: combinedHash >>> 0, nodes, constraints, instances,
  surfaceBytes, clothGridBytes, waterBytes,
}));
