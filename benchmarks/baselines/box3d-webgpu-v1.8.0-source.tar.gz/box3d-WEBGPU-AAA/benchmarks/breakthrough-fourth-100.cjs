'use strict';
/**
 * v1.8 fourth 100-workload tournament.
 *
 * Compares the production GPU-resident intact-cloth handoff against the bundled
 * exact v1.7 source. The tournament covers frame construction, complete
 * simulation frames, projectile storms, topology-mutating tearing controls,
 * and unchanged rope/water controls. Every record carries raw timing samples,
 * determinism, state equivalence, reconstructed visual-stream equivalence, and
 * dynamic upload-byte accounting.
 */
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const { performance } = require('node:perf_hooks');
const { spawnSync } = require('node:child_process');

const root = path.resolve(__dirname, '..');
const samples = Math.max(3, Number.parseInt(process.env.FOURTH_SAMPLES || '5', 10));
const scale = Math.max(0.15, Number(process.env.FOURTH_SCALE || '1'));
const baselineOverride = process.env.V18_BASELINE_ROOT ? path.resolve(process.env.V18_BASELINE_ROOT) : null;
const startExperiment = Math.max(1, Number.parseInt(process.env.FOURTH_START || '1', 10));
const endExperiment = Math.min(100, Number.parseInt(process.env.FOURTH_END || '100', 10));
if (startExperiment > endExperiment) throw new Error(`FOURTH_START ${startExperiment} exceeds FOURTH_END ${endExperiment}`);

function median(values) {
  const sorted = [...values].sort((a, b) => a - b);
  const middle = sorted.length >> 1;
  return sorted.length & 1 ? sorted[middle] : (sorted[middle - 1] + sorted[middle]) * 0.5;
}
function mad(values) {
  const center = median(values);
  return median(values.map((value) => Math.abs(value - center)));
}
function geometricMean(values) {
  const positive = values.filter((value) => Number.isFinite(value) && value > 0);
  return positive.length ? Math.exp(positive.reduce((sum, value) => sum + Math.log(value), 0) / positive.length) : 0;
}
function relativeL2(a, b) {
  if (!a || !b || a.length !== b.length) return Infinity;
  let error = 0;
  let reference = 0;
  for (let i = 0; i < a.length; i++) {
    const delta = b[i] - a[i];
    error += delta * delta;
    reference += a[i] * a[i];
  }
  return Math.sqrt(error / Math.max(reference, 1e-30));
}
function rmsError(a, b) {
  if (!a || !b || a.length !== b.length) return Infinity;
  let error = 0;
  for (let i = 0; i < a.length; i++) {
    const delta = b[i] - a[i];
    error += delta * delta;
  }
  return Math.sqrt(error / Math.max(1, a.length));
}
function maxAbsError(a, b) {
  if (!a || !b || a.length !== b.length) return Infinity;
  let maximum = 0;
  for (let i = 0; i < a.length; i++) maximum = Math.max(maximum, Math.abs(b[i] - a[i]));
  return maximum;
}
function finiteArray(values) {
  if (!values) return true;
  for (let i = 0; i < values.length; i++) if (!Number.isFinite(values[i])) return false;
  return true;
}
function exactArray(a, b) {
  if (!a || !b || a.length !== b.length) return false;
  for (let i = 0; i < a.length; i++) if (a[i] !== b[i]) return false;
  return true;
}
function run(command, args, options = {}) {
  const result = spawnSync(command, args, { stdio: 'inherit', ...options });
  if (result.status !== 0) throw new Error(`${command} ${args.join(' ')} failed with ${result.status}`);
}
function prepareBaseline() {
  if (baselineOverride) return baselineOverride;
  const archive = path.join(root, 'benchmarks/baselines/box3d-webgpu-v1.7.0-source.tar.gz');
  if (!fs.existsSync(archive)) throw new Error(`Missing bundled baseline: ${archive}`);
  const target = path.join(os.tmpdir(), `box3d-webgpu-v17-fourth-${process.pid}`);
  fs.rmSync(target, { recursive: true, force: true });
  fs.mkdirSync(target, { recursive: true });
  run('tar', ['-xzf', archive, '-C', target, '--strip-components=1']);
  const nodeModules = path.join(root, 'node_modules');
  fs.rmSync(path.join(target, 'node_modules'), { recursive: true, force: true });
  fs.symlinkSync(nodeModules, path.join(target, 'node_modules'), process.platform === 'win32' ? 'junction' : 'dir');
  run(path.join(nodeModules, '.bin/tsc'), ['-p', path.join(target, 'tsconfig.test.json')], { cwd: target });
  fs.mkdirSync(path.join(target, '.test-build'), { recursive: true });
  fs.writeFileSync(path.join(target, '.test-build/package.json'), '{"type":"commonjs"}');
  return target;
}
function loadProject(projectRoot, variant) {
  const build = path.join(projectRoot, '.test-build');
  const { SCENES } = require(path.join(build, 'src/scenes.js'));
  const { SoftSimulationSuite } = require(path.join(build, 'src/soft/simulations.js'));
  const kernels = require(path.join(build, 'src/soft/wasm-kernels.js'));
  const module = new WebAssembly.Module(fs.readFileSync(path.join(projectRoot, 'public/soft-kernels-simd.wasm')));
  kernels.installSoftKernelModule(module, `${variant}-simd`);
  return { root: projectRoot, variant, SCENES, SoftSimulationSuite };
}
function createSuite(project, definition) {
  const suite = new project.SoftSimulationSuite();
  if (!suite.createScene(project.SCENES[definition.sceneId], 5, 0x180000 + definition.sceneId)) {
    throw new Error(`${project.variant} failed to create scene ${definition.sceneId}`);
  }
  if (definition.rain) suite.spawnRain(definition.rain, 14, 24);
  return suite;
}
function markFrameDirty(suite) {
  suite.active.frameDirty = true;
}
function operation(suite, type) {
  if (type === 'frame') {
    markFrameDirty(suite);
    suite.buildFrame(false);
  } else if (type === 'step') {
    suite.step(1 / 60, 4);
  } else {
    suite.step(1 / 60, 4);
    suite.buildFrame(false);
  }
}
function decodeOct(x, y) {
  let nx = x;
  let ny = y;
  let nz = 1 - Math.abs(nx) - Math.abs(ny);
  if (nz < 0) {
    const oldX = nx;
    nx = (1 - Math.abs(ny)) * (oldX < 0 ? -1 : 1);
    ny = (1 - Math.abs(oldX)) * (ny < 0 ? -1 : 1);
  }
  const length = Math.max(1e-20, Math.sqrt(nx * nx + ny * ny + nz * nz));
  return [nx / length, ny / length, nz / length];
}
function decodePackedSurface(surface) {
  const count = surface.vertexCount;
  const positions = new Float32Array(count * 3);
  const normals = new Float32Array(count * 3);
  const colors = new Float32Array(count * 4);
  const uvs = new Float32Array(count * 2);
  const view = new DataView(surface.vertices.buffer, surface.vertices.byteOffset, surface.vertices.byteLength);
  for (let i = 0; i < count; i++) {
    const byte = i * surface.vertexStride;
    const p = i * 3;
    const c = i * 4;
    const uv = i * 2;
    positions[p] = view.getFloat32(byte, true);
    positions[p + 1] = view.getFloat32(byte + 4, true);
    positions[p + 2] = view.getFloat32(byte + 8, true);
    const oct = decodeOct(view.getInt16(byte + 12, true) / 32767, view.getInt16(byte + 14, true) / 32767);
    normals[p] = oct[0]; normals[p + 1] = oct[1]; normals[p + 2] = oct[2];
    colors[c] = view.getUint8(byte + 16) / 255;
    colors[c + 1] = view.getUint8(byte + 17) / 255;
    colors[c + 2] = view.getUint8(byte + 18) / 255;
    colors[c + 3] = view.getUint8(byte + 19) / 255;
    uvs[uv] = view.getUint16(byte + 20, true) / 65535;
    uvs[uv + 1] = view.getUint16(byte + 22, true) / 65535;
  }
  return {
    positions,
    normals,
    colors,
    uvs,
    indices: Uint16Array.from(surface.indices.subarray(0, surface.indexCount)),
  };
}
function reconstructGrid(grid) {
  const count = grid.vertexCount;
  const positions = Float32Array.from(grid.positions.subarray(0, count * 3));
  const normals = new Float32Array(count * 3);
  const colors = new Float32Array(count * 4);
  const uvs = new Float32Array(count * 2);
  const cols = grid.cols;
  const rows = grid.rows;
  const a = grid.baseColorA;
  const b = grid.baseColorB;
  const invCols = 1 / Math.max(1, cols - 1);
  const invRows = 1 / Math.max(1, rows - 1);
  for (let y = 0; y < rows; y++) {
    const downY = Math.max(y, 1) - 1;
    const upY = Math.min(y + 1, rows - 1);
    for (let x = 0; x < cols; x++) {
      const index = y * cols + x;
      const leftX = Math.max(x, 1) - 1;
      const rightX = Math.min(x + 1, cols - 1);
      const left = (y * cols + leftX) * 3;
      const right = (y * cols + rightX) * 3;
      const down = (downY * cols + x) * 3;
      const up = (upY * cols + x) * 3;
      const txX = positions[right] - positions[left];
      const txY = positions[right + 1] - positions[left + 1];
      const txZ = positions[right + 2] - positions[left + 2];
      const tyX = positions[up] - positions[down];
      const tyY = positions[up + 1] - positions[down + 1];
      const tyZ = positions[up + 2] - positions[down + 2];
      let nx = tyY * txZ - tyZ * txY;
      let ny = tyZ * txX - tyX * txZ;
      let nz = tyX * txY - tyY * txX;
      let length = Math.sqrt(nx * nx + ny * ny + nz * nz);
      if (length <= 1e-9) {
        nx = 0; ny = grid.verticalLayout ? 0 : 1; nz = grid.verticalLayout ? 1 : 0;
        length = 1;
      }
      const p = index * 3;
      normals[p] = nx / length; normals[p + 1] = ny / length; normals[p + 2] = nz / length;
      const u = x * invCols;
      const v = y * invRows;
      const uv = index * 2;
      uvs[uv] = u; uvs[uv + 1] = v;
      const checker = ((Math.floor(u * 10) + Math.floor(v * 8)) & 1) === 0 ? 0.22 : 0.78;
      const br = a[0] + (b[0] - a[0]) * checker;
      const bg = a[1] + (b[1] - a[1]) * checker;
      const bb = a[2] + (b[2] - a[2]) * checker;
      const stress = Math.max(0, Math.min(1, grid.strain[index] * 3.2));
      const blend = stress * 0.72;
      const c = index * 4;
      colors[c] = br + (1 - br) * blend;
      colors[c + 1] = bg + (0.14 - bg) * blend;
      colors[c + 2] = bb + (0.03 - bb) * blend;
      colors[c + 3] = stress;
    }
  }
  return {
    positions,
    normals,
    colors,
    uvs,
    indices: Uint16Array.from(grid.indices.subarray(0, grid.indexCount)),
  };
}
function capture(suite) {
  const frame = suite.buildFrame(false);
  const active = suite.active;
  const state = active.kind === 'water' ? active.eta : active.positions;
  const stateCopy = Float32Array.from(state);
  const matrices = Float32Array.from(frame.matrices.subarray(0, frame.instanceCount * 16));
  const colors = Float32Array.from(frame.colors.subarray(0, frame.instanceCount * 4));
  const visual = frame.surface ? decodePackedSurface(frame.surface) : frame.clothGrid ? reconstructGrid(frame.clothGrid) : null;
  const surfaceBytes = frame.surface ? frame.surface.vertexCount * frame.surface.vertexStride : 0;
  const clothGridBytes = frame.clothGrid ? frame.clothGrid.vertexCount * 4 * Float32Array.BYTES_PER_ELEMENT : 0;
  const waterBytes = frame.waterGrid ? frame.waterGrid.vertexCount * 3 * Float32Array.BYTES_PER_ELEMENT : 0;
  const finite = finiteArray(stateCopy) && finiteArray(matrices) && finiteArray(colors) &&
    (!visual || [visual.positions, visual.normals, visual.colors, visual.uvs].every(finiteArray));
  return {
    hash: suite.hash(), state: stateCopy, finite, matrices, colors, visual,
    instanceCount: frame.instanceCount, nodeCount: frame.nodeCount,
    constraintCount: frame.constraintCount, brokenCount: frame.brokenCount,
    surfaceBytes, clothGridBytes, waterBytes,
    hasSurface: !!frame.surface, hasClothGrid: !!frame.clothGrid, hasWaterGrid: !!frame.waterGrid,
  };
}
function measure(project, definition, sampleIndex) {
  global.gc?.();
  const suite = createSuite(project, definition);
  const warmup = Math.max(2, Math.round(definition.warmup * scale));
  const iterations = Math.max(3, Math.round(definition.iterations * scale));
  for (let i = 0; i < warmup; i++) operation(suite, definition.operation);
  global.gc?.();
  const started = performance.now();
  for (let i = 0; i < iterations; i++) operation(suite, definition.operation);
  const elapsed = performance.now() - started;
  return { ms: elapsed / iterations, capture: capture(suite), sampleIndex, iterations };
}

const clothIds = Array.from({ length: 50 }, (_, i) => 600 + i);
const intactIds = clothIds.filter((id) => {
  const mode = Math.floor((id - 600) / 10);
  const variant = (id - 600) % 10;
  return variant !== 6 && !(mode >= 3 && variant === 7);
});
const tearingIds = clothIds.filter((id) => !intactIds.includes(id));
const definitions = [];
function add(category, ids, operationType, iterations, warmup, extra = {}) {
  for (const sceneId of ids) definitions.push({ category, sceneId, operation: operationType, iterations, warmup, ...extra });
}
add('cloth-frame', intactIds.slice(0, 35), 'frame', 1100, 24);
add('cloth-full', [...intactIds.slice(12), ...intactIds.slice(0, 12)].slice(0, 25), 'full', 100, 14);
add('cloth-storm', [...intactIds].reverse().slice(0, 20), 'full', 55, 6, { rain: 120 });
add('cloth-tearing-control', tearingIds, 'full', 60, 8);
add('water-full-control', Array.from({ length: 7 }, (_, i) => 743 + i), 'full', 150, 12);
add('rope-full-control', Array.from({ length: 6 }, (_, i) => 694 + i), 'full', 110, 10);
if (definitions.length !== 100) throw new Error(`internal error: expected 100 definitions, got ${definitions.length}`);

const baselineRoot = prepareBaseline();
const baseline = loadProject(baselineRoot, 'v1.7');
const optimized = loadProject(root, 'v1.8');
const records = [];
const startedAll = performance.now();

for (let experimentIndex = startExperiment - 1; experimentIndex < endExperiment; experimentIndex++) {
  const definition = definitions[experimentIndex];
  const baselineSamples = [];
  const optimizedSamples = [];
  const baselineCaptures = [];
  const optimizedCaptures = [];
  for (let sampleIndex = 0; sampleIndex < samples; sampleIndex++) {
    const order = ((experimentIndex + sampleIndex) & 1) === 0
      ? [[baseline, baselineSamples, baselineCaptures], [optimized, optimizedSamples, optimizedCaptures]]
      : [[optimized, optimizedSamples, optimizedCaptures], [baseline, baselineSamples, baselineCaptures]];
    for (const [project, times, captures] of order) {
      const result = measure(project, definition, sampleIndex);
      times.push(result.ms);
      captures.push(result.capture);
    }
  }
  const baselineMedian = median(baselineSamples);
  const optimizedMedian = median(optimizedSamples);
  const speedup = baselineMedian / optimizedMedian;
  const b = baselineCaptures[baselineCaptures.length - 1];
  const o = optimizedCaptures[optimizedCaptures.length - 1];
  const baselineDeterministic = new Set(baselineCaptures.map((entry) => entry.hash)).size === 1;
  const optimizedDeterministic = new Set(optimizedCaptures.map((entry) => entry.hash)).size === 1;
  const stateError = relativeL2(b.state, o.state);
  const matrixError = relativeL2(b.matrices, o.matrices);
  const instanceColorError = relativeL2(b.colors, o.colors);
  let visualPositionError = 0;
  let visualNormalError = 0;
  let visualColorRms = 0;
  let visualColorMax = 0;
  let visualUvMax = 0;
  let topologyEqual = true;
  if (b.visual || o.visual) {
    visualPositionError = relativeL2(b.visual?.positions, o.visual?.positions);
    visualNormalError = relativeL2(b.visual?.normals, o.visual?.normals);
    visualColorRms = rmsError(b.visual?.colors, o.visual?.colors);
    visualColorMax = maxAbsError(b.visual?.colors, o.visual?.colors);
    visualUvMax = maxAbsError(b.visual?.uvs, o.visual?.uvs);
    topologyEqual = exactArray(b.visual?.indices, o.visual?.indices);
  }
  const outputShapeValid = b.nodeCount === o.nodeCount && b.constraintCount === o.constraintCount &&
    b.instanceCount === o.instanceCount && b.brokenCount === o.brokenCount;
  const changedCloth = definition.category === 'cloth-frame' || definition.category === 'cloth-full' || definition.category === 'cloth-storm';
  const transportValid = changedCloth
    ? b.hasSurface && o.hasClothGrid && b.surfaceBytes > 0 && o.clothGridBytes > 0
    : definition.category === 'cloth-tearing-control'
      ? b.hasSurface && o.hasSurface && !o.hasClothGrid
      : true;
  const correctness = b.finite && o.finite && baselineDeterministic && optimizedDeterministic &&
    stateError <= 1e-7 && matrixError <= 1e-7 && instanceColorError <= 1e-7 && outputShapeValid && transportValid &&
    visualPositionError <= 1e-7 && visualNormalError <= 2.5e-4 && visualColorRms <= 0.0045 &&
    visualColorMax <= 0.006 && visualUvMax <= 2e-5 && topologyEqual;
  const isControl = definition.category.endsWith('-control');
  let status;
  if (!correctness) status = 'rejected-correctness';
  else if (isControl) status = 'control';
  else if (speedup >= 1.05) status = 'accepted';
  else if (speedup >= 0.98) status = 'borderline';
  else status = 'rejected-no-win';
  const record = {
    id: experimentIndex + 1,
    category: definition.category,
    sceneId: definition.sceneId,
    scene: optimized.SCENES[definition.sceneId].title,
    operation: definition.operation,
    rain: definition.rain || 0,
    status,
    baselineSamplesMs: baselineSamples,
    optimizedSamplesMs: optimizedSamples,
    baselineMedianMs: baselineMedian,
    optimizedMedianMs: optimizedMedian,
    baselineMadMs: mad(baselineSamples),
    optimizedMadMs: mad(optimizedSamples),
    speedup,
    correctness: {
      passed: correctness,
      finite: b.finite && o.finite,
      baselineDeterministic,
      optimizedDeterministic,
      crossVersionHashMatch: b.hash === o.hash,
      stateRelativeL2: stateError,
      matrixRelativeL2: matrixError,
      instanceColorRelativeL2: instanceColorError,
      visualPositionRelativeL2: visualPositionError,
      visualNormalRelativeL2: visualNormalError,
      visualColorRms,
      visualColorMax,
      visualUvMax,
      topologyEqual,
      outputShapeValid,
      transportValid,
    },
    payload: {
      baselineDynamicVertexBytes: b.surfaceBytes,
      optimizedDynamicStateBytes: o.clothGridBytes || o.surfaceBytes || o.waterBytes,
      byteReduction: b.surfaceBytes > 0 && o.clothGridBytes > 0 ? 1 - o.clothGridBytes / b.surfaceBytes : 0,
    },
  };
  records.push(record);
  console.log(`${String(record.id).padStart(3, '0')}/100 ${definition.category.padEnd(23)} ${speedup.toFixed(2)}× ${status}`);
}

const counts = { accepted: 0, borderline: 0, control: 0, 'rejected-no-win': 0, 'rejected-correctness': 0 };
for (const record of records) counts[record.status]++;
const categoryNames = [...new Set(records.map((entry) => entry.category))];
const categories = Object.fromEntries(categoryNames.map((name) => {
  const entries = records.filter((entry) => entry.category === name);
  return [name, {
    count: entries.length,
    geometricMeanSpeedup: geometricMean(entries.map((entry) => entry.speedup)),
    medianSpeedup: median(entries.map((entry) => entry.speedup)),
    accepted: entries.filter((entry) => entry.status === 'accepted').length,
    controls: entries.filter((entry) => entry.status === 'control').length,
  }];
}));
const output = {
  schema: 1,
  generatedAt: new Date().toISOString(),
  environment: { node: process.version, platform: process.platform, arch: process.arch, cpu: os.cpus()[0]?.model ?? 'unknown' },
  method: {
    samplesPerExperiment: samples,
    iterationScale: scale,
    alternatingOrder: true,
    medianAndMad: true,
    warmup: true,
    baseline: 'bundled exact v1.7.0 source',
    optimized: 'v1.8 worktree',
    acceptanceThreshold: 1.05,
    correctness: 'finite state, deterministic and cross-version hashes, exact state/topology, reconstructed normal/color/UV fidelity, output shape, and transport checks',
  },
  summary: {
    experimentCount: records.length,
    ...Object.fromEntries(Object.entries(counts).map(([key, value]) => [`${key}Count`, value])),
    elapsedMs: performance.now() - startedAll,
    categories,
    maximumSpeedup: Math.max(...records.map((entry) => entry.speedup)),
    medianSpeedup: median(records.map((entry) => entry.speedup)),
    changedPathGeometricMeanSpeedup: geometricMean(records.filter((entry) => !entry.category.endsWith('-control')).map((entry) => entry.speedup)),
  },
  experiments: records,
};
const resultsDir = path.join(root, 'benchmarks/results');
fs.mkdirSync(resultsDir, { recursive: true });
if (startExperiment !== 1 || endExperiment !== 100) {
  const shard = {
    schema: 1,
    generatedAt: output.generatedAt,
    environment: output.environment,
    method: output.method,
    range: { startExperiment, endExperiment },
    elapsedMs: output.summary.elapsedMs,
    experiments: records,
  };
  const shardName = `v1.8-fourth-breakthrough-shard-${startExperiment}-${endExperiment}.json`;
  fs.writeFileSync(path.join(resultsDir, shardName), JSON.stringify(shard, null, 2));
  console.log(JSON.stringify({ shard: shardName, experimentCount: records.length, elapsedMs: output.summary.elapsedMs }, null, 2));
  process.exit(0);
}
fs.writeFileSync(path.join(resultsDir, 'v1.8-fourth-breakthrough-100.json'), JSON.stringify(output, null, 2));
const csvHeader = ['id','category','sceneId','scene','operation','rain','status','baselineMedianMs','optimizedMedianMs','speedup','stateRelativeL2','visualNormalRelativeL2','visualColorRms','visualColorMax','visualUvMax','baselineDynamicVertexBytes','optimizedDynamicStateBytes','byteReduction'];
const quote = (value) => `"${String(value).replaceAll('"', '""')}"`;
const csv = [csvHeader.join(','), ...records.map((entry) => [
  entry.id, entry.category, entry.sceneId, quote(entry.scene), entry.operation, entry.rain, entry.status,
  entry.baselineMedianMs, entry.optimizedMedianMs, entry.speedup,
  entry.correctness.stateRelativeL2, entry.correctness.visualNormalRelativeL2,
  entry.correctness.visualColorRms, entry.correctness.visualColorMax, entry.correctness.visualUvMax,
  entry.payload.baselineDynamicVertexBytes, entry.payload.optimizedDynamicStateBytes, entry.payload.byteReduction,
].join(','))].join('\n');
fs.writeFileSync(path.join(resultsDir, 'v1.8-fourth-breakthrough-100.csv'), `${csv}\n`);
const md = [
  '# v1.8 Fourth Breakthrough — 100 Production-Path Experiments', '',
  `- Accepted changed paths: **${counts.accepted}**`,
  `- Borderline changed paths: **${counts.borderline}**`,
  `- Unchanged-path controls: **${counts.control}**`,
  `- Rejected, no win: **${counts['rejected-no-win']}**`,
  `- Rejected, correctness: **${counts['rejected-correctness']}**`,
  `- Changed-path geometric mean: **${output.summary.changedPathGeometricMeanSpeedup.toFixed(2)}×**`,
  `- Maximum measured speedup: **${output.summary.maximumSpeedup.toFixed(2)}×**`, '',
  '| Category | Tests | Geometric mean | Median | Accepted | Controls |', '|---|---:|---:|---:|---:|---:|',
  ...Object.entries(categories).map(([name, value]) => `| ${name} | ${value.count} | ${value.geometricMeanSpeedup.toFixed(2)}× | ${value.medianSpeedup.toFixed(2)}× | ${value.accepted} | ${value.controls} |`), '',
  'Raw samples, visual-fidelity metrics, and upload-byte evidence are in the JSON result.', '',
];
fs.writeFileSync(path.join(resultsDir, 'V1.8_FOURTH_BREAKTHROUGH_100.md'), md.join('\n'));
console.log(JSON.stringify(output.summary, null, 2));
