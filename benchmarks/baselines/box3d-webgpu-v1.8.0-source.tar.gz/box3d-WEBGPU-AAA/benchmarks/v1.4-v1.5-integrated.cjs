'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { performance } = require('node:perf_hooks');
const root = path.resolve(__dirname, '..');
const baseRoot = path.join(root, 'benchmarks/baselines/v1.4-compiled');
const optRoot = path.join(root, '.test-build');
const base = {
  scenes: require(path.join(baseRoot, 'src/scenes.js')).SCENES,
  Soft: require(path.join(baseRoot, 'src/soft/simulations.js')).SoftSimulationSuite,
  Rigid: require(path.join(baseRoot, 'src/physics/fallback.js')).FallbackPhysicsBackend,
};
const opt = {
  scenes: require(path.join(optRoot, 'src/scenes.js')).SCENES,
  Soft: require(path.join(optRoot, 'src/soft/simulations.js')).SoftSimulationSuite,
  Rigid: require(path.join(optRoot, 'src/physics/fallback.js')).FallbackPhysicsBackend,
};
function median(a){const s=[...a].sort((x,y)=>x-y);return s[s.length>>1]}
function mad(a){const m=median(a);return median(a.map(x=>Math.abs(x-m)))}
function soft(mod,id,warm,frames,action){const s=new mod.Soft();const scene=mod.scenes[id];s.createScene(scene,5,0x12345678);let spawnedRain=0;if(action==='rain')spawnedRain=s.spawnRain(scene.family==='rope'?96:150,14,24);if(action==='projectile')for(let i=0;i<6;i++)s.launchProjectile([-18,4+i,-4+i],[38,0,0],.65);for(let i=0;i<warm;i++){s.step(1/60,4);s.buildFrame(false)}const t=performance.now();for(let i=0;i<frames;i++){s.step(1/60,4);s.buildFrame(false)}const elapsed=performance.now()-t;const frame=s.buildFrame(false);return{msPerFrame:elapsed/frames,hash:s.hash(),energy:frame.energy,broken:frame.brokenCount,nodes:frame.nodeCount,spawnedRain,positions:s.active?.positions?Array.from(s.active.positions):null}}
function rigid(mod,id,warm,frames){const b=new mod.Rigid(4096);b.createScene(mod.scenes[id],5,0x12345678);for(let i=0;i<warm;i++)b.step(1/60,2);const t=performance.now();for(let i=0;i<frames;i++)b.step(1/60,2);const elapsed=performance.now()-t;return{msPerFrame:elapsed/frames,hash:b.replayHash(),bodies:b.bodyCount(),dynamic:b.dynamicCount()}}
const workloads={
 'cloth-steady':m=>soft(m,649,20,50,'none'),
 'cloth-rain':m=>soft(m,649,1,12,'rain'),
 'cloth-sphere':m=>soft(m,647,15,35,'none'),
 'cloth-tear':m=>soft(m,646,8,25,'projectile'),
 'rope-steady':m=>soft(m,699,20,80,'none'),
 'rope-rain':m=>soft(m,699,1,20,'rain'),
 'water':m=>soft(m,749,20,80,'none'),
 'rigid-grid':m=>rigid(m,39,8,50),
 'rigid-bridge':m=>rigid(m,149,8,50),
 'rigid-material':m=>rigid(m,299,8,50),
};
function positionError(a,b){if(!a||!b||a.length!==b.length)return null;let e=0,r=0,max=0;for(let i=0;i<a.length;i++){const d=b[i]-a[i];e+=d*d;r+=a[i]*a[i];max=Math.max(max,Math.abs(d))}return{relativeL2:Math.sqrt(e/Math.max(1e-30,r)),rmse:Math.sqrt(e/a.length),maxAbsolute:max}}
const results={};
for(const [name,run] of Object.entries(workloads)){
 const samples={baseline:[],optimized:[]},details={baseline:[],optimized:[]};
 for(let sample=0;sample<5;sample++){
  const order=sample%2===0?[['baseline',base],['optimized',opt]]:[['optimized',opt],['baseline',base]];
  for(const [label,mod] of order){const d=run(mod);samples[label].push(d.msPerFrame);details[label].push(d)}
 }
 const bm=median(samples.baseline),om=median(samples.optimized);
 const deterministic=new Set(details.optimized.map(x=>x.hash)).size===1;
 const exactHash=details.baseline[0].hash===details.optimized[0].hash;
 results[name]={baselineMedianMs:bm,optimizedMedianMs:om,speedup:bm/om,baselineMadMs:mad(samples.baseline),optimizedMadMs:mad(samples.optimized),baselineSamplesMs:samples.baseline,optimizedSamplesMs:samples.optimized,deterministic,exactHash,positionError:positionError(details.baseline[0].positions,details.optimized[0].positions),baselineHash:details.baseline[0].hash,optimizedHash:details.optimized[0].hash};
 console.log(`${name.padEnd(16)} ${bm.toFixed(4)} -> ${om.toFixed(4)} ms  ${(bm/om).toFixed(2)}x`);
}
const out={schema:1,generatedAt:new Date().toISOString(),method:'Five repeated samples in one Node process, alternating v1.4/v1.5 order; median wall-clock ms per complete simulation+frame-build workload.',results};
const dir=path.join(root,'benchmarks/results');fs.mkdirSync(dir,{recursive:true});
fs.writeFileSync(path.join(dir,'v1.4-v1.5-integrated.json'),JSON.stringify(out,null,2));
const md=['# v1.4 → v1.5 Integrated Performance Comparison','',out.method,'','| Workload | v1.4 ms | v1.5 ms | Speedup | Deterministic | Exact hash |','|---|---:|---:|---:|---:|---:|',...Object.entries(results).map(([n,r])=>`| ${n} | ${r.baselineMedianMs.toFixed(4)} | ${r.optimizedMedianMs.toFixed(4)} | **${r.speedup.toFixed(2)}×** | ${r.deterministic?'yes':'no'} | ${r.exactHash?'yes':'no'} |`),''];
fs.writeFileSync(path.join(dir,'V1.4_V1.5_INTEGRATED.md'),md.join('\n'));
