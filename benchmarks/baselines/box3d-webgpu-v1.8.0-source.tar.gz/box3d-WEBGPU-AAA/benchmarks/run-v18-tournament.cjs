'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const root = path.resolve(__dirname, '..');
const resultsDir = path.join(root, 'benchmarks/results');
fs.mkdirSync(resultsDir, { recursive: true });
for (const name of fs.readdirSync(resultsDir)) {
  if (/^v1\.8-fourth-breakthrough-shard-\d+-\d+\.json$/.test(name)) fs.rmSync(path.join(resultsDir, name));
}
const samples = process.env.FOURTH_SAMPLES || '5';
const scale = process.env.FOURTH_SCALE || '0.35';
for (const [start, end] of [[1, 35], [36, 60], [61, 80], [81, 100]]) {
  const result = spawnSync(process.execPath, ['--expose-gc', path.join(__dirname, 'breakthrough-fourth-100.cjs')], {
    cwd: root,
    stdio: 'inherit',
    env: { ...process.env, FOURTH_SAMPLES: samples, FOURTH_SCALE: scale, FOURTH_START: String(start), FOURTH_END: String(end) },
  });
  if (result.status !== 0) process.exit(result.status ?? 1);
}
const merge = spawnSync(process.execPath, [path.join(__dirname, 'merge-v18-shards.cjs')], { cwd: root, stdio: 'inherit' });
process.exit(merge.status ?? 1);
