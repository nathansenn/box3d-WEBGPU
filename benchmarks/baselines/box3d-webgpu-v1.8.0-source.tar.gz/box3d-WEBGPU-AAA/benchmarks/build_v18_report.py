#!/usr/bin/env python3
import json, pathlib
root = pathlib.Path(__file__).resolve().parents[1]
results = root / 'benchmarks' / 'results'
t = json.loads((results / 'v1.8-fourth-breakthrough-100.json').read_text())
i = json.loads((results / 'v1.7-v1.8-isolated.json').read_text())
c = t['summary']['categories']
changed = [e for e in t['experiments'] if not e['category'].endswith('-control')]
max_normal = max(e['correctness']['visualNormalRelativeL2'] for e in changed)
max_color_rms = max(e['correctness']['visualColorRms'] for e in changed)
max_color = max(e['correctness']['visualColorMax'] for e in changed)
max_uv = max(e['correctness']['visualUvMax'] for e in changed)
lines = [
'# Box3D WebGPU AAA v1.8.0 — GPU-Cloth Breakthrough Performance Report','',
'## Executive result','',
'This pass moves intact regular-grid cloth surface reconstruction from the CPU to the WebGPU vertex stage. The authoritative PBD/WASM solver still owns positions and strain; WebGPU reconstructs smooth normals, UVs, the legacy checker palette, stress color, woven shading, and shadows. Tearing cloth keeps the topology-aware packed CPU surface path.','',
'### 100-experiment tournament','',
 f"- Experiments: **{t['summary']['experimentCount']}**",
 f"- Samples per experiment: **{t['method']['samplesPerExperiment']}**",
 f"- Iteration scale: **{t['method']['iterationScale']}×** of the standard loop count",
 '- Baseline/optimized order alternated for every experiment.','- Warm-up precedes timing.','- Medians and median absolute deviations are retained in raw evidence.','- Every changed path must preserve finite state, deterministic and cross-version hashes, topology, positions, reconstructed normals/colors/UVs, output shape, and transport contracts.','',
 f"- Accepted changed paths: **{t['summary']['acceptedCount']}**",
 f"- Borderline changed paths: **{t['summary']['borderlineCount']}**",
 f"- Unchanged-path controls: **{t['summary']['controlCount']}**",
 f"- No-win rejections: **{t['summary']['rejected-no-winCount']}**",
 f"- Correctness failures: **{t['summary']['rejected-correctnessCount']}**",
 f"- Changed-path geometric mean: **{t['summary']['changedPathGeometricMeanSpeedup']:.2f}×** (dominated by eliminated frame reconstruction and not a whole-engine claim)",'',
'| Category | Tests | Geometric mean | Median | Accepted |','|---|---:|---:|---:|---:|']
for name in ['cloth-frame','cloth-full','cloth-storm','cloth-tearing-control','water-full-control','rope-full-control']:
    v=c[name]; lines.append(f"| {name} | {v['count']} | **{v['geometricMeanSpeedup']:.2f}×** | {v['medianSpeedup']:.2f}× | {v['accepted']} |")
lines += ['','### Isolated fresh-process comparison','',
 f"- Samples per workload: **{i['method']['samples']}**",
 f"- Paired bootstrap resamples: **{i['method']['bootstrapIterations']}**",
 '- Each measurement uses a fresh Node process; process startup is excluded from the timed loop.','- Version order alternates.','',
 f"- Changed-path geometric mean: **{i['summary']['changedGeometricMeanSpeedup']:.2f}×**",
 f"- Dynamic/mixed geometric mean: **{i['summary']['dynamicGeometricMeanSpeedup']:.3f}×**",'',
'| Workload | v1.7 ms | v1.8 ms | Speedup | Paired 95% interval |','|---|---:|---:|---:|---:|']
for r in i['results']:
    lines.append(f"| {r['label']} | {r['baselineMedianMs']:.6f} | {r['optimizedMedianMs']:.6f} | **{r['speedup']:.2f}×** | {r['pairedBootstrap95'][0]:.2f}–{r['pairedBootstrap95'][1]:.2f}× |")
lines += ['','## Architecture','',
'```text','v1.7 intact cloth','PBD/WASM solver → CPU normal/color/UV packing → 24-byte vertex upload → WebGPU','',
'v1.8 intact cloth','PBD/WASM solver → position + strain storage upload → WebGPU reconstruction/shading','',
'Tearing cloth','PBD topology mutation → topology-aware CPU surface → WebGPU','```','',
'For intact cloth, steady dynamic data falls from 24 bytes per vertex to 16 bytes per vertex: **33.33% fewer uploaded bytes**. Topology is static and cached. Unchanged frame revisions produce zero additional uploads.','',
'## Visual and numerical fidelity','',
'- Simulation positions and hashes are exact across v1.7 and v1.8 for all 100 experiments.','- Topology and output counts are exact.','- A compact pair of X/Y parity masks preserves the legacy CPU checker pattern, including floating-point endpoint behavior, without uploading per-vertex colors.','- Dawn compiles and submits both the main and shadow GPU-cloth pipelines.','',
 f"- Maximum reconstructed-normal relative L2: **{max_normal:.8f}**",
 f"- Maximum color RMS error: **{max_color_rms:.8f}**",
 f"- Maximum per-channel color error: **{max_color:.8f}** (one 8-bit step)",
 f"- Maximum UV error: **{max_uv:.8f}**",'',
'## Interpretation','',
'The 80–100× handoff numbers measure elimination of CPU vertex reconstruction near the timer floor; they are not whole-engine or physical-GPU FPS multipliers. Complete cloth workloads improve more modestly because constraint solving remains dominant. The fresh-process mixed maximum cloth/rope/water workload is the most conservative application-level result for this pass.','',
'No target-Mac physical-GPU timestamp result is claimed. Dawn proves WGSL, bind groups, storage buffers, shadow and HDR pipeline compatibility, indexed draws, upload caching, and command submission in this environment.','',
'## Reproduction','', '```bash','npm ci','npm run bench:fourth:100','npm run bench:v1.7-v1.8','npm run bench:fourth:gate','npm run validate:v1.8','```','',
'Raw evidence: `benchmarks/results/v1.8-fourth-breakthrough-100.json` and `benchmarks/results/v1.7-v1.8-isolated.json`.','']
(root / 'docs' / 'PERFORMANCE_V1.8.md').write_text('\n'.join(lines))
(root / 'PERFORMANCE.md').write_text('\n'.join([
'# Performance Edition v1.8.0','',
 f"GPU-resident intact cloth removes CPU surface reconstruction, measuring {c['cloth-frame']['geometricMeanSpeedup']:.2f}× geometric-mean faster frame handoff across 35 cloth scenes, {c['cloth-full']['geometricMeanSpeedup']:.2f}× across 25 complete cloth workloads, and {i['summary']['dynamicGeometricMeanSpeedup']:.3f}× across isolated dynamic/mixed release workloads.",'',
'Intact-cloth dynamic uploads are 33.33% smaller. Tearing cloth retains the topology-aware CPU path.','',
'See [docs/PERFORMANCE_V1.8.md](docs/PERFORMANCE_V1.8.md).','']))
print(root / 'docs' / 'PERFORMANCE_V1.8.md')
