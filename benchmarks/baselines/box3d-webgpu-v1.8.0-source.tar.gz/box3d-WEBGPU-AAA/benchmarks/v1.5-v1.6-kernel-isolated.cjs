'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const { performance } = require('node:perf_hooks');

const root = path.resolve(__dirname, '..');

function runCommand(command, args, options = {}) {
  const result = spawnSync(command, args, {
    cwd: options.cwd || root,
    encoding: 'utf8',
    maxBuffer: 8 * 1024 * 1024,
  });
  if (result.status !== 0) {
    throw new Error(`${command} ${args.join(' ')} failed:
${result.stderr || result.stdout}`);
  }
}

function prepareBundledBaseline() {
  if (process.env.V15_ROOT) return path.resolve(process.env.V15_ROOT);

  const archive = path.join(root, 'benchmarks/baselines/box3d-webgpu-v1.5.0-source.tar.gz');
  const target = path.join(root, '.bench-baseline-v1.5');
  if (!fs.existsSync(archive)) {
    throw new Error(`bundled v1.5 baseline is missing: ${archive}`);
  }

  fs.rmSync(target, { recursive: true, force: true });
  fs.mkdirSync(target, { recursive: true });
  runCommand('tar', ['-xzf', archive, '-C', target, '--strip-components=1']);

  const dependencyLink = path.join(target, 'node_modules');
  const projectDependencies = path.join(root, 'node_modules');
  if (!fs.existsSync(projectDependencies)) {
    throw new Error('node_modules is missing; run npm ci before the isolated benchmark');
  }
  fs.symlinkSync(projectDependencies, dependencyLink, process.platform === 'win32' ? 'junction' : 'dir');

  runCommand(path.join(root, 'node_modules/.bin/tsc'), ['-p', path.join(target, 'tsconfig.test.json')], { cwd: target });
  fs.writeFileSync(path.join(target, '.test-build/package.json'), '{"type":"commonjs"}');
  return target;
}

const baselineRoot = prepareBundledBaseline();
const worker = path.join(root, 'benchmarks/v1.5-v1.6-kernel-worker.cjs');
const samples = Math.max(3, Number.parseInt(process.env.V16_SAMPLES || '7', 10));
const bootstrapIterations = Math.max(1000, Number.parseInt(process.env.V16_BOOTSTRAPS || '10000', 10));
const workloads = [
  ['cloth-standard-full', 'Cloth standard · step + surface'],
  ['cloth-maximum-full', 'Cloth maximum · step + surface'],
  ['cloth-maximum-step', 'Cloth maximum · solver only'],
  ['rope-maximum-full', 'Rope maximum · step + instances'],
  ['rope-storm-full', 'Rope storm · 96 impacts'],
  ['water-wave-full', 'Water wave · step + surface'],
  ['water-maximum-full', 'Water maximum · step + surface'],
  ['cloth-paused-frame', 'Cloth paused · unchanged frame'],
  ['rope-paused-frame', 'Rope paused · unchanged frame'],
  ['water-paused-frame', 'Water paused · unchanged frame'],
];

function median(values) {
  const sorted = [...values].sort((a, b) => a - b);
  const middle = sorted.length >> 1;
  return sorted.length & 1 ? sorted[middle] : (sorted[middle - 1] + sorted[middle]) * 0.5;
}
function mad(values) {
  const center = median(values);
  return median(values.map((value) => Math.abs(value - center)));
}
function run(variant, workloadId) {
  const sourceRoot = variant === 'v1.5' ? baselineRoot : root;
  const result = spawnSync(process.execPath, ['--expose-gc', worker, sourceRoot, variant, workloadId], {
    cwd: root,
    encoding: 'utf8',
    maxBuffer: 1024 * 1024,
  });
  if (result.status !== 0) throw new Error(`${variant} ${workloadId} failed:\n${result.stderr || result.stdout}`);
  return JSON.parse(result.stdout);
}

// Deterministic xorshift for reproducible paired bootstrap intervals.
let randomState = 0x16c0ffee;
function random01() {
  randomState ^= randomState << 13;
  randomState ^= randomState >>> 17;
  randomState ^= randomState << 5;
  return (randomState >>> 0) / 0x100000000;
}
function percentile(sorted, p) {
  const position = (sorted.length - 1) * p;
  const lower = Math.floor(position);
  const upper = Math.ceil(position);
  const t = position - lower;
  return sorted[lower] + (sorted[upper] - sorted[lower]) * t;
}
function bootstrapPairedRatios(baseline, optimized) {
  const ratios = [];
  for (let iteration = 0; iteration < bootstrapIterations; iteration++) {
    const b = [];
    const o = [];
    for (let i = 0; i < baseline.length; i++) {
      const index = Math.floor(random01() * baseline.length);
      b.push(baseline[index]);
      o.push(optimized[index]);
    }
    ratios.push(median(b) / median(o));
  }
  ratios.sort((a, b) => a - b);
  return [percentile(ratios, 0.025), percentile(ratios, 0.975)];
}

const started = performance.now();
const results = [];
for (let workloadIndex = 0; workloadIndex < workloads.length; workloadIndex++) {
  const [id, label] = workloads[workloadIndex];
  const baseline = [];
  const optimized = [];
  const baselineHashes = [];
  const optimizedHashes = [];
  for (let sample = 0; sample < samples; sample++) {
    const order = ((sample + workloadIndex) & 1) === 0 ? ['v1.5', 'v1.6'] : ['v1.6', 'v1.5'];
    for (const variant of order) {
      const measurement = run(variant, id);
      if (variant === 'v1.5') {
        baseline.push(measurement.msPerOperation);
        baselineHashes.push(measurement.hash);
      } else {
        optimized.push(measurement.msPerOperation);
        optimizedHashes.push(measurement.hash);
      }
    }
  }
  const baselineMedian = median(baseline);
  const optimizedMedian = median(optimized);
  const speedup = baselineMedian / optimizedMedian;
  const interval = bootstrapPairedRatios(baseline, optimized);
  const result = {
    id,
    label,
    category: id.includes('paused') ? 'unchanged-frame-cache' : 'dynamic-simulation',
    baselineSamplesMs: baseline,
    optimizedSamplesMs: optimized,
    baselineMedianMs: baselineMedian,
    optimizedMedianMs: optimizedMedian,
    baselineMadMs: mad(baseline),
    optimizedMadMs: mad(optimized),
    speedup,
    pairedBootstrap95: interval,
    baselineDeterministic: new Set(baselineHashes).size === 1,
    optimizedDeterministic: new Set(optimizedHashes).size === 1,
    baselineHashes,
    optimizedHashes,
  };
  results.push(result);
  console.log(`${String(workloadIndex + 1).padStart(2, '0')}/${workloads.length} ${label}: ${speedup.toFixed(2)}× [${interval[0].toFixed(2)}, ${interval[1].toFixed(2)}]`);
}

const dynamic = results.filter((result) => result.category === 'dynamic-simulation');
const cache = results.filter((result) => result.category === 'unchanged-frame-cache');
const geometricMean = (values) => Math.exp(values.reduce((sum, value) => sum + Math.log(value), 0) / values.length);
const output = {
  schema: 1,
  generatedAt: new Date().toISOString(),
  environment: { node: process.version, platform: process.platform, arch: process.arch },
  method: {
    samples,
    bootstrapIterations,
    freshProcessPerMeasurement: true,
    alternatingOrder: true,
    processStartupExcluded: true,
  },
  summary: {
    dynamicGeometricMeanSpeedup: geometricMean(dynamic.map((result) => result.speedup)),
    dynamicMedianSpeedup: median(dynamic.map((result) => result.speedup)),
    cacheGeometricMeanSpeedup: geometricMean(cache.map((result) => result.speedup)),
    elapsedMs: performance.now() - started,
  },
  results,
};
const resultsDir = path.join(root, 'benchmarks/results');
fs.mkdirSync(resultsDir, { recursive: true });
fs.writeFileSync(path.join(resultsDir, 'v1.5-v1.6-kernel-isolated.json'), JSON.stringify(output, null, 2));
const markdown = [
  '# v1.5 → v1.6 Isolated Kernel Benchmark',
  '',
  `- Dynamic geometric mean: **${output.summary.dynamicGeometricMeanSpeedup.toFixed(2)}×**`,
  `- Dynamic median: **${output.summary.dynamicMedianSpeedup.toFixed(2)}×**`,
  `- Unchanged-frame cache geometric mean: **${output.summary.cacheGeometricMeanSpeedup.toFixed(0)}×**`,
  '',
  '| Workload | v1.5 ms | v1.6 ms | Speedup | Paired 95% interval |',
  '|---|---:|---:|---:|---:|',
  ...results.map((result) => `| ${result.label} | ${result.baselineMedianMs.toFixed(6)} | ${result.optimizedMedianMs.toFixed(6)} | **${result.speedup.toFixed(2)}×** | ${result.pairedBootstrap95[0].toFixed(2)}–${result.pairedBootstrap95[1].toFixed(2)}× |`),
  '',
];
fs.writeFileSync(path.join(resultsDir, 'V1.5_V1.6_KERNEL_ISOLATED.md'), markdown.join('\n'));
console.log(JSON.stringify(output.summary, null, 2));
