'use strict';
/**
 * v1.7 third 100-workload tournament.
 *
 * Measures the exact production paths changed in this pass against the bundled
 * v1.6 source. Every record contains raw samples, median/MAD, determinism, state
 * equivalence and (where applicable) rendered-stream equivalence. This is a
 * scene-diverse tournament rather than 100 aliases of one micro-kernel.
 */
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const { performance } = require('node:perf_hooks');
const { spawnSync } = require('node:child_process');

const root = path.resolve(__dirname, '..');
const samples = Math.max(3, Number.parseInt(process.env.THIRD_SAMPLES || '5', 10));
const scale = Math.max(0.2, Number(process.env.THIRD_SCALE || '1'));
const baselineOverride = process.env.V17_BASELINE_ROOT ? path.resolve(process.env.V17_BASELINE_ROOT) : null;

function median(values) {
  const sorted = [...values].sort((a, b) => a - b);
  const middle = sorted.length >> 1;
  return sorted.length & 1 ? sorted[middle] : (sorted[middle - 1] + sorted[middle]) * 0.5;
}
function mad(values) {
  const center = median(values);
  return median(values.map((value) => Math.abs(value - center)));
}
function relativeL2(a, b) {
  if (!a || !b || a.length !== b.length) return Infinity;
  let error = 0;
  let reference = 0;
  for (let i = 0; i < a.length; i++) {
    const delta = b[i] - a[i];
    error += delta * delta;
    reference += a[i] * a[i];
  }
  return Math.sqrt(error / Math.max(reference, 1e-30));
}
function finiteArray(values) {
  for (let i = 0; i < values.length; i++) if (!Number.isFinite(values[i])) return false;
  return true;
}
function run(command, args, options = {}) {
  const result = spawnSync(command, args, { stdio: 'inherit', ...options });
  if (result.status !== 0) throw new Error(`${command} ${args.join(' ')} failed with ${result.status}`);
}
function prepareBaseline() {
  if (baselineOverride) return baselineOverride;
  const archive = path.join(root, 'benchmarks/baselines/box3d-webgpu-v1.6.0-source.tar.gz');
  if (!fs.existsSync(archive)) throw new Error(`Missing bundled baseline: ${archive}`);
  const target = path.join(os.tmpdir(), `box3d-webgpu-v16-third-${process.pid}`);
  fs.rmSync(target, { recursive: true, force: true });
  fs.mkdirSync(target, { recursive: true });
  run('tar', ['-xzf', archive, '-C', target, '--strip-components=1']);
  const nodeModules = path.join(root, 'node_modules');
  fs.rmSync(path.join(target, 'node_modules'), { recursive: true, force: true });
  fs.symlinkSync(nodeModules, path.join(target, 'node_modules'), process.platform === 'win32' ? 'junction' : 'dir');
  run(path.join(nodeModules, '.bin/tsc'), ['-p', path.join(target, 'tsconfig.test.json')], { cwd: target });
  fs.writeFileSync(path.join(target, '.test-build/package.json'), '{"type":"commonjs"}');
  return target;
}
function loadProject(projectRoot, variant) {
  const build = path.join(projectRoot, '.test-build');
  const { SCENES } = require(path.join(build, 'src/scenes.js'));
  const { SoftSimulationSuite } = require(path.join(build, 'src/soft/simulations.js'));
  const kernels = require(path.join(build, 'src/soft/wasm-kernels.js'));
  const module = new WebAssembly.Module(fs.readFileSync(path.join(projectRoot, 'public/soft-kernels-simd.wasm')));
  kernels.installSoftKernelModule(module, `${variant}-simd`);
  return { root: projectRoot, variant, SCENES, SoftSimulationSuite };
}
function createSuite(project, sceneId, seed) {
  const suite = new project.SoftSimulationSuite();
  if (!suite.createScene(project.SCENES[sceneId], 5, seed)) throw new Error(`${project.variant} failed to create scene ${sceneId}`);
  return suite;
}
function markFrameDirty(suite) {
  // TypeScript private fields compile to normal properties. This isolates the
  // real frame-construction path without advancing the solver in frame-only tests.
  suite.active.frameDirty = true;
}
function operation(suite, type) {
  if (type === 'frame') {
    markFrameDirty(suite);
    suite.buildFrame(false);
  } else if (type === 'step') {
    suite.step(1 / 60, 4);
  } else {
    suite.step(1 / 60, 4);
    suite.buildFrame(false);
  }
}
function capture(suite) {
  const frame = suite.buildFrame(false);
  const active = suite.active;
  const state = active.kind === 'water' ? active.eta : active.positions;
  const stateCopy = Float32Array.from(state);
  const matrices = Float32Array.from(frame.matrices.subarray(0, frame.instanceCount * 16));
  const colors = Float32Array.from(frame.colors.subarray(0, frame.instanceCount * 4));
  const surfaceBytes = frame.surface ? frame.surface.vertexCount * frame.surface.vertexStride : 0;
  const waterBytes = frame.waterGrid ? frame.waterGrid.vertexCount * 3 * Float32Array.BYTES_PER_ELEMENT : 0;
  return {
    hash: suite.hash(),
    state: stateCopy,
    finite: finiteArray(stateCopy) && finiteArray(matrices) && finiteArray(colors),
    matrices,
    colors,
    instanceCount: frame.instanceCount,
    nodeCount: frame.nodeCount,
    constraintCount: frame.constraintCount,
    surfaceBytes,
    waterBytes,
    hasSurface: !!frame.surface,
    hasWaterGrid: !!frame.waterGrid,
  };
}
function measure(project, definition, sampleIndex) {
  global.gc?.();
  const suite = createSuite(project, definition.sceneId, 0x170000 + definition.sceneId);
  if (definition.rain) suite.spawnRain(definition.rain, 14, 24);
  const warmup = Math.max(2, Math.round(definition.warmup * scale));
  const iterations = Math.max(3, Math.round(definition.iterations * scale));
  for (let i = 0; i < warmup; i++) operation(suite, definition.operation);
  global.gc?.();
  const started = performance.now();
  for (let i = 0; i < iterations; i++) operation(suite, definition.operation);
  const elapsed = performance.now() - started;
  return { ms: elapsed / iterations, capture: capture(suite), sampleIndex, iterations };
}

const definitions = [];
function addRange(category, ids, operationType, iterations, warmup) {
  for (const sceneId of ids) definitions.push({ category, sceneId, operation: operationType, iterations, warmup });
}
// 25 GPU-water frame reconstruction tests, covering five modes and all variants.
addRange('water-frame', Array.from({ length: 25 }, (_, i) => 725 + i), 'frame', 900, 20);
// 20 complete water frames: solver + render handoff.
addRange('water-full', Array.from({ length: 20 }, (_, i) => 730 + i), 'full', 120, 16);
// 20 rope render-stream construction tests.
addRange('rope-frame', Array.from({ length: 20 }, (_, i) => 680 + i), 'frame', 1300, 20);
// 15 complete rope frames.
addRange('rope-full', Array.from({ length: 15 }, (_, i) => 685 + i), 'full', 100, 14);
// 10 unchanged cloth production workloads: a convergence/control group.
addRange('cloth-full-control', Array.from({ length: 10 }, (_, i) => 640 + i), 'full', 55, 10);
// 10 water-solver-only controls prove that the gain comes from render handoff.
addRange('water-step-control', Array.from({ length: 10 }, (_, i) => 740 + i), 'step', 220, 18);
if (definitions.length !== 100) throw new Error(`internal error: expected 100 definitions, got ${definitions.length}`);

const baselineRoot = prepareBaseline();
const baseline = loadProject(baselineRoot, 'v1.6');
const optimized = loadProject(root, 'v1.7');
const records = [];
const startedAll = performance.now();

for (let experimentIndex = 0; experimentIndex < definitions.length; experimentIndex++) {
  const definition = definitions[experimentIndex];
  const baselineSamples = [];
  const optimizedSamples = [];
  const baselineCaptures = [];
  const optimizedCaptures = [];
  for (let sampleIndex = 0; sampleIndex < samples; sampleIndex++) {
    const order = ((experimentIndex + sampleIndex) & 1) === 0
      ? [[baseline, baselineSamples, baselineCaptures], [optimized, optimizedSamples, optimizedCaptures]]
      : [[optimized, optimizedSamples, optimizedCaptures], [baseline, baselineSamples, baselineCaptures]];
    for (const [project, times, captures] of order) {
      const result = measure(project, definition, sampleIndex);
      times.push(result.ms);
      captures.push(result.capture);
    }
  }
  const baselineMedian = median(baselineSamples);
  const optimizedMedian = median(optimizedSamples);
  const speedup = baselineMedian / optimizedMedian;
  const b = baselineCaptures[baselineCaptures.length - 1];
  const o = optimizedCaptures[optimizedCaptures.length - 1];
  const baselineDeterministic = new Set(baselineCaptures.map((entry) => entry.hash)).size === 1;
  const optimizedDeterministic = new Set(optimizedCaptures.map((entry) => entry.hash)).size === 1;
  const stateError = relativeL2(b.state, o.state);
  const matrixError = definition.category.startsWith('rope') ? relativeL2(b.matrices, o.matrices) : 0;
  const colorError = definition.category.startsWith('rope') ? relativeL2(b.colors, o.colors) : 0;
  const outputShapeValid = b.nodeCount === o.nodeCount && b.constraintCount === o.constraintCount && b.instanceCount === o.instanceCount;
  const transportValid = definition.category.startsWith('water')
    ? b.hasSurface && o.hasWaterGrid && o.waterBytes > 0
    : true;
  const correctness = b.finite && o.finite && baselineDeterministic && optimizedDeterministic &&
    stateError <= 1e-7 && matrixError <= 5e-5 && colorError <= 5e-5 && outputShapeValid && transportValid;
  const isControl = definition.category.endsWith('-control');
  let status;
  if (!correctness) status = 'rejected-correctness';
  else if (isControl) status = 'control';
  else if (speedup >= 1.05) status = 'accepted';
  else if (speedup >= 0.98) status = 'borderline';
  else status = 'rejected-no-win';
  const record = {
    id: experimentIndex + 1,
    category: definition.category,
    sceneId: definition.sceneId,
    scene: optimized.SCENES[definition.sceneId].title,
    operation: definition.operation,
    status,
    baselineSamplesMs: baselineSamples,
    optimizedSamplesMs: optimizedSamples,
    baselineMedianMs: baselineMedian,
    optimizedMedianMs: optimizedMedian,
    baselineMadMs: mad(baselineSamples),
    optimizedMadMs: mad(optimizedSamples),
    speedup,
    correctness: {
      passed: correctness,
      baselineDeterministic,
      optimizedDeterministic,
      stateRelativeL2: stateError,
      matrixRelativeL2: matrixError,
      colorRelativeL2: colorError,
      outputShapeValid,
      transportValid,
    },
    payload: {
      baselineDynamicVertexBytes: b.surfaceBytes,
      optimizedDynamicStateBytes: o.waterBytes,
      byteReduction: b.surfaceBytes > 0 && o.waterBytes > 0 ? 1 - o.waterBytes / b.surfaceBytes : 0,
    },
  };
  records.push(record);
  console.log(`${String(record.id).padStart(3, '0')}/100 ${record.category.padEnd(20)} scene ${record.sceneId}: ${record.speedup.toFixed(2)}× ${record.status}`);
}

const counts = Object.fromEntries(['accepted', 'borderline', 'control', 'rejected-no-win', 'rejected-correctness'].map((status) => [status, records.filter((entry) => entry.status === status).length]));
const categories = {};
for (const category of [...new Set(records.map((entry) => entry.category))]) {
  const group = records.filter((entry) => entry.category === category);
  categories[category] = {
    count: group.length,
    medianSpeedup: median(group.map((entry) => entry.speedup)),
    geometricMeanSpeedup: Math.exp(group.reduce((sum, entry) => sum + Math.log(entry.speedup), 0) / group.length),
    accepted: group.filter((entry) => entry.status === 'accepted').length,
  };
}
const output = {
  schema: 1,
  generatedAt: new Date().toISOString(),
  environment: { node: process.version, platform: process.platform, arch: process.arch, cpu: os.cpus()[0]?.model ?? 'unknown' },
  method: {
    experimentCount: 100,
    samplesPerExperiment: samples,
    iterationScale: scale,
    alternatingOrder: true,
    medianAndMad: true,
    warmup: true,
    baseline: 'bundled exact v1.6.0 source',
    optimized: 'v1.7 worktree',
    acceptanceThreshold: 1.05,
    correctness: 'finite state, deterministic hashes, cross-version state equivalence, rope stream equivalence, output-shape and transport checks',
  },
  summary: {
    experimentCount: records.length,
    ...Object.fromEntries(Object.entries(counts).map(([key, value]) => [`${key}Count`, value])),
    elapsedMs: performance.now() - startedAll,
    categories,
    maximumSpeedup: Math.max(...records.map((entry) => entry.speedup)),
    medianSpeedup: median(records.map((entry) => entry.speedup)),
  },
  experiments: records,
};
const resultsDir = path.join(root, 'benchmarks/results');
fs.mkdirSync(resultsDir, { recursive: true });
fs.writeFileSync(path.join(resultsDir, 'v1.7-third-breakthrough-100.json'), JSON.stringify(output, null, 2));
const csvHeader = ['id','category','sceneId','scene','operation','status','baselineMedianMs','optimizedMedianMs','speedup','stateRelativeL2','matrixRelativeL2','colorRelativeL2','baselineDynamicVertexBytes','optimizedDynamicStateBytes','byteReduction'];
const quote = (value) => `"${String(value).replaceAll('"', '""')}"`;
const csv = [csvHeader.join(','), ...records.map((entry) => [
  entry.id, entry.category, entry.sceneId, quote(entry.scene), entry.operation, entry.status,
  entry.baselineMedianMs, entry.optimizedMedianMs, entry.speedup,
  entry.correctness.stateRelativeL2, entry.correctness.matrixRelativeL2, entry.correctness.colorRelativeL2,
  entry.payload.baselineDynamicVertexBytes, entry.payload.optimizedDynamicStateBytes, entry.payload.byteReduction,
].join(','))].join('\n');
fs.writeFileSync(path.join(resultsDir, 'v1.7-third-breakthrough-100.csv'), `${csv}\n`);
const md = [
  '# v1.7 Third Breakthrough — 100 Production-Path Experiments', '',
  `- Accepted: **${counts.accepted}**`,
  `- Borderline: **${counts.borderline}**`,
  `- Unchanged-path controls: **${counts.control}**`,
  `- Rejected, no win: **${counts['rejected-no-win']}**`,
  `- Rejected, correctness: **${counts['rejected-correctness']}**`,
  `- Maximum measured speedup: **${output.summary.maximumSpeedup.toFixed(2)}×**`, '',
  '| Category | Tests | Geometric mean | Median | Accepted |', '|---|---:|---:|---:|---:|',
  ...Object.entries(categories).map(([name, value]) => `| ${name} | ${value.count} | ${value.geometricMeanSpeedup.toFixed(2)}× | ${value.medianSpeedup.toFixed(2)}× | ${value.accepted} |`), '',
  'Raw samples and correctness metrics are in the JSON result.', '',
];
fs.writeFileSync(path.join(resultsDir, 'V1.7_THIRD_BREAKTHROUGH_100.md'), md.join('\n'));
console.log(JSON.stringify(output.summary, null, 2));
