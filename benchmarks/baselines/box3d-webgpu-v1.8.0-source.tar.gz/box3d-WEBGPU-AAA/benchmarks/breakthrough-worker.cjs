'use strict';

const path = require('node:path');
const { performance } = require('node:perf_hooks');

const root = path.resolve(__dirname, '..');
const version = process.argv[2];
const workload = process.argv[3];
const detail = process.argv.includes('--detail');
if (version !== 'baseline' && version !== 'optimized') throw new Error(`unknown version: ${version}`);

const moduleRoot = version === 'baseline'
  ? path.join(root, 'benchmarks', 'baselines', 'v1.4-compiled')
  : path.join(root, '.test-build');
const SCENES = require(path.join(moduleRoot, 'src/scenes.js')).SCENES;
const SoftSimulationSuite = require(path.join(moduleRoot, 'src/soft/simulations.js')).SoftSimulationSuite;
const FallbackPhysicsBackend = require(path.join(moduleRoot, 'src/physics/fallback.js')).FallbackPhysicsBackend;

const definitions = {
  'cloth-steady': { type: 'soft', scene: 649, warm: 20, frames: 50, action: 'none' },
  'cloth-rain': { type: 'soft', scene: 649, warm: 1, frames: 12, action: 'rain' },
  'cloth-sphere': { type: 'soft', scene: 647, warm: 15, frames: 35, action: 'none' },
  'cloth-tear': { type: 'soft', scene: 646, warm: 8, frames: 25, action: 'projectile' },
  'rope-steady': { type: 'soft', scene: 699, warm: 20, frames: 80, action: 'none' },
  'rope-rain': { type: 'soft', scene: 699, warm: 1, frames: 20, action: 'rain' },
  water: { type: 'soft', scene: 749, warm: 20, frames: 80, action: 'none' },
  'rigid-grid': { type: 'rigid', scene: 39, warm: 8, frames: 50 },
  'rigid-bridge': { type: 'rigid', scene: 149, warm: 8, frames: 50 },
  'rigid-material': { type: 'rigid', scene: 299, warm: 8, frames: 50 },
};

const definition = definitions[workload];
if (!definition) throw new Error(`unknown workload: ${workload}`);

function runSoft(def) {
  const suite = new SoftSimulationSuite();
  suite.createScene(SCENES[def.scene], 5, 0x12345678);
  let spawnedRain = 0;
  if (def.action === 'rain') spawnedRain = suite.spawnRain(SCENES[def.scene].family === 'rope' ? 96 : 150, 14, 24);
  if (def.action === 'projectile') {
    for (let i = 0; i < 6; i++) suite.launchProjectile([-18, 4 + i, -4 + i], [38, 0, 0], 0.65);
  }
  for (let i = 0; i < def.warm; i++) {
    suite.step(1 / 60, 4);
    suite.buildFrame(false);
  }
  const start = performance.now();
  for (let i = 0; i < def.frames; i++) {
    suite.step(1 / 60, 4);
    suite.buildFrame(false);
  }
  const elapsed = performance.now() - start;
  const frame = suite.buildFrame(false);
  const active = suite.active;
  const result = {
    msPerFrame: elapsed / def.frames,
    hash: suite.hash(),
    energy: frame.energy,
    broken: frame.brokenCount,
    nodes: frame.nodeCount,
    constraints: frame.constraintCount,
    finite: suite.validate().ok,
    spawnedRain,
  };
  if (detail && active && active.positions) result.positions = Array.from(active.positions);
  suite.destroy();
  return result;
}

function runRigid(def) {
  const backend = new FallbackPhysicsBackend(4096);
  backend.createScene(SCENES[def.scene], 5, 0x12345678);
  for (let i = 0; i < def.warm; i++) backend.step(1 / 60, 2);
  const start = performance.now();
  for (let i = 0; i < def.frames; i++) backend.step(1 / 60, 2);
  const elapsed = performance.now() - start;
  const matrixStart = Number(backend._b3w_matrices_ptr()) / 4;
  const matrixCount = Math.min(backend.bodyCount(), 128) * 16;
  let finite = true;
  for (const value of backend.HEAPF32.subarray(matrixStart, matrixStart + matrixCount)) {
    if (!Number.isFinite(value)) { finite = false; break; }
  }
  return {
    msPerFrame: elapsed / def.frames,
    hash: backend.replayHash(),
    bodies: backend.bodyCount(),
    dynamic: backend.dynamicCount(),
    finite,
  };
}

const result = definition.type === 'soft' ? runSoft(definition) : runRigid(definition);
process.stdout.write(JSON.stringify(result));
