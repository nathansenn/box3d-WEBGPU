'use strict';
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { performance } = require('node:perf_hooks');
const { spawnSync } = require('node:child_process');
const root = path.resolve(__dirname, '..');
const archive = path.join(root, 'benchmarks/baselines/box3d-webgpu-v1.7.0-source.tar.gz');
const samples = Math.max(3, Number.parseInt(process.env.V18_SAMPLES || '7', 10));
const bootstrapIterations = Math.max(1000, Number.parseInt(process.env.V18_BOOTSTRAPS || '10000', 10));
const workloads = [
  ['cloth-standard-frame', 'Standard cloth · render handoff', 'frame-breakthrough'],
  ['cloth-maximum-frame', 'Maximum cloth · render handoff', 'frame-breakthrough'],
  ['cloth-standard-full', 'Standard cloth · solver + handoff', 'dynamic-breakthrough'],
  ['cloth-maximum-full', 'Maximum cloth · solver + handoff', 'dynamic-breakthrough'],
  ['cloth-sphere-full', 'Collider drape · solver + handoff', 'dynamic-breakthrough'],
  ['cloth-storm-full', 'Maximum cloth · 120-projectile storm', 'dynamic-breakthrough'],
  ['cloth-banner-storm', 'Banner cloth · 120-projectile storm', 'dynamic-breakthrough'],
  ['cloth-tearing-control', 'Tearing cloth · topology control', 'control'],
  ['water-control', 'Maximum water · unchanged control', 'control'],
  ['mixed-maximum', 'Mixed maximum cloth + rope + water', 'mixed'],
];
function runCommand(command, args, options = {}) {
  const result = spawnSync(command, args, { stdio: 'inherit', ...options });
  if (result.status !== 0) throw new Error(`${command} ${args.join(' ')} failed`);
}
function prepareBaseline() {
  if (!fs.existsSync(archive)) throw new Error(`missing ${archive}`);
  const target = path.join(os.tmpdir(), `box3d-v17-v18-${process.pid}`);
  fs.rmSync(target, { recursive: true, force: true });
  fs.mkdirSync(target, { recursive: true });
  runCommand('tar', ['-xzf', archive, '-C', target, '--strip-components=1']);
  fs.rmSync(path.join(target, 'node_modules'), { recursive: true, force: true });
  fs.symlinkSync(path.join(root, 'node_modules'), path.join(target, 'node_modules'), process.platform === 'win32' ? 'junction' : 'dir');
  runCommand(path.join(root, 'node_modules/.bin/tsc'), ['-p', path.join(target, 'tsconfig.test.json')], { cwd: target });
  fs.mkdirSync(path.join(target, '.test-build'), { recursive: true });
  fs.writeFileSync(path.join(target, '.test-build/package.json'), '{"type":"commonjs"}');
  return target;
}
const baselineRoot = process.env.V18_BASELINE_ROOT ? path.resolve(process.env.V18_BASELINE_ROOT) : prepareBaseline();
const worker = path.join(root, 'benchmarks/v1.7-v1.8-worker.cjs');
function median(a) { const s = [...a].sort((x, y) => x - y), m = s.length >> 1; return s.length & 1 ? s[m] : (s[m - 1] + s[m]) * 0.5; }
function mad(a) { const m = median(a); return median(a.map((x) => Math.abs(x - m))); }
function gm(a) { return Math.exp(a.reduce((sum, x) => sum + Math.log(x), 0) / a.length); }
function run(variant, workloadId) {
  const sourceRoot = variant === 'v1.7' ? baselineRoot : root;
  const result = spawnSync(process.execPath, ['--expose-gc', worker, sourceRoot, variant, workloadId], { cwd: root, encoding: 'utf8', maxBuffer: 1024 * 1024 });
  if (result.status !== 0) throw new Error(`${variant} ${workloadId} failed:\n${result.stderr || result.stdout}`);
  return JSON.parse(result.stdout);
}
let randomState = 0x18c0ffee;
function random01() { randomState ^= randomState << 13; randomState ^= randomState >>> 17; randomState ^= randomState << 5; return (randomState >>> 0) / 0x100000000; }
function percentile(s, p) { const x = (s.length - 1) * p, l = Math.floor(x), u = Math.ceil(x), t = x - l; return s[l] + (s[u] - s[l]) * t; }
function bootstrap(b, o) {
  const ratios = [];
  for (let it = 0; it < bootstrapIterations; it++) {
    const bb = [], oo = [];
    for (let i = 0; i < b.length; i++) { const j = Math.floor(random01() * b.length); bb.push(b[j]); oo.push(o[j]); }
    ratios.push(median(bb) / median(oo));
  }
  ratios.sort((a, b) => a - b);
  return [percentile(ratios, 0.025), percentile(ratios, 0.975)];
}
const started = performance.now();
const results = [];
for (let wi = 0; wi < workloads.length; wi++) {
  const [id, label, category] = workloads[wi];
  const b = [], o = [], bh = [], oh = [], metadata = [];
  for (let sample = 0; sample < samples; sample++) {
    const order = ((sample + wi) & 1) === 0 ? ['v1.7', 'v1.8'] : ['v1.8', 'v1.7'];
    for (const variant of order) {
      const measurement = run(variant, id);
      (variant === 'v1.7' ? b : o).push(measurement.msPerOperation);
      (variant === 'v1.7' ? bh : oh).push(measurement.hash);
      metadata.push(measurement);
    }
  }
  const baselineMedian = median(b);
  const optimizedMedian = median(o);
  const speedup = baselineMedian / optimizedMedian;
  const ci = bootstrap(b, o);
  const baselineMetadata = metadata.filter((entry) => entry.variant === 'v1.7').at(-1);
  const optimizedMetadata = metadata.filter((entry) => entry.variant === 'v1.8').at(-1);
  const record = {
    id, label, category,
    baselineSamplesMs: b, optimizedSamplesMs: o,
    baselineMedianMs: baselineMedian, optimizedMedianMs: optimizedMedian,
    baselineMadMs: mad(b), optimizedMadMs: mad(o), speedup,
    pairedBootstrap95: ci,
    baselineDeterministic: new Set(bh).size === 1,
    optimizedDeterministic: new Set(oh).size === 1,
    crossVersionHashMatch: bh[0] === oh[0],
    baselineHashes: bh, optimizedHashes: oh,
    payload: {
      baselineSurfaceBytes: baselineMetadata?.surfaceBytes || 0,
      optimizedClothGridBytes: optimizedMetadata?.clothGridBytes || 0,
      byteReduction: baselineMetadata?.surfaceBytes && optimizedMetadata?.clothGridBytes
        ? 1 - optimizedMetadata.clothGridBytes / baselineMetadata.surfaceBytes : 0,
    },
    metadata: [baselineMetadata, optimizedMetadata],
  };
  results.push(record);
  console.log(`${String(wi + 1).padStart(2, '0')}/${workloads.length} ${label}: ${speedup.toFixed(2)}× [${ci[0].toFixed(2)}, ${ci[1].toFixed(2)}]`);
}
const changed = results.filter((entry) => entry.category !== 'control');
const dynamic = results.filter((entry) => entry.category === 'dynamic-breakthrough' || entry.category === 'mixed');
const output = {
  schema: 1,
  generatedAt: new Date().toISOString(),
  environment: { node: process.version, platform: process.platform, arch: process.arch, cpu: os.cpus()[0]?.model ?? 'unknown' },
  method: { samples, bootstrapIterations, freshProcessPerMeasurement: true, alternatingOrder: true, processStartupExcluded: true },
  summary: {
    changedGeometricMeanSpeedup: gm(changed.map((entry) => entry.speedup)),
    dynamicGeometricMeanSpeedup: gm(dynamic.map((entry) => entry.speedup)),
    medianSpeedup: median(results.map((entry) => entry.speedup)),
    elapsedMs: performance.now() - started,
  },
  results,
};
const resultsDir = path.join(root, 'benchmarks/results');
fs.mkdirSync(resultsDir, { recursive: true });
fs.writeFileSync(path.join(resultsDir, 'v1.7-v1.8-isolated.json'), JSON.stringify(output, null, 2));
const md = [
  '# v1.7 → v1.8 Isolated Fresh-Process Benchmark', '',
  `- Changed-path geometric mean: **${output.summary.changedGeometricMeanSpeedup.toFixed(2)}×**`,
  `- Dynamic/mixed geometric mean: **${output.summary.dynamicGeometricMeanSpeedup.toFixed(2)}×**`, '',
  '| Workload | v1.7 ms | v1.8 ms | Speedup | Paired 95% interval |', '|---|---:|---:|---:|---:|',
  ...results.map((entry) => `| ${entry.label} | ${entry.baselineMedianMs.toFixed(6)} | ${entry.optimizedMedianMs.toFixed(6)} | **${entry.speedup.toFixed(2)}×** | ${entry.pairedBootstrap95[0].toFixed(2)}–${entry.pairedBootstrap95[1].toFixed(2)}× |`), '',
];
fs.writeFileSync(path.join(resultsDir, 'V1.7_V1.8_ISOLATED.md'), md.join('\n'));
console.log(JSON.stringify(output.summary, null, 2));
