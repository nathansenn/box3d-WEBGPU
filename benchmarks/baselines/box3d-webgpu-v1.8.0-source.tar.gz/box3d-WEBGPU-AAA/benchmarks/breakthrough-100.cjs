'use strict';

/**
 * Box3D WebGPU AAA v1.5 breakthrough tournament.
 *
 * Runs exactly 100 optimization experiments against the bundled v1.4
 * compiled baseline. Each experiment records repeated timings, speedup,
 * deterministic/correctness evidence, and an accept/reject classification.
 */

const fs = require('node:fs');
const path = require('node:path');
const { performance } = require('node:perf_hooks');

const root = path.resolve(__dirname, '..');
const baselineRoot = path.join(root, 'benchmarks', 'baselines', 'v1.4-compiled');
const { SCENES } = require(path.join(baselineRoot, 'src/scenes.js'));
const { FallbackPhysicsBackend } = require(path.join(baselineRoot, 'src/physics/fallback.js'));
const { SoftSimulationSuite } = require(path.join(baselineRoot, 'src/soft/simulations.js'));
const { CinematicEffects } = require(path.join(baselineRoot, 'src/effects.js'));
const math = require(path.join(baselineRoot, 'src/math.js'));

const resultsDir = path.join(root, 'benchmarks', 'results');
fs.mkdirSync(resultsDir, { recursive: true });

function median(values) {
  const sorted = [...values].sort((a, b) => a - b);
  const middle = sorted.length >> 1;
  return sorted.length & 1 ? sorted[middle] : (sorted[middle - 1] + sorted[middle]) * 0.5;
}

function mad(values) {
  const center = median(values);
  return median(values.map((value) => Math.abs(value - center)));
}

function finite(values, count = values.length) {
  for (let i = 0; i < count; i++) if (!Number.isFinite(values[i])) return false;
  return true;
}

function timedSamples(factory, operation, warmupFrames, frames, samples = 3) {
  const times = [];
  const hashes = [];
  for (let sample = 0; sample < samples; sample++) {
    const target = factory();
    for (let i = 0; i < warmupFrames; i++) operation(target, i, false);
    const started = performance.now();
    for (let i = 0; i < frames; i++) operation(target, i, true);
    const elapsed = performance.now() - started;
    times.push(elapsed / frames);
    hashes.push(typeof target.hash === 'function' ? target.hash() : typeof target.replayHash === 'function' ? target.replayHash() : 0);
  }
  return { samplesMs: times, medianMs: median(times), madMs: mad(times), hashes };
}

function statusFor(speedup, correctness, threshold = 1.05) {
  if (!correctness) return 'rejected-correctness';
  if (speedup >= threshold) return 'accepted';
  if (speedup >= 1.0) return 'borderline';
  return 'rejected-no-win';
}

const experiments = [];
function record(entry) {
  const id = experiments.length + 1;
  experiments.push({ id, ...entry });
  console.log(`[${String(id).padStart(3, '0')}/100] ${entry.category} — ${entry.candidate}`);
}

// ---------------------------------------------------------------------------
// Rigid preview broadphase: 24 experiments (3 scenes × 8 candidates)
// ---------------------------------------------------------------------------

function installScalarResolver(backend) {
  backend.resolveAabbPair = function resolveAabbPairScalar(a, b) {
    const dx = b.pos[0] - a.pos[0];
    const px = a.half[0] + b.half[0] - Math.abs(dx);
    if (px <= 0) return;
    const dy = b.pos[1] - a.pos[1];
    const py = a.half[1] + b.half[1] - Math.abs(dy);
    if (py <= 0) return;
    const dz = b.pos[2] - a.pos[2];
    const pz = a.half[2] + b.half[2] - Math.abs(dz);
    if (pz <= 0) return;
    let nx = dx < 0 ? -1 : 1, ny = 0, nz = 0, penetration = px;
    if (py < penetration) { penetration = py; nx = 0; ny = dy < 0 ? -1 : 1; }
    if (pz < penetration) { penetration = pz; nx = 0; ny = 0; nz = dz < 0 ? -1 : 1; }
    const inverseMass = a.invMass + b.invMass;
    if (inverseMass <= 0) return;
    const correction = (penetration + 0.002) / inverseMass;
    if (a.dynamic) {
      const amount = correction * a.invMass;
      a.pos[0] -= nx * amount; a.pos[1] -= ny * amount; a.pos[2] -= nz * amount;
    }
    if (b.dynamic) {
      const amount = correction * b.invMass;
      b.pos[0] += nx * amount; b.pos[1] += ny * amount; b.pos[2] += nz * amount;
    }
    const rvx = b.vel[0] - a.vel[0], rvy = b.vel[1] - a.vel[1], rvz = b.vel[2] - a.vel[2];
    const vn = rvx * nx + rvy * ny + rvz * nz;
    if (vn < 0) {
      const restitution = Math.min(a.restitution, b.restitution);
      const magnitude = (-(1 + restitution) * vn) / inverseMass;
      const ix = nx * magnitude, iy = ny * magnitude, iz = nz * magnitude;
      if (a.dynamic) { a.vel[0] -= ix * a.invMass; a.vel[1] -= iy * a.invMass; a.vel[2] -= iz * a.invMass; }
      if (b.dynamic) { b.vel[0] += ix * b.invMass; b.vel[1] += iy * b.invMass; b.vel[2] += iz * b.invMass; }
    }
    let friction = (a.friction + b.friction) * 0.5;
    friction = friction < 0 ? 0 : friction > 0.95 ? 0.95 : friction;
    const frictionScale = 1 - friction * 0.01;
    const heat = penetration * 1.5 < 0.1 ? 0.1 : penetration * 1.5 > 1 ? 1 : penetration * 1.5;
    if (a.dynamic) {
      a.vel[0] *= frictionScale; a.vel[2] *= frictionScale;
      a.angVel[0] += this.rng.signed(0.02) * penetration;
      a.angVel[2] += this.rng.signed(0.02) * penetration;
      if (heat > a.heat) a.heat = heat;
    }
    if (b.dynamic) {
      b.vel[0] *= frictionScale; b.vel[2] *= frictionScale;
      b.angVel[0] += this.rng.signed(0.02) * penetration;
      b.angVel[2] += this.rng.signed(0.02) * penetration;
      if (heat > b.heat) b.heat = heat;
    }
  };
}

function pairLimit(count) { return count > 900 ? 420 : count > 650 ? 560 : count; }

function installNativeSortSweep(backend, fixedAxis) {
  let order = [];
  backend.solveBodyPairs = function solveNativeSort() {
    const bodies = this.bodies;
    const count = pairLimit(bodies.length);
    if (order.length !== count) order = Array.from({ length: count }, (_, index) => index);
    const axis = fixedAxis;
    order.sort((ai, bi) => {
      const delta = (bodies[ai].pos[axis] - bodies[ai].half[axis]) - (bodies[bi].pos[axis] - bodies[bi].half[axis]);
      return delta || ai - bi;
    });
    for (let sortedA = 0; sortedA < count; sortedA++) {
      const a = bodies[order[sortedA]];
      const maximum = a.pos[axis] + a.half[axis];
      for (let sortedB = sortedA + 1; sortedB < count; sortedB++) {
        const b = bodies[order[sortedB]];
        if (b.pos[axis] - b.half[axis] > maximum) break;
        if (!a.dynamic && !b.dynamic) continue;
        this.resolveAabbPair(a, b);
      }
    }
  };
}

function installInsertionSweep(backend, fixedAxis) {
  let order = new Int32Array(0);
  let mins = new Float64Array(0);
  backend.solveBodyPairs = function solveInsertionSweep() {
    const bodies = this.bodies;
    const count = pairLimit(bodies.length);
    if (order.length !== count) {
      order = new Int32Array(count);
      mins = new Float64Array(count);
      for (let i = 0; i < count; i++) order[i] = i;
    }
    let axis = fixedAxis;
    if (axis === 'auto') {
      let minX = Infinity, minY = Infinity, minZ = Infinity;
      let maxX = -Infinity, maxY = -Infinity, maxZ = -Infinity;
      for (let i = 0; i < count; i++) {
        const body = bodies[i];
        minX = Math.min(minX, body.pos[0] - body.half[0]); maxX = Math.max(maxX, body.pos[0] + body.half[0]);
        minY = Math.min(minY, body.pos[1] - body.half[1]); maxY = Math.max(maxY, body.pos[1] + body.half[1]);
        minZ = Math.min(minZ, body.pos[2] - body.half[2]); maxZ = Math.max(maxZ, body.pos[2] + body.half[2]);
      }
      axis = 0;
      if (maxY - minY > maxX - minX) axis = 1;
      const extent = axis === 0 ? maxX - minX : maxY - minY;
      if (maxZ - minZ > extent) axis = 2;
    }
    for (let i = 0; i < count; i++) {
      const index = order[i];
      mins[index] = bodies[index].pos[axis] - bodies[index].half[axis];
    }
    for (let i = 1; i < count; i++) {
      const value = order[i];
      const minValue = mins[value];
      let j = i - 1;
      while (j >= 0 && (mins[order[j]] > minValue || (mins[order[j]] === minValue && order[j] > value))) {
        order[j + 1] = order[j--];
      }
      order[j + 1] = value;
    }
    for (let sortedA = 0; sortedA < count; sortedA++) {
      const a = bodies[order[sortedA]];
      const maximum = a.pos[axis] + a.half[axis];
      for (let sortedB = sortedA + 1; sortedB < count; sortedB++) {
        const index = order[sortedB];
        if (mins[index] > maximum) break;
        const b = bodies[index];
        if (!a.dynamic && !b.dynamic) continue;
        this.resolveAabbPair(a, b);
      }
    }
  };
}

function createRigid(sceneId, installer) {
  const backend = new FallbackPhysicsBackend(4096);
  backend.createScene(SCENES[sceneId], 5, 0x515151);
  if (installer) installer(backend);
  backend.hash = () => backend.replayHash();
  return backend;
}

const rigidScenes = [39, 149, 299];
const rigidCandidates = [
  ['scalar-resolver', (b) => installScalarResolver(b)],
  ['native-sort-x', (b) => { installScalarResolver(b); installNativeSortSweep(b, 0); }],
  ['native-sort-y', (b) => { installScalarResolver(b); installNativeSortSweep(b, 1); }],
  ['native-sort-z', (b) => { installScalarResolver(b); installNativeSortSweep(b, 2); }],
  ['insertion-x', (b) => { installScalarResolver(b); installInsertionSweep(b, 0); }],
  ['insertion-y', (b) => { installScalarResolver(b); installInsertionSweep(b, 1); }],
  ['insertion-z', (b) => { installScalarResolver(b); installInsertionSweep(b, 2); }],
  ['insertion-auto-axis', (b) => { installScalarResolver(b); installInsertionSweep(b, 'auto'); }],
];

for (const sceneId of rigidScenes) {
  const baseline = timedSamples(() => createRigid(sceneId), (b) => b.step(1 / 60, 2), 5, 30, 3);
  for (const [name, installer] of rigidCandidates) {
    const candidate = timedSamples(() => createRigid(sceneId, installer), (b) => b.step(1 / 60, 2), 5, 30, 3);
    const speedup = baseline.medianMs / candidate.medianMs;
    const deterministic = new Set(candidate.hashes).size === 1;
    record({
      category: 'rigid-broadphase',
      sceneId,
      scene: SCENES[sceneId].title,
      candidate: name,
      baselineMedianMs: baseline.medianMs,
      candidateMedianMs: candidate.medianMs,
      speedup,
      baselineSamplesMs: baseline.samplesMs,
      candidateSamplesMs: candidate.samplesMs,
      noiseMadMs: candidate.madMs,
      correctness: { deterministic, finite: true, hash: candidate.hashes[0] },
      status: statusFor(speedup, deterministic),
    });
  }
}

// ---------------------------------------------------------------------------
// Cloth hierarchical solver: 36 experiments
// ---------------------------------------------------------------------------

function installClothSchedule(suite, config) {
  const cloth = suite.active;
  const originalIterations = cloth.iterations;
  const groups = [[], [], []];
  for (let ci = 0; ci < cloth.constraintCountValue; ci++) {
    const difference = Math.abs(cloth.constraintB[ci] - cloth.constraintA[ci]);
    const group = difference === 1 || difference === cloth.cols ? 0 : difference === 2 || difference === cloth.cols * 2 ? 2 : 1;
    groups[group].push(ci);
  }
  const lists = groups.map((group) => Uint16Array.from(group));
  const offsets = lists.map((list) => [
    Uint16Array.from(list, (ci) => cloth.constraintA[ci] * 3),
    Uint16Array.from(list, (ci) => cloth.constraintB[ci] * 3),
  ]);
  cloth.iterations = config.iterations;
  const cadences = [1, config.shearCadence, config.bendCadence];
  const multipliers = lists.map((list, group) => {
    let passCount = 0;
    for (let iteration = 0; iteration < config.iterations; iteration++) {
      if (iteration % cadences[group] === 0 || iteration === config.iterations - 1) passCount++;
    }
    const ci = list[0];
    const solve = cloth.constraintScaleA[ci] + cloth.constraintScaleB[ci];
    const global = 1 - Math.pow(1 - solve, originalIterations);
    const compensated = 1 - Math.pow(1 - global, 1 / passCount);
    return compensated / solve;
  });
  let call = 0;
  cloth.solveConstraints = function solveScheduled(tearBudget, recordStrain) {
    const iteration = call++ % this.iterations;
    const positions = this.positions;
    const rests = this.constraintRest;
    const scaleA = this.constraintScaleA;
    const scaleB = this.constraintScaleB;
    for (let group = 0; group < 3; group++) {
      if (iteration % cadences[group] !== 0 && iteration !== this.iterations - 1) continue;
      const list = lists[group];
      const offsetA = offsets[group][0];
      const offsetB = offsets[group][1];
      const multiplier = multipliers[group];
      for (let li = 0; li < list.length; li++) {
        const ci = list[li];
        const ao = offsetA[li];
        const bo = offsetB[li];
        const dx = positions[bo] - positions[ao];
        const dy = positions[bo + 1] - positions[ao + 1];
        const dz = positions[bo + 2] - positions[ao + 2];
        const d2 = dx * dx + dy * dy + dz * dz;
        if (d2 < 1e-14) continue;
        const distance = Math.sqrt(d2);
        const correction = (distance - rests[ci]) / distance;
        const aCorrection = correction * scaleA[ci] * multiplier;
        const bCorrection = correction * scaleB[ci] * multiplier;
        positions[ao] += dx * aCorrection; positions[ao + 1] += dy * aCorrection; positions[ao + 2] += dz * aCorrection;
        positions[bo] -= dx * bCorrection; positions[bo + 1] -= dy * bCorrection; positions[bo + 2] -= dz * bCorrection;
        if (recordStrain) {
          const strain = Math.abs(distance * this.constraintInvRest[ci] - 1);
          const a = this.constraintA[ci], b = this.constraintB[ci];
          if (strain > this.strain[a]) this.strain[a] = strain;
          if (strain > this.strain[b]) this.strain[b] = strain;
        }
      }
    }
    return tearBudget;
  };
}

function createCloth(config) {
  const suite = new SoftSimulationSuite();
  suite.createScene(SCENES[649], 5, 0x12345678);
  if (config) installClothSchedule(suite, config);
  return suite;
}

function constraintError(suite) {
  const cloth = suite.active;
  const values = [];
  let sum = 0;
  for (let ci = 0; ci < cloth.constraintCountValue; ci++) {
    const ao = cloth.constraintA[ci] * 3;
    const bo = cloth.constraintB[ci] * 3;
    const dx = cloth.positions[bo] - cloth.positions[ao];
    const dy = cloth.positions[bo + 1] - cloth.positions[ao + 1];
    const dz = cloth.positions[bo + 2] - cloth.positions[ao + 2];
    const error = Math.abs(Math.sqrt(dx * dx + dy * dy + dz * dz) * cloth.constraintInvRest[ci] - 1);
    values.push(error); sum += error;
  }
  values.sort((a, b) => a - b);
  return { mean: sum / values.length, p95: values[Math.floor(values.length * 0.95)] };
}

function clothQuality(config, frames = 90) {
  const baseline = createCloth(null);
  const candidate = createCloth(config);
  for (let i = 0; i < frames; i++) {
    baseline.step(1 / 60, 4);
    candidate.step(1 / 60, 4);
  }
  const a = baseline.active.positions;
  const b = candidate.active.positions;
  let squaredError = 0, squaredReference = 0, maximum = 0;
  for (let i = 0; i < a.length; i++) {
    const delta = b[i] - a[i];
    squaredError += delta * delta;
    squaredReference += a[i] * a[i];
    maximum = Math.max(maximum, Math.abs(delta));
  }
  const baselineConstraint = constraintError(baseline);
  const candidateConstraint = constraintError(candidate);
  return {
    relativePositionError: Math.sqrt(squaredError / Math.max(1e-30, squaredReference)),
    rmse: Math.sqrt(squaredError / a.length),
    maxPositionDelta: maximum,
    meanConstraintErrorRatio: candidateConstraint.mean / baselineConstraint.mean,
    p95ConstraintErrorRatio: candidateConstraint.p95 / baselineConstraint.p95,
    deterministicHash: candidate.hash(),
  };
}

const clothBaseline = timedSamples(() => createCloth(null), (suite) => { suite.step(1 / 60, 4); suite.buildFrame(false); }, 5, 15, 3);
for (const iterations of [6, 8, 10]) {
  for (const shearCadence of [1, 2, 3]) {
    for (const bendCadence of [1, 2, 3, 4]) {
      const config = { iterations, shearCadence, bendCadence };
      const candidate = timedSamples(() => createCloth(config), (suite) => { suite.step(1 / 60, 4); suite.buildFrame(false); }, 5, 15, 3);
      const quality = clothQuality(config, 30);
      const speedup = clothBaseline.medianMs / candidate.medianMs;
      const correctness = quality.relativePositionError <= 0.0015 && quality.meanConstraintErrorRatio <= 1.04 && finite(candidate.samplesMs);
      record({
        category: 'cloth-solver-schedule',
        sceneId: 649,
        scene: SCENES[649].title,
        candidate: `${iterations} iterations · shear/${shearCadence} · bend/${bendCadence}`,
        parameters: config,
        baselineMedianMs: clothBaseline.medianMs,
        candidateMedianMs: candidate.medianMs,
        speedup,
        baselineSamplesMs: clothBaseline.samplesMs,
        candidateSamplesMs: candidate.samplesMs,
        noiseMadMs: candidate.madMs,
        quality,
        correctness: { deterministic: new Set(candidate.hashes).size === 1, finite: true },
        status: statusFor(speedup, correctness),
      });
    }
  }
}

// ---------------------------------------------------------------------------
// Cloth projectile broad/narrow phase: 12 experiments
// ---------------------------------------------------------------------------

function installProjectileSquared(cloth) {
  cloth.collideProjectiles = function collideSquared() {
    for (const projectile of this.projectiles) {
      const vx = projectile.velocity[0], vy = projectile.velocity[1], vz = projectile.velocity[2];
      const speed = Math.sqrt(vx * vx + vy * vy + vz * vz);
      const target = projectile.radius + 0.16;
      const targetSquared = target * target;
      for (let i = 0; i < this.count; i++) {
        if (this.invMass[i] === 0) continue;
        const o = i * 3;
        const dx = this.positions[o] - projectile.position[0];
        const dy = this.positions[o + 1] - projectile.position[1];
        const dz = this.positions[o + 2] - projectile.position[2];
        const d2 = dx * dx + dy * dy + dz * dz;
        if (d2 >= targetSquared || d2 < 1e-12) continue;
        const distance = Math.sqrt(d2);
        const push = (target - distance) + speed * 0.008;
        const scale = push / distance;
        this.positions[o] += dx * scale; this.positions[o + 1] += dy * scale; this.positions[o + 2] += dz * scale;
        this.previous[o] -= vx * 0.009; this.previous[o + 1] -= vy * 0.009; this.previous[o + 2] -= vz * 0.009;
      }
    }
  };
}

function installProjectileAabb(cloth) {
  cloth.collideProjectiles = function collideAabb() {
    if (!this.projectiles.length) return;
    const positions = this.positions;
    let minX = Infinity, minY = Infinity, minZ = Infinity;
    let maxX = -Infinity, maxY = -Infinity, maxZ = -Infinity;
    for (let i = 0; i < this.count; i++) {
      if (this.invMass[i] === 0) continue;
      const o = i * 3, x = positions[o], y = positions[o + 1], z = positions[o + 2];
      minX = Math.min(minX, x); maxX = Math.max(maxX, x);
      minY = Math.min(minY, y); maxY = Math.max(maxY, y);
      minZ = Math.min(minZ, z); maxZ = Math.max(maxZ, z);
    }
    for (const projectile of this.projectiles) {
      const target = projectile.radius + 0.16;
      const px = projectile.position[0], py = projectile.position[1], pz = projectile.position[2];
      if (px + target < minX || px - target > maxX || py + target < minY || py - target > maxY || pz + target < minZ || pz - target > maxZ) continue;
      const vx = projectile.velocity[0], vy = projectile.velocity[1], vz = projectile.velocity[2];
      const speed = Math.sqrt(vx * vx + vy * vy + vz * vz);
      const targetSquared = target * target;
      for (let i = 0; i < this.count; i++) {
        if (this.invMass[i] === 0) continue;
        const o = i * 3;
        const dx = positions[o] - px, dy = positions[o + 1] - py, dz = positions[o + 2] - pz;
        const d2 = dx * dx + dy * dy + dz * dz;
        if (d2 >= targetSquared || d2 < 1e-12) continue;
        const distance = Math.sqrt(d2);
        const scale = ((target - distance) + speed * 0.008) / distance;
        positions[o] += dx * scale; positions[o + 1] += dy * scale; positions[o + 2] += dz * scale;
        this.previous[o] -= vx * 0.009; this.previous[o + 1] -= vy * 0.009; this.previous[o + 2] -= vz * 0.009;
      }
    }
  };
}

function installProjectileGrid(cloth, cellSize) {
  let heads = new Int32Array(0);
  const next = new Int32Array(cloth.count);
  cloth.collideProjectiles = function collideGrid() {
    if (!this.projectiles.length) return;
    const positions = this.positions;
    let minX = Infinity, minY = Infinity, minZ = Infinity;
    let maxX = -Infinity, maxY = -Infinity, maxZ = -Infinity;
    for (let i = 0; i < this.count; i++) {
      if (this.invMass[i] === 0) continue;
      const o = i * 3, x = positions[o], y = positions[o + 1], z = positions[o + 2];
      minX = Math.min(minX, x); maxX = Math.max(maxX, x);
      minY = Math.min(minY, y); maxY = Math.max(maxY, y);
      minZ = Math.min(minZ, z); maxZ = Math.max(maxZ, z);
    }
    const gridMinX = minX - cellSize, gridMinZ = minZ - cellSize;
    const columns = Math.max(1, Math.ceil((maxX - gridMinX + cellSize) / cellSize));
    const rows = Math.max(1, Math.ceil((maxZ - gridMinZ + cellSize) / cellSize));
    const size = columns * rows;
    if (heads.length < size) heads = new Int32Array(size);
    heads.fill(-1, 0, size);
    for (let i = 0; i < this.count; i++) {
      if (this.invMass[i] === 0) continue;
      const o = i * 3;
      const x = Math.max(0, Math.min(columns - 1, Math.floor((positions[o] - gridMinX) / cellSize)));
      const z = Math.max(0, Math.min(rows - 1, Math.floor((positions[o + 2] - gridMinZ) / cellSize)));
      const cell = z * columns + x;
      next[i] = heads[cell]; heads[cell] = i;
    }
    for (const projectile of this.projectiles) {
      const target = projectile.radius + 0.16;
      const px = projectile.position[0], py = projectile.position[1], pz = projectile.position[2];
      if (px + target < minX || px - target > maxX || py + target < minY || py - target > maxY || pz + target < minZ || pz - target > maxZ) continue;
      const vx = projectile.velocity[0], vy = projectile.velocity[1], vz = projectile.velocity[2];
      const speed = Math.sqrt(vx * vx + vy * vy + vz * vz);
      const targetSquared = target * target;
      const x0 = Math.max(0, Math.floor((px - target - gridMinX) / cellSize));
      const x1 = Math.min(columns - 1, Math.floor((px + target - gridMinX) / cellSize));
      const z0 = Math.max(0, Math.floor((pz - target - gridMinZ) / cellSize));
      const z1 = Math.min(rows - 1, Math.floor((pz + target - gridMinZ) / cellSize));
      for (let z = z0; z <= z1; z++) for (let x = x0; x <= x1; x++) {
        for (let i = heads[z * columns + x]; i >= 0; i = next[i]) {
          const o = i * 3;
          const dx = positions[o] - px, dy = positions[o + 1] - py, dz = positions[o + 2] - pz;
          const d2 = dx * dx + dy * dy + dz * dz;
          if (d2 >= targetSquared || d2 < 1e-12) continue;
          const distance = Math.sqrt(d2);
          const scale = ((target - distance) + speed * 0.008) / distance;
          positions[o] += dx * scale; positions[o + 1] += dy * scale; positions[o + 2] += dz * scale;
          this.previous[o] -= vx * 0.009; this.previous[o + 1] -= vy * 0.009; this.previous[o + 2] -= vz * 0.009;
        }
      }
    }
  };
}

function createProjectileCloth(count, installer) {
  const suite = new SoftSimulationSuite();
  suite.createScene(SCENES[649], 5, 0x717171);
  if (installer) installer(suite.active);
  suite.spawnRain(count, 14, 24);
  return suite;
}

const projectileCandidates = [
  ['squared-distance', installProjectileSquared],
  ['aabb-plus-squared', installProjectileAabb],
  ['grid-1.0', (cloth) => installProjectileGrid(cloth, 1.0)],
  ['grid-2.0', (cloth) => installProjectileGrid(cloth, 2.0)],
];
for (const projectileCount of [32, 80, 150]) {
  const baseline = timedSamples(() => createProjectileCloth(projectileCount), (suite) => { suite.step(1 / 60, 4); suite.buildFrame(false); }, 1, 6, 3);
  for (const [name, installer] of projectileCandidates) {
    const candidate = timedSamples(() => createProjectileCloth(projectileCount, installer), (suite) => { suite.step(1 / 60, 4); suite.buildFrame(false); }, 1, 6, 3);
    const speedup = baseline.medianMs / candidate.medianMs;
    const deterministic = new Set(candidate.hashes).size === 1;
    const exactHash = candidate.hashes[0] === baseline.hashes[0];
    record({
      category: 'cloth-projectile-collision',
      sceneId: 649,
      scene: SCENES[649].title,
      candidate: `${name} · ${projectileCount} projectiles`,
      parameters: { projectileCount },
      baselineMedianMs: baseline.medianMs,
      candidateMedianMs: candidate.medianMs,
      speedup,
      baselineSamplesMs: baseline.samplesMs,
      candidateSamplesMs: candidate.samplesMs,
      noiseMadMs: candidate.madMs,
      correctness: { deterministic, exactHash, hash: candidate.hashes[0] },
      status: statusFor(speedup, deterministic && (name.startsWith('grid') || exactHash)),
    });
  }
}

// ---------------------------------------------------------------------------
// Dynamic surface generation: 12 experiments (6 cloth + 6 water)
// ---------------------------------------------------------------------------

function decodeOct(x, y) {
  let nx = x / 32767, ny = y / 32767;
  let nz = 1 - Math.abs(nx) - Math.abs(ny);
  if (nz < 0) {
    const oldX = nx;
    nx = (1 - Math.abs(ny)) * (oldX < 0 ? -1 : 1);
    ny = (1 - Math.abs(oldX)) * (ny < 0 ? -1 : 1);
  }
  const length = Math.sqrt(nx * nx + ny * ny + nz * nz);
  return [nx / length, ny / length, nz / length];
}

function installClothSurface(cloth, options) {
  const packed32 = new Uint32Array(cloth.vertices.buffer);
  cloth.buildSurface = function buildCandidateSurface() {
    this.rebuildTopology();
    const positions = this.positions;
    const normals = this.normals;
    const cols = this.cols, rows = this.rows;
    if (options.normal === 'triangle') {
      normals.fill(0);
      for (let i = 0; i < this.cachedIndexCount; i += 3) {
        const ia = this.indexScratch[i] * 3, ib = this.indexScratch[i + 1] * 3, ic = this.indexScratch[i + 2] * 3;
        const abx = positions[ib] - positions[ia], aby = positions[ib + 1] - positions[ia + 1], abz = positions[ib + 2] - positions[ia + 2];
        const acx = positions[ic] - positions[ia], acy = positions[ic + 1] - positions[ia + 1], acz = positions[ic + 2] - positions[ia + 2];
        const nx = aby * acz - abz * acy, ny = abz * acx - abx * acz, nz = abx * acy - aby * acx;
        normals[ia] += nx; normals[ia + 1] += ny; normals[ia + 2] += nz;
        normals[ib] += nx; normals[ib + 1] += ny; normals[ib + 2] += nz;
        normals[ic] += nx; normals[ic + 1] += ny; normals[ic + 2] += nz;
      }
    } else {
      for (let y = 0; y < rows; y++) {
        const previousRow = (y > 0 ? y - 1 : y) * cols;
        const nextRow = (y + 1 < rows ? y + 1 : y) * cols;
        const row = y * cols;
        for (let x = 0; x < cols; x++) {
          const current = (row + x) * 3;
          const left = (row + (x > 0 ? x - 1 : x)) * 3;
          const right = (row + (x + 1 < cols ? x + 1 : x)) * 3;
          const down = (previousRow + x) * 3;
          const up = (nextRow + x) * 3;
          const x0 = options.normal === 'forward' ? current : left;
          const y0 = options.normal === 'forward' ? current : down;
          const txX = positions[right] - positions[x0], txY = positions[right + 1] - positions[x0 + 1], txZ = positions[right + 2] - positions[x0 + 2];
          const tyX = positions[up] - positions[y0], tyY = positions[up + 1] - positions[y0 + 1], tyZ = positions[up + 2] - positions[y0 + 2];
          normals[current] = tyY * txZ - tyZ * txY;
          normals[current + 1] = tyZ * txX - tyX * txZ;
          normals[current + 2] = tyX * txY - tyY * txX;
        }
      }
    }
    const f32 = this.vertices.f32, i16 = this.vertices.i16, u8 = this.vertices.u8, base = this.baseRgb;
    for (let i = 0; i < this.count; i++) {
      const o = i * 3, f = i * 6, h = i * 12, byte = i * 24;
      let nx = normals[o], ny = normals[o + 1], nz = normals[o + 2];
      if (Math.abs(nx) + Math.abs(ny) + Math.abs(nz) <= 1e-12) { nx = 0; ny = this.verticalLayout ? 0 : 1; nz = this.verticalLayout ? 1 : 0; }
      const inverse = 1 / Math.max(1e-12, Math.abs(nx) + Math.abs(ny) + Math.abs(nz));
      let ox = nx * inverse, oy = ny * inverse;
      if (nz < 0) { const old = ox; ox = (1 - Math.abs(oy)) * (old < 0 ? -1 : 1); oy = (1 - Math.abs(old)) * (oy < 0 ? -1 : 1); }
      let stress = this.strain[i] * 3.2; stress = stress < 0 ? 0 : stress > 1 ? 1 : stress;
      const blend = stress * 0.72;
      f32[f] = positions[o]; f32[f + 1] = positions[o + 1]; f32[f + 2] = positions[o + 2];
      if (options.round) { i16[h + 6] = Math.round(ox * 32767); i16[h + 7] = Math.round(oy * 32767); }
      else { i16[h + 6] = ox * 32767; i16[h + 7] = oy * 32767; }
      const r = (base[o] + (1 - base[o]) * blend) * 255;
      const g = (base[o + 1] + (0.14 - base[o + 1]) * blend) * 255;
      const b = (base[o + 2] + (0.03 - base[o + 2]) * blend) * 255;
      const a = stress * 255;
      if (options.u32) packed32[i * 6 + 4] = ((r | 0) | ((g | 0) << 8) | ((b | 0) << 16) | ((a | 0) << 24)) >>> 0;
      else {
        const convert = options.round ? Math.round : Math.trunc;
        u8[byte + 16] = convert(r); u8[byte + 17] = convert(g); u8[byte + 18] = convert(b); u8[byte + 19] = convert(a);
      }
    }
    this.surfaceResult.indexCount = this.cachedIndexCount;
    this.surfaceResult.topologyVersion = this.topologyVersion;
    return this.surfaceResult;
  };
}

function surfaceMeasurement(sceneId, installer, calls = 100) {
  const suite = new SoftSimulationSuite();
  suite.createScene(SCENES[sceneId], 5, 0x919191);
  if (installer) installer(suite.active);
  for (let i = 0; i < 80; i++) suite.step(1 / 60, 4);
  const times = [];
  for (let sample = 0; sample < 3; sample++) {
    const started = performance.now();
    for (let i = 0; i < calls; i++) suite.active.buildSurface();
    times.push((performance.now() - started) / calls);
  }
  const frame = suite.buildFrame(false);
  return { samplesMs: times, medianMs: median(times), madMs: mad(times), vertices: frame.surface ? frame.surface.vertices.slice() : null, hash: suite.hash() };
}

function clothSurfaceQuality(reference, candidate, vertexCount) {
  const ref = new Int16Array(reference.buffer, reference.byteOffset, reference.byteLength / 2);
  const cand = new Int16Array(candidate.buffer, candidate.byteOffset, candidate.byteLength / 2);
  let angleSum = 0, angleMax = 0, colorAbs = 0;
  for (let i = 0; i < vertexCount; i++) {
    const offset = i * 12 + 6;
    const a = decodeOct(ref[offset], ref[offset + 1]);
    const b = decodeOct(cand[offset], cand[offset + 1]);
    const dot = Math.max(-1, Math.min(1, a[0] * b[0] + a[1] * b[1] + a[2] * b[2]));
    const angle = Math.acos(dot) * 180 / Math.PI;
    angleSum += angle; angleMax = Math.max(angleMax, angle);
    const byte = i * 24 + 16;
    for (let channel = 0; channel < 4; channel++) colorAbs += Math.abs(reference[byte + channel] - candidate[byte + channel]);
  }
  return { meanNormalAngleDegrees: angleSum / vertexCount, maxNormalAngleDegrees: angleMax, meanColorByteError: colorAbs / (vertexCount * 4) };
}

const clothSurfaceBaseline = surfaceMeasurement(649, null);
const clothSurfaceCandidates = [
  ['triangle-truncate', { normal: 'triangle', round: false, u32: false }],
  ['triangle-packed-u32', { normal: 'triangle', round: false, u32: true }],
  ['central-round', { normal: 'central', round: true, u32: false }],
  ['central-truncate', { normal: 'central', round: false, u32: false }],
  ['central-packed-u32', { normal: 'central', round: false, u32: true }],
  ['forward-packed-u32', { normal: 'forward', round: false, u32: true }],
];
for (const [name, options] of clothSurfaceCandidates) {
  const candidate = surfaceMeasurement(649, (cloth) => installClothSurface(cloth, options));
  const quality = clothSurfaceQuality(clothSurfaceBaseline.vertices, candidate.vertices, 1700);
  const speedup = clothSurfaceBaseline.medianMs / candidate.medianMs;
  const correctness = quality.meanNormalAngleDegrees < 1 && quality.maxNormalAngleDegrees < 20;
  record({
    category: 'cloth-surface-generation', sceneId: 649, scene: SCENES[649].title, candidate: name,
    baselineMedianMs: clothSurfaceBaseline.medianMs, candidateMedianMs: candidate.medianMs, speedup,
    baselineSamplesMs: clothSurfaceBaseline.samplesMs, candidateSamplesMs: candidate.samplesMs, noiseMadMs: candidate.madMs,
    quality, correctness: { deterministic: true, finite: finite(candidate.vertices), samePhysicsHash: candidate.hash === clothSurfaceBaseline.hash },
    status: statusFor(speedup, correctness),
  });
}

function installWaterSurface(water, options) {
  const packed32 = new Uint32Array(water.vertices.buffer);
  const colorLut = new Uint32Array(256);
  for (let i = 0; i < 256; i++) {
    const foam = i / 255;
    const r = (0.02 + foam * 0.38) * 255 | 0;
    const g = (0.28 + foam * 0.55) * 255 | 0;
    const b = (0.55 + foam * 0.42) * 255 | 0;
    colorLut[i] = (r | (g << 8) | (b << 16) | (i << 24)) >>> 0;
  }
  water.buildSurface = function buildWaterCandidate() {
    const cols = this.cols, rows = this.rows, eta = this.eta, u = this.u, v = this.v;
    const f32 = this.vertices.f32, i16 = this.vertices.i16, u8 = this.vertices.u8;
    for (let z = 0; z < rows; z++) {
      const row = z * cols, downRow = (z > 0 ? z - 1 : z) * cols, upRow = (z + 1 < rows ? z + 1 : z) * cols;
      for (let x = 0; x < cols; x++) {
        const i = row + x;
        const left = eta[row + (x > 0 ? x - 1 : x)], right = eta[row + (x + 1 < cols ? x + 1 : x)];
        const down = eta[downRow + x], up = eta[upRow + x];
        const nx = -(right - left) * this.invTwoDx, nz = -(up - down) * this.invTwoDz;
        const inverse = 1 / Math.max(1e-12, Math.abs(nx) + 1 + Math.abs(nz));
        let ox = nx * inverse, oy = inverse;
        if (nz < 0) { const old = ox; ox = (1 - Math.abs(oy)) * (old < 0 ? -1 : 1); oy = (1 - Math.abs(old)) * (oy < 0 ? -1 : 1); }
        const laplacian = Math.abs(left + right + down + up - 4 * eta[i]);
        let speed;
        if (options.speed === 'l1') speed = (Math.abs(u[i]) + Math.abs(v[i])) * 0.70710678;
        else if (options.speed === 'squared') speed = (u[i] * u[i] + v[i] * v[i]) * 0.5;
        else speed = Math.sqrt(u[i] * u[i] + v[i] * v[i]);
        let foam = laplacian * 2.2 + speed * 0.22 - 0.08; foam = foam < 0 ? 0 : foam > 1 ? 1 : foam;
        const f = i * 6, h = i * 12, byte = i * 24;
        f32[f + 1] = this.baseY + eta[i];
        if (options.roundNormals) { i16[h + 6] = Math.round(ox * 32767); i16[h + 7] = Math.round(oy * 32767); }
        else { i16[h + 6] = ox * 32767; i16[h + 7] = oy * 32767; }
        const alpha = options.roundColor ? Math.round(foam * 255) : foam * 255 | 0;
        if (options.lut) packed32[i * 6 + 4] = colorLut[alpha];
        else {
          const r = (0.02 + foam * 0.38) * 255, g = (0.28 + foam * 0.55) * 255, b = (0.55 + foam * 0.42) * 255;
          if (options.u32) packed32[i * 6 + 4] = ((r | 0) | ((g | 0) << 8) | ((b | 0) << 16) | ((alpha | 0) << 24)) >>> 0;
          else {
            const convert = options.roundColor ? Math.round : Math.trunc;
            u8[byte + 16] = convert(r); u8[byte + 17] = convert(g); u8[byte + 18] = convert(b); u8[byte + 19] = alpha;
          }
        }
      }
    }
    return this.surfaceResult;
  };
}

function byteQuality(reference, candidate) {
  let absolute = 0, maximum = 0, differing = 0;
  for (let i = 0; i < reference.length; i++) {
    const delta = Math.abs(reference[i] - candidate[i]);
    absolute += delta; maximum = Math.max(maximum, delta); if (delta) differing++;
  }
  return { meanAbsoluteByteError: absolute / reference.length, maxByteError: maximum, differingByteFraction: differing / reference.length };
}

const waterSurfaceBaseline = surfaceMeasurement(749, null, 80);
const waterCandidates = [
  ['truncate-normals', { roundNormals: false, roundColor: true, u32: false, lut: false, speed: 'sqrt' }],
  ['packed-color-round', { roundNormals: true, roundColor: true, u32: true, lut: false, speed: 'sqrt' }],
  ['truncate-plus-packed', { roundNormals: false, roundColor: false, u32: true, lut: false, speed: 'sqrt' }],
  ['color-lut', { roundNormals: false, roundColor: false, u32: true, lut: true, speed: 'sqrt' }],
  ['l1-speed-foam', { roundNormals: false, roundColor: false, u32: true, lut: true, speed: 'l1' }],
  ['squared-speed-foam', { roundNormals: false, roundColor: false, u32: true, lut: true, speed: 'squared' }],
];
for (const [name, options] of waterCandidates) {
  const candidate = surfaceMeasurement(749, (water) => installWaterSurface(water, options), 80);
  const quality = byteQuality(waterSurfaceBaseline.vertices, candidate.vertices);
  const speedup = waterSurfaceBaseline.medianMs / candidate.medianMs;
  const correctness = options.speed === 'sqrt' ? quality.meanAbsoluteByteError < 0.2 : quality.meanAbsoluteByteError < 2.5;
  record({
    category: 'water-surface-generation', sceneId: 749, scene: SCENES[749].title, candidate: name,
    baselineMedianMs: waterSurfaceBaseline.medianMs, candidateMedianMs: candidate.medianMs, speedup,
    baselineSamplesMs: waterSurfaceBaseline.samplesMs, candidateSamplesMs: candidate.samplesMs, noiseMadMs: candidate.madMs,
    quality, correctness: { deterministic: true, finite: finite(candidate.vertices), samePhysicsHash: candidate.hash === waterSurfaceBaseline.hash },
    status: statusFor(speedup, correctness),
  });
}

// ---------------------------------------------------------------------------
// Cinematic effects allocation/trig variants: 8 experiments
// ---------------------------------------------------------------------------

function installEffectsInPlace(effects) {
  effects.update = function updateInPlace(dt) {
    const step = dt < 0 ? 0 : dt > 0.05 ? 0.05 : dt;
    this.elapsed += step;
    const dragScale = step * 60;
    let write = 0;
    for (let read = 0; read < this.particles.length; read++) {
      const p = this.particles[read];
      p.life -= step; p.vel[1] -= p.gravity * step;
      const drag = Math.pow(p.drag, dragScale);
      p.vel[0] *= drag; p.vel[1] *= drag; p.vel[2] *= drag;
      p.pos[0] += p.vel[0] * step; p.pos[1] += p.vel[1] * step; p.pos[2] += p.vel[2] * step;
      p.rot[0] += p.angularVelocity[0] * step; p.rot[1] += p.angularVelocity[1] * step; p.rot[2] += p.angularVelocity[2] * step;
      const growth = 1 + p.growth * step;
      p.half[0] = Math.max(0.006, p.half[0] * growth); p.half[1] = Math.max(0.006, p.half[1] * growth); p.half[2] = Math.max(0.006, p.half[2] * growth);
      if (p.life > 0 && p.pos[1] > -4) this.particles[write++] = p;
    }
    this.particles.length = write;
    write = 0;
    for (let read = 0; read < this.shockwaves.length; read++) {
      const wave = this.shockwaves[read]; wave.life -= step; wave.radius += wave.speed * step;
      if (wave.life > 0) this.shockwaves[write++] = wave;
    }
    this.shockwaves.length = write;
    this.shakeEnergy *= Math.pow(0.88, dragScale);
    if (this.shakeEnergy < 0.002) this.shakeEnergy = 0;
  };
}

function installEffectsFrame(effects, reuse, recurrence) {
  let matrices = new Float32Array(256), colors = new Float32Array(64);
  const lines = [];
  effects.buildFrame = function buildOptimizedFrame(maxInstances) {
    const count = Math.min(maxInstances, this.particles.length);
    if (!reuse) { matrices = new Float32Array(count * 16); colors = new Float32Array(count * 4); }
    else {
      if (matrices.length < count * 16) matrices = new Float32Array(Math.max(count * 16, matrices.length * 2));
      if (colors.length < count * 4) colors = new Float32Array(Math.max(count * 4, colors.length * 2));
    }
    for (let i = 0; i < count; i++) {
      const p = this.particles[i];
      const life = Math.max(0, Math.min(1, p.life / Math.max(0.001, p.maxLife)));
      math.writeModelMatrixFromEuler(matrices, i * 16, p.pos, p.rot, p.half);
      const factor = 0.72 + life * 0.28, offset = i * 4;
      colors[offset] = p.color[0] * factor; colors[offset + 1] = p.color[1] * factor; colors[offset + 2] = p.color[2] * factor;
      colors[offset + 3] = 1 + Math.max(0, p.color[3] - 1) * life;
    }
    lines.length = 0;
    for (const wave of this.shockwaves) {
      const alpha = Math.max(0, Math.min(1, wave.life / wave.maxLife)) * wave.color[3];
      const segments = 72;
      if (recurrence) {
        const step = Math.PI * 2 / segments, c = Math.cos(step), s = Math.sin(step);
        let x = wave.radius, z = 0;
        for (let i = 0; i < segments; i++) {
          const nextX = x * c - z * s, nextZ = x * s + z * c;
          lines.push({ ax: wave.center[0] + x, ay: wave.center[1] + 0.05, az: wave.center[2] + z, bx: wave.center[0] + nextX, by: wave.center[1] + 0.05, bz: wave.center[2] + nextZ, r: wave.color[0], g: wave.color[1], b: wave.color[2], a: alpha });
          x = nextX; z = nextZ;
        }
      } else {
        for (let i = 0; i < segments; i++) {
          const a = i / segments * Math.PI * 2, b = (i + 1) / segments * Math.PI * 2;
          lines.push({ ax: wave.center[0] + Math.cos(a) * wave.radius, ay: wave.center[1] + 0.05, az: wave.center[2] + Math.sin(a) * wave.radius, bx: wave.center[0] + Math.cos(b) * wave.radius, by: wave.center[1] + 0.05, bz: wave.center[2] + Math.sin(b) * wave.radius, r: wave.color[0], g: wave.color[1], b: wave.color[2], a: alpha });
        }
      }
    }
    return { matrices, colors, count, debugLines: lines };
  };
}

function createEffects(load, mode) {
  const effects = new CinematicEffects();
  if (mode === 'in-place' || mode === 'all') installEffectsInPlace(effects);
  if (mode === 'reuse') installEffectsFrame(effects, true, false);
  if (mode === 'trig-recurrence') installEffectsFrame(effects, false, true);
  if (mode === 'all') installEffectsFrame(effects, true, true);
  for (let i = 0; i < load; i++) effects.spawnExplosion([i - load * 0.5, 4, 0], 35, 1536);
  for (let i = 0; i < load; i++) effects.spawnRainFlash([0, 12, 0], 1536);
  effects.hash = () => effects.particleCount();
  return effects;
}

for (const load of [4, 10]) {
  const baseline = timedSamples(() => createEffects(load, 'baseline'), (effects) => { effects.update(1 / 60); effects.buildFrame(1536); }, 3, 30, 3);
  for (const mode of ['in-place', 'reuse', 'trig-recurrence', 'all']) {
    const candidate = timedSamples(() => createEffects(load, mode), (effects) => { effects.update(1 / 60); const frame = effects.buildFrame(1536); if (!finite(frame.matrices, frame.count * 16)) throw new Error('non-finite effect matrix'); }, 3, 30, 3);
    const speedup = baseline.medianMs / candidate.medianMs;
    record({
      category: 'cinematic-effects', candidate: `${mode} · load ${load}`,
      parameters: { load }, baselineMedianMs: baseline.medianMs, candidateMedianMs: candidate.medianMs, speedup,
      baselineSamplesMs: baseline.samplesMs, candidateSamplesMs: candidate.samplesMs, noiseMadMs: candidate.madMs,
      correctness: { deterministicParticleCount: new Set(candidate.hashes).size === 1, finite: true },
      status: statusFor(speedup, true, 1.03),
    });
  }
}

// ---------------------------------------------------------------------------
// Collision-specialization controls: 8 experiments
// ---------------------------------------------------------------------------

function installSquaredSphere(cloth) {
  cloth.solveCollisions = function solveSquaredSphere() {
    const target = this.sphereRadius + 0.08;
    const targetSquared = target * target;
    for (let i = 0; i < this.count; i++) {
      if (this.invMass[i] === 0) continue;
      const o = i * 3;
      if (this.positions[o + 1] < 0.12) {
        this.positions[o + 1] = 0.12;
        this.previous[o] = this.positions[o] - (this.positions[o] - this.previous[o]) * 0.72;
        this.previous[o + 2] = this.positions[o + 2] - (this.positions[o + 2] - this.previous[o + 2]) * 0.72;
      }
      if (this.sphereRadius > 0) {
        const dx = this.positions[o] - this.sphereCenter[0], dy = this.positions[o + 1] - this.sphereCenter[1], dz = this.positions[o + 2] - this.sphereCenter[2];
        const d2 = dx * dx + dy * dy + dz * dz;
        if (d2 < targetSquared && d2 > 1e-12) {
          const scale = target / Math.sqrt(d2);
          this.positions[o] = this.sphereCenter[0] + dx * scale;
          this.positions[o + 1] = this.sphereCenter[1] + dy * scale;
          this.positions[o + 2] = this.sphereCenter[2] + dz * scale;
        }
      }
    }
  };
}

for (const sceneId of [603, 623, 643, 647]) {
  const create = (optimized) => {
    const suite = new SoftSimulationSuite(); suite.createScene(SCENES[sceneId], 5, 0x818181);
    if (optimized) installSquaredSphere(suite.active);
    return suite;
  };
  const baseline = timedSamples(() => create(false), (suite) => { suite.step(1 / 60, 4); suite.buildFrame(false); }, 5, 20, 3);
  const candidate = timedSamples(() => create(true), (suite) => { suite.step(1 / 60, 4); suite.buildFrame(false); }, 5, 20, 3);
  const speedup = baseline.medianMs / candidate.medianMs;
  const exactHash = baseline.hashes[0] === candidate.hashes[0];
  record({
    category: 'cloth-sphere-collision', sceneId, scene: SCENES[sceneId].title, candidate: 'squared-distance sphere rejection',
    baselineMedianMs: baseline.medianMs, candidateMedianMs: candidate.medianMs, speedup,
    baselineSamplesMs: baseline.samplesMs, candidateSamplesMs: candidate.samplesMs, noiseMadMs: candidate.madMs,
    correctness: { deterministic: new Set(candidate.hashes).size === 1, exactHash },
    status: statusFor(speedup, exactHash, 1.03),
  });
}

function installRopeProjectileAabb(rope) {
  rope.collideProjectiles = function collideRopeAabb() {
    if (!this.projectiles.length) return;
    const positions = this.positions, previous = this.previous, invMass = this.invMass;
    let minX = Infinity, minY = Infinity, minZ = Infinity, maxX = -Infinity, maxY = -Infinity, maxZ = -Infinity;
    for (let i = 0; i < invMass.length; i++) {
      if (invMass[i] === 0) continue;
      const o = i * 3, x = positions[o], y = positions[o + 1], z = positions[o + 2];
      minX = Math.min(minX, x); maxX = Math.max(maxX, x); minY = Math.min(minY, y); maxY = Math.max(maxY, y); minZ = Math.min(minZ, z); maxZ = Math.max(maxZ, z);
    }
    for (const projectile of this.projectiles) {
      const target = projectile.radius + 0.22, px = projectile.position[0], py = projectile.position[1], pz = projectile.position[2];
      if (px + target < minX || px - target > maxX || py + target < minY || py - target > maxY || pz + target < minZ || pz - target > maxZ) continue;
      const vx = projectile.velocity[0], vy = projectile.velocity[1], vz = projectile.velocity[2];
      const speed = Math.sqrt(vx * vx + vy * vy + vz * vz), targetSquared = target * target;
      for (let i = 0; i < invMass.length; i++) {
        if (invMass[i] === 0) continue;
        const o = i * 3, dx = positions[o] - px, dy = positions[o + 1] - py, dz = positions[o + 2] - pz;
        const d2 = dx * dx + dy * dy + dz * dz;
        if (d2 > targetSquared || d2 < 1e-12) continue;
        const distance = Math.sqrt(d2), scale = speed * 0.012 / distance;
        previous[o] -= vx * 0.012; previous[o + 1] -= vy * 0.012; previous[o + 2] -= vz * 0.012;
        if (speed > 14) this.breakNearestConstraint(projectile.position, projectile.radius + 0.9);
        positions[o] += dx * scale; positions[o + 1] += dy * scale; positions[o + 2] += dz * scale;
      }
    }
  };
}

for (const projectileCount of [20, 48, 72, 96]) {
  const create = (optimized) => {
    const suite = new SoftSimulationSuite(); suite.createScene(SCENES[699], 5, 0x929292);
    if (optimized) installRopeProjectileAabb(suite.active);
    suite.spawnRain(projectileCount, 14, 24);
    return suite;
  };
  const baseline = timedSamples(() => create(false), (suite) => { suite.step(1 / 60, 4); suite.buildFrame(false); }, 1, 8, 3);
  const candidate = timedSamples(() => create(true), (suite) => { suite.step(1 / 60, 4); suite.buildFrame(false); }, 1, 8, 3);
  const speedup = baseline.medianMs / candidate.medianMs;
  const exactHash = baseline.hashes[0] === candidate.hashes[0];
  record({
    category: 'rope-projectile-collision', sceneId: 699, scene: SCENES[699].title,
    candidate: `AABB + squared-distance · ${projectileCount} projectiles`, parameters: { projectileCount },
    baselineMedianMs: baseline.medianMs, candidateMedianMs: candidate.medianMs, speedup,
    baselineSamplesMs: baseline.samplesMs, candidateSamplesMs: candidate.samplesMs, noiseMadMs: candidate.madMs,
    correctness: { deterministic: new Set(candidate.hashes).size === 1, exactHash },
    status: statusFor(speedup, exactHash),
  });
}

if (experiments.length !== 100) throw new Error(`expected exactly 100 experiments, got ${experiments.length}`);

const accepted = experiments.filter((entry) => entry.status === 'accepted');
const rejectedCorrectness = experiments.filter((entry) => entry.status === 'rejected-correctness');
const sortedWins = [...experiments].sort((a, b) => b.speedup - a.speedup);
const summary = {
  schema: 1,
  generatedAt: new Date().toISOString(),
  environment: { node: process.version, platform: process.platform, arch: process.arch },
  experimentCount: experiments.length,
  acceptedCount: accepted.length,
  rejectedCorrectnessCount: rejectedCorrectness.length,
  fastest: sortedWins.slice(0, 15).map(({ id, category, candidate, speedup, status }) => ({ id, category, candidate, speedup, status })),
  experiments,
};

const jsonPath = path.join(resultsDir, 'v1.5-breakthrough-100.json');
fs.writeFileSync(jsonPath, JSON.stringify(summary, null, 2));

const columns = ['id', 'category', 'sceneId', 'candidate', 'baselineMedianMs', 'candidateMedianMs', 'speedup', 'status'];
const escapeCsv = (value) => `"${String(value ?? '').replaceAll('"', '""')}"`;
const csv = [columns.join(','), ...experiments.map((entry) => columns.map((column) => escapeCsv(entry[column])).join(','))].join('\n') + '\n';
fs.writeFileSync(path.join(resultsDir, 'v1.5-breakthrough-100.csv'), csv);

const lines = [
  '# Box3D WebGPU AAA v1.5 — 100-Experiment Breakthrough Tournament',
  '',
  `- Experiments: **${experiments.length}**`,
  `- Accepted measured wins: **${accepted.length}**`,
  `- Correctness rejections: **${rejectedCorrectness.length}**`,
  `- Node: \`${process.version}\` on \`${process.platform}/${process.arch}\``,
  '',
  '## Top measured results',
  '',
  '| # | Category | Candidate | Speedup | Decision |',
  '|---:|---|---|---:|---|',
  ...sortedWins.slice(0, 25).map((entry) => `| ${entry.id} | ${entry.category} | ${entry.candidate.replaceAll('|', '\\|')} | **${entry.speedup.toFixed(2)}×** | ${entry.status} |`),
  '',
  '## Method',
  '',
  'Each experiment runs repeated warm-up and timed loops against the bundled compiled v1.4 baseline. The JSON artifact preserves every raw timing sample, median, MAD, quality/error metric, replay-hash evidence, and decision. Ratios from unrelated kernels are not multiplied together.',
  '',
  '## Complete experiment index',
  '',
  '| # | Category | Candidate | Baseline ms | Candidate ms | Speedup | Decision |',
  '|---:|---|---|---:|---:|---:|---|',
  ...experiments.map((entry) => `| ${entry.id} | ${entry.category} | ${entry.candidate.replaceAll('|', '\\|')} | ${entry.baselineMedianMs.toFixed(5)} | ${entry.candidateMedianMs.toFixed(5)} | ${entry.speedup.toFixed(3)}× | ${entry.status} |`),
  '',
];
fs.writeFileSync(path.join(resultsDir, 'V1.5_BREAKTHROUGH_100.md'), lines.join('\n'));

console.log(`✅ 100-experiment tournament complete: ${accepted.length} accepted, ${rejectedCorrectness.length} correctness rejections`);
for (const entry of sortedWins.slice(0, 12)) console.log(`${String(entry.id).padStart(3, '0')} ${entry.speedup.toFixed(2)}× ${entry.category} — ${entry.candidate} [${entry.status}]`);
console.log(jsonPath);
