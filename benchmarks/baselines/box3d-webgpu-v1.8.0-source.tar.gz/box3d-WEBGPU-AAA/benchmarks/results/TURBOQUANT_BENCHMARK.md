# TurboQuant Simulation-State Benchmark

Generated: 2026-07-12T01:41:11.509Z

## Decision

**Do not enable TurboQuant on the current same-thread physics → WebGPU upload path.** The JavaScript rotation, quantization, packing, unpacking, and reconstruction cost is greater than a local typed-array copy.

**Use the predictive 4-bit transport mode for network snapshots, remote spectators, cloud simulation replication, replay archives, or other bandwidth-limited boundaries.** Once encoded, its payload is much cheaper to copy and transmit, and the measured break-even link rate is reported below.

## Recommended predictive 4-bit result

| Workload | Raw/frame | Packet/frame | Compression | Encode + decode | Relative L2 | Copy-only speedup | Link break-even | 10 MB/s model | 25 MB/s model | 50 MB/s model |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| cloth | 19.92 KiB | 2.81 KiB | 7.08× | 0.4410 ms | 1.258% | 5.31× | 39.7 MB/s | 2.80× | 1.47× | 0.82× |
| rope | 25.06 KiB | 3.55 KiB | 7.06× | 0.5270 ms | 1.126% | 10.04× | 41.8 MB/s | 2.88× | 1.53× | 0.86× |
| water | 75.47 KiB | 10.62 KiB | 7.11× | 1.6501 ms | 1.244% | 12.58× | 40.2 MB/s | 2.82× | 1.48× | 0.83× |

The network model is `raw bytes / link rate` versus `codec time + compressed bytes / link rate`; it excludes protocol overhead and assumes codec work is not overlapped. Lower-bandwidth links favor compression.

## All tested codecs

### Tensioned Membrane Drum — Cinematic

| Codec | Compression | Predictive time/frame | Predictive relative L2 | Local end-to-end | Break-even |
|---|---:|---:|---:|---:|---:|
| TurboQuant blockwise dense 4-bit | 5.31× | 0.7499 ms | 1.016% | 0.0007× | 22.1 MB/s |
| TurboQuant structured 4-bit | 6.38× | 0.4559 ms | 1.085% | 0.0010× | 37.7 MB/s |
| TurboQuant structured 3-bit | 7.97× | 0.4083 ms | 2.100% | 0.0011× | 43.7 MB/s |
| TurboQuant structured 4-bit delta | 7.08× | 0.4410 ms | 1.258% | 0.0010× | 39.7 MB/s |
| TurboQuant structured 3-bit delta | 9.11× | 0.3866 ms | 2.516% | 0.0012× | 47.0 MB/s |

### Rope Net Resonance — Cinematic

| Codec | Compression | Predictive time/frame | Predictive relative L2 | Local end-to-end | Break-even |
|---|---:|---:|---:|---:|---:|
| TurboQuant blockwise dense 4-bit | 5.32× | 0.9192 ms | 1.151% | 0.0006× | 22.7 MB/s |
| TurboQuant structured 4-bit | 6.35× | 0.5558 ms | 1.088% | 0.0012× | 38.9 MB/s |
| TurboQuant structured 3-bit | 7.94× | 0.4880 ms | 2.185% | 0.0012× | 46.0 MB/s |
| TurboQuant structured 4-bit delta | 7.06× | 0.5270 ms | 1.126% | 0.0011× | 41.8 MB/s |
| TurboQuant structured 3-bit delta | 9.07× | 0.4692 ms | 2.275% | 0.0012× | 48.7 MB/s |

### Leviathan Impact Pool — Cinematic

| Codec | Compression | Predictive time/frame | Predictive relative L2 | Local end-to-end | Break-even |
|---|---:|---:|---:|---:|---:|
| TurboQuant blockwise dense 4-bit | 5.33× | 2.5063 ms | 1.028% | 0.0007× | 25.1 MB/s |
| TurboQuant structured 4-bit | 6.40× | 1.5415 ms | 1.064% | 0.0011× | 42.3 MB/s |
| TurboQuant structured 3-bit | 8.00× | 1.5168 ms | 2.128% | 0.0012× | 44.6 MB/s |
| TurboQuant structured 4-bit delta | 7.11× | 1.6501 ms | 1.244% | 0.0011× | 40.2 MB/s |
| TurboQuant structured 3-bit delta | 9.14× | 1.3591 ms | 2.478% | 0.0013× | 50.6 MB/s |

## Worker transport check

A local Node worker transferred 48 water frames. Raw transferable transport took 5.751 ms total; predictive TurboQuant encode + transfer + decode took 94.383 ms. End-to-end speedup was **0.0609×**, meaning TurboQuant was **16.4× slower** for this local worker path.

Transferred bytes fell from 3,709,440 to 521,856 (7.11× smaller), but local memory transfer was already too fast for the JavaScript codec cost to amortize.

## Algorithm mapping and scope

- `dense` is a **blockwise adaptation of TurboQuant-MSE**: normalize each block, apply a deterministic random orthogonal rotation, use Gaussian Lloyd–Max scalar centroids, and inverse-rotate during reconstruction. It is not the paper’s single full-vector dense rotation.
- `structured` replaces the dense rotation with randomized normalized Walsh–Hadamard stages. This is a TurboQuant-style fast transform aligned with the later Fast-TurboQuant direction, not an official Google implementation.
- QJL residual correction is intentionally omitted because this engine reconstructs positions/matrices; it is not estimating attention inner products.
- Predictive mode quantizes the difference from the prior reconstructed frame. Encoder and decoder therefore remain synchronized on the same lossy reference.

## Reproduction

```bash
npm ci
TQ_FRAMES=60 TQ_SAMPLES=5 TQ_WARMUPS=2 TQ_FANOUTS=1,4,16 npm run bench:turboquant:all
```

Runtime: v22.16.0 on linux/x64; 60 frames/workload, 5 timed samples, 2 warmups.
