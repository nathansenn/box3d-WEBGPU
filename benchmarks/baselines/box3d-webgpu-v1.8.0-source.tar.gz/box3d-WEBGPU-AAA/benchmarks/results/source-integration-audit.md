# Source Integration Audit

Changed implementation/configuration files: **3**

Source files: **1** · WASM files: **0** · scripts: **0**

Line delta: **+76 / -4**

| File | Added | Deleted | Baseline | Optimized |
|---|---:|---:|---|---|
| `package-lock.json` | 2 | 2 | 2dd7993c750d | 29ff6f6455b4 |
| `package.json` | 7 | 2 | d8889296f455 | ac244b36faca |
| `src/perf/runtime.ts` | 67 | 0 | new | 52384ddf462e |
