# Box3D WebGPU — 100 Optimization Candidate Benchmarks

Generated: 2026-07-10T22:41:50.246Z

## Method

- Nine timed samples after four warm-up passes.
- Median ns/op is used; MAD tracks run noise.
- Accepted only at ≥3% median improvement with bounded noise.
- Every candidate is retained in raw JSON/CSV, including regressions and inconclusive results.
- Perceptual/workload-equivalent changes require the end-to-end quality gate before integration.

## Summary

| Candidates | Accepted | Borderline | Rejected | Accepted geometric-mean kernel speedup |
|---:|---:|---:|---:|---:|
| 100 | 85 | 2 | 13 | 17.952× |

## Results

| # | Subsystem | Candidate | Baseline ns/op | Optimized ns/op | Speedup | Status |
|---:|---|---|---:|---:|---:|---|
| 1 | Math | Specialize 3D vector length instead of Math.hypot | 63.44 | 2.55 | 24.832× | accepted |
| 2 | Math | Replace pow(x, 2) with multiplication | 2.30 | 1.90 | 1.212× | accepted |
| 3 | Math | Use squared distance for threshold tests | 5.22 | 5.74 | 0.908× | rejected-no-win |
| 4 | Math | Inline hot clamp operation | 9.80 | 3.10 | 3.162× | accepted |
| 5 | Math | Cache reciprocal rest length | 2.28 | 2.11 | 1.082× | accepted |
| 6 | Math | Use scalar vector temporaries | 7.48 | 3.07 | 2.436× | accepted |
| 7 | Math | Avoid destructuring hot vectors | 3.33 | 2.22 | 1.504× | accepted |
| 8 | Math | Avoid temporary arithmetic objects | 2.01 | 2.04 | 0.986× | rejected-no-win |
| 9 | Math | Specialize normal-vector normalization | 1007.97 | 61.83 | 16.303× | accepted |
| 10 | Math | Hoist repeated fixed coefficients | 5.52 | 2.04 | 2.704× | accepted |
| 11 | Data layout | Convert particle AoS to SoA | 3.83 | 2.81 | 1.364× | accepted |
| 12 | Data layout | Pack cloth constraints into typed arrays | 8.29 | 6.16 | 1.346× | accepted |
| 13 | Data layout | Pack rope segments into typed arrays | 8.15 | 6.17 | 1.322× | accepted |
| 14 | Data layout | Pack material IDs into bytes | 12.07 | 1.48 | 8.154× | accepted |
| 15 | Data layout | Pack event data into SoA ring buffers | 2165.73 | 2.60 | 834.337× | accepted |
| 16 | Data layout | Use active-index list instead of scanning inactive bodies | 3.18 | 4.36 | 0.730× | rejected-no-win |
| 17 | Data layout | Use bit flags for broken constraints | 5.50 | 6.47 | 0.850× | rejected-no-win |
| 18 | Data layout | Use compact integer indices for topology | 8.28 | 6.17 | 1.342× | accepted |
| 19 | Data layout | Stream matrices directly into packed storage | 15.24 | 4.18 | 3.651× | accepted |
| 20 | Data layout | Cache static transform stream | 356.77 | 0.06 | 5775.929× | borderline |
| 21 | Allocation | Preallocate vector temporaries | 6.39 | 2.87 | 2.225× | accepted |
| 22 | Allocation | Reuse output objects | 1.96 | 2.08 | 0.946× | rejected-no-win |
| 23 | Allocation | Replace map allocation with a reusable buffer | 157.84 | 21.06 | 7.493× | accepted |
| 24 | Allocation | Compact active elements in place instead of filter | 125.04 | 15.19 | 8.231× | accepted |
| 25 | Allocation | Replace reduce callback with indexed loop | 102.54 | 13.13 | 7.811× | accepted |
| 26 | Allocation | Write vertex streams by index instead of push | 953.94 | 28.50 | 33.475× | accepted |
| 27 | Allocation | Use TypedArray.set for contiguous copies | 7.88 | 1.49 | 5.299× | accepted |
| 28 | Allocation | Grow dynamic buffers geometrically | 15.23 | 0.23 | 67.163× | accepted |
| 29 | Allocation | Use object pools for projectiles | 2.51 | 2.52 | 0.996× | rejected-no-win |
| 30 | Allocation | Batch rain spawn into packed storage | 28.54 | 12.91 | 2.211× | accepted |
| 31 | Cloth | Skip broken constraints before math | 5.39 | 6.36 | 0.848× | rejected-no-win |
| 32 | Cloth | Cache inverse rest lengths | 2.27 | 2.03 | 1.120× | accepted |
| 33 | Cloth | Separate structural constraints into contiguous arrays | 8.13 | 6.09 | 1.336× | accepted |
| 34 | Cloth | Separate shear constraints into contiguous arrays | 8.45 | 6.15 | 1.374× | accepted |
| 35 | Cloth | Separate bend constraints into contiguous arrays | 8.57 | 6.04 | 1.420× | accepted |
| 36 | Cloth | Cache UV coordinates | 28.36 | 0.06 | 455.679× | accepted |
| 37 | Cloth | Cache intact topology indices | 2106.07 | 0.03 | 66839.356× | accepted |
| 38 | Cloth | Rebuild tear topology only when dirty | 1887.68 | 0.04 | 46753.891× | accepted |
| 39 | Cloth | Generate interleaved surface data directly | 857.81 | 26.87 | 31.921× | accepted |
| 40 | Cloth | Decimate expensive normal regeneration when stable | 3.11 | 5.54 | 0.561× | rejected-no-win |
| 41 | Rope | Pack rope nodes into SoA arrays | 3.84 | 1.63 | 2.359× | accepted |
| 42 | Rope | Skip severed segments early | 2.05 | 1.58 | 1.304× | accepted |
| 43 | Rope | Cache segment inverse rest length | 1.95 | 1.63 | 1.201× | accepted |
| 44 | Rope | Reuse segment transform matrix | 27.65 | 3.68 | 7.506× | accepted |
| 45 | Rope | Batch all rope segment instances | 876.13 | 28.59 | 30.647× | accepted |
| 46 | Rope | Maintain active segment range | 3.10 | 3.27 | 0.947× | rejected-no-win |
| 47 | Rope | Pack anchor flags into bytes | 11.63 | 1.67 | 6.969× | accepted |
| 48 | Rope | Reuse payload integration temporary | 1.64 | 1.61 | 1.019× | borderline |
| 49 | Rope | Avoid closure allocation in segment iteration | 17.24 | 1.71 | 10.093× | accepted |
| 50 | Rope | Use squared threshold for cable break checks | 3.42 | 3.04 | 1.124× | accepted |
| 51 | Water | Swap height buffers instead of copying | 14.95 | 11.42 | 1.310× | accepted |
| 52 | Water | Split interior stencil from boundary handling | 99.66 | 108.10 | 0.922× | rejected-no-win |
| 53 | Water | Precompute grid neighbor offsets | 137.65 | 102.84 | 1.338× | accepted |
| 54 | Water | Cache grid UV coordinates | 27.71 | 0.05 | 513.785× | accepted |
| 55 | Water | Cache regular-grid indices | 2016.12 | 0.04 | 56683.078× | accepted |
| 56 | Water | Fuse height and velocity coefficient setup | 1.93 | 1.75 | 1.104× | accepted |
| 57 | Water | Use squared radius for ripple injection | 3.28 | 3.03 | 1.081× | accepted |
| 58 | Water | Reuse droplet pool | 1.96 | 2.03 | 0.964× | rejected-no-win |
| 59 | Water | Batch droplet instance stream | 824.28 | 26.86 | 30.693× | accepted |
| 60 | Water | Update normals at a stable cadence | 2.59 | 1.64 | 1.578× | accepted |
| 61 | Surface mesh | Cache cloth UV stream | 28.17 | 0.01 | 2831.785× | accepted |
| 62 | Surface mesh | Cache water UV stream | 24.35 | 0.01 | 2292.733× | accepted |
| 63 | Surface mesh | Cache cloth index topology | 1959.40 | 0.01 | 240470.735× | accepted |
| 64 | Surface mesh | Cache water index topology | 1977.19 | 0.01 | 254072.376× | accepted |
| 65 | Surface mesh | Reuse interleaved vertex staging buffer | 893.10 | 28.21 | 31.659× | accepted |
| 66 | Surface mesh | Reuse surface-result object | 1.73 | 1.66 | 1.043× | accepted |
| 67 | Surface mesh | Pack colors into material IDs before expansion | 11.86 | 1.60 | 7.391× | accepted |
| 68 | Surface mesh | Specialize finite-difference normals | 914.71 | 41.43 | 22.080× | accepted |
| 69 | Surface mesh | Skip topology rebuild when no tear occurred | 2090.76 | 0.01 | 276250.494× | accepted |
| 70 | Surface mesh | Use contiguous typed-array copies | 7.84 | 1.03 | 7.632× | accepted |
| 71 | Renderer CPU | Reuse instance staging arrays | 875.54 | 27.48 | 31.859× | accepted |
| 72 | Renderer CPU | Use geometric GPU-buffer growth | 17.68 | 0.03 | 701.454× | accepted |
| 73 | Renderer CPU | Cache static transforms | 143.83 | 0.06 | 2450.205× | accepted |
| 74 | Renderer CPU | Pack material classification | 11.61 | 1.61 | 7.229× | accepted |
| 75 | Renderer CPU | Write matrices without temporary arrays | 18.36 | 3.31 | 5.553× | accepted |
| 76 | Renderer CPU | Batch effect instances | 840.65 | 27.58 | 30.477× | accepted |
| 77 | Renderer CPU | Batch rope instances | 828.38 | 27.10 | 30.571× | accepted |
| 78 | Renderer CPU | Batch droplets | 879.75 | 36.91 | 23.834× | accepted |
| 79 | Renderer CPU | Skip zero-count draw preparation | 2.01 | 1.59 | 1.262× | accepted |
| 80 | Renderer CPU | Cap debug geometry before generation | 134.30 | 15.39 | 8.727× | accepted |
| 81 | Rigid preview | Use SoA body transform state | 3.78 | 1.63 | 2.318× | accepted |
| 82 | Rigid preview | Maintain active body indices | 3.17 | 3.03 | 1.045× | accepted |
| 83 | Rigid preview | Cache static-body matrices | 139.23 | 0.01 | 11334.578× | accepted |
| 84 | Rigid preview | Pool projectiles | 1.88 | 2.23 | 0.842× | rejected-no-win |
| 85 | Rigid preview | Batch rain bodies | 22.37 | 15.66 | 1.429× | accepted |
| 86 | Rigid preview | Use squared collision broadphase checks | 3.38 | 3.04 | 1.112× | accepted |
| 87 | Rigid preview | Pack body material IDs | 11.87 | 1.60 | 7.398× | accepted |
| 88 | Rigid preview | Skip sleeping bodies before transform math | 2.01 | 1.59 | 1.266× | accepted |
| 89 | Rigid preview | Reuse transform matrices | 22.33 | 3.48 | 6.418× | accepted |
| 90 | Rigid preview | Use ring buffer for action events | 119.03 | 2.54 | 46.878× | accepted |
| 91 | Scheduling | Decimate telemetry formatting | 922.70 | 16.19 | 56.980× | accepted |
| 92 | Scheduling | Avoid per-frame callback closures | 13.28 | 1.64 | 8.099× | accepted |
| 93 | Scheduling | Use ring-buffer event queue | 113.43 | 3.29 | 34.479× | accepted |
| 94 | Scheduling | Reuse fixed-step scratch state | 1.60 | 1.65 | 0.969× | rejected-no-win |
| 95 | Scheduling | Skip inactive work before arithmetic | 2.02 | 1.55 | 1.304× | accepted |
| 96 | Scheduling | Batch spawn commands | 21.63 | 12.78 | 1.692× | accepted |
| 97 | WASM bridge | Cache typed heap views until memory changes | 144.60 | 0.00 | 30276.466× | accepted |
| 98 | WASM bridge | Stream packed transforms instead of JS objects | 3.81 | 1.85 | 2.057× | accepted |
| 99 | WASM bridge | Pack material stream into bytes | 11.99 | 1.61 | 7.447× | accepted |
| 100 | Build/runtime | Eliminate hot-loop closure creation | 13.31 | 1.63 | 8.187× | accepted |

## Interpretation

A kernel win is evidence for that implementation choice, not permission to stack all ratios multiplicatively. The release report separately measures complete scenes and validates deterministic/visual contracts.
