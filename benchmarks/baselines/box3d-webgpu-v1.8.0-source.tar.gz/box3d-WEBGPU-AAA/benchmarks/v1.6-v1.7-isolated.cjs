'use strict';
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { performance } = require('node:perf_hooks');
const { spawnSync } = require('node:child_process');
const root = path.resolve(__dirname, '..');
const archive = path.join(root, 'benchmarks/baselines/box3d-webgpu-v1.6.0-source.tar.gz');
const samples = Math.max(3, Number.parseInt(process.env.V17_SAMPLES || '7', 10));
const bootstrapIterations = Math.max(1000, Number.parseInt(process.env.V17_BOOTSTRAPS || '10000', 10));
const workloads = [
  ['water-maximum-frame', 'Water maximum · render handoff', 'frame-breakthrough'],
  ['water-wave-full', 'Water wave · solver + render handoff', 'dynamic-breakthrough'],
  ['water-maximum-full', 'Water maximum · solver + render handoff', 'dynamic-breakthrough'],
  ['rope-maximum-frame', 'Rope maximum · render stream', 'frame-breakthrough'],
  ['rope-maximum-full', 'Rope maximum · solver + instances', 'dynamic-breakthrough'],
  ['rope-mooring-full', 'Rope mooring · zero-length-link guard', 'dynamic-breakthrough'],
  ['rope-storm-full', 'Rope storm · 96 impacts', 'dynamic-breakthrough'],
  ['cloth-maximum-full', 'Cloth maximum · unchanged control', 'control'],
  ['water-maximum-step', 'Water maximum · solver-only control', 'control'],
  ['mixed-soft-tour', 'Mixed maximum cloth + rope + water frame', 'mixed'],
];
function runCommand(command, args, options = {}) {
  const result = spawnSync(command, args, { stdio: 'inherit', ...options });
  if (result.status !== 0) throw new Error(`${command} ${args.join(' ')} failed`);
}
function prepareBaseline() {
  if (!fs.existsSync(archive)) throw new Error(`missing ${archive}`);
  const target = path.join(os.tmpdir(), `box3d-v16-v17-${process.pid}`);
  fs.rmSync(target, { recursive: true, force: true }); fs.mkdirSync(target, { recursive: true });
  runCommand('tar', ['-xzf', archive, '-C', target, '--strip-components=1']);
  fs.rmSync(path.join(target, 'node_modules'), { recursive: true, force: true });
  fs.symlinkSync(path.join(root, 'node_modules'), path.join(target, 'node_modules'), process.platform === 'win32' ? 'junction' : 'dir');
  runCommand(path.join(root, 'node_modules/.bin/tsc'), ['-p', path.join(target, 'tsconfig.test.json')], { cwd: target });
  fs.writeFileSync(path.join(target, '.test-build/package.json'), '{"type":"commonjs"}');
  return target;
}
const baselineRoot = process.env.V17_BASELINE_ROOT ? path.resolve(process.env.V17_BASELINE_ROOT) : prepareBaseline();
const worker = path.join(root, 'benchmarks/v1.6-v1.7-worker.cjs');
function median(a){const s=[...a].sort((x,y)=>x-y),m=s.length>>1;return s.length&1?s[m]:(s[m-1]+s[m])*0.5}
function mad(a){const m=median(a);return median(a.map(x=>Math.abs(x-m)))}
function run(variant, workloadId) {
  const sourceRoot = variant === 'v1.6' ? baselineRoot : root;
  const result = spawnSync(process.execPath, ['--expose-gc', worker, sourceRoot, variant, workloadId], { cwd: root, encoding: 'utf8', maxBuffer: 1024*1024 });
  if (result.status !== 0) throw new Error(`${variant} ${workloadId} failed:\n${result.stderr || result.stdout}`);
  return JSON.parse(result.stdout);
}
let randomState=0x17c0ffee;function random01(){randomState^=randomState<<13;randomState^=randomState>>>17;randomState^=randomState<<5;return(randomState>>>0)/0x100000000}
function percentile(s,p){const x=(s.length-1)*p,l=Math.floor(x),u=Math.ceil(x),t=x-l;return s[l]+(s[u]-s[l])*t}
function bootstrap(b,o){const r=[];for(let it=0;it<bootstrapIterations;it++){const bb=[],oo=[];for(let i=0;i<b.length;i++){const j=Math.floor(random01()*b.length);bb.push(b[j]);oo.push(o[j])}r.push(median(bb)/median(oo))}r.sort((a,b)=>a-b);return[percentile(r,.025),percentile(r,.975)]}
const started=performance.now(),results=[];
for(let wi=0;wi<workloads.length;wi++){
  const [id,label,category]=workloads[wi],b=[],o=[],bh=[],oh=[],meta=[];
  for(let s=0;s<samples;s++){
    const order=((s+wi)&1)===0?['v1.6','v1.7']:['v1.7','v1.6'];
    for(const variant of order){const m=run(variant,id);(variant==='v1.6'?b:o).push(m.msPerOperation);(variant==='v1.6'?bh:oh).push(m.hash);meta.push(m)}
  }
  const bm=median(b),om=median(o),speedup=bm/om,ci=bootstrap(b,o);
  const record={id,label,category,baselineSamplesMs:b,optimizedSamplesMs:o,baselineMedianMs:bm,optimizedMedianMs:om,baselineMadMs:mad(b),optimizedMadMs:mad(o),speedup,pairedBootstrap95:ci,baselineDeterministic:new Set(bh).size===1,optimizedDeterministic:new Set(oh).size===1,crossVersionHashMatch:bh[0]===oh[0],baselineHashes:bh,optimizedHashes:oh,metadata:meta.slice(-2)};
  results.push(record);console.log(`${String(wi+1).padStart(2,'0')}/${workloads.length} ${label}: ${speedup.toFixed(2)}× [${ci[0].toFixed(2)}, ${ci[1].toFixed(2)}]`);
}
const gm=a=>Math.exp(a.reduce((s,x)=>s+Math.log(x),0)/a.length);
const changed=results.filter(x=>x.category!=='control');
const dynamic=results.filter(x=>x.category==='dynamic-breakthrough'||x.category==='mixed');
const output={schema:1,generatedAt:new Date().toISOString(),environment:{node:process.version,platform:process.platform,arch:process.arch,cpu:os.cpus()[0]?.model??'unknown'},method:{samples,bootstrapIterations,freshProcessPerMeasurement:true,alternatingOrder:true,processStartupExcluded:true},summary:{changedGeometricMeanSpeedup:gm(changed.map(x=>x.speedup)),dynamicGeometricMeanSpeedup:gm(dynamic.map(x=>x.speedup)),medianSpeedup:median(results.map(x=>x.speedup)),elapsedMs:performance.now()-started},results};
const d=path.join(root,'benchmarks/results');fs.mkdirSync(d,{recursive:true});fs.writeFileSync(path.join(d,'v1.6-v1.7-isolated.json'),JSON.stringify(output,null,2));
const md=['# v1.6 → v1.7 Isolated Fresh-Process Benchmark','',`- Changed-path geometric mean: **${output.summary.changedGeometricMeanSpeedup.toFixed(2)}×**`,`- Dynamic/mixed geometric mean: **${output.summary.dynamicGeometricMeanSpeedup.toFixed(2)}×**`,'','| Workload | v1.6 ms | v1.7 ms | Speedup | Paired 95% interval |','|---|---:|---:|---:|---:|',...results.map(x=>`| ${x.label} | ${x.baselineMedianMs.toFixed(6)} | ${x.optimizedMedianMs.toFixed(6)} | **${x.speedup.toFixed(2)}×** | ${x.pairedBootstrap95[0].toFixed(2)}–${x.pairedBootstrap95[1].toFixed(2)}× |`),''];fs.writeFileSync(path.join(d,'V1.6_V1.7_ISOLATED.md'),md.join('\n'));
console.log(JSON.stringify(output.summary,null,2));
