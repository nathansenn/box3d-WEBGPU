'use strict';
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const resultsDir = path.join(root, 'benchmarks/results');
const shardFiles = fs.readdirSync(resultsDir)
  .filter((name) => /^v1\.8-fourth-breakthrough-shard-\d+-\d+\.json$/.test(name))
  .sort((a, b) => Number(a.match(/shard-(\d+)/)[1]) - Number(b.match(/shard-(\d+)/)[1]));
if (!shardFiles.length) throw new Error('no v1.8 shard files found');
const shards = shardFiles.map((name) => JSON.parse(fs.readFileSync(path.join(resultsDir, name), 'utf8')));
const records = shards.flatMap((shard) => shard.experiments).sort((a, b) => a.id - b.id);
if (records.length !== 100) throw new Error(`expected 100 merged records, received ${records.length}`);
for (let i = 0; i < 100; i++) if (records[i].id !== i + 1) throw new Error(`missing or duplicate experiment ${i + 1}`);
function median(values) { const sorted = [...values].sort((a, b) => a - b), m = sorted.length >> 1; return sorted.length & 1 ? sorted[m] : (sorted[m - 1] + sorted[m]) * 0.5; }
function geometricMean(values) { return Math.exp(values.reduce((sum, value) => sum + Math.log(value), 0) / values.length); }
const counts = { accepted: 0, borderline: 0, control: 0, 'rejected-no-win': 0, 'rejected-correctness': 0 };
for (const record of records) counts[record.status]++;
const categoryNames = [...new Set(records.map((entry) => entry.category))];
const categories = Object.fromEntries(categoryNames.map((name) => {
  const entries = records.filter((entry) => entry.category === name);
  return [name, {
    count: entries.length,
    geometricMeanSpeedup: geometricMean(entries.map((entry) => entry.speedup)),
    medianSpeedup: median(entries.map((entry) => entry.speedup)),
    accepted: entries.filter((entry) => entry.status === 'accepted').length,
    controls: entries.filter((entry) => entry.status === 'control').length,
  }];
}));
const output = {
  schema: 1,
  generatedAt: new Date().toISOString(),
  environment: shards[0].environment,
  method: { ...shards[0].method, shardedExecution: true, shardFiles },
  summary: {
    experimentCount: 100,
    ...Object.fromEntries(Object.entries(counts).map(([key, value]) => [`${key}Count`, value])),
    elapsedMs: shards.reduce((sum, shard) => sum + (shard.elapsedMs || 0), 0),
    categories,
    maximumSpeedup: Math.max(...records.map((entry) => entry.speedup)),
    medianSpeedup: median(records.map((entry) => entry.speedup)),
    changedPathGeometricMeanSpeedup: geometricMean(records.filter((entry) => !entry.category.endsWith('-control')).map((entry) => entry.speedup)),
  },
  experiments: records,
};
fs.writeFileSync(path.join(resultsDir, 'v1.8-fourth-breakthrough-100.json'), JSON.stringify(output, null, 2));
const quote = (value) => `"${String(value).replaceAll('"', '""')}"`;
const csvHeader = ['id','category','sceneId','scene','operation','rain','status','baselineMedianMs','optimizedMedianMs','speedup','stateRelativeL2','visualNormalRelativeL2','visualColorRms','visualColorMax','visualUvMax','baselineDynamicVertexBytes','optimizedDynamicStateBytes','byteReduction'];
const csv = [csvHeader.join(','), ...records.map((entry) => [entry.id, entry.category, entry.sceneId, quote(entry.scene), entry.operation, entry.rain, entry.status, entry.baselineMedianMs, entry.optimizedMedianMs, entry.speedup, entry.correctness.stateRelativeL2, entry.correctness.visualNormalRelativeL2, entry.correctness.visualColorRms, entry.correctness.visualColorMax, entry.correctness.visualUvMax, entry.payload.baselineDynamicVertexBytes, entry.payload.optimizedDynamicStateBytes, entry.payload.byteReduction].join(','))].join('\n');
fs.writeFileSync(path.join(resultsDir, 'v1.8-fourth-breakthrough-100.csv'), `${csv}\n`);
const md = ['# v1.8 Fourth Breakthrough — 100 Production-Path Experiments','',`- Accepted changed paths: **${counts.accepted}**`,`- Borderline changed paths: **${counts.borderline}**`,`- Unchanged-path controls: **${counts.control}**`,`- Rejected, no win: **${counts['rejected-no-win']}**`,`- Rejected, correctness: **${counts['rejected-correctness']}**`,`- Changed-path geometric mean: **${output.summary.changedPathGeometricMeanSpeedup.toFixed(2)}×**`,`- Maximum measured speedup: **${output.summary.maximumSpeedup.toFixed(2)}×**`,'','| Category | Tests | Geometric mean | Median | Accepted | Controls |','|---|---:|---:|---:|---:|---:|',...Object.entries(categories).map(([name,value])=>`| ${name} | ${value.count} | ${value.geometricMeanSpeedup.toFixed(2)}× | ${value.medianSpeedup.toFixed(2)}× | ${value.accepted} | ${value.controls} |`),'','Raw samples, visual-fidelity metrics, and upload-byte evidence are in the JSON result.',''];
fs.writeFileSync(path.join(resultsDir, 'V1.8_FOURTH_BREAKTHROUGH_100.md'), md.join('\n'));
console.log(JSON.stringify(output.summary, null, 2));
