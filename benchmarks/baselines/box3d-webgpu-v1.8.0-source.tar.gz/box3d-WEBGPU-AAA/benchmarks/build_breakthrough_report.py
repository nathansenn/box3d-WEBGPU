#!/usr/bin/env python3
"""Generate v1.5 performance documentation from benchmark evidence."""

from __future__ import annotations

import json
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "benchmarks" / "results"


def read_json(name: str) -> dict:
    with (RESULTS / name).open("r", encoding="utf-8") as handle:
        return json.load(handle)


def percent(value: float) -> str:
    return f"{value * 100:.4f}%"


def main() -> None:
    tournament = read_json("v1.5-breakthrough-100.json")
    isolated = read_json("v1.4-v1.5-isolated.json")
    results = isolated["results"]
    status = Counter(entry["status"] for entry in tournament["experiments"])
    categories = Counter(entry["category"] for entry in tournament["experiments"])
    exact = [name for name, value in results.items() if value["exactHash"]]
    approximate = [
        name
        for name, value in results.items()
        if value.get("positionError") and value["positionError"]["relativeL2"] > 0
    ]
    rejected = [
        entry
        for entry in tournament["experiments"]
        if entry["status"] == "rejected-correctness"
    ]

    workload_rows = []
    for name, value in results.items():
        if value["exactHash"]:
            relation = "exact hash"
        elif value.get("positionError"):
            relation = "bounded approximation"
        else:
            relation = "deterministic reordered solver"
        error = percent(value["positionError"]["relativeL2"]) if value.get("positionError") else "n/a"
        workload_rows.append(
            f"| {name} | {value['baselineMedianMs']:.4f} | {value['optimizedMedianMs']:.4f} | "
            f"**{value['ratioOfMediansSpeedup']:.2f}×** | "
            f"{value['pairedBootstrap95']['lower95']:.2f}–{value['pairedBootstrap95']['upper95']:.2f}× | "
            f"{relation} | {error} |"
        )

    category_rows = "\n".join(f"| {name} | {count} |" for name, count in categories.items())
    fastest_rows = "\n".join(
        f"| {entry['id']} | {entry['category']}: {entry['candidate']} | "
        f"**{entry['speedup']:.2f}×** | {entry['status']} |"
        for entry in tournament["fastest"][:15]
    )
    exact_lines = "\n".join(f"- {name}" for name in exact)
    approximate_lines = "\n".join(
        f"- {name}: {percent(results[name]['positionError']['relativeL2'])} relative L2 error"
        for name in approximate
    )
    rejected_lines = "\n".join(
        f"- Experiment {entry['id']}, {entry['category']}, {entry['candidate']}: "
        f"`{json.dumps(entry['correctness'], separators=(',', ':'))}`"
        for entry in rejected
    )

    rope_rain_count = results["rope-rain"].get("optimizedSpawnedRain", 96)
    cloth_rain_count = results["cloth-rain"].get("optimizedSpawnedRain", 150)

    report = f"""# Box3D WebGPU AAA v1.5.0 — Breakthrough Performance Report

## Executive result

Version 1.5.0 applies the winning candidates from an exactly **100-experiment** optimization tournament to the real simulation and rendering-preparation source. It then compares the integrated build with the bundled v1.4.0 baseline using complete simulation-plus-frame workloads.

The stricter fresh-process benchmark measured:

- **{isolated['aggregate']['geometricMeanSpeedup']:.2f}× geometric-mean speedup** across ten representative workloads;
- **{isolated['aggregate']['medianSpeedup']:.2f}× median workload speedup**;
- **{results['cloth-rain']['ratioOfMediansSpeedup']:.2f}×** for maximum cloth under a {cloth_rain_count}-projectile impact storm;
- **{results['rope-rain']['ratioOfMediansSpeedup']:.2f}×** for maximum rope under its {rope_rain_count}-projectile cap;
- **{results['rigid-bridge']['ratioOfMediansSpeedup']:.2f}×** for the dense bridge preview scene;
- no meaningful steady-rope regression: **{results['rope-steady']['ratioOfMediansSpeedup']:.3f}×**, with the paired confidence interval spanning parity.

These ratios are measured independently. They are not multiplied into an artificial “total engine” number.

## Fresh-process integrated proof

{isolated['method']}

| Workload | v1.4 ms | v1.5 ms | Speedup | Paired bootstrap 95% CI | Replay relation | Position error |
|---|---:|---:|---:|---:|---|---:|
{chr(10).join(workload_rows)}

The confidence intervals are paired bootstrap intervals over fresh-process sample speed ratios. They characterize this Linux/x64 Node environment and these workloads, not every browser, CPU, or GPU.

## 100-experiment tournament

| Outcome | Count |
|---|---:|
| Accepted measured wins | {status['accepted']} |
| Borderline / within noise | {status['borderline']} |
| Rejected — no speed win | {status['rejected-no-win']} |
| Rejected — correctness or visual fidelity | {status['rejected-correctness']} |
| **Total** | **{tournament['experimentCount']}** |

Experiment families:

| Family | Experiments |
|---|---:|
{category_rows}

Every JSON experiment record includes raw samples, medians, speedup, a quality/correctness object, and the accept/reject decision. The complete index is in `benchmarks/results/V1.5_BREAKTHROUGH_100.md`; machine-readable evidence is in `v1.5-breakthrough-100.json` and `.csv`.

### Fastest search results

| # | Candidate | Speedup | Decision |
|---:|---|---:|---|
{fastest_rows}

The tournament numbers are search measurements. The fresh-process integrated table above is the release-level proof for the actual selected source. Rope tournament loads stay at or below the real 96-projectile solver cap; the evidence records executed, not merely requested, work.

## Integrated optimizations

### 1. Hierarchical cloth projection

Non-tearing cloth now separates packed structural, shear, and bend constraints. Structural links run every projection pass; shear and bend run at measured lower cadences with pass-count stiffness compensation. The maximum fast schedule is eight iterations and two integration substeps. Tearing scenes retain the original full constraint order and remain exact-hash equivalent in the integrated test.

For representative non-tearing cloth, the selected schedule produced relative position errors of:

- steady cloth: **{percent(results['cloth-steady']['positionError']['relativeL2'])}**;
- impact-storm cloth: **{percent(results['cloth-rain']['positionError']['relativeL2'])}**.

Both remain below the 0.2% release ceiling. The exact values, RMSE, and maximum absolute delta are in the JSON evidence.

### 2. Broad rejection for projectile coupling

Cloth and rope first reject entire projectile paths against the active particle AABB. Only surviving projectiles enter particle narrow phase, where squared distance rejects misses before a square root. This removes the previous O(projectiles × all particles) cost for distant rain/impact particles while preserving exact rope replay output.

### 3. Coherent sweep-and-prune rigid preview

The deterministic JavaScript preview backend replaces its quadratic candidate scan with a longest-axis sweep-and-prune broadphase. Typed order/bounds arrays are retained across frames and insertion-sorted, taking advantage of temporal coherence. A scalar in-place AABB resolver removes temporary vector allocations.

The collision pair order is intentionally different from v1.4, so preview hashes differ across versions. Within v1.5, repeated runs remain deterministic, finite, and preserve body/dynamic counts. The native Box3D WASM backend is not changed by this preview optimization.

### 4. Dynamic surface preparation

Intact cloth grids derive normals from central tangents in O(vertices), while torn cloth keeps triangle accumulation so holes and disconnected topology shade correctly. Packed RGBA uses a shared 32-bit write on little-endian hosts with an explicit byte fallback elsewhere. Typed-array conversion replaces repeated scalar rounding.

### 5. Allocation-free cinematic effects

Effect particles and shockwaves compact in place. Matrix/color output uses geometrically grown reusable buffers, debug-line objects are reused, and shockwave rings use trigonometric recurrence rather than repeated per-segment sine/cosine calls.

## Correctness and quality decisions

Exact v1.4 replay hashes were retained for:

{exact_lines}

Bounded, deterministic cloth approximation is used for:

{approximate_lines}

The following tournament candidates were rejected specifically because output equivalence or visual quality failed:

{rejected_lines}

This is why v1.5 does not simply enable every candidate that benchmarked quickly.

## Reproduce the evidence

Compile the benchmark modules:

```bash
npm run bench:breakthrough:compile
```

Run exactly 100 experiments:

```bash
npm run bench:breakthrough:100
```

Run the quick same-process integrated comparison:

```bash
npm run bench:breakthrough:integrated
```

Run the stricter fresh-process proof:

```bash
BREAKTHROUGH_SAMPLES={isolated['sampleCount']} BREAKTHROUGH_BOOTSTRAPS={isolated['bootstrapCount']} npm run bench:breakthrough:isolated
```

Run all validation and benchmark gates:

```bash
npm run validate:breakthrough
```

## Evidence boundary

- Timings cover CPU simulation and CPU frame construction in Node, not physical-GPU execution.
- Dawn tests validate WebGPU shaders, resources, pipelines, and command submission; they do not provide target-device frame timing.
- The native Box3D WASM solver was not recompiled by these JavaScript preview/soft-system optimizations.
- A target-browser benchmark on the intended Mac/GPU remains required before quoting browser FPS.
- TurboQuant remains disabled on the local frame path because v1.4 proved it slows local Worker transport despite reducing bytes.

## Next performance frontier

The remaining large opportunities require architecture changes rather than more scalar cleanup:

1. worker-owned soft simulation with SharedArrayBuffer double buffering;
2. WASM SIMD kernels for constraints and shallow water;
3. WebGPU compute cloth and water solvers;
4. GPU compaction and indirect drawing;
5. spatial partitioning for cloth/rigid bidirectional coupling;
6. GPU timestamp-query profiling on supported target hardware;
7. multithreaded native Box3D with cross-origin isolation.
"""

    (ROOT / "docs" / "PERFORMANCE_V1.5.md").write_text(report, encoding="utf-8")
    (ROOT / "PERFORMANCE.md").write_text(
        "# Performance Edition v1.5.0\n\n"
        "The current measured optimization report is "
        "[docs/PERFORMANCE_V1.5.md](docs/PERFORMANCE_V1.5.md).\n\n"
        "Reproducible baselines are bundled under `benchmarks/baselines/`. "
        "Run `npm run bench:breakthrough` for the 100-experiment tournament, "
        "same-process integrated comparison, fresh-process proof, and evidence gate.\n",
        encoding="utf-8",
    )

    changes = {
        "schema": 1,
        "version": "1.5.0",
        "generatedAt": isolated["generatedAt"],
        "tournament": {
            "experiments": tournament["experimentCount"],
            "accepted": tournament["acceptedCount"],
            "rejectedCorrectness": tournament["rejectedCorrectnessCount"],
        },
        "integratedFreshProcess": {
            "geometricMeanSpeedup": isolated["aggregate"]["geometricMeanSpeedup"],
            "medianSpeedup": isolated["aggregate"]["medianSpeedup"],
            "sampleCount": isolated["sampleCount"],
            "bootstrapCount": isolated["bootstrapCount"],
            "results": {
                name: {
                    "baselineMedianMs": value["baselineMedianMs"],
                    "optimizedMedianMs": value["optimizedMedianMs"],
                    "speedup": value["ratioOfMediansSpeedup"],
                    "confidence95": [
                        value["pairedBootstrap95"]["lower95"],
                        value["pairedBootstrap95"]["upper95"],
                    ],
                    "exactHash": value["exactHash"],
                    "relativePositionError": (
                        value["positionError"]["relativeL2"]
                        if value.get("positionError")
                        else None
                    ),
                    "spawnedRain": value.get("optimizedSpawnedRain", 0),
                }
                for name, value in results.items()
            },
        },
        "changedRuntimeFiles": [
            "src/soft/packed-surface.ts",
            "src/soft/simulations.ts",
            "src/physics/fallback.ts",
            "src/effects.ts",
        ],
        "techniques": [
            "hierarchical cloth constraint scheduling with stiffness compensation",
            "particle-AABB and squared-distance projectile rejection",
            "coherent longest-axis sweep-and-prune preview broadphase",
            "scalar in-place AABB resolution",
            "central-difference intact-grid cloth normals",
            "endianness-safe packed RGBA writes",
            "in-place particle/shockwave compaction and reusable effect streams",
        ],
    }
    (ROOT / "PERFORMANCE_CHANGES.json").write_text(
        json.dumps(changes, indent=2) + "\n", encoding="utf-8"
    )
    print(
        f"wrote v1.5 report: {tournament['experimentCount']} experiments, "
        f"{isolated['aggregate']['geometricMeanSpeedup']:.2f}x geometric mean"
    )


if __name__ == "__main__":
    main()
