'use strict';

/**
 * Fresh-process v1.4 -> v1.5 comparison.
 * Each timing sample launches a new Node process, so baseline and optimized
 * modules cannot share JIT state, caches, globals, or garbage-collector history.
 */

const fs = require('node:fs');
const path = require('node:path');
const { execFileSync } = require('node:child_process');

const root = path.resolve(__dirname, '..');
const worker = path.join(root, 'benchmarks', 'breakthrough-worker.cjs');
const resultsDir = path.join(root, 'benchmarks', 'results');
const sampleCount = Math.max(5, Number.parseInt(process.env.BREAKTHROUGH_SAMPLES || '5', 10));
const bootstrapCount = Math.max(1000, Number.parseInt(process.env.BREAKTHROUGH_BOOTSTRAPS || '5000', 10));
const workloads = [
  'cloth-steady', 'cloth-rain', 'cloth-sphere', 'cloth-tear',
  'rope-steady', 'rope-rain', 'water',
  'rigid-grid', 'rigid-bridge', 'rigid-material',
];

function median(values) {
  const sorted = [...values].sort((a, b) => a - b);
  const middle = sorted.length >> 1;
  return sorted.length & 1 ? sorted[middle] : (sorted[middle - 1] + sorted[middle]) * 0.5;
}
function mad(values) {
  const center = median(values);
  return median(values.map((value) => Math.abs(value - center)));
}
function percentile(sorted, q) {
  const index = (sorted.length - 1) * q;
  const lower = Math.floor(index);
  const upper = Math.ceil(index);
  if (lower === upper) return sorted[lower];
  return sorted[lower] + (sorted[upper] - sorted[lower]) * (index - lower);
}
function run(version, workload, detail = false) {
  const args = [worker, version, workload];
  if (detail) args.push('--detail');
  let lastError = null;
  for (let attempt = 0; attempt < 3; attempt++) {
    try {
      const output = execFileSync(process.execPath, args, {
        cwd: root,
        encoding: 'utf8',
        stdio: ['ignore', 'pipe', 'inherit'],
        maxBuffer: 16 * 1024 * 1024,
        timeout: 30_000,
        killSignal: 'SIGKILL',
      });
      return JSON.parse(output);
    } catch (error) {
      lastError = error;
      console.error(`retry ${attempt + 1}/3 after ${version}/${workload} worker failure: ${error.message}`);
    }
  }
  throw lastError;
}
function positionError(a, b) {
  if (!a || !b || a.length !== b.length) return null;
  let errorSquared = 0;
  let referenceSquared = 0;
  let maxAbsolute = 0;
  for (let i = 0; i < a.length; i++) {
    const delta = b[i] - a[i];
    errorSquared += delta * delta;
    referenceSquared += a[i] * a[i];
    maxAbsolute = Math.max(maxAbsolute, Math.abs(delta));
  }
  return {
    relativeL2: Math.sqrt(errorSquared / Math.max(1e-30, referenceSquared)),
    rmse: Math.sqrt(errorSquared / a.length),
    maxAbsolute,
  };
}
function bootstrapPairedGeomean(ratios, count) {
  let state = 0x51f15e5d;
  const random = () => {
    state = (Math.imul(state, 1664525) + 1013904223) >>> 0;
    return state / 0x100000000;
  };
  const samples = new Float64Array(count);
  for (let sample = 0; sample < count; sample++) {
    let logSum = 0;
    for (let i = 0; i < ratios.length; i++) {
      logSum += Math.log(ratios[Math.floor(random() * ratios.length)]);
    }
    samples[sample] = Math.exp(logSum / ratios.length);
  }
  samples.sort();
  return {
    lower95: percentile(samples, 0.025),
    median: percentile(samples, 0.5),
    upper95: percentile(samples, 0.975),
  };
}

const results = {};
for (const workload of workloads) {
  const baselineSamples = [];
  const optimizedSamples = [];
  const baselineHashes = [];
  const optimizedHashes = [];
  for (let sample = 0; sample < sampleCount; sample++) {
    const order = sample % 2 === 0 ? ['baseline', 'optimized'] : ['optimized', 'baseline'];
    for (const version of order) {
      const result = run(version, workload);
      if (!result.finite) throw new Error(`${version}/${workload} produced non-finite output`);
      if (version === 'baseline') {
        baselineSamples.push(result.msPerFrame);
        baselineHashes.push(result.hash);
      } else {
        optimizedSamples.push(result.msPerFrame);
        optimizedHashes.push(result.hash);
      }
    }
  }
  const baselineDetail = run('baseline', workload, true);
  const optimizedDetail = run('optimized', workload, true);
  const ratios = baselineSamples.map((value, index) => value / optimizedSamples[index]);
  const baselineMedianMs = median(baselineSamples);
  const optimizedMedianMs = median(optimizedSamples);
  const entry = {
    baselineMedianMs,
    optimizedMedianMs,
    medianRatioSpeedup: median(ratios),
    ratioOfMediansSpeedup: baselineMedianMs / optimizedMedianMs,
    pairedBootstrap95: bootstrapPairedGeomean(ratios, bootstrapCount),
    baselineMadMs: mad(baselineSamples),
    optimizedMadMs: mad(optimizedSamples),
    baselineSamplesMs: baselineSamples,
    optimizedSamplesMs: optimizedSamples,
    pairedRatios: ratios,
    baselineDeterministic: new Set(baselineHashes).size === 1,
    optimizedDeterministic: new Set(optimizedHashes).size === 1,
    exactHash: baselineDetail.hash === optimizedDetail.hash,
    baselineHash: baselineDetail.hash,
    optimizedHash: optimizedDetail.hash,
    positionError: positionError(baselineDetail.positions, optimizedDetail.positions),
    sameNodeCount: baselineDetail.nodes === optimizedDetail.nodes,
    sameConstraintCount: baselineDetail.constraints === optimizedDetail.constraints,
    sameBodyCount: baselineDetail.bodies === optimizedDetail.bodies,
    sameDynamicCount: baselineDetail.dynamic === optimizedDetail.dynamic,
    baselineSpawnedRain: baselineDetail.spawnedRain ?? 0,
    optimizedSpawnedRain: optimizedDetail.spawnedRain ?? 0,
  };
  results[workload] = entry;
  console.log(`${workload.padEnd(16)} ${baselineMedianMs.toFixed(4)} -> ${optimizedMedianMs.toFixed(4)} ms  ${entry.ratioOfMediansSpeedup.toFixed(2)}x  CI ${entry.pairedBootstrap95.lower95.toFixed(2)}-${entry.pairedBootstrap95.upper95.toFixed(2)}x`);
}

const geomean = (values) => Math.exp(values.reduce((sum, value) => sum + Math.log(value), 0) / values.length);
const aggregateRatios = Object.values(results).map((entry) => entry.ratioOfMediansSpeedup);
const output = {
  schema: 1,
  generatedAt: new Date().toISOString(),
  environment: { node: process.version, platform: process.platform, arch: process.arch },
  method: `${sampleCount} fresh-process paired samples per workload, alternating version order; medians, MAD, paired speed ratios, and ${bootstrapCount}-resample paired bootstrap confidence intervals. Timers cover complete simulation plus frame construction, not process startup.`,
  sampleCount,
  bootstrapCount,
  aggregate: {
    geometricMeanSpeedup: geomean(aggregateRatios),
    medianSpeedup: median(aggregateRatios),
    minimumSpeedup: Math.min(...aggregateRatios),
    maximumSpeedup: Math.max(...aggregateRatios),
  },
  results,
};
fs.mkdirSync(resultsDir, { recursive: true });
fs.writeFileSync(path.join(resultsDir, 'v1.4-v1.5-isolated.json'), JSON.stringify(output, null, 2));
const lines = [
  '# v1.4 → v1.5 Fresh-Process Performance Proof', '', output.method, '',
  `- Geometric-mean speedup across the ten workloads: **${output.aggregate.geometricMeanSpeedup.toFixed(2)}×**`,
  `- Median workload speedup: **${output.aggregate.medianSpeedup.toFixed(2)}×**`, '',
  '| Workload | v1.4 ms | v1.5 ms | Speedup | Paired 95% CI | Deterministic | Exact hash | Relative position error |',
  '|---|---:|---:|---:|---:|---:|---:|---:|',
  ...Object.entries(results).map(([name, entry]) => {
    const error = entry.positionError ? `${(entry.positionError.relativeL2 * 100).toFixed(4)}%` : 'n/a';
    return `| ${name} | ${entry.baselineMedianMs.toFixed(4)} | ${entry.optimizedMedianMs.toFixed(4)} | **${entry.ratioOfMediansSpeedup.toFixed(2)}×** | ${entry.pairedBootstrap95.lower95.toFixed(2)}–${entry.pairedBootstrap95.upper95.toFixed(2)}× | ${entry.optimizedDeterministic ? 'yes' : 'no'} | ${entry.exactHash ? 'yes' : 'no'} | ${error} |`;
  }), '',
  'The confidence interval is a paired bootstrap over per-sample baseline/optimized speed ratios. It describes this environment and workload set; it is not a universal hardware guarantee.', '',
];
fs.writeFileSync(path.join(resultsDir, 'V1.4_V1.5_ISOLATED.md'), lines.join('\n'));
