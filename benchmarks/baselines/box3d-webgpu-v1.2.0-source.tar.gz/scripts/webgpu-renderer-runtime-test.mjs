import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import ts from 'typescript';
import { create, globals } from 'webgpu';

Object.assign(globalThis, globals);
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const rendererSource = fs.readFileSync(path.join(root, 'src/webgpu/renderer.ts'), 'utf8');
const runtimeDir = path.join(root, '.test-build');
fs.mkdirSync(runtimeDir, { recursive: true });
const runtimeModulePath = path.join(runtimeDir, 'renderer-runtime.mjs');
const transpiledRenderer = ts.transpileModule(rendererSource, {
  compilerOptions: {
    target: ts.ScriptTarget.ES2022,
    module: ts.ModuleKind.ES2022,
    importsNotUsedAsValues: ts.ImportsNotUsedAsValues.Remove,
  },
  fileName: 'renderer.ts',
}).outputText;
fs.writeFileSync(runtimeModulePath, transpiledRenderer);

let gpu = create(['backend=null']);
Object.defineProperty(globalThis, 'navigator', {
  configurable: true,
  value: { gpu },
});
Object.defineProperty(globalThis, 'window', {
  configurable: true,
  value: { devicePixelRatio: 1 },
});

let configuredDevice;
let configuredFormat;
let currentTexture;
const canvas = {
  clientWidth: 96,
  clientHeight: 64,
  width: 0,
  height: 0,
  getContext(kind) {
    return kind === 'webgpu' ? context : null;
  },
};
const context = {
  configure(options) {
    configuredDevice = options.device;
    configuredFormat = options.format;
  },
  getCurrentTexture() {
    currentTexture?.destroy();
    assert.ok(configuredDevice, 'canvas context must be configured before rendering');
    assert.ok(configuredFormat, 'canvas context must have a preferred format');
    currentTexture = configuredDevice.createTexture({
      label: 'AAA test swapchain texture',
      size: [Math.max(1, canvas.width), Math.max(1, canvas.height)],
      format: configuredFormat,
      usage: GPUTextureUsage.RENDER_ATTACHMENT | GPUTextureUsage.COPY_SRC,
    });
    return currentTexture;
  },
};

const { WebGPURenderer } = await import(`${pathToFileURL(runtimeModulePath).href}?v=${Date.now()}`);
const renderer = await WebGPURenderer.create(canvas, 8);
const runtimeErrors = [];
renderer.device.addEventListener?.('uncapturederror', (event) => {
  runtimeErrors.push(event.error?.message ?? String(event.error));
});
const identity = [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1];
const quality = {
  id: 'cinematic',
  label: 'Cinematic',
  exposure: 1.1,
  bloomStrength: 0.5,
  fogDensity: 0.006,
  shadowStrength: 1,
  effectBudget: 64,
  resolutionScale: 1,
};
renderer.writeSceneUniforms({
  viewProjection: identity,
  lightViewProjection: identity,
  cameraPosition: [0, 4, 8],
  lightDirection: [0.42, -0.84, 0.34],
  fogColor: [0.055, 0.085, 0.14],
  timeSeconds: 1,
  quality,
});
const heap = new Float32Array(20);
heap.set(identity, 0);
heap.set([0.8, 0.4, 0.2, 1], 16);
const source = {
  HEAPF32: heap,
  _b3w_matrices_ptr: () => 0,
  _b3w_colors_ptr: () => 16 * Float32Array.BYTES_PER_ELEMENT,
};
assert.equal(renderer.uploadInstances(source, 1), 20 * Float32Array.BYTES_PER_ELEMENT);
const firstRenderMs = renderer.render(1, [{
  ax: -1, ay: 0, az: 0,
  bx: 1, by: 0, bz: 0,
  r: 1, g: 0.5, b: 0.2, a: 0.8,
}]);
assert.ok(Number.isFinite(firstRenderMs) && firstRenderMs >= 0, 'actual renderer must submit the shadow/HDR/post frame');
await renderer.device.queue.onSubmittedWorkDone();
assert.deepEqual(renderer.viewport(), [96, 64]);
assert.ok(renderer.uploadedMegabytes() > 0, 'actual renderer must account for instance uploads');

const surfaceVertices = new Float32Array([
  -1.5, 2.2, -1.5, 0, 1, 0, 0.08, 0.42, 0.82, 0.15, 0, 0,
   1.5, 2.2, -1.5, 0, 1, 0, 0.16, 0.58, 0.92, 0.35, 1, 0,
  -1.5, 2.2,  1.5, 0, 1, 0, 0.20, 0.70, 1.00, 0.62, 0, 1,
   1.5, 2.2,  1.5, 0, 1, 0, 0.34, 0.82, 1.00, 0.90, 1, 1,
]);
const surfaceIndices = new Uint32Array([0, 2, 1, 1, 2, 3]);
const clothBytes = renderer.uploadSurface({
  material: 'cloth',
  vertices: surfaceVertices,
  indices: surfaceIndices,
  vertexCount: 4,
  indexCount: 6,
});
assert.equal(clothBytes, surfaceVertices.byteLength + surfaceIndices.byteLength);
const clothRenderMs = renderer.render(1, []);
assert.ok(Number.isFinite(clothRenderMs) && clothRenderMs >= 0, 'actual renderer must submit a cloth shadow/surface frame');
await renderer.device.queue.onSubmittedWorkDone();

const waterBytes = renderer.uploadSurface({
  material: 'water',
  vertices: surfaceVertices,
  indices: surfaceIndices,
  vertexCount: 4,
  indexCount: 6,
});
assert.equal(waterBytes, surfaceVertices.byteLength + surfaceIndices.byteLength);
const waterRenderMs = renderer.render(1, []);
assert.ok(Number.isFinite(waterRenderMs) && waterRenderMs >= 0, 'actual renderer must submit a translucent water frame');
await renderer.device.queue.onSubmittedWorkDone();

renderer.writeSceneUniforms({
  viewProjection: identity,
  lightViewProjection: identity,
  cameraPosition: [0, 4, 8],
  lightDirection: [0.42, -0.84, 0.34],
  fogColor: [0.055, 0.085, 0.14],
  timeSeconds: 2,
  quality: { ...quality, id: 'performance', label: 'Performance', shadowStrength: 0, resolutionScale: 0.7 },
});
renderer.uploadSurface(null);
const secondRenderMs = renderer.render(0, []);
assert.ok(Number.isFinite(secondRenderMs) && secondRenderMs >= 0, 'actual renderer must submit a zero-instance/no-shadow frame');
await renderer.device.queue.onSubmittedWorkDone();
assert.deepEqual(renderer.viewport(), [67, 44]);
assert.deepEqual(runtimeErrors, [], 'actual WebGPURenderer emitted no uncaptured WebGPU errors');

console.log('✅ Actual WebGPURenderer runtime test passed: rigid shadows, indexed cloth, translucent water, debug lines, resize, empty frame, and clean Dawn error stream');

currentTexture?.destroy();
renderer.device.destroy();
Object.defineProperty(globalThis, 'navigator', { configurable: true, value: {} });
gpu = null;
