# Repository Summary

## Box3D WebGPU AAA Physics Lab v1.1.0

| Area | Delivered |
|---|---|
| Rigid physics | Box3D C17 → Emscripten/WASM bridge plus deterministic preview backend |
| Cloth | PBD particles, structural/shear/bend constraints, pinning, wind, collision, tearing |
| Rope | PBD cables, bend links, anchors, payloads, tension visualization, controlled breakage |
| Water | Interactive 2.5D shallow-water heightfield, currents, foam, droplets, floaters |
| Catalog | 750 deterministic scenes across 15 families |
| Direction | 30 cinematic hero demonstrations and Maximum AAA Tour |
| Rendering | WebGPU instancing, indexed dynamic surfaces, HDR, 4× MSAA, shadows, fog, post |
| Diagnostics | Rigid/soft counts, constraints/cells, breaks, energy, CPU times, uploads, hashes |
| Validation | 11 unit suites, 150-scene soft soak, Dawn WGSL/pipeline/runtime, strict C17 bridge test |
| Deployment | Vite production build, GitHub Pages workflow, push scripts, source checksum manifest |

### New in v1.1.0

- 50 cloth scenes and two cloth hero demonstrations.
- 50 rope/rigging scenes and two cable hero demonstrations.
- 50 water scenes and two fluid hero demonstrations.
- Dynamic indexed cloth/water renderer path.
- Woven cloth and translucent water WGSL materials.
- Deterministic topology failure, line breakage, waves, currents, foam, droplets, and floaters.
- Permanent long-duration soft-simulation soak and C bridge syntax gates.

### Architectural boundary

Box3D owns rigid-body simulation. The soft-simulation suite owns cloth, rope, and water. WebGPU receives model matrices, material colors, dynamic indexed surfaces, and debug lines from both domains. The project does not misrepresent the current water solver as a volumetric fluid engine or the current soft systems as GPU-compute solvers.
