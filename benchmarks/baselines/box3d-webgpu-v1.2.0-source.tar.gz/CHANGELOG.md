# Changelog

## 1.2.0 — Performance Engineering Edition

- Added a reproducible 100-candidate optimization benchmark suite with raw JSON and CSV evidence.
- Added baseline-versus-optimized whole-project timing with medians and MAD noise reporting.
- Added allocation-free performance primitives, geometric capacity growth, and fixed ring-buffer utilities.
- Specialized side-effect-free vector-length and square operations in validated hot paths.
- Retained packed soft-body data layouts and cached cloth topology from the optimization branch.
- Added permanent `bench:100`, `bench:end-to-end`, `bench:all`, and `validate:performance` gates.
- Documented accepted, borderline, rejected, and future architectural candidates without multiplying unrelated benchmark ratios.

## 1.1.0 — cloth, rope, and interactive water edition

### Added

- 150 deterministic soft/fluid scenes: 50 cloth, 50 rope/rigging, and 50 water scenarios.
- Six directed hero demonstrations: Tempest Standard Protocol, Parachute Canopy Failure, Sky Crane Cable Failure, Suspension Cable Resonance, Tsunami Research Array, and Leviathan Impact Basin.
- Deterministic position-based cloth with structural, shear, and bend constraints; multiple pin layouts; wind; collision; strain visualization; controlled tearing; and topology holes.
- Deterministic rope/cable PBD with anchors, payloads, bend links, catenaries, cross-links, tension coloring, projectile severing, and controlled breakage.
- Interactive 2.5D linear shallow-water simulation with height/velocity fields, reflected boundaries, waves, wakes, fountains, rain, dam-break fronts, vortices, floaters, foam, and impact displacement.
- Indexed dynamic-surface upload path for cloth and water, including dedicated surface-shadow, woven-cloth, and translucent-water WebGPU pipelines.
- Soft-system command-deck telemetry for solver type, nodes, constraints/cells, broken links, energy, and combined replay hash.
- `npm run test:soft-soak` for all 150 soft/fluid scenes and paired deterministic deep replays.
- `npm run test:cbridge` for strict C17 bridge syntax/API-contract validation with warnings as errors.
- Detailed cloth/rope/water architecture and validation documentation.

### Changed

- Catalog expanded from 600 to 750 scenes and from 12 to 15 families.
- Hero director expanded from 24 to 30 authored sequences.
- Dawn validation expanded from five to eight WGSL modules and now covers indexed cloth/water draws.
- Renderer runtime test now uploads and renders real cloth and water surface frames.
- Soft solvers preallocate hot-path buffers and precompute constraint stiffness to avoid large per-frame allocation churn.
- Source-manifest verification now works with either GNU `sha256sum` or macOS `shasum`.

### Validation

- 11 deterministic Node suites pass.
- All 750 scenes construct and step; all 30 hero definitions validate.
- All 150 soft/fluid scenes pass finite-stream, topology, budget, action, and replay checks.
- Long-run preparation soaks covered 6,000 cloth, 9,000 rope, and 12,000 water frames without numerical corruption.
- Eight WGSL modules and the complete rigid/cloth/water frame graph pass Dawn validation with zero uncaptured errors.

## 1.0.2 — full WebGPU frame-validation hotfix

- Fixed a render-pass compatibility error discovered after the 1.0.1 shader correction: the atmospheric sky pipeline was used in a `depth24plus` render pass without declaring a matching depth/stencil state.
- Added `depthStencil: { format: 'depth24plus', depthWriteEnabled: false, depthCompare: 'always' }` to the sky pipeline so it shares the HDR pass safely without modifying depth.
- Added a Dawn-backed `npm run test:webgpu` gate using the null backend. It compiles all five WGSL modules, creates the shadow, sky, solid, line, RGBA post, and BGRA post pipelines, validates bind groups and attachments, and submits a complete offscreen shadow/HDR/post frame.
- Added a second Dawn test that transpiles and executes the actual `WebGPURenderer` class with a canvas-context shim, rendering one shadowed/debug-line frame and one resized no-shadow/zero-instance frame.
- Added a repository regression assertion for sky-pass depth compatibility.
- Fixed an illegal shadow-pass feedback loop: the writable depth map was also present in the scene sampling bind group. The shadow pass now uses a separate uniform-only layout and bind group.
- Added regression assertions that the shadow pass binds only the isolated shadow uniform group.
- Skipped zero-instance solid draw calls to remove Dawn diagnostics and avoid needless command encoding in empty scenes.
- Independently reproduced the original 1.0.0 `textureSampleCompare` failure in Dawn and confirmed that the 1.0.2 solid shader compiles with zero messages.

## 1.0.1 — WGSL shadow validation hotfix

- Fixed startup failure on strict WebGPU implementations where the PBR solid shader rejected `textureSampleCompare` in non-uniform fragment control flow.
- Replaced the shadow-map PCF lookup with `textureSampleCompareLevel`, which does not compute derivatives and has no uniform-control-flow requirement.
- Removed the per-fragment early return from the shadow lookup and masks out-of-bounds projections with `select`/`mix` after sampling.
- Added repository self-test assertions to prevent reintroducing derivative-sensitive `textureSampleCompare` in the solid shader path.

## 1.0.0 — 2026-07-10 — AAA Physics Lab Edition

### Added

- 24 directed hero demonstrations layered over the 600-scene capability catalog.
- Timed camera tracks, captions, impulses, projectiles, explosions, stress rain,
  time dilation, camera shake, and telemetry-lock beats.
- 2,048² PCF shadow mapping, four-sample MSAA, `rgba16float` HDR rendering,
  PBR-inspired GGX lighting, atmospheric sky/fog, emissive effects, bloom,
  tone mapping, vignette, and film grain.
- Performance, Balanced, Cinematic, and Ultra render profiles with real
  resolution, shadow, and effect-budget differences.
- Deterministic cinematic effects, authored scene dressing, and 624-scenario
  in-browser validation.
- A reproducible Box3D v0.1.0 Emscripten wrapper, stable C ABI, refreshed heap
  views after WASM memory growth, and safe GitHub publishing scripts.
- Detailed demo, renderer, native-port, test, publishing, and local browser
  validation documentation.
- MIT license and third-party notices.

### Corrected

- Camera elevation now uses positive pitch consistently, keeping catalog and
  cinematic cameras above their targets rather than below the ground plane.
- Non-uniform instance scaling now uses a normalized rotation basis for normal
  transformation, preventing distorted lighting on beams and slabs.
- Native build topology now wraps Box3D as a subproject rather than inheriting
  inappropriate top-level browser thread settings.
- Emscripten heap access now refreshes typed-array views after memory growth.

### Validation

- Strict TypeScript passed.
- Nine deterministic suites passed.
- All 600 catalog scenes constructed successfully.
- All 24 hero timelines passed camera/beat validation.
- Production and GitHub Pages builds passed.
- npm audit reported zero moderate-or-higher vulnerabilities.
- Native bridge passed strict C17 syntax checking with warnings as errors.
