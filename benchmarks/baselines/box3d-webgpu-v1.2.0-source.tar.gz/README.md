# Box3D WebGPU — AAA Physics Lab

> **v1.2.0 Performance Edition:** 100 measured optimization candidates, whole-project baseline comparisons, raw evidence, and reproducible performance gates. See [`docs/PERFORMANCE_OPTIMIZATION_REPORT.md`](docs/PERFORMANCE_OPTIMIZATION_REPORT.md).


A browser-native 3D simulation showcase that combines **Box3D rigid-body physics**, deterministic **position-based cloth and rope**, an interactive **shallow-water solver**, and an HDR **WebGPU** renderer.

```text
Box3D C17 / WebAssembly                 TypeScript soft-simulation layer
rigid bodies, collisions, impacts       cloth PBD · rope PBD · shallow water
                 \                         /
                  \ fixed-step coordinator /
                   transform + material + dynamic-surface streams
                                      ↓
                     WebGPU shadows / HDR / MSAA / post
                                      ↓
                     750 deterministic capability scenes
                     30 cinematic hero demonstrations
```

> **Version 1.1.0:** adds 150 cloth, rope, and water scenes; six new directed hero demonstrations; indexed dynamic-surface rendering; woven-cloth and translucent-water WGSL pipelines; soft-system telemetry; deterministic tearing and cable breakage; water currents, foam, droplets, and buoyancy proxies; deep numerical soak tests; and a strict C17 bridge syntax gate.

This is an **AAA-style capability lab and production foundation**, not a claim that every system of a finished commercial engine is complete. The project concentrates on physics behavior, deterministic testability, high-volume WebGPU streaming, cinematic readability, and a clean architecture that can keep growing.

---

## What this edition delivers

### Rigid-body simulation

- Box3D C17 backend, compiled to WebAssembly with Emscripten.
- Fixed 60 Hz stepping with four solver substeps by default.
- Continuous collision enabled in the native bridge.
- 4,096 rigid-body slots and deterministic transform/color streams.
- Impulse, radial explosion, projectile, and body-rain actions.
- Deterministic preview backend so the application runs before the WASM artifact is built.

### Cloth simulation

- Deterministic position-based dynamics using Verlet-style integration.
- Structural, shear, and bend constraints.
- Multiple pinning layouts for banners, curtains, canopies, hammocks, sails, cargo nets, and membranes.
- Wind, turbulence, gravity, ground collision, and sphere collision.
- Strain visualization and controlled constraint failure.
- Topology-aware tears that remove affected cloth triangles.
- Projectile, blast, rain, and broad-impulse interaction.
- Dynamic normals and a two-sided woven-cloth WebGPU material.

### Rope and cable simulation

- Deterministic PBD chains with distance and bend constraints.
- Single cables, catenaries, ladders, mooring arrays, cable curtains, slings, ziplines, and rope nets.
- Fixed anchors, concentrated payloads, line tension, resonance, and controlled breakage.
- Projectile severing, explosions, stress rain, ground collision, and payload swing.
- Oriented instanced rope segments with tension-to-heat material feedback.

### Interactive water

- Stable 2.5D linear shallow-water heightfield.
- Height and horizontal velocity fields with reflected boundaries and drag.
- Ripples, storm seas, waves, wakes, fountains, rain, dam-break fronts, vortices, harbor floaters, and impact basins.
- Surface normals, curvature/speed-derived foam, droplets, current-vector diagnostics, and buoyancy proxies.
- Projectile and explosion displacement.
- Translucent WebGPU water with Fresnel response, broad and sharp specular highlights, foam, micro-waves, fog, and HDR post-processing.

### AAA WebGPU presentation

- Shared instanced rigid/rope/effect geometry.
- Indexed dynamic vertex/index streams for cloth and water.
- 2,048 × 2,048 directional shadow map with 3 × 3 PCF.
- `rgba16float` HDR scene target and four-sample MSAA.
- PBR-inspired GGX solid shading.
- Two-sided cloth lighting and transparent water rendering.
- Atmospheric sky, horizon haze, procedural stars, sun glow, and distance fog.
- ACES-inspired tone mapping, lightweight bloom, vignette, and film grain.
- Deterministic sparks, smoke, dust, shockwaves, muzzle flashes, rain flashes, and camera shake.
- Runtime WGSL compilation diagnostics.

---

## 750-scene capability matrix

The catalog is generated as:

```text
15 families × 5 presentation modes × 10 variants = 750 deterministic scenes
```

| Family | Scenes | Primary capability |
|---|---:|---|
| Stack Labs | 50 | stacked contacts, settling, buckling, sleeping |
| Domino Dynamics | 50 | thin bodies, timing, contact-wave propagation |
| Tall Structures | 50 | floors, columns, impacts, progressive collapse |
| Bridges / Infrastructure | 50 | segmented decks, concentrated loads, span failure |
| Material Labs | 50 | friction, restitution, mass, damping, ramps |
| Rain / Stress | 50 | body creation, collision density, transform bandwidth |
| Demolition | 50 | walls, fortifications, projectiles, radial disruption |
| Vehicles / Machines | 50 | moving cargo, obstacles, rollover, impact lanes |
| Marble / Toy Physics | 50 | small-body flow, pegs, ramps, timing gates |
| Construction Sites | 50 | framing, scaffolds, modular loads, crane staging |
| Warehouses / Logistics | 50 | racks, pallets, sorting lanes, inventory cascades |
| Architecture | 50 | atriums, colonnades, façades, large structures |
| **Cloth / Fabric** | **50** | folds, wind, pinning, drape, strain, tearing |
| **Rope / Rigging** | **50** | tension, payloads, anchors, resonance, breakage |
| **Water / Fluids** | **50** | wave propagation, currents, foam, wakes, impacts |

The five presentation modes increase density and direction from a clean baseline through cinematic and maximum-stress arrangements. The **30 hero sequences** add authored cameras, timed actions, slow motion, effects, and telemetry capture over selected scenes.

See [`docs/AAA_SHOWCASE.md`](docs/AAA_SHOWCASE.md) and [`docs/SOFT_BODY_AND_WATER.md`](docs/SOFT_BODY_AND_WATER.md).

---

## Six new hero demonstrations

| Hero | System | What it proves |
|---|---|---|
| **Tempest Standard Protocol** | Cloth | pinned banner, wind front, impact, tear, recovery |
| **Parachute Canopy Failure** | Cloth | curved membrane, four-corner load, puncture, failure |
| **Sky Crane Cable Failure** | Rope | payload swing, tension, line severing, residual motion |
| **Suspension Cable Resonance** | Rope | coupled catenaries, cross-links, resonance, partial failure |
| **Tsunami Research Array** | Water | traveling wave front, reflections, interference, foam |
| **Leviathan Impact Basin** | Water | rain, waves, ballistic impact, splash crown, floaters |

Press **T** or click **Maximum AAA Tour** to play all 30 hero sequences.

---

## Run immediately

From the project root—the directory containing `package.json`:

```bash
npm install
npm run dev
```

Open the localhost URL printed by Vite in a WebGPU-capable browser.

The app first attempts to load:

```text
public/box3d/box3d.js
public/box3d/box3d.wasm
```

When those files are absent, the application uses the deterministic preview backend for rigid staging. Cloth, rope, and water remain fully active because they are implemented in the TypeScript soft-simulation layer.

### Correct folder

Run npm commands here:

```text
box3d-WEBGPU/
├── package.json
├── src/
├── wasm/
└── scripts/
```

Do not run them inside `third_party/box3d/`; that folder is the upstream C/CMake dependency and intentionally has no Node `package.json`.

Verify the source and environment:

```bash
npm run verify:source
npm run doctor
```

---

## Build the native Box3D WASM backend

### 1. Activate Emscripten

```bash
git clone https://github.com/emscripten-core/emsdk.git ~/emsdk
cd ~/emsdk
./emsdk install latest
./emsdk activate latest
source ./emsdk_env.sh
```

### 2. Fetch Box3D

```bash
cd /path/to/box3d-WEBGPU
npm run fetch:box3d
```

The fetch script defaults to the pinned revision configured by the project. A deliberate override is supported:

```bash
BOX3D_REF=main npm run fetch:box3d
```

### 3. Build and run

```bash
npm run build:wasm
npm run dev
```

Generated files:

```text
public/box3d/box3d.js
public/box3d/box3d.wasm
```

The application backend badge should then report **Box3D WASM**.

---

## Controls

| Input | Action |
|---|---|
| Pointer drag | Orbit camera and leave cinematic mode |
| Mouse wheel | Zoom |
| Hero Play / Restart / Next | Control the selected cinematic demonstration |
| Maximum AAA Tour / `T` | Chain all 30 hero sequences |
| Search / family / scene | Browse all 750 scenes |
| Previous / Next / arrow keys | Step through filtered scenes |
| Random / `R` | Load a random matching scene |
| Stress | Rebuild at level 1–5 |
| Render profile | Performance, Balanced, Cinematic, or Ultra |
| Time scale | 0.25×, 0.5×, 1×, or 2× |
| Space | Broad structural/soft-system impulse |
| `E` | Radial blast; displaces cloth, cables, and water |
| `F` | Fire a projectile; can puncture cloth or sever rope |
| Rain | Spawn rigid stress bodies or soft/fluid impacts |
| `P` | Pause/resume |
| `N` | Advance one fixed frame |
| `D` | Toggle bounds, grid, axes, constraints/currents, and effects |

---

## Telemetry

The command deck reports:

```text
rigid bodies / dynamic bodies / effects
soft-system type / nodes / constraints or cells / broken links / energy
FPS / simulation CPU ms / render encode-submit CPU ms
GPU upload MB / active backend / quality profile / replay hash
```

Render-submit timing is CPU-side command encoding/submission time, not GPU timestamp-query time.

---

## Test and validate

### Standard gate

```bash
npm run validate
```

It runs:

1. strict TypeScript checking;
2. 11 deterministic Node suites;
3. constructors for all 750 scenes;
4. validation for all 30 hero timelines;
5. cloth/rope/water action and replay tests;
6. repository and UI contract checks;
7. strict C17 bridge syntax with warnings as errors;
8. Dawn validation of eight WGSL modules and all rigid/cloth/water pipelines;
9. execution of the actual renderer runtime against Dawn;
10. a production Vite build.

### Deep soft-system soak

```bash
npm run test:soft-soak
```

This builds every one of the 150 cloth/rope/water scenes, drives impulses, projectiles, blasts, and rain, validates topology and finite streams, and performs paired deterministic replays for maximum cloth, rope, and water scenes.

Increase the soak duration:

```bash
SOFT_SOAK_FRAMES=120 SOFT_DEEP_FRAMES=1200 npm run test:soft-soak
```

### Live browser gate

Inside the running app, click **Run 750 + 30 Browser Tests**. Run it once with the preview backend and again after building Box3D WASM.

Detailed plans and results:

- [`docs/TEST_PLAN.md`](docs/TEST_PLAN.md)
- [`docs/LOCAL_BROWSER_VALIDATION.md`](docs/LOCAL_BROWSER_VALIDATION.md)
- [`VALIDATION_REPORT.md`](VALIDATION_REPORT.md)

---

## Architecture and source map

```text
src/main.ts
  fixed-step coordinator, UI, camera, cinematic director, action routing,
  rigid/soft stream composition, telemetry, live browser validation

src/scenes.ts
  deterministic 750-scene catalog across 15 families

src/showcases.ts
  30 directed sequences with camera tracks and timed beats

src/soft/simulations.ts
  cloth PBD, rope PBD, shallow-water solver, tearing/breakage,
  dynamic indexed surfaces, soft-system telemetry and validation

src/effects.ts
  deterministic particles, shockwaves, dust, flashes, camera shake

src/physics/wasm.ts
  Emscripten loading and stable Box3D PhysicsBackend wrapper

src/physics/fallback.ts
  deterministic rigid staging when native WASM is unavailable

src/webgpu/renderer.ts
  rigid instancing, indexed cloth/water surfaces, shadow passes,
  HDR/MSAA, material pipelines, sky/fog/effects/post-processing

wasm/box3d_web.c
  native Box3D world and body creation, transform/color streams,
  impulses, projectiles, rain, replay hash, scene staging

scripts/soft-simulation-soak.cjs
  150-scene numerical and deterministic soft/fluid stress gate

scripts/webgpu-pipeline-test.mjs
  Dawn shader/pipeline/resource/full-frame validation

scripts/webgpu-renderer-runtime-test.mjs
  executes the actual WebGPURenderer class against Dawn
```

---

## Current technical boundaries

- Box3D is authoritative for rigid bodies; cloth and rope are deterministic CPU PBD systems in TypeScript.
- Water is an interactive **2.5D heightfield**, not a general volumetric SPH/FLIP/Navier–Stokes solver.
- Cloth/rope/water currently exchange actions and staging with rigid scenes, but they are not yet fully bidirectionally coupled to arbitrary Box3D collision shapes.
- The soft solvers run on the CPU; WebGPU currently renders their outputs. GPU-compute solvers are a future optimization path.
- The renderer supports one active dynamic indexed cloth or water surface per scene, plus instanced ropes, payloads, droplets, rigid bodies, and effects.
- The native bridge supplies rigid staging for the new families; one-to-one native recipe parity remains future work.
- A target-browser visual acceptance run and the local Emscripten build remain required before calling a specific machine/browser combination production-certified.

---

## License and attribution

This project is MIT licensed. Upstream Box3D remains under its own license and is fetched separately. See [`THIRD_PARTY_NOTICES.md`](THIRD_PARTY_NOTICES.md).
