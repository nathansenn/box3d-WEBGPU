import {
  LcgRng,
  clamp,
  isFiniteArray,
  vec3Cross,
  vec3Length,
  vec3Normalize,
  vec3Sub,
  writeModelMatrixFromEuler,
  type Vec3,
} from '../math';
import type { ScenePreset } from '../scenes';
import type { DebugLine, DynamicSurfaceFrame } from '../types';

export type SoftSimulationKind = 'none' | 'cloth' | 'rope' | 'water';

export type SoftSimulationFrame = {
  kind: SoftSimulationKind;
  label: string;
  matrices: Float32Array;
  colors: Float32Array;
  instanceCount: number;
  surface: DynamicSurfaceFrame | null;
  debugLines: readonly DebugLine[];
  nodeCount: number;
  constraintCount: number;
  brokenCount: number;
  energy: number;
  hash: number;
};

interface SoftSimulation {
  readonly kind: Exclude<SoftSimulationKind, 'none'>;
  readonly label: string;
  step(dt: number, subSteps: number): void;
  kick(strength: number): void;
  explode(center: Vec3, strength: number, radius: number): void;
  launchProjectile(position: Vec3, velocity: Vec3, size: number): number;
  spawnRain(count: number, spread: number, height: number): number;
  buildFrame(debug: boolean): SoftSimulationFrame;
  destroy(): void;
}

const EMPTY_FLOAT32 = new Float32Array(0);
const EMPTY_UINT32 = new Uint32Array(0);
const MAX_SOFT_INSTANCES = 2048;
const MAX_WATER_DROPLETS = 768;
const SURFACE_VERTEX_FLOATS = 12;

function softFamily(family: ScenePreset['family']): family is 'cloth' | 'rope' | 'water' {
  return family === 'cloth' || family === 'rope' || family === 'water';
}

function quantizedHash(values: ArrayLike<number>, count = values.length): number {
  let hash = 2166136261 >>> 0;
  const safeCount = Math.min(count, values.length);
  for (let i = 0; i < safeCount; i++) {
    const q = Math.trunc(values[i] * 1000) | 0;
    hash ^= q & 0xff; hash = Math.imul(hash, 16777619) >>> 0;
    hash ^= (q >>> 8) & 0xff; hash = Math.imul(hash, 16777619) >>> 0;
    hash ^= (q >>> 16) & 0xff; hash = Math.imul(hash, 16777619) >>> 0;
    hash ^= (q >>> 24) & 0xff; hash = Math.imul(hash, 16777619) >>> 0;
  }
  return hash >>> 0;
}

function mixColor(a: readonly number[], b: readonly number[], t: number): [number, number, number, number] {
  const u = clamp(t, 0, 1);
  return [
    a[0] + (b[0] - a[0]) * u,
    a[1] + (b[1] - a[1]) * u,
    a[2] + (b[2] - a[2]) * u,
    a[3] + (b[3] - a[3]) * u,
  ];
}

function writeSegmentMatrix(
  out: Float32Array,
  offset: number,
  a: Vec3,
  b: Vec3,
  radius: number,
): void {
  const delta: Vec3 = [b[0] - a[0], b[1] - a[1], b[2] - a[2]];
  const length = Math.max(0.0001, vec3Length(delta));
  const y: Vec3 = [delta[0] / length, delta[1] / length, delta[2] / length];
  const reference: Vec3 = Math.abs(y[1]) < 0.94 ? [0, 1, 0] : [1, 0, 0];
  let x = vec3Normalize(vec3Cross(reference, y));
  if (vec3Length(x) < 1e-5) x = [1, 0, 0];
  const z = vec3Normalize(vec3Cross(y, x));
  const halfLength = length * 0.5;

  out[offset + 0] = x[0] * radius;
  out[offset + 1] = x[1] * radius;
  out[offset + 2] = x[2] * radius;
  out[offset + 3] = 0;
  out[offset + 4] = y[0] * halfLength;
  out[offset + 5] = y[1] * halfLength;
  out[offset + 6] = y[2] * halfLength;
  out[offset + 7] = 0;
  out[offset + 8] = z[0] * radius;
  out[offset + 9] = z[1] * radius;
  out[offset + 10] = z[2] * radius;
  out[offset + 11] = 0;
  out[offset + 12] = (a[0] + b[0]) * 0.5;
  out[offset + 13] = (a[1] + b[1]) * 0.5;
  out[offset + 14] = (a[2] + b[2]) * 0.5;
  out[offset + 15] = 1;
}

function setColor(out: Float32Array, index: number, color: readonly number[]): void {
  const offset = index * 4;
  out[offset + 0] = color[0];
  out[offset + 1] = color[1];
  out[offset + 2] = color[2];
  out[offset + 3] = color[3];
}

function readPosition(array: Float32Array, index: number): Vec3 {
  const offset = index * 3;
  return [array[offset], array[offset + 1], array[offset + 2]];
}

function writePosition(array: Float32Array, index: number, value: Vec3): void {
  const offset = index * 3;
  array[offset] = value[0];
  array[offset + 1] = value[1];
  array[offset + 2] = value[2];
}

function distance(array: Float32Array, a: number, b: number): number {
  const ao = a * 3;
  const bo = b * 3;
  return Math.hypot(
    array[bo] - array[ao],
    array[bo + 1] - array[ao + 1],
    array[bo + 2] - array[ao + 2],
  );
}

type SoftProjectile = {
  position: Vec3;
  velocity: Vec3;
  radius: number;
  life: number;
  color: [number, number, number, number];
};

type ClothConstraint = {
  a: number;
  b: number;
  rest: number;
  solveStiffness: number;
  breakThreshold: number;
  broken: boolean;
  edgeType: 0 | 1 | 2 | 3;
  edgeIndex: number;
};

class ClothSimulation implements SoftSimulation {
  readonly kind = 'cloth' as const;
  readonly label: string;

  private readonly cols: number;
  private readonly rows: number;
  private readonly count: number;
  private readonly positions: Float32Array;
  private readonly previous: Float32Array;
  private readonly invMass: Float32Array;
  private readonly strain: Float32Array;
  private readonly normals: Float32Array;
  private readonly constraints: ClothConstraint[] = [];
  private readonly horizontalBroken: Uint8Array;
  private readonly verticalBroken: Uint8Array;
  private readonly vertices: Float32Array;
  private readonly indexScratch: Uint32Array;
  private readonly instanceMatrices = new Float32Array(MAX_SOFT_INSTANCES * 16);
  private readonly instanceColors = new Float32Array(MAX_SOFT_INSTANCES * 4);
  private readonly projectiles: SoftProjectile[] = [];
  private readonly rng: LcgRng;
  private readonly stress: number;
  private readonly variant: number;
  private readonly mode: number;
  private readonly iterations: number;
  private readonly windStrength: number;
  private readonly sphereCenter: Vec3;
  private readonly sphereRadius: number;
  private readonly verticalLayout: boolean;
  private readonly baseColorA: [number, number, number, number];
  private readonly baseColorB: [number, number, number, number];
  private time = 0;
  private brokenCountValue = 0;
  private energyValue = 0;
  private hashValue = 0;

  constructor(scene: ScenePreset, stress: number, seed: number) {
    this.variant = scene.variant;
    this.mode = scene.mode;
    this.stress = stress;
    this.cols = Math.min(52, 24 + stress * 4 + (scene.mode >= 3 ? 4 : 0) + (scene.variant % 2) * 2);
    this.rows = Math.min(36, 16 + stress * 3 + (scene.mode === 4 ? 3 : 0));
    this.count = this.cols * this.rows;
    this.positions = new Float32Array(this.count * 3);
    this.previous = new Float32Array(this.count * 3);
    this.invMass = new Float32Array(this.count);
    this.strain = new Float32Array(this.count);
    this.normals = new Float32Array(this.count * 3);
    this.horizontalBroken = new Uint8Array(this.rows * Math.max(0, this.cols - 1));
    this.verticalBroken = new Uint8Array(Math.max(0, this.rows - 1) * this.cols);
    this.vertices = new Float32Array(this.count * SURFACE_VERTEX_FLOATS);
    this.indexScratch = new Uint32Array(Math.max(0, (this.cols - 1) * (this.rows - 1) * 6));
    // PBD quality is driven by both substeps and solver iterations. Keep the
    // total pass count bounded so maximum cloth scenes remain interactive in
    // JavaScript while retaining enough projection passes for stable folds.
    this.iterations = 5 + stress + (scene.mode >= 3 ? 2 : 0);
    this.windStrength = 3.5 + stress * 1.35 + scene.mode * 0.45;
    this.rng = new LcgRng(seed ^ 0xc10f7a);
    this.label = `${scene.title.replace(/\s+—.*$/, '')} · PBD cloth ${this.cols}×${this.rows}`;
    this.verticalLayout = [0, 1, 5, 6, 8].includes(this.variant);
    this.sphereCenter = this.variant === 7 ? [0, 4.2, 0] : this.variant === 3 ? [0, 4.5, 0] : [0, -100, 0];
    this.sphereRadius = this.variant === 7 ? 3.1 : this.variant === 3 ? 1.6 : 0;

    const palettes: readonly [[number, number, number, number], [number, number, number, number]][] = [
      [[0.04, 0.52, 0.72, 1], [0.92, 0.17, 0.23, 1]],
      [[0.12, 0.26, 0.56, 1], [0.98, 0.76, 0.24, 1]],
      [[0.22, 0.70, 0.62, 1], [0.08, 0.24, 0.42, 1]],
      [[0.78, 0.14, 0.52, 1], [0.18, 0.82, 0.90, 1]],
      [[0.86, 0.38, 0.08, 1], [0.98, 0.88, 0.45, 1]],
    ];
    [this.baseColorA, this.baseColorB] = palettes[this.variant % palettes.length];

    this.initializeParticles();
    this.initializeConstraints();
    this.previous.set(this.positions);
    this.buildSurface();
  }

  private index(x: number, y: number): number { return y * this.cols + x; }

  private initializeParticles(): void {
    const vertical = this.verticalLayout;
    const width = this.variant === 4 ? 15 : 14 + this.variant * 0.16;
    const height = this.variant === 4 ? 4.5 : 8.5 + (this.variant % 3) * 0.5;
    const baseY = vertical ? 2.0 : (this.variant === 2 ? 10.5 : this.variant === 9 ? 5.8 : 8.4);

    for (let y = 0; y < this.rows; y++) {
      const v = y / Math.max(1, this.rows - 1);
      for (let x = 0; x < this.cols; x++) {
        const u = x / Math.max(1, this.cols - 1);
        const i = this.index(x, y);
        let p: Vec3;
        if (vertical) {
          const flutter = Math.sin(u * Math.PI) * Math.sin(v * Math.PI) * 0.18;
          p = [(u - 0.5) * width, baseY + (1 - v) * height, flutter];
          if (this.variant === 0 || this.variant === 5) p[0] -= width * 0.44;
          if (this.variant === 6) p[2] += Math.sin(u * 8 + v * 3) * 0.05;
        } else {
          const xw = (u - 0.5) * width;
          const zw = (v - 0.5) * (this.variant === 4 ? 5.2 : 10.5);
          let yw = baseY;
          if (this.variant === 2) {
            const nx = (u - 0.5) * 2;
            const nz = (v - 0.5) * 2;
            yw += Math.max(0, 1 - nx * nx - nz * nz) * 2.4;
          } else if (this.variant === 3 || this.variant === 4) {
            yw -= Math.sin(u * Math.PI) * Math.sin(v * Math.PI) * (this.variant === 4 ? 1.6 : 0.9);
          } else if (this.variant === 7) {
            yw += Math.sin(u * Math.PI) * Math.sin(v * Math.PI) * 0.12;
          } else if (this.variant === 9) {
            yw += Math.sin(u * Math.PI * 2) * Math.sin(v * Math.PI * 2) * 0.08;
          }
          p = [xw, yw, zw];
        }
        writePosition(this.positions, i, p);
        this.invMass[i] = 1;
      }
    }

    const pin = (x: number, y: number): void => { this.invMass[this.index(x, y)] = 0; };
    const pinTopRow = (): void => { for (let x = 0; x < this.cols; x++) pin(x, 0); };
    const pinPerimeter = (): void => {
      for (let x = 0; x < this.cols; x++) { pin(x, 0); pin(x, this.rows - 1); }
      for (let y = 0; y < this.rows; y++) { pin(0, y); pin(this.cols - 1, y); }
    };

    switch (this.variant) {
      case 0:
      case 5:
        for (let y = 0; y < this.rows; y++) pin(0, y);
        break;
      case 1:
      case 8:
        pinTopRow();
        break;
      case 2:
      case 3:
      case 7:
        pin(0, 0); pin(this.cols - 1, 0); pin(0, this.rows - 1); pin(this.cols - 1, this.rows - 1);
        break;
      case 4:
        for (let y = 0; y < this.rows; y++) { pin(0, y); pin(this.cols - 1, y); }
        break;
      case 6:
        for (let x = 0; x < this.cols; x += 3) pin(x, 0);
        pin(this.cols - 1, 0);
        break;
      case 9:
        pinPerimeter();
        break;
      default:
        pinTopRow();
        break;
    }
  }

  private addConstraint(
    a: number,
    b: number,
    stiffness: number,
    breakThreshold: number,
    edgeType: ClothConstraint['edgeType'] = 0,
    edgeIndex = -1,
  ): void {
    this.constraints.push({
      a,
      b,
      rest: distance(this.positions, a, b),
      solveStiffness: 1 - Math.pow(1 - stiffness, 1 / this.iterations),
      breakThreshold,
      broken: false,
      edgeType,
      edgeIndex,
    });
  }

  private initializeConstraints(): void {
    const tearScene = this.variant === 6 || (this.mode >= 3 && this.variant === 7);
    const structuralBreak = tearScene ? 1.34 + this.stress * 0.035 : 4.5;
    const shearBreak = tearScene ? structuralBreak * 1.08 : 4.8;

    for (let y = 0; y < this.rows; y++) {
      for (let x = 0; x < this.cols; x++) {
        const i = this.index(x, y);
        if (x + 1 < this.cols) {
          this.addConstraint(i, this.index(x + 1, y), 0.98, structuralBreak, 1, y * (this.cols - 1) + x);
        }
        if (y + 1 < this.rows) {
          this.addConstraint(i, this.index(x, y + 1), 0.98, structuralBreak, 2, y * this.cols + x);
        }
        if (x + 1 < this.cols && y + 1 < this.rows) {
          this.addConstraint(i, this.index(x + 1, y + 1), 0.88, shearBreak, 0, -1);
          this.addConstraint(this.index(x + 1, y), this.index(x, y + 1), 0.88, shearBreak, 0, -1);
        }
        if (x + 2 < this.cols) this.addConstraint(i, this.index(x + 2, y), 0.48, 8, 0, -1);
        if (y + 2 < this.rows) this.addConstraint(i, this.index(x, y + 2), 0.48, 8, 0, -1);
      }
    }
  }

  step(dt: number, subSteps: number): void {
    if (!Number.isFinite(dt) || dt <= 0) return;
    // Two position-integration substeps plus the bounded projection loop are
    // substantially faster than blindly mirroring the rigid-body substep
    // count, and avoid doing 70+ complete constraint sweeps per frame.
    const steps = Math.min(2, clamp(Math.round(subSteps), 1, 8));
    const subDt = Math.min(dt, 1 / 30) / steps;
    this.strain.fill(0);
    for (let sub = 0; sub < steps; sub++) {
      this.time += subDt;
      this.integrateProjectiles(subDt);
      this.integrateParticles(subDt);
      this.collideProjectiles();
      let tearBudget = this.variant === 6 ? 8 : this.mode >= 3 ? 3 : 1;
      for (let iteration = 0; iteration < this.iterations; iteration++) {
        for (const constraint of this.constraints) {
          if (constraint.broken) continue;
          tearBudget = this.solveConstraint(constraint, tearBudget);
        }
        this.solveCollisions();
      }
    }
    this.computeEnergy(dt);
  }

  private integrateParticles(dt: number): void {
    const dt2 = dt * dt;
    const drag = 0.992 - this.stress * 0.0004;
    const gust = this.windStrength * (0.72 + 0.28 * Math.sin(this.time * 1.7));
    const vertical = this.verticalLayout;

    for (let i = 0; i < this.count; i++) {
      if (this.invMass[i] === 0) continue;
      const o = i * 3;
      const x = this.positions[o];
      const y = this.positions[o + 1];
      const z = this.positions[o + 2];
      const vx = (x - this.previous[o]) * drag;
      const vy = (y - this.previous[o + 1]) * drag;
      const vz = (z - this.previous[o + 2]) * drag;
      this.previous[o] = x;
      this.previous[o + 1] = y;
      this.previous[o + 2] = z;

      const turbulence = Math.sin(this.time * 3.1 + x * 0.48 + y * 0.22 + z * 0.31)
        + 0.45 * Math.sin(this.time * 7.3 - x * 0.27 + y * 0.39);
      const edgeFactor = 0.55 + 0.45 * Math.sin(((i % this.cols) / Math.max(1, this.cols - 1)) * Math.PI);
      const windX = gust * edgeFactor * (0.78 + turbulence * 0.18);
      const windZ = gust * (vertical ? 0.28 : 0.52) * Math.sin(this.time * 1.3 + x * 0.17);
      const lift = vertical ? turbulence * 0.25 : Math.max(0, turbulence) * 0.55 + (this.variant === 2 ? 1.2 : 0);

      this.positions[o] = x + vx + windX * dt2;
      this.positions[o + 1] = y + vy + (-9.81 + lift) * dt2;
      this.positions[o + 2] = z + vz + windZ * dt2;
    }
  }

  private solveConstraint(constraint: ClothConstraint, tearBudget: number): number {
    const ao = constraint.a * 3;
    const bo = constraint.b * 3;
    const dx = this.positions[bo] - this.positions[ao];
    const dy = this.positions[bo + 1] - this.positions[ao + 1];
    const dz = this.positions[bo + 2] - this.positions[ao + 2];
    const dist = Math.hypot(dx, dy, dz);
    if (dist < 1e-7) return tearBudget;
    const ratio = dist / Math.max(1e-7, constraint.rest);
    const strain = Math.abs(ratio - 1);
    this.strain[constraint.a] = Math.max(this.strain[constraint.a], strain);
    this.strain[constraint.b] = Math.max(this.strain[constraint.b], strain);

    if (ratio > constraint.breakThreshold && tearBudget > 0 && constraint.edgeType !== 0) {
      constraint.broken = true;
      tearBudget--;
      this.brokenCountValue++;
      if (constraint.edgeType === 1 && constraint.edgeIndex >= 0) this.horizontalBroken[constraint.edgeIndex] = 1;
      if (constraint.edgeType === 2 && constraint.edgeIndex >= 0) this.verticalBroken[constraint.edgeIndex] = 1;
      return tearBudget;
    }

    const wa = this.invMass[constraint.a];
    const wb = this.invMass[constraint.b];
    const w = wa + wb;
    if (w <= 0) return tearBudget;
    const correction = ((dist - constraint.rest) / dist) * constraint.solveStiffness / w;
    if (wa > 0) {
      this.positions[ao] += dx * correction * wa;
      this.positions[ao + 1] += dy * correction * wa;
      this.positions[ao + 2] += dz * correction * wa;
    }
    if (wb > 0) {
      this.positions[bo] -= dx * correction * wb;
      this.positions[bo + 1] -= dy * correction * wb;
      this.positions[bo + 2] -= dz * correction * wb;
    }
    return tearBudget;
  }

  private solveCollisions(): void {
    for (let i = 0; i < this.count; i++) {
      if (this.invMass[i] === 0) continue;
      const o = i * 3;
      if (this.positions[o + 1] < 0.12) {
        this.positions[o + 1] = 0.12;
        this.previous[o] = this.positions[o] - (this.positions[o] - this.previous[o]) * 0.72;
        this.previous[o + 2] = this.positions[o + 2] - (this.positions[o + 2] - this.previous[o + 2]) * 0.72;
      }
      if (this.sphereRadius > 0) {
        const dx = this.positions[o] - this.sphereCenter[0];
        const dy = this.positions[o + 1] - this.sphereCenter[1];
        const dz = this.positions[o + 2] - this.sphereCenter[2];
        const dist = Math.hypot(dx, dy, dz);
        const target = this.sphereRadius + 0.08;
        if (dist < target && dist > 1e-6) {
          const scale = target / dist;
          this.positions[o] = this.sphereCenter[0] + dx * scale;
          this.positions[o + 1] = this.sphereCenter[1] + dy * scale;
          this.positions[o + 2] = this.sphereCenter[2] + dz * scale;
        }
      }
    }
  }

  private integrateProjectiles(dt: number): void {
    for (const projectile of this.projectiles) {
      projectile.life -= dt;
      projectile.velocity[1] -= 9.81 * dt;
      projectile.position[0] += projectile.velocity[0] * dt;
      projectile.position[1] += projectile.velocity[1] * dt;
      projectile.position[2] += projectile.velocity[2] * dt;
      if (projectile.position[1] < projectile.radius) {
        projectile.position[1] = projectile.radius;
        projectile.velocity[1] = Math.abs(projectile.velocity[1]) * 0.22;
        projectile.velocity[0] *= 0.72;
        projectile.velocity[2] *= 0.72;
      }
    }
    for (let i = this.projectiles.length - 1; i >= 0; i--) {
      if (this.projectiles[i].life <= 0) this.projectiles.splice(i, 1);
    }
  }

  private collideProjectiles(): void {
    for (const projectile of this.projectiles) {
      const speed = Math.hypot(projectile.velocity[0], projectile.velocity[1], projectile.velocity[2]);
      for (let i = 0; i < this.count; i++) {
        if (this.invMass[i] === 0) continue;
        const o = i * 3;
        const dx = this.positions[o] - projectile.position[0];
        const dy = this.positions[o + 1] - projectile.position[1];
        const dz = this.positions[o + 2] - projectile.position[2];
        const dist = Math.hypot(dx, dy, dz);
        const target = projectile.radius + 0.16;
        if (dist >= target || dist < 1e-6) continue;
        const nx = dx / dist;
        const ny = dy / dist;
        const nz = dz / dist;
        const push = (target - dist) + speed * 0.008;
        this.positions[o] += nx * push;
        this.positions[o + 1] += ny * push;
        this.positions[o + 2] += nz * push;
        this.previous[o] -= projectile.velocity[0] * 0.009;
        this.previous[o + 1] -= projectile.velocity[1] * 0.009;
        this.previous[o + 2] -= projectile.velocity[2] * 0.009;
      }
    }
  }

  private computeEnergy(dt: number): void {
    let energy = 0;
    const invDt = 1 / Math.max(dt, 1e-5);
    for (let i = 0; i < this.count; i++) {
      const o = i * 3;
      const vx = (this.positions[o] - this.previous[o]) * invDt;
      const vy = (this.positions[o + 1] - this.previous[o + 1]) * invDt;
      const vz = (this.positions[o + 2] - this.previous[o + 2]) * invDt;
      energy += vx * vx + vy * vy + vz * vz;
    }
    this.energyValue = energy / Math.max(1, this.count);
  }

  kick(strength: number): void {
    const impulse = Math.max(1, strength) * 0.018;
    for (let i = 0; i < this.count; i++) {
      if (this.invMass[i] === 0) continue;
      const o = i * 3;
      const wave = 0.35 + 0.65 * ((i % this.cols) / Math.max(1, this.cols - 1));
      this.previous[o] -= impulse * wave;
      this.previous[o + 1] += this.rng.signed(impulse * 0.2);
      this.previous[o + 2] -= this.rng.signed(impulse * 0.45);
    }
  }

  explode(center: Vec3, strength: number, radius: number): void {
    const r = Math.max(0.5, radius);
    for (let i = 0; i < this.count; i++) {
      if (this.invMass[i] === 0) continue;
      const o = i * 3;
      const dx = this.positions[o] - center[0];
      const dy = this.positions[o + 1] - center[1];
      const dz = this.positions[o + 2] - center[2];
      const dist = Math.hypot(dx, dy, dz);
      if (dist >= r || dist < 1e-6) continue;
      const falloff = 1 - dist / r;
      const impulse = strength * falloff * 0.012;
      this.previous[o] -= (dx / dist) * impulse;
      this.previous[o + 1] -= (dy / dist + 0.35) * impulse;
      this.previous[o + 2] -= (dz / dist) * impulse;
    }
  }

  launchProjectile(position: Vec3, velocity: Vec3, size: number): number {
    if (this.projectiles.length >= 24) return -1;
    this.projectiles.push({
      position: [...position] as Vec3,
      velocity: [...velocity] as Vec3,
      radius: clamp(size, 0.18, 1.6),
      life: 8,
      color: [1, 0.62, 0.13, 2.1],
    });
    return this.projectiles.length - 1;
  }

  spawnRain(count: number, spread: number, height: number): number {
    const allowed = Math.max(0, Math.min(Math.max(0, Math.round(count)), 160 - this.projectiles.length));
    for (let i = 0; i < allowed; i++) {
      this.projectiles.push({
        position: [this.rng.signed(spread), height + this.rng.range(0, 10), this.rng.signed(spread * 0.65)],
        velocity: [this.rng.signed(0.6), this.rng.range(-12, -7), this.rng.signed(0.6)],
        radius: this.rng.range(0.055, 0.12),
        life: 5,
        color: [0.25, 0.78, 1, 1.8],
      });
    }
    return allowed;
  }

  private buildSurface(): DynamicSurfaceFrame {
    let indexCount = 0;
    const normals = this.normals;
    normals.fill(0);

    const cellBroken = (x: number, y: number): boolean => {
      const top = this.horizontalBroken[y * (this.cols - 1) + x] !== 0;
      const bottom = this.horizontalBroken[(y + 1) * (this.cols - 1) + x] !== 0;
      const left = this.verticalBroken[y * this.cols + x] !== 0;
      const right = this.verticalBroken[y * this.cols + x + 1] !== 0;
      return top || bottom || left || right;
    };

    for (let y = 0; y < this.rows - 1; y++) {
      for (let x = 0; x < this.cols - 1; x++) {
        if (cellBroken(x, y)) continue;
        const i0 = this.index(x, y);
        const i1 = this.index(x + 1, y);
        const i2 = this.index(x, y + 1);
        const i3 = this.index(x + 1, y + 1);
        if ((x + y) % 2 === 0) {
          this.indexScratch[indexCount++] = i0;
          this.indexScratch[indexCount++] = i2;
          this.indexScratch[indexCount++] = i1;
          this.indexScratch[indexCount++] = i1;
          this.indexScratch[indexCount++] = i2;
          this.indexScratch[indexCount++] = i3;
        } else {
          this.indexScratch[indexCount++] = i0;
          this.indexScratch[indexCount++] = i2;
          this.indexScratch[indexCount++] = i3;
          this.indexScratch[indexCount++] = i0;
          this.indexScratch[indexCount++] = i3;
          this.indexScratch[indexCount++] = i1;
        }
      }
    }

    for (let i = 0; i < indexCount; i += 3) {
      const ia = this.indexScratch[i];
      const ib = this.indexScratch[i + 1];
      const ic = this.indexScratch[i + 2];
      const a = readPosition(this.positions, ia);
      const b = readPosition(this.positions, ib);
      const c = readPosition(this.positions, ic);
      const n = vec3Cross(vec3Sub(b, a), vec3Sub(c, a));
      for (const index of [ia, ib, ic]) {
        const o = index * 3;
        normals[o] += n[0];
        normals[o + 1] += n[1];
        normals[o + 2] += n[2];
      }
    }

    for (let y = 0; y < this.rows; y++) {
      const v = y / Math.max(1, this.rows - 1);
      for (let x = 0; x < this.cols; x++) {
        const u = x / Math.max(1, this.cols - 1);
        const i = this.index(x, y);
        const po = i * 3;
        const no = i * 3;
        const vo = i * SURFACE_VERTEX_FLOATS;
        const accumulated: Vec3 = [normals[no], normals[no + 1], normals[no + 2]];
        const normal = vec3Length(accumulated) > 1e-7
          ? vec3Normalize(accumulated)
          : (this.verticalLayout ? [0, 0, 1] as Vec3 : [0, 1, 0] as Vec3);
        const checker = ((Math.floor(u * 10) + Math.floor(v * 8)) & 1) === 0 ? 0.22 : 0.78;
        const base = mixColor(this.baseColorA, this.baseColorB, checker);
        const stress = clamp(this.strain[i] * 3.2, 0, 1);
        const color = mixColor(base, [1, 0.14, 0.03, 1], stress * 0.72);
        this.vertices[vo] = this.positions[po];
        this.vertices[vo + 1] = this.positions[po + 1];
        this.vertices[vo + 2] = this.positions[po + 2];
        this.vertices[vo + 3] = normal[0];
        this.vertices[vo + 4] = normal[1];
        this.vertices[vo + 5] = normal[2];
        this.vertices[vo + 6] = color[0];
        this.vertices[vo + 7] = color[1];
        this.vertices[vo + 8] = color[2];
        this.vertices[vo + 9] = stress;
        this.vertices[vo + 10] = u;
        this.vertices[vo + 11] = v;
      }
    }

    this.hashValue = quantizedHash(this.positions, Math.min(this.positions.length, 4096));
    return {
      material: 'cloth',
      vertices: this.vertices,
      indices: this.indexScratch.subarray(0, indexCount),
      vertexCount: this.count,
      indexCount,
    };
  }

  buildFrame(debug: boolean): SoftSimulationFrame {
    const matrices = this.instanceMatrices;
    const colors = this.instanceColors;
    let instanceCount = 0;

    if (this.sphereRadius > 0 && instanceCount < MAX_SOFT_INSTANCES) {
      writeModelMatrixFromEuler(matrices, instanceCount * 16, this.sphereCenter, [0, 0, 0], [this.sphereRadius, this.sphereRadius, this.sphereRadius]);
      setColor(colors, instanceCount, [0.12, 0.18, 0.28, 1]);
      instanceCount++;
    }
    for (const projectile of this.projectiles) {
      if (instanceCount >= MAX_SOFT_INSTANCES) break;
      writeModelMatrixFromEuler(matrices, instanceCount * 16, projectile.position, [this.time, this.time * 0.7, 0], [projectile.radius, projectile.radius, projectile.radius]);
      setColor(colors, instanceCount, projectile.color);
      instanceCount++;
    }

    const debugLines: DebugLine[] = [];
    if (debug) {
      const stride = Math.max(1, Math.floor(this.constraints.length / 420));
      for (let i = 0; i < this.constraints.length; i += stride) {
        const constraint = this.constraints[i];
        if (constraint.broken) continue;
        const a = readPosition(this.positions, constraint.a);
        const b = readPosition(this.positions, constraint.b);
        const ratio = distance(this.positions, constraint.a, constraint.b) / Math.max(1e-6, constraint.rest);
        const tension = clamp((ratio - 1) * 5, 0, 1);
        debugLines.push({
          ax: a[0], ay: a[1], az: a[2], bx: b[0], by: b[1], bz: b[2],
          r: 0.2 + tension * 0.8, g: 0.8 - tension * 0.65, b: 1 - tension * 0.8, a: 0.22,
        });
      }
    }

    return {
      kind: this.kind,
      label: this.label,
      matrices: matrices.subarray(0, instanceCount * 16),
      colors: colors.subarray(0, instanceCount * 4),
      instanceCount,
      surface: this.buildSurface(),
      debugLines,
      nodeCount: this.count,
      constraintCount: this.constraints.length,
      brokenCount: this.brokenCountValue,
      energy: this.energyValue,
      hash: this.hashValue,
    };
  }

  destroy(): void {
    this.projectiles.length = 0;
  }
}

type RopeConstraint = {
  a: number;
  b: number;
  rest: number;
  solveStiffness: number;
  breakThreshold: number;
  broken: boolean;
  render: boolean;
  radius: number;
  color: [number, number, number, number];
};

type RopePayload = {
  particle: number;
  half: Vec3;
  color: [number, number, number, number];
};

class RopeSimulation implements SoftSimulation {
  readonly kind = 'rope' as const;
  readonly label: string;

  private positions: Float32Array;
  private previous: Float32Array;
  private invMass: Float32Array;
  private constraints: RopeConstraint[] = [];
  private payloads: RopePayload[] = [];
  private projectiles: SoftProjectile[] = [];
  private readonly instanceMatrices = new Float32Array(MAX_SOFT_INSTANCES * 16);
  private readonly instanceColors = new Float32Array(MAX_SOFT_INSTANCES * 4);
  private readonly rng: LcgRng;
  private readonly stress: number;
  private readonly variant: number;
  private readonly mode: number;
  private readonly iterations: number;
  private time = 0;
  private brokenCountValue = 0;
  private energyValue = 0;
  private hashValue = 0;

  constructor(scene: ScenePreset, stress: number, seed: number) {
    this.stress = stress;
    this.variant = scene.variant;
    this.mode = scene.mode;
    this.iterations = 6 + stress + (scene.mode >= 3 ? 2 : 0);
    this.rng = new LcgRng(seed ^ 0x70e5a11);
    this.label = `${scene.title.replace(/\s+—.*$/, '')} · PBD rope/cable solver`;

    const positions: number[] = [];
    const invMass: number[] = [];
    const addParticle = (p: Vec3, mass = 1): number => {
      const index = invMass.length;
      positions.push(p[0], p[1], p[2]);
      invMass.push(mass <= 0 ? 0 : 1 / mass);
      return index;
    };
    const addConstraint = (
      a: number,
      b: number,
      stiffness: number,
      breakThreshold: number,
      render: boolean,
      radius: number,
      color: [number, number, number, number],
    ): void => {
      const ao = a * 3;
      const bo = b * 3;
      const rest = Math.hypot(
        positions[bo] - positions[ao],
        positions[bo + 1] - positions[ao + 1],
        positions[bo + 2] - positions[ao + 2],
      );
      this.constraints.push({
        a,
        b,
        rest,
        solveStiffness: 1 - Math.pow(1 - stiffness, 1 / this.iterations),
        breakThreshold,
        broken: false,
        render,
        radius,
        color,
      });
    };
    const addChain = (
      start: Vec3,
      end: Vec3,
      segments: number,
      sag: number,
      pinStart: boolean,
      pinEnd: boolean,
      radius: number,
      color: [number, number, number, number],
      breakThreshold = 1.65,
    ): number[] => {
      const chain: number[] = [];
      for (let i = 0; i <= segments; i++) {
        const t = i / segments;
        const p: Vec3 = [
          start[0] + (end[0] - start[0]) * t,
          start[1] + (end[1] - start[1]) * t - Math.sin(Math.PI * t) * sag,
          start[2] + (end[2] - start[2]) * t,
        ];
        const pinned = (i === 0 && pinStart) || (i === segments && pinEnd);
        chain.push(addParticle(p, pinned ? 0 : 1));
      }
      for (let i = 0; i < chain.length - 1; i++) {
        addConstraint(chain[i], chain[i + 1], 0.99, breakThreshold, true, radius, color);
      }
      for (let i = 0; i < chain.length - 2; i++) {
        addConstraint(chain[i], chain[i + 2], 0.42, breakThreshold * 1.75, false, radius, color);
      }
      return chain;
    };

    const gold: [number, number, number, number] = [0.94, 0.62, 0.16, 1];
    const steel: [number, number, number, number] = [0.45, 0.62, 0.76, 1];
    const red: [number, number, number, number] = [0.84, 0.18, 0.18, 1];
    const teal: [number, number, number, number] = [0.08, 0.65, 0.72, 1];
    const segments = 28 + stress * 7 + (scene.mode >= 3 ? 6 : 0);
    const weak = this.variant === 5 || this.variant === 8 ? 1.27 + stress * 0.03 : 1.58 + stress * 0.04;

    if (this.variant === 0) {
      const chain = addChain([0, 17, 0], [0, 5.2, 0], segments, 0.3, true, false, 0.10, gold, weak);
      this.payloads.push({ particle: chain[chain.length - 1], half: [1.6, 0.65, 1.0], color: [1, 0.62, 0.12, 1] });
      invMass[chain[chain.length - 1]] = 1 / 8;
    } else if (this.variant === 1) {
      const left = addChain([-16, 9.5, -1.7], [16, 9.5, -1.7], segments, 4.3, true, true, 0.09, teal, weak);
      const right = addChain([-16, 9.5, 1.7], [16, 9.5, 1.7], segments, 4.3, true, true, 0.09, teal, weak);
      for (let i = 0; i < left.length; i += 2) {
        addConstraint(left[i], right[i], 0.95, 1.8, true, 0.13, steel);
      }
    } else if (this.variant === 2) {
      const chain = addChain([0, 17, 0], [8, 5, 0], segments, 1.4, true, false, 0.11, red, weak);
      this.payloads.push({ particle: chain[chain.length - 1], half: [1.2, 1.2, 1.2], color: [0.86, 0.18, 0.12, 1] });
      invMass[chain[chain.length - 1]] = 1 / 11;
    } else if (this.variant === 3) {
      const left = addChain([-2.2, 16, 0], [-2.2, 2.3, 0], segments, 0.3, true, false, 0.075, gold, weak);
      const right = addChain([2.2, 16, 0], [2.2, 2.3, 0], segments, 0.3, true, false, 0.075, gold, weak);
      for (let i = 2; i < Math.min(left.length, right.length); i += 3) {
        addConstraint(left[i], right[i], 0.98, 2.0, true, 0.11, steel);
      }
    } else if (this.variant === 4) {
      const center = addParticle([0, 5.5, 0], 12);
      this.payloads.push({ particle: center, half: [1.4, 0.45, 1.4], color: [0.12, 0.72, 0.82, 1] });
      const anchors: Vec3[] = [[-14, 10, -10], [14, 10, -10], [-14, 10, 10], [14, 10, 10]];
      for (const anchor of anchors) {
        const chain = addChain(anchor, [0, 5.5, 0], Math.max(14, Math.floor(segments * 0.55)), 1.2, true, false, 0.08, teal, weak);
        const end = chain[chain.length - 1];
        addConstraint(end, center, 0.99, weak, true, 0.1, teal);
      }
    } else if (this.variant === 5) {
      for (let lane = -4; lane <= 4; lane++) {
        addChain([lane * 2.2, 16, 0], [lane * 2.2, 1.2, this.rng.signed(0.8)], Math.max(18, Math.floor(segments * 0.65)), 0.2, true, false, 0.055, lane % 2 ? gold : red, weak);
      }
    } else if (this.variant === 6) {
      const chain = addChain([-16, 13, -4], [16, 7, 4], segments, 2.5, true, true, 0.105, teal, weak);
      const riderIndex = chain[Math.floor(chain.length * 0.38)];
      this.payloads.push({ particle: riderIndex, half: [0.7, 1.0, 0.55], color: [0.96, 0.74, 0.18, 1] });
      invMass[riderIndex] = 1 / 6;
    } else if (this.variant === 7) {
      const chain = addChain([-18, 6, 0], [14, 12, 0], segments, 2.0, true, true, 0.09, red, weak);
      this.payloads.push({ particle: chain[Math.floor(chain.length * 0.62)], half: [0.8, 0.55, 0.8], color: [0.22, 0.72, 0.44, 1] });
    } else if (this.variant === 8) {
      const payload = addParticle([0, 5.4, 0], 18);
      this.payloads.push({ particle: payload, half: [2.4, 0.7, 1.5], color: [1, 0.52, 0.1, 1] });
      const anchors: Vec3[] = [[-7, 16, -5], [7, 16, -5], [-7, 16, 5], [7, 16, 5]];
      for (const anchor of anchors) {
        const chain = addChain(anchor, [0, 5.4, 0], Math.max(16, Math.floor(segments * 0.58)), 0.8, true, false, 0.09, gold, weak);
        addConstraint(chain[chain.length - 1], payload, 0.99, weak, true, 0.11, gold);
      }
    } else {
      const horizontal: number[][] = [];
      for (let row = -3; row <= 3; row++) {
        horizontal.push(addChain([-13, 11 + row * 0.55, -4], [13, 11 + row * 0.55, 4], Math.max(18, Math.floor(segments * 0.7)), 2.8, true, true, 0.055, row % 2 ? teal : gold, weak));
      }
      for (let c = 0; c < horizontal[0].length; c += 4) {
        for (let r = 0; r < horizontal.length - 1; r++) {
          addConstraint(horizontal[r][c], horizontal[r + 1][c], 0.9, 1.8, true, 0.045, steel);
        }
      }
    }

    this.positions = new Float32Array(positions);
    this.previous = new Float32Array(positions);
    this.invMass = new Float32Array(invMass);
    this.buildFrame(false);
  }

  step(dt: number, subSteps: number): void {
    if (!Number.isFinite(dt) || dt <= 0) return;
    const steps = Math.min(3, clamp(Math.round(subSteps), 1, 8));
    const subDt = Math.min(dt, 1 / 30) / steps;
    for (let sub = 0; sub < steps; sub++) {
      this.time += subDt;
      this.integrateProjectiles(subDt);
      this.integrate(subDt);
      this.collideProjectiles();
      let breakBudget = this.mode >= 3 ? 4 : 1;
      for (let iteration = 0; iteration < this.iterations; iteration++) {
        for (const constraint of this.constraints) {
          if (constraint.broken) continue;
          breakBudget = this.solveConstraint(constraint, breakBudget);
        }
        this.solveCollisions();
      }
    }
    this.computeEnergy(dt);
    this.hashValue = quantizedHash(this.positions, Math.min(this.positions.length, 4096));
  }

  private integrate(dt: number): void {
    const dt2 = dt * dt;
    for (let i = 0; i < this.invMass.length; i++) {
      if (this.invMass[i] === 0) continue;
      const o = i * 3;
      const x = this.positions[o];
      const y = this.positions[o + 1];
      const z = this.positions[o + 2];
      const vx = (x - this.previous[o]) * 0.994;
      const vy = (y - this.previous[o + 1]) * 0.994;
      const vz = (z - this.previous[o + 2]) * 0.994;
      this.previous[o] = x;
      this.previous[o + 1] = y;
      this.previous[o + 2] = z;
      const wind = Math.sin(this.time * 1.8 + y * 0.32 + z * 0.19) * (0.8 + this.stress * 0.2);
      this.positions[o] = x + vx + wind * dt2;
      this.positions[o + 1] = y + vy - 9.81 * dt2;
      this.positions[o + 2] = z + vz + Math.cos(this.time * 1.1 + x * 0.2) * 0.38 * dt2;
    }
  }

  private solveConstraint(constraint: RopeConstraint, breakBudget: number): number {
    const ao = constraint.a * 3;
    const bo = constraint.b * 3;
    const dx = this.positions[bo] - this.positions[ao];
    const dy = this.positions[bo + 1] - this.positions[ao + 1];
    const dz = this.positions[bo + 2] - this.positions[ao + 2];
    const dist = Math.hypot(dx, dy, dz);
    if (dist < 1e-7) return breakBudget;
    const ratio = dist / Math.max(1e-7, constraint.rest);
    if (constraint.render && ratio > constraint.breakThreshold && breakBudget > 0) {
      constraint.broken = true;
      this.brokenCountValue++;
      return breakBudget - 1;
    }
    const wa = this.invMass[constraint.a];
    const wb = this.invMass[constraint.b];
    const w = wa + wb;
    if (w <= 0) return breakBudget;
    const correction = ((dist - constraint.rest) / dist) * constraint.solveStiffness / w;
    if (wa > 0) {
      this.positions[ao] += dx * correction * wa;
      this.positions[ao + 1] += dy * correction * wa;
      this.positions[ao + 2] += dz * correction * wa;
    }
    if (wb > 0) {
      this.positions[bo] -= dx * correction * wb;
      this.positions[bo + 1] -= dy * correction * wb;
      this.positions[bo + 2] -= dz * correction * wb;
    }
    return breakBudget;
  }

  private solveCollisions(): void {
    for (let i = 0; i < this.invMass.length; i++) {
      if (this.invMass[i] === 0) continue;
      const o = i * 3;
      if (this.positions[o + 1] < 0.16) {
        this.positions[o + 1] = 0.16;
        this.previous[o] = this.positions[o] - (this.positions[o] - this.previous[o]) * 0.65;
        this.previous[o + 2] = this.positions[o + 2] - (this.positions[o + 2] - this.previous[o + 2]) * 0.65;
      }
      this.positions[o] = clamp(this.positions[o], -42, 42);
      this.positions[o + 2] = clamp(this.positions[o + 2], -42, 42);
    }
  }

  private integrateProjectiles(dt: number): void {
    for (const projectile of this.projectiles) {
      projectile.life -= dt;
      projectile.velocity[1] -= 9.81 * dt;
      projectile.position[0] += projectile.velocity[0] * dt;
      projectile.position[1] += projectile.velocity[1] * dt;
      projectile.position[2] += projectile.velocity[2] * dt;
    }
    for (let i = this.projectiles.length - 1; i >= 0; i--) {
      if (this.projectiles[i].life <= 0 || this.projectiles[i].position[1] < -4) this.projectiles.splice(i, 1);
    }
  }

  private collideProjectiles(): void {
    for (const projectile of this.projectiles) {
      const speed = Math.hypot(projectile.velocity[0], projectile.velocity[1], projectile.velocity[2]);
      for (let i = 0; i < this.invMass.length; i++) {
        if (this.invMass[i] === 0) continue;
        const o = i * 3;
        const dx = this.positions[o] - projectile.position[0];
        const dy = this.positions[o + 1] - projectile.position[1];
        const dz = this.positions[o + 2] - projectile.position[2];
        const d = Math.hypot(dx, dy, dz);
        if (d > projectile.radius + 0.22 || d < 1e-6) continue;
        const impulse = speed * 0.012;
        this.previous[o] -= projectile.velocity[0] * 0.012;
        this.previous[o + 1] -= projectile.velocity[1] * 0.012;
        this.previous[o + 2] -= projectile.velocity[2] * 0.012;
        if (speed > 14) this.breakNearestConstraint(projectile.position, projectile.radius + 0.9);
        this.positions[o] += (dx / d) * impulse;
        this.positions[o + 1] += (dy / d) * impulse;
        this.positions[o + 2] += (dz / d) * impulse;
      }
    }
  }

  private breakNearestConstraint(center: Vec3, radius: number): boolean {
    let best: RopeConstraint | null = null;
    let bestDistance = radius;
    for (const constraint of this.constraints) {
      if (!constraint.render || constraint.broken) continue;
      const a = readPosition(this.positions, constraint.a);
      const b = readPosition(this.positions, constraint.b);
      const mx = (a[0] + b[0]) * 0.5;
      const my = (a[1] + b[1]) * 0.5;
      const mz = (a[2] + b[2]) * 0.5;
      const d = Math.hypot(mx - center[0], my - center[1], mz - center[2]);
      if (d < bestDistance) {
        bestDistance = d;
        best = constraint;
      }
    }
    if (!best) return false;
    best.broken = true;
    this.brokenCountValue++;
    return true;
  }

  private computeEnergy(dt: number): void {
    const invDt = 1 / Math.max(1e-5, dt);
    let energy = 0;
    for (let i = 0; i < this.invMass.length; i++) {
      const o = i * 3;
      const vx = (this.positions[o] - this.previous[o]) * invDt;
      const vy = (this.positions[o + 1] - this.previous[o + 1]) * invDt;
      const vz = (this.positions[o + 2] - this.previous[o + 2]) * invDt;
      energy += vx * vx + vy * vy + vz * vz;
    }
    this.energyValue = energy / Math.max(1, this.invMass.length);
  }

  kick(strength: number): void {
    const scale = Math.max(1, strength) * 0.026;
    for (let i = 0; i < this.invMass.length; i++) {
      if (this.invMass[i] === 0) continue;
      const o = i * 3;
      this.previous[o] -= scale * (0.6 + this.rng.next01() * 0.5);
      this.previous[o + 1] += this.rng.signed(scale * 0.18);
      this.previous[o + 2] -= this.rng.signed(scale * 0.55);
    }
  }

  explode(center: Vec3, strength: number, radius: number): void {
    const r = Math.max(1, radius);
    for (let i = 0; i < this.invMass.length; i++) {
      if (this.invMass[i] === 0) continue;
      const o = i * 3;
      const dx = this.positions[o] - center[0];
      const dy = this.positions[o + 1] - center[1];
      const dz = this.positions[o + 2] - center[2];
      const d = Math.hypot(dx, dy, dz);
      if (d >= r || d < 1e-6) continue;
      const impulse = (1 - d / r) * strength * 0.018;
      this.previous[o] -= (dx / d) * impulse;
      this.previous[o + 1] -= (dy / d + 0.25) * impulse;
      this.previous[o + 2] -= (dz / d) * impulse;
    }
    if (strength > 15) {
      for (let i = 0; i < Math.min(4, Math.floor(strength / 8)); i++) this.breakNearestConstraint(center, r * 0.75);
    }
  }

  launchProjectile(position: Vec3, velocity: Vec3, size: number): number {
    if (this.projectiles.length >= 16) return -1;
    this.projectiles.push({
      position: [...position] as Vec3,
      velocity: [...velocity] as Vec3,
      radius: clamp(size, 0.2, 1.5),
      life: 8,
      color: [1, 0.42, 0.08, 2.4],
    });
    return this.projectiles.length - 1;
  }

  spawnRain(count: number, spread: number, height: number): number {
    const allowed = Math.max(0, Math.min(Math.max(0, Math.round(count)), 96 - this.projectiles.length));
    for (let i = 0; i < allowed; i++) {
      this.projectiles.push({
        position: [this.rng.signed(spread), height + this.rng.range(0, 12), this.rng.signed(spread)],
        velocity: [this.rng.signed(1), this.rng.range(-14, -8), this.rng.signed(1)],
        radius: this.rng.range(0.08, 0.18),
        life: 5,
        color: [0.2, 0.72, 1, 1.8],
      });
    }
    return allowed;
  }

  buildFrame(debug: boolean): SoftSimulationFrame {
    const maxCount = MAX_SOFT_INSTANCES;
    const matrices = this.instanceMatrices;
    const colors = this.instanceColors;
    let instanceCount = 0;

    for (const constraint of this.constraints) {
      if (!constraint.render || constraint.broken) continue;
      if (instanceCount >= maxCount) break;
      const a = readPosition(this.positions, constraint.a);
      const b = readPosition(this.positions, constraint.b);
      const ratio = distance(this.positions, constraint.a, constraint.b) / Math.max(1e-6, constraint.rest);
      const tension = clamp((ratio - 1) * 4.2, 0, 1);
      const color = mixColor(constraint.color, [1, 0.06, 0.02, 2.2], tension);
      writeSegmentMatrix(matrices, instanceCount * 16, a, b, constraint.radius * (1 - tension * 0.2));
      setColor(colors, instanceCount, color);
      instanceCount++;
    }

    for (const payload of this.payloads) {
      if (instanceCount >= maxCount) break;
      const p = readPosition(this.positions, payload.particle);
      const o = payload.particle * 3;
      const vx = this.positions[o] - this.previous[o];
      const vz = this.positions[o + 2] - this.previous[o + 2];
      writeModelMatrixFromEuler(matrices, instanceCount * 16, p, [vz * 0.8, 0, -vx * 0.8], payload.half);
      setColor(colors, instanceCount, payload.color);
      instanceCount++;
    }

    for (const projectile of this.projectiles) {
      if (instanceCount >= maxCount) break;
      writeModelMatrixFromEuler(matrices, instanceCount * 16, projectile.position, [this.time * 1.8, this.time, 0], [projectile.radius, projectile.radius, projectile.radius]);
      setColor(colors, instanceCount, projectile.color);
      instanceCount++;
    }

    const debugLines: DebugLine[] = [];
    if (debug) {
      for (let i = 0; i < this.invMass.length; i += Math.max(1, Math.floor(this.invMass.length / 160))) {
        const p = readPosition(this.positions, i);
        const pinned = this.invMass[i] === 0;
        debugLines.push({
          ax: p[0] - 0.12, ay: p[1], az: p[2], bx: p[0] + 0.12, by: p[1], bz: p[2],
          r: pinned ? 1 : 0.2, g: pinned ? 0.72 : 0.85, b: pinned ? 0.12 : 1, a: 0.7,
        });
      }
    }

    this.hashValue = quantizedHash(this.positions, Math.min(this.positions.length, 4096));
    return {
      kind: this.kind,
      label: this.label,
      matrices: matrices.subarray(0, instanceCount * 16),
      colors: colors.subarray(0, instanceCount * 4),
      instanceCount,
      surface: null,
      debugLines,
      nodeCount: this.invMass.length,
      constraintCount: this.constraints.length,
      brokenCount: this.brokenCountValue,
      energy: this.energyValue,
      hash: this.hashValue,
    };
  }

  destroy(): void {
    this.constraints = [];
    this.payloads = [];
    this.projectiles = [];
    this.positions = EMPTY_FLOAT32;
    this.previous = EMPTY_FLOAT32;
    this.invMass = EMPTY_FLOAT32;
  }
}

type WaterDroplet = {
  position: Vec3;
  velocity: Vec3;
  radius: number;
  life: number;
};

type WaterFloater = {
  position: Vec3;
  velocity: Vec3;
  half: Vec3;
  color: [number, number, number, number];
  mass: number;
};

class WaterSimulation implements SoftSimulation {
  readonly kind = 'water' as const;
  readonly label: string;

  private readonly cols: number;
  private readonly rows: number;
  private readonly count: number;
  private readonly width: number;
  private readonly depth: number;
  private readonly dx: number;
  private readonly dz: number;
  private readonly baseY: number;
  private eta: Float32Array;
  private u: Float32Array;
  private v: Float32Array;
  private nextEta: Float32Array;
  private nextU: Float32Array;
  private nextV: Float32Array;
  private readonly vertices: Float32Array;
  private readonly indices: Uint32Array;
  private readonly instanceMatrices = new Float32Array(MAX_SOFT_INSTANCES * 16);
  private readonly instanceColors = new Float32Array(MAX_SOFT_INSTANCES * 4);
  private readonly droplets: WaterDroplet[] = [];
  private readonly floaters: WaterFloater[] = [];
  private readonly rng: LcgRng;
  private readonly stress: number;
  private readonly variant: number;
  private readonly mode: number;
  private time = 0;
  private energyValue = 0;
  private hashValue = 0;

  constructor(scene: ScenePreset, stress: number, seed: number) {
    this.stress = stress;
    this.variant = scene.variant;
    this.mode = scene.mode;
    this.cols = Math.min(96, 44 + stress * 8 + (scene.mode >= 3 ? 8 : 0));
    this.rows = Math.min(80, 34 + stress * 6 + (scene.mode === 4 ? 6 : 0));
    this.count = this.cols * this.rows;
    this.width = 34;
    this.depth = 24;
    this.dx = this.width / Math.max(1, this.cols - 1);
    this.dz = this.depth / Math.max(1, this.rows - 1);
    this.baseY = 1.45;
    this.eta = new Float32Array(this.count);
    this.u = new Float32Array(this.count);
    this.v = new Float32Array(this.count);
    this.nextEta = new Float32Array(this.count);
    this.nextU = new Float32Array(this.count);
    this.nextV = new Float32Array(this.count);
    this.vertices = new Float32Array(this.count * SURFACE_VERTEX_FLOATS);
    this.indices = new Uint32Array(Math.max(0, (this.cols - 1) * (this.rows - 1) * 6));
    this.rng = new LcgRng(seed ^ 0x57a7e12);
    this.label = `${scene.title.replace(/\s+—.*$/, '')} · linear shallow-water ${this.cols}×${this.rows}`;
    this.initializeSurface();
    this.initializeVariants();
    this.buildSurface();
  }

  private index(x: number, z: number): number { return z * this.cols + x; }

  private worldToGrid(x: number, z: number): [number, number] {
    return [
      (x / this.width + 0.5) * (this.cols - 1),
      (z / this.depth + 0.5) * (this.rows - 1),
    ];
  }

  private gridToWorld(x: number, z: number): [number, number] {
    return [
      (x / Math.max(1, this.cols - 1) - 0.5) * this.width,
      (z / Math.max(1, this.rows - 1) - 0.5) * this.depth,
    ];
  }

  private initializeSurface(): void {
    let cursor = 0;
    for (let z = 0; z < this.rows - 1; z++) {
      for (let x = 0; x < this.cols - 1; x++) {
        const i0 = this.index(x, z);
        const i1 = this.index(x + 1, z);
        const i2 = this.index(x, z + 1);
        const i3 = this.index(x + 1, z + 1);
        this.indices[cursor++] = i0;
        this.indices[cursor++] = i2;
        this.indices[cursor++] = i1;
        this.indices[cursor++] = i1;
        this.indices[cursor++] = i2;
        this.indices[cursor++] = i3;
      }
    }
  }

  private initializeVariants(): void {
    if (this.variant === 0) {
      this.disturb(0, 0, 0.9, 2.2, 1.4);
      this.disturb(-7, 3, 0.45, 1.2, 0.6);
    } else if (this.variant === 1) {
      for (let z = 0; z < this.rows; z++) {
        for (let x = 0; x < Math.floor(this.cols * 0.18); x++) {
          this.eta[this.index(x, z)] = 1.2 * (1 - x / Math.max(1, this.cols * 0.18));
          this.u[this.index(x, z)] = 1.8;
        }
      }
    } else if (this.variant === 2) {
      for (let z = 0; z < this.rows; z++) {
        for (let x = 0; x < this.cols; x++) {
          const [wx, wz] = this.gridToWorld(x, z);
          this.eta[this.index(x, z)] = Math.sin(wx * 0.55) * 0.12 + Math.cos(wz * 0.72) * 0.09 + this.rng.signed(0.025);
          this.u[this.index(x, z)] = Math.sin(wz * 0.4) * 0.35;
          this.v[this.index(x, z)] = Math.cos(wx * 0.32) * 0.28;
        }
      }
    } else if (this.variant === 3) {
      this.floaters.push({ position: [-12, this.baseY + 0.7, 0], velocity: [2.2, 0, 0.45], half: [1.8, 0.42, 0.75], color: [0.95, 0.42, 0.08, 1], mass: 4 });
    } else if (this.variant === 4) {
      this.disturb(0, 0, 1.2, 1.6, 2.2);
    } else if (this.variant === 5) {
      this.spawnRain(80 + this.stress * 30, 15, 11);
    } else if (this.variant === 6) {
      for (let z = 0; z < this.rows; z++) {
        for (let x = 0; x < this.cols; x++) {
          if (x < this.cols * 0.42) this.eta[this.index(x, z)] = 0.75;
        }
      }
    } else if (this.variant === 7) {
      for (let z = 0; z < this.rows; z++) {
        for (let x = 0; x < this.cols; x++) {
          const [wx, wz] = this.gridToWorld(x, z);
          const r = Math.hypot(wx, wz) + 0.3;
          this.u[this.index(x, z)] = -wz / r * 1.2;
          this.v[this.index(x, z)] = wx / r * 1.2;
          this.eta[this.index(x, z)] = -Math.exp(-r * 0.24) * 0.45;
        }
      }
    } else if (this.variant === 8) {
      this.floaters.push({ position: [-6, this.baseY + 0.5, -2], velocity: [0.3, 0, 0.1], half: [1.2, 0.35, 0.8], color: [0.18, 0.48, 0.78, 1], mass: 3 });
      this.floaters.push({ position: [5, this.baseY + 0.45, 3], velocity: [-0.2, 0, -0.1], half: [0.8, 0.3, 0.6], color: [0.92, 0.72, 0.22, 1], mass: 2 });
    } else {
      this.floaters.push({ position: [0, this.baseY + 2.4, 0], velocity: [0, -1, 0], half: [1.3, 1.3, 1.3], color: [0.82, 0.18, 0.12, 1], mass: 12 });
      this.disturb(0, 0, 1.6, 2.5, 2.6);
    }
  }

  step(dt: number, subSteps: number): void {
    if (!Number.isFinite(dt) || dt <= 0) return;
    const steps = clamp(Math.round(subSteps), 1, 8);
    const subDt = Math.min(dt, 1 / 30) / steps;
    for (let sub = 0; sub < steps; sub++) {
      this.time += subDt;
      this.applyAutomaticForcing();
      this.solveShallowWater(subDt);
      this.updateDroplets(subDt);
      this.updateFloaters(subDt);
    }
    this.computeEnergy();
  }

  private applyAutomaticForcing(): void {
    if (this.variant === 0 && Math.floor(this.time * 2.2) !== Math.floor((this.time - 1 / 60) * 2.2)) {
      this.disturb(this.rng.signed(11), this.rng.signed(7), this.rng.range(0.2, 0.55), this.rng.range(0.7, 1.5), 0.7);
    } else if (this.variant === 2) {
      const z = Math.sin(this.time * 0.45) * 8;
      this.disturb(-16, z, Math.sin(this.time * 2.4) * 0.035, 1.4, 0.12);
    } else if (this.variant === 3) {
      const x = -14 + (this.time * 3.1) % 28;
      const z = Math.sin(this.time * 0.9) * 3.8;
      this.disturb(x, z, -0.055, 0.8, 0.35);
      this.disturb(x - 1.2, z + 0.8, 0.045, 0.7, 0.24);
      this.disturb(x - 1.2, z - 0.8, 0.045, 0.7, 0.24);
    } else if (this.variant === 4) {
      this.disturb(0, 0, Math.sin(this.time * 5.2) * 0.045, 1.0, 0.16);
    } else if (this.variant === 7) {
      const angle = this.time * 1.4;
      this.disturb(Math.cos(angle) * 4, Math.sin(angle) * 4, -0.035, 1.1, 0.28);
    }
  }

  private solveShallowWater(dt: number): void {
    const gravity = 9.81;
    const meanDepth = 1.35 + this.stress * 0.05;
    const drag = 0.28 + this.mode * 0.025;

    this.nextU.set(this.u);
    this.nextV.set(this.v);
    for (let z = 1; z < this.rows - 1; z++) {
      for (let x = 1; x < this.cols - 1; x++) {
        const i = this.index(x, z);
        const dEtaDx = (this.eta[this.index(x + 1, z)] - this.eta[this.index(x - 1, z)]) / (2 * this.dx);
        const dEtaDz = (this.eta[this.index(x, z + 1)] - this.eta[this.index(x, z - 1)]) / (2 * this.dz);
        this.nextU[i] = this.u[i] + (-gravity * dEtaDx - drag * this.u[i]) * dt;
        this.nextV[i] = this.v[i] + (-gravity * dEtaDz - drag * this.v[i]) * dt;
      }
    }

    this.nextEta.set(this.eta);
    for (let z = 1; z < this.rows - 1; z++) {
      for (let x = 1; x < this.cols - 1; x++) {
        const i = this.index(x, z);
        const duDx = (this.nextU[this.index(x + 1, z)] - this.nextU[this.index(x - 1, z)]) / (2 * this.dx);
        const dvDz = (this.nextV[this.index(x, z + 1)] - this.nextV[this.index(x, z - 1)]) / (2 * this.dz);
        const next = this.eta[i] - meanDepth * (duDx + dvDz) * dt;
        this.nextEta[i] = clamp(next, -1.65, 1.65);
      }
    }

    for (let x = 0; x < this.cols; x++) {
      for (const z of [0, this.rows - 1]) {
        const i = this.index(x, z);
        const inner = this.index(x, z === 0 ? 1 : this.rows - 2);
        this.nextEta[i] = this.nextEta[inner] * 0.92;
        this.nextU[i] = this.nextU[inner] * 0.78;
        this.nextV[i] = -this.nextV[inner] * 0.18;
      }
    }
    for (let z = 0; z < this.rows; z++) {
      for (const x of [0, this.cols - 1]) {
        const i = this.index(x, z);
        const inner = this.index(x === 0 ? 1 : this.cols - 2, z);
        this.nextEta[i] = this.nextEta[inner] * 0.92;
        this.nextU[i] = -this.nextU[inner] * 0.18;
        this.nextV[i] = this.nextV[inner] * 0.78;
      }
    }

    [this.eta, this.nextEta] = [this.nextEta, this.eta];
    [this.u, this.nextU] = [this.nextU, this.u];
    [this.v, this.nextV] = [this.nextV, this.v];
  }

  private disturb(x: number, z: number, amplitude: number, radius: number, radialVelocity: number): void {
    const [gx, gz] = this.worldToGrid(x, z);
    const rx = Math.ceil(radius / this.dx) + 1;
    const rz = Math.ceil(radius / this.dz) + 1;
    const minX = Math.max(1, Math.floor(gx) - rx);
    const maxX = Math.min(this.cols - 2, Math.ceil(gx) + rx);
    const minZ = Math.max(1, Math.floor(gz) - rz);
    const maxZ = Math.min(this.rows - 2, Math.ceil(gz) + rz);
    for (let iz = minZ; iz <= maxZ; iz++) {
      for (let ix = minX; ix <= maxX; ix++) {
        const [wx, wz] = this.gridToWorld(ix, iz);
        const dx = wx - x;
        const dz = wz - z;
        const d = Math.hypot(dx, dz);
        if (d > radius) continue;
        const falloff = 0.5 + 0.5 * Math.cos((d / Math.max(0.001, radius)) * Math.PI);
        const i = this.index(ix, iz);
        this.eta[i] = clamp(this.eta[i] + amplitude * falloff, -1.65, 1.65);
        if (d > 1e-5) {
          this.u[i] += (dx / d) * radialVelocity * falloff;
          this.v[i] += (dz / d) * radialVelocity * falloff;
        }
      }
    }
  }

  private sample(x: number, z: number): { height: number; u: number; v: number } {
    const [gxRaw, gzRaw] = this.worldToGrid(x, z);
    const gx = clamp(gxRaw, 0, this.cols - 1.001);
    const gz = clamp(gzRaw, 0, this.rows - 1.001);
    const x0 = Math.floor(gx);
    const z0 = Math.floor(gz);
    const x1 = Math.min(this.cols - 1, x0 + 1);
    const z1 = Math.min(this.rows - 1, z0 + 1);
    const tx = gx - x0;
    const tz = gz - z0;
    const sampleField = (field: Float32Array): number => {
      const a = field[this.index(x0, z0)] * (1 - tx) + field[this.index(x1, z0)] * tx;
      const b = field[this.index(x0, z1)] * (1 - tx) + field[this.index(x1, z1)] * tx;
      return a * (1 - tz) + b * tz;
    };
    return { height: this.baseY + sampleField(this.eta), u: sampleField(this.u), v: sampleField(this.v) };
  }

  private updateDroplets(dt: number): void {
    for (const droplet of this.droplets) {
      droplet.life -= dt;
      droplet.velocity[1] -= 9.81 * dt;
      droplet.position[0] += droplet.velocity[0] * dt;
      droplet.position[1] += droplet.velocity[1] * dt;
      droplet.position[2] += droplet.velocity[2] * dt;
      const water = this.sample(droplet.position[0], droplet.position[2]);
      if (droplet.position[1] <= water.height && droplet.life > 0) {
        const speed = Math.abs(droplet.velocity[1]);
        this.disturb(droplet.position[0], droplet.position[2], clamp(speed * 0.025, 0.04, 0.36), clamp(droplet.radius * 5, 0.5, 1.6), speed * 0.025);
        droplet.life = 0;
      }
    }
    for (let i = this.droplets.length - 1; i >= 0; i--) {
      if (this.droplets[i].life <= 0) this.droplets.splice(i, 1);
    }
  }

  private updateFloaters(dt: number): void {
    for (const floater of this.floaters) {
      const water = this.sample(floater.position[0], floater.position[2]);
      const bottom = floater.position[1] - floater.half[1];
      const submergence = clamp((water.height - bottom) / Math.max(0.1, floater.half[1] * 2), 0, 1.4);
      const buoyancy = 15.5 * submergence / Math.max(0.5, floater.mass * 0.35);
      floater.velocity[1] += (-9.81 + buoyancy) * dt;
      floater.velocity[0] += (water.u - floater.velocity[0]) * submergence * dt * 1.8;
      floater.velocity[2] += (water.v - floater.velocity[2]) * submergence * dt * 1.8;
      floater.velocity[0] *= 0.998;
      floater.velocity[1] *= 0.995;
      floater.velocity[2] *= 0.998;
      floater.position[0] += floater.velocity[0] * dt;
      floater.position[1] += floater.velocity[1] * dt;
      floater.position[2] += floater.velocity[2] * dt;
      if (floater.position[1] - floater.half[1] < 0.15) {
        floater.position[1] = floater.half[1] + 0.15;
        floater.velocity[1] = Math.abs(floater.velocity[1]) * 0.18;
      }
      if (Math.abs(floater.position[0]) > this.width * 0.47) floater.velocity[0] *= -0.55;
      if (Math.abs(floater.position[2]) > this.depth * 0.47) floater.velocity[2] *= -0.55;
      this.disturb(floater.position[0], floater.position[2], -submergence * 0.006, Math.max(floater.half[0], floater.half[2]) * 1.6, submergence * 0.015);
    }
  }

  private computeEnergy(): void {
    let energy = 0;
    for (let i = 0; i < this.count; i++) {
      energy += this.eta[i] * this.eta[i] * 9.81 + this.u[i] * this.u[i] + this.v[i] * this.v[i];
    }
    this.energyValue = energy / Math.max(1, this.count);
  }

  kick(strength: number): void {
    const amplitude = clamp(strength * 0.08, 0.2, 1.2);
    this.disturb(-this.width * 0.36, 0, amplitude, 3.2, strength * 0.08);
    for (let z = 1; z < this.rows - 1; z++) {
      const i = this.index(2, z);
      this.u[i] += strength * 0.14;
    }
  }

  explode(center: Vec3, strength: number, radius: number): void {
    this.disturb(center[0], center[2], clamp(strength * 0.07, 0.35, 1.65), clamp(radius * 0.32, 1.2, 5.2), strength * 0.09);
    const splashCount = Math.max(0, Math.min(
      180,
      Math.max(20, Math.round(strength * 5)),
      MAX_WATER_DROPLETS - this.droplets.length,
    ));
    for (let i = 0; i < splashCount; i++) {
      const angle = this.rng.range(0, Math.PI * 2);
      const speed = this.rng.range(2, 7) * Math.sqrt(Math.max(1, strength) / 12);
      this.droplets.push({
        position: [center[0] + Math.cos(angle) * this.rng.range(0, 1.2), this.sample(center[0], center[2]).height + this.rng.range(0.1, 0.5), center[2] + Math.sin(angle) * this.rng.range(0, 1.2)],
        velocity: [Math.cos(angle) * speed, this.rng.range(4, 10), Math.sin(angle) * speed],
        radius: this.rng.range(0.04, 0.11),
        life: this.rng.range(1, 3),
      });
    }
  }

  launchProjectile(position: Vec3, velocity: Vec3, size: number): number {
    if (this.floaters.length >= 20) return -1;
    this.floaters.push({
      position: [...position] as Vec3,
      velocity: [...velocity] as Vec3,
      half: [size, size, size],
      color: [1, 0.46, 0.08, 2.1],
      mass: 8 + size * 8,
    });
    return this.floaters.length - 1;
  }

  spawnRain(count: number, spread: number, height: number): number {
    const allowed = Math.max(0, Math.min(Math.max(0, Math.round(count)), MAX_WATER_DROPLETS - this.droplets.length));
    for (let i = 0; i < allowed; i++) {
      this.droplets.push({
        position: [this.rng.signed(Math.min(spread, this.width * 0.48)), height + this.rng.range(0, 10), this.rng.signed(Math.min(spread, this.depth * 0.48))],
        velocity: [this.rng.signed(0.45), this.rng.range(-12, -7), this.rng.signed(0.45)],
        radius: this.rng.range(0.025, 0.075),
        life: 4,
      });
    }
    return allowed;
  }

  private buildSurface(): DynamicSurfaceFrame {
    for (let z = 0; z < this.rows; z++) {
      for (let x = 0; x < this.cols; x++) {
        const i = this.index(x, z);
        const vo = i * SURFACE_VERTEX_FLOATS;
        const [wx, wz] = this.gridToWorld(x, z);
        const left = this.eta[this.index(Math.max(0, x - 1), z)];
        const right = this.eta[this.index(Math.min(this.cols - 1, x + 1), z)];
        const down = this.eta[this.index(x, Math.max(0, z - 1))];
        const up = this.eta[this.index(x, Math.min(this.rows - 1, z + 1))];
        const normal = vec3Normalize([-(right - left) / (2 * this.dx), 1, -(up - down) / (2 * this.dz)]);
        const laplacian = Math.abs(left + right + down + up - 4 * this.eta[i]);
        const speed = Math.hypot(this.u[i], this.v[i]);
        const foam = clamp(laplacian * 2.2 + speed * 0.22 - 0.08, 0, 1);
        this.vertices[vo] = wx;
        this.vertices[vo + 1] = this.baseY + this.eta[i];
        this.vertices[vo + 2] = wz;
        this.vertices[vo + 3] = normal[0];
        this.vertices[vo + 4] = normal[1];
        this.vertices[vo + 5] = normal[2];
        this.vertices[vo + 6] = 0.02 + foam * 0.38;
        this.vertices[vo + 7] = 0.28 + foam * 0.55;
        this.vertices[vo + 8] = 0.55 + foam * 0.42;
        this.vertices[vo + 9] = foam;
        this.vertices[vo + 10] = x / Math.max(1, this.cols - 1);
        this.vertices[vo + 11] = z / Math.max(1, this.rows - 1);
      }
    }
    this.hashValue = quantizedHash(this.eta, Math.min(this.eta.length, 4096));
    return {
      material: 'water',
      vertices: this.vertices,
      indices: this.indices,
      vertexCount: this.count,
      indexCount: this.indices.length,
    };
  }

  buildFrame(debug: boolean): SoftSimulationFrame {
    const maxCount = MAX_SOFT_INSTANCES;
    const matrices = this.instanceMatrices;
    const colors = this.instanceColors;
    let instanceCount = 0;
    for (const floater of this.floaters) {
      if (instanceCount >= maxCount) break;
      const water = this.sample(floater.position[0], floater.position[2]);
      const pitch = clamp((water.v - floater.velocity[2]) * 0.08, -0.35, 0.35);
      const roll = clamp((floater.velocity[0] - water.u) * 0.08, -0.35, 0.35);
      writeModelMatrixFromEuler(matrices, instanceCount * 16, floater.position, [pitch, 0, roll], floater.half);
      setColor(colors, instanceCount, floater.color);
      instanceCount++;
    }
    for (const droplet of this.droplets) {
      if (instanceCount >= maxCount) break;
      writeModelMatrixFromEuler(matrices, instanceCount * 16, droplet.position, [0, 0, 0], [droplet.radius, droplet.radius * 1.9, droplet.radius]);
      setColor(colors, instanceCount, [0.18, 0.68, 1, 1.7]);
      instanceCount++;
    }

    const debugLines: DebugLine[] = [];
    if (debug) {
      const stepX = Math.max(3, Math.floor(this.cols / 12));
      const stepZ = Math.max(3, Math.floor(this.rows / 9));
      for (let z = stepZ; z < this.rows - stepZ; z += stepZ) {
        for (let x = stepX; x < this.cols - stepX; x += stepX) {
          const i = this.index(x, z);
          const [wx, wz] = this.gridToWorld(x, z);
          const y = this.baseY + this.eta[i] + 0.05;
          debugLines.push({
            ax: wx, ay: y, az: wz,
            bx: wx + this.u[i] * 0.55, by: y, bz: wz + this.v[i] * 0.55,
            r: 0.18, g: 0.82, b: 1, a: 0.55,
          });
        }
      }
    }

    return {
      kind: this.kind,
      label: this.label,
      matrices: matrices.subarray(0, instanceCount * 16),
      colors: colors.subarray(0, instanceCount * 4),
      instanceCount,
      surface: this.buildSurface(),
      debugLines,
      nodeCount: this.count + this.droplets.length + this.floaters.length,
      constraintCount: Math.max(0, (this.cols - 2) * (this.rows - 2) * 3),
      brokenCount: 0,
      energy: this.energyValue,
      hash: this.hashValue,
    };
  }

  destroy(): void {
    this.droplets.length = 0;
    this.floaters.length = 0;
    this.eta = EMPTY_FLOAT32;
    this.u = EMPTY_FLOAT32;
    this.v = EMPTY_FLOAT32;
    this.nextEta = EMPTY_FLOAT32;
    this.nextU = EMPTY_FLOAT32;
    this.nextV = EMPTY_FLOAT32;
  }
}

const EMPTY_FRAME: SoftSimulationFrame = {
  kind: 'none',
  label: 'Rigid-body only',
  matrices: EMPTY_FLOAT32,
  colors: EMPTY_FLOAT32,
  instanceCount: 0,
  surface: null,
  debugLines: [],
  nodeCount: 0,
  constraintCount: 0,
  brokenCount: 0,
  energy: 0,
  hash: 0,
};

export class SoftSimulationSuite {
  private active: SoftSimulation | null = null;
  private lastScene: ScenePreset | null = null;
  private lastStress = 1;
  private lastSeed = 0;

  createScene(scene: ScenePreset, stress: number, seed: number): boolean {
    this.active?.destroy();
    this.active = null;
    this.lastScene = scene;
    this.lastStress = clamp(Math.round(stress), 1, 5);
    this.lastSeed = seed >>> 0;
    if (!softFamily(scene.family)) return false;
    if (scene.family === 'cloth') this.active = new ClothSimulation(scene, this.lastStress, this.lastSeed);
    else if (scene.family === 'rope') this.active = new RopeSimulation(scene, this.lastStress, this.lastSeed);
    else this.active = new WaterSimulation(scene, this.lastStress, this.lastSeed);
    return true;
  }

  reset(): void {
    if (this.lastScene) this.createScene(this.lastScene, this.lastStress, this.lastSeed);
  }

  isActive(): boolean { return this.active !== null; }
  kind(): SoftSimulationKind { return this.active?.kind ?? 'none'; }
  label(): string { return this.active?.label ?? EMPTY_FRAME.label; }

  step(dt: number, subSteps: number): void { this.active?.step(dt, subSteps); }
  kick(strength: number): void { this.active?.kick(strength); }
  explode(center: Vec3, strength: number, radius: number): void { this.active?.explode(center, strength, radius); }
  launchProjectile(position: Vec3, velocity: Vec3, size: number): number { return this.active?.launchProjectile(position, velocity, size) ?? -1; }
  spawnRain(count: number, spread: number, height: number): number { return this.active?.spawnRain(count, spread, height) ?? 0; }
  buildFrame(debug = false): SoftSimulationFrame { return this.active?.buildFrame(debug) ?? EMPTY_FRAME; }
  hash(): number { return this.active?.buildFrame(false).hash ?? 0; }

  destroy(): void {
    this.active?.destroy();
    this.active = null;
  }

  validate(): { ok: boolean; message: string } {
    const frame = this.buildFrame(false);
    if (frame.kind === 'none') return { ok: true, message: 'No soft simulation active.' };
    if (frame.instanceCount < 0 || frame.instanceCount > MAX_SOFT_INSTANCES) {
      return { ok: false, message: `${frame.kind} exceeded the ${MAX_SOFT_INSTANCES}-instance soft simulation budget.` };
    }
    if (frame.matrices.length !== frame.instanceCount * 16 || frame.colors.length !== frame.instanceCount * 4) {
      return { ok: false, message: `${frame.kind} instance stream lengths do not match the declared instance count.` };
    }
    if (!isFiniteArray(frame.matrices) || !isFiniteArray(frame.colors)) {
      return { ok: false, message: `${frame.kind} instance stream contains non-finite values.` };
    }
    if (!Number.isFinite(frame.energy) || frame.energy < 0 || !Number.isInteger(frame.hash)) {
      return { ok: false, message: `${frame.kind} telemetry contains invalid energy or replay-hash values.` };
    }
    if (frame.surface) {
      if (frame.surface.vertexCount <= 0 || frame.surface.indexCount <= 0) {
        return { ok: false, message: `${frame.kind} surface topology is empty.` };
      }
      if (frame.surface.vertices.length !== frame.surface.vertexCount * SURFACE_VERTEX_FLOATS) {
        return { ok: false, message: `${frame.kind} surface vertex stride/count is inconsistent.` };
      }
      if (!isFiniteArray(frame.surface.vertices) || frame.surface.indices.length !== frame.surface.indexCount) {
        return { ok: false, message: `${frame.kind} surface stream is invalid.` };
      }
      for (let i = 0; i < frame.surface.indexCount; i++) {
        if (frame.surface.indices[i] >= frame.surface.vertexCount) {
          return { ok: false, message: `${frame.kind} surface index ${frame.surface.indices[i]} is out of range.` };
        }
      }
    }
    if (frame.nodeCount <= 0 || frame.hash === 0) return { ok: false, message: `${frame.kind} telemetry did not initialize.` };
    return { ok: true, message: `${frame.kind} validated: ${frame.nodeCount} nodes, ${frame.constraintCount} constraints.` };
  }
}

export const SOFT_INSTANCE_BUDGET = MAX_SOFT_INSTANCES;
export const SOFT_SURFACE_VERTEX_FLOATS = SURFACE_VERTEX_FLOATS;
export const EMPTY_SURFACE: DynamicSurfaceFrame = {
  material: 'cloth',
  vertices: EMPTY_FLOAT32,
  indices: EMPTY_UINT32,
  vertexCount: 0,
  indexCount: 0,
};
