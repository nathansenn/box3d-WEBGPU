# Performance Edition

## Reproducible baseline

The exact v1.1.0 source baseline is bundled at `benchmarks/baseline/box3d-WEBGPU-AAA-v1.1.0-source.tar.gz`. `npm run bench:end-to-end` extracts it into a temporary benchmark workspace when `BOX3D_BASELINE` is not provided, so the before/after comparison works outside this build environment.
