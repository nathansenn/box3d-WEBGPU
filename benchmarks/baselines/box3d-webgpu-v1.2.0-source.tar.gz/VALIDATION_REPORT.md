# Validation Report — Box3D WebGPU AAA Physics Lab v1.1.0

## Release scope

This report covers the edition that adds deterministic cloth, rope, and interactive shallow-water simulation to the validated v1.0.2 rigid/WebGPU foundation.

```text
750 deterministic scenes
30 cinematic hero demonstrations
150 cloth/rope/water scenes
8 WGSL shader modules in the Dawn gate
11 deterministic Node suites
```

## Automated release gates

| Gate | Result |
|---|---:|
| Strict TypeScript | Passed |
| Deterministic Node suites | 11 / 11 passed |
| Generated scene constructors | 750 / 750 passed |
| Cloth/rope/water constructors | 150 / 150 passed |
| Hero definitions and camera/beat validation | 30 / 30 passed |
| Repository/UI/build contract self-test | Passed |
| C17 native bridge syntax (`-Wall -Wextra -Werror`) | Passed |
| Dawn WGSL compilation | 8 / 8 shader modules passed |
| Rigid, cloth, water, line, sky, shadow, and post pipelines | Passed |
| Indexed dynamic-surface upload/draw | Passed |
| Full shadow → HDR/MSAA → post frame submission | Passed |
| Actual `WebGPURenderer` runtime path | Passed |
| Dawn uncaptured validation errors | 0 |
| Production Vite build | Passed |
| GitHub Pages relative-base build | Passed |
| npm moderate-or-higher audit | 0 vulnerabilities |

## Soft-system catalog soak

The permanent `npm run test:soft-soak` gate performs a representative stress sequence in every soft/fluid scene and paired deterministic replays for the maximum cloth, rope, and water entries.

Default gate result:

```text
150 scenes
3,600 catalog frames
1,800 paired deterministic replay frames
50 cloth scenes
50 rope scenes
50 water scenes
maximum nodes:       7,011
maximum constraints: 18,360
maximum instances:     571
maximum breaks:        130
maximum energy:        447.153…
```

Each frame is checked for:

- finite model matrices and material colors;
- valid instance counts and stream lengths;
- finite energy and initialized replay hashes;
- finite dynamic-surface vertices;
- exact 12-float surface stride;
- complete index streams with every index in range;
- correct solver family and initialized telemetry.

## Extended stress evidence

Additional long-duration runs were executed during release preparation.

| System | Coverage | Frames | High-water marks / result |
|---|---:|---:|---|
| Cloth | 50 scenes | 6,000 | 1,700 nodes, 9,782 constraints, 357 controlled breaks; finite topology |
| Rope | 50 scenes | 9,000 | 405 nodes, 783 constraints, 474 instances, 77 breaks; finite segment stream |
| Water | 50 scenes | 12,000 | 6,785 nodes, 18,360 cells, 345 instances; bounded finite field |

Deep paired/repeated deterministic runs:

```text
cloth scene 649  · 600 frames  · final hash 1423879200
rope scene 699   · 1,200 frames · final hash 3510898898
water scene 749  · 3,600 frames · final hash 4288531700
```

Hashes are regression signatures for this code/revision and action schedule. They are not cryptographic guarantees across future implementations.

## Renderer validation

The Dawn test extracts and compiles eight WGSL modules and creates the complete render topology:

```text
rigid shadow pipeline
dynamic cloth shadow pipeline
atmospheric sky pipeline
PBR rigid solid pipeline
woven cloth pipeline
interactive water pipeline
line/effect pipeline
post-processing pipeline
```

It also creates a BGRA post-process compatibility variant, binds isolated shadow resources, uploads dynamic indexed cloth/water surfaces, and submits a complete offscreen frame.

A second test transpiles and runs the actual `WebGPURenderer` class against a Dawn-backed canvas shim. It covers:

- renderer construction and resource allocation;
- rigid instances;
- cloth indexed surface upload and draw;
- water indexed surface upload and draw;
- shadows and dynamic-surface shadows;
- debug/effect lines;
- target resize;
- empty/no-shadow frames;
- zero uncaptured WebGPU errors.

The v1.0.2 protections remain enforced:

- `textureSampleCompareLevel` avoids derivative-uniformity failure;
- atmospheric sky declares `depth24plus` compatibility;
- writable shadow depth is isolated from the later sampled bind group;
- zero-instance rigid draws are skipped.

## Production bundle

The v1.1.0 production and relative-base GitHub Pages builds completed with:

```text
dist/index.html                  24.52 kB · 6.56 kB gzip
dist/assets/index-ClVqnSfm.js  164.13 kB · 48.41 kB gzip
```

The asset hash can change when source or toolchain output changes; the size is recorded as a release reference rather than a permanent contract.

## Solver performance observations

After allocation and constraint-loop optimization, local Node measurements in this validation environment showed maximum cloth scenes around 10–15 ms per simulation frame, with rope and water generally lower. The default 150-scene soak completed in about 28 seconds in this container. These are regression observations from one CPU environment—not cross-device browser benchmarks, visible compositing measurements, or physical-GPU timing.

## Browser-render validation boundary

Dawn validates shader compilation, pipeline creation, attachment compatibility, resources, indexed draws, and command submission without requiring a visible hardware-backed browser window. A target-device browser run is still required for:

- pixel-level appearance and transparency ordering;
- browser/driver-specific behavior;
- hardware performance;
- device-loss behavior;
- high-DPI and resize behavior;
- full-screen capture quality.

Use `docs/LOCAL_BROWSER_VALIDATION.md` and the in-app **Run 750 + 30 Browser Tests** control.

## Native Box3D build boundary

The native C bridge passed strict syntax/API-contract validation. A true Emscripten link against the fetched upstream Box3D source still requires a local machine with Emscripten activated:

```bash
npm run fetch:box3d
npm run build:wasm
npm run validate
npm run dev
```

The cloth, rope, and water solvers are TypeScript systems and do not depend on the WASM artifact. The native build changes rigid-body staging from the deterministic preview backend to Box3D WASM.

## Release assessment

The v1.1.0 source is suitable as a validated **engineering/demo release**: the codebase, generated catalog, soft-system numerical behavior, shader modules, pipeline resources, indexed rendering, and production bundle pass the automated gates. Native Box3D linking and a visible target-browser acceptance run remain the final machine-specific production gates.
