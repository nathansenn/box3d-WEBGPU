function ok(value: unknown, message = 'assertion failed'): void {
  if (!value) throw new Error(message);
}

function equal<T>(actual: T, expected: T, message?: string): void {
  if (actual !== expected) {
    throw new Error(message ?? `expected ${String(actual)} to equal ${String(expected)}`);
  }
}

function deepEqual(actual: unknown, expected: unknown, message?: string): void {
  const a = JSON.stringify(actual);
  const b = JSON.stringify(expected);
  if (a !== b) throw new Error(message ?? `expected ${a} to deepEqual ${b}`);
}

import {
  isFiniteArray,
  mat4Identity,
  mat4Multiply,
  mat4Orthographic,
  mat4Perspective,
  writeModelMatrixFromEuler,
} from '../src/math';
import { CinematicEffects } from '../src/effects';
import { FallbackPhysicsBackend } from '../src/physics/fallback';
import { FEATURED_SCENE_IDS, SCENES, SCENE_CATEGORIES, sceneLabel } from '../src/scenes';
import { AAA_SHOWCASES, getShowcaseById, getShowcaseByOrdinal, sampleShowcaseCamera } from '../src/showcases';
import { SOFT_INSTANCE_BUDGET, SoftSimulationSuite } from '../src/soft/simulations';
import { PACKED_SURFACE_VERTEX_BYTES } from '../src/soft/packed-surface';
import { TurboQuantCodec, TurboQuantDeltaStream, turboQuantCompressionRatio, turboQuantError } from '../src/compression/turboquant';
import type { DynamicSurfaceFrame } from '../src/types';

function approx(a: number, b: number, eps = 1e-5): void {
  ok(Math.abs(a - b) <= eps, `expected ${a} ≈ ${b}`);
}

function surfaceStateFinite(surface: DynamicSurfaceFrame): boolean {
  if (surface.path === 'gpu-cloth') {
    return isFiniteArray(surface.positions) && isFiniteArray(surface.restPositions) && isFiniteArray(surface.strain);
  }
  if (surface.path === 'gpu-water') return isFiniteArray(surface.eta) && isFiniteArray(surface.u) && isFiniteArray(surface.v);
  return isFiniteArray(surface.vertices);
}

function testMath(): void {
  const id = mat4Identity();
  const model = new Float32Array(16);
  writeModelMatrixFromEuler(model, 0, [1, 2, 3], [0, 0, 0], [2, 3, 4]);
  const result = mat4Multiply(id, model);
  for (let i = 0; i < 16; i++) approx(result[i], model[i]);
  approx(model[0], 2);
  approx(model[5], 3);
  approx(model[10], 4);
  approx(model[12], 1);
  approx(model[13], 2);
  approx(model[14], 3);

  const perspective = mat4Perspective(Math.PI / 3, 16 / 9, 0.08, 360);
  const orthographic = mat4Orthographic(-50, 50, -30, 30, 0.1, 190);
  ok(isFiniteArray(perspective), 'perspective matrix must be finite');
  ok(isFiniteArray(orthographic), 'orthographic matrix must be finite');
  ok(perspective[0] > 0 && perspective[5] > 0, 'perspective focal terms must be positive');
  ok(orthographic[0] > 0 && orthographic[5] > 0, 'orthographic scale terms must be positive');
}

function testSceneCatalog(): void {
  equal(SCENES.length, 750);
  equal(FEATURED_SCENE_IDS.length, 30);
  const ids = new Set(SCENES.map((scene) => scene.id));
  equal(ids.size, SCENES.length);
  deepEqual([...ids].slice(0, 5), [0, 1, 2, 3, 4]);
  deepEqual([...ids].slice(-5), [745, 746, 747, 748, 749]);
  for (const category of SCENE_CATEGORIES) {
    ok(SCENES.some((scene) => scene.category === category), `${category} should have scenes`);
  }
  for (const scene of SCENES) {
    ok(sceneLabel(scene).startsWith(String(scene.id + 1).padStart(3, '0')));
    ok(scene.title.length > 5);
    ok(scene.defaultStress >= 1 && scene.defaultStress <= 5);
    ok(scene.variant >= 0 && scene.variant < 10);
    ok(scene.tags.length >= 4);
    ok(scene.camera.pitch >= 0.08 && scene.camera.pitch <= 1.3, `${scene.title} camera elevation must remain above the scene`);
    const cameraEyeY = scene.camera.target[1] + Math.sin(scene.camera.pitch) * scene.camera.distance;
    ok(cameraEyeY > scene.camera.target[1], `${scene.title} camera eye must be above its target`);
  }
}

function testHeroShowcaseCatalog(): void {
  equal(AAA_SHOWCASES.length, 30);
  const ids = new Set(AAA_SHOWCASES.map((showcase) => showcase.id));
  equal(ids.size, AAA_SHOWCASES.length, 'showcase IDs must be unique');

  for (let i = 0; i < AAA_SHOWCASES.length; i++) {
    const showcase = AAA_SHOWCASES[i];
    ok(SCENES.some((scene) => scene.id === showcase.sceneId), `${showcase.title} must reference a valid scene`);
    ok(showcase.title.length > 8);
    ok(showcase.tagline.length > 24);
    ok(showcase.objective.length > 32);
    ok(showcase.duration >= 12);
    ok(showcase.cameraTrack.length >= 5);
    ok(showcase.beats.length >= 6);
    ok(showcase.beats.every((beat, index) => index === 0 || beat.at >= showcase.beats[index - 1].at), `${showcase.title} beats must be sorted`);
    ok(showcase.cameraTrack.every((key, index) => index === 0 || key.at >= showcase.cameraTrack[index - 1].at), `${showcase.title} camera keys must be sorted`);

    for (const time of [0, showcase.duration * 0.25, showcase.duration * 0.5, showcase.duration * 0.75, showcase.duration]) {
      const camera = sampleShowcaseCamera(showcase, time);
      ok(Number.isFinite(camera.yaw + camera.pitch + camera.distance + camera.target[0] + camera.target[1] + camera.target[2]), `${showcase.title} camera must be finite`);
      ok(camera.distance >= 8, `${showcase.title} camera distance must remain usable`);
      ok(camera.pitch >= 0.08 && camera.pitch <= 1.3, `${showcase.title} camera elevation must remain above the scene`);
      const eyeY = camera.target[1] + Math.sin(camera.pitch) * camera.distance;
      ok(eyeY > camera.target[1], `${showcase.title} camera eye must be above its target`);
    }

    equal(getShowcaseById(showcase.id).id, showcase.id);
    equal(getShowcaseByOrdinal(i + AAA_SHOWCASES.length).id, showcase.id);
  }
}

function testFallbackCanCreateEveryScene(): void {
  const backend = new FallbackPhysicsBackend(4096);
  for (const scene of SCENES) {
    const count = backend.createScene(scene, 1, 0x1234 + scene.id);
    ok(count > 0, `${scene.title} should create bodies`);
    const matrixStart = Number(backend._b3w_matrices_ptr()) / 4;
    const matrices = backend.HEAPF32.subarray(matrixStart, matrixStart + Math.min(backend.bodyCount(), 24) * 16);
    ok(isFiniteArray(matrices), `${scene.title} produced non-finite matrices`);
    ok(backend.replayHash() !== 0, `${scene.title} hash should update`);
  }
}

function testAAACinematicSetDressing(): void {
  const baseline = new FallbackPhysicsBackend(4096);
  const cinematic = new FallbackPhysicsBackend(4096);
  const baselineCount = baseline.createScene(SCENES[0], 1, 0x4141);
  const cinematicCount = cinematic.createScene(SCENES[40], 1, 0x4141);
  ok(cinematicCount > baselineCount, `AAA scene should add authored set dressing (${cinematicCount} > ${baselineCount})`);

  for (const showcase of AAA_SHOWCASES) {
    const scene = SCENES[showcase.sceneId];
    const count = cinematic.createScene(scene, showcase.recommendedStress, 0x7000 + scene.id);
    ok(count > 10, `${showcase.title} should create a substantial hero scene`);
    cinematic.step(1 / 60, 2);
    const start = Number(cinematic._b3w_matrices_ptr()) / 4;
    ok(isFiniteArray(cinematic.HEAPF32.subarray(start, start + Math.min(48, count) * 16)), `${showcase.title} matrices must remain finite`);
  }
}

function testFeaturedScenesStep(): void {
  const backend = new FallbackPhysicsBackend(4096);
  for (const id of FEATURED_SCENE_IDS) {
    const scene = SCENES[id];
    ok(scene, `featured scene ${id} should exist`);
    backend.createScene(scene, 1, 0x5000 + id);
    for (let i = 0; i < 3; i++) backend.step(1 / 60, 1);
    const matrixStart = Number(backend._b3w_matrices_ptr()) / 4;
    const matrices = backend.HEAPF32.subarray(matrixStart, matrixStart + Math.min(backend.bodyCount(), 32) * 16);
    ok(isFiniteArray(matrices), `${scene.title} stepped into invalid matrices`);
  }
}

function testDeterminism(): void {
  const scene = SCENES[40];
  const a = new FallbackPhysicsBackend(4096);
  const b = new FallbackPhysicsBackend(4096);
  a.createScene(scene, 2, 0xbeef);
  b.createScene(scene, 2, 0xbeef);
  for (let i = 0; i < 12; i++) {
    a.step(1 / 60, 2);
    b.step(1 / 60, 2);
  }
  equal(a.replayHash(), b.replayHash(), 'same seed AAA replay hash should match');
}

function testFallbackCoherentBroadphase(): void {
  const scene = SCENES.find((candidate) => candidate.family === 'rain' && candidate.mode === 4 && candidate.variant === 9);
  ok(scene, 'maximum rain scene should exist');
  const a = new FallbackPhysicsBackend(4096);
  const b = new FallbackPhysicsBackend(4096);
  a.createScene(scene!, 5, 0x5a9b00);
  b.createScene(scene!, 5, 0x5a9b00);
  equal(a.spawnRain(180, 28, 34), b.spawnRain(180, 28, 34));
  for (let i = 0; i < 10; i++) {
    a.step(1 / 60, 2);
    b.step(1 / 60, 2);
  }
  equal(a.replayHash(), b.replayHash(), 'coherent broadphase must remain deterministic after body growth');
  equal(a.broadphaseAxis(), b.broadphaseAxis(), 'broadphase axis selection must be deterministic');
  equal(a.broadphaseCandidateCount(), b.broadphaseCandidateCount(), 'candidate discovery must be deterministic');
  const pairLimit = a.bodyCount() > 900 ? 420 : a.bodyCount() > 650 ? 560 : a.bodyCount();
  const bruteForcePairs = pairLimit * (pairLimit - 1) * 0.5;
  ok(a.broadphaseCandidateCount() < bruteForcePairs, 'sweep-and-prune should reject broadphase pairs');
}


function testSoftSimulationCatalog(): void {
  const suite = new SoftSimulationSuite();
  const counts = { cloth: 0, rope: 0, water: 0 };
  for (const scene of SCENES) {
    if (scene.family !== 'cloth' && scene.family !== 'rope' && scene.family !== 'water') continue;
    counts[scene.family]++;
    ok(suite.createScene(scene, Math.min(3, scene.defaultStress), 0x810000 + scene.id), `${scene.title} should activate a soft/fluid solver`);
    for (let i = 0; i < 4; i++) suite.step(1 / 60, 2);
    const frame = suite.buildFrame(true);
    equal(frame.kind, scene.family);
    ok(frame.label.length > 10, `${scene.title} must expose solver telemetry`);
    ok(frame.nodeCount > 0, `${scene.title} must have simulation nodes`);
    ok(frame.constraintCount > 0, `${scene.title} must expose constraints/cells`);
    ok(frame.instanceCount <= SOFT_INSTANCE_BUDGET, `${scene.title} exceeded the soft instance budget`);
    ok(isFiniteArray(frame.matrices), `${scene.title} produced non-finite instance matrices`);
    ok(isFiniteArray(frame.colors), `${scene.title} produced non-finite instance colors`);
    ok(Number.isFinite(frame.energy) && frame.energy >= 0, `${scene.title} produced invalid energy telemetry`);
    ok(frame.hash !== 0, `${scene.title} must produce a replay hash`);
    const validation = suite.validate();
    ok(validation.ok, validation.message);

    if (scene.family === 'cloth' || scene.family === 'water') {
      ok(frame.surface, `${scene.title} requires a dynamic indexed surface`);
      if (scene.family === 'water') equal(frame.surface!.path, 'gpu-water', `${scene.title} should use GPU-resident water reconstruction`);
      else if (scene.variant === 6 || (scene.mode >= 3 && scene.variant === 7)) {
        equal(frame.surface!.path, 'packed', `${scene.title} should retain topology-aware packed rendering while tearing`);
      } else {
        equal(frame.surface!.path, 'gpu-cloth', `${scene.title} should use GPU-resident intact-cloth reconstruction`);
      }
      ok(frame.surface!.vertexCount > 0 && frame.surface!.indexCount > 0, `${scene.title} surface must contain topology`);
      ok(surfaceStateFinite(frame.surface!), `${scene.title} surface state must be finite`);
      if (frame.surface!.path === 'packed') {
        equal(frame.surface!.vertexStride, PACKED_SURFACE_VERTEX_BYTES);
        equal(frame.surface!.vertices.byteLength, frame.surface!.vertexCount * frame.surface!.vertexStride);
      } else if (frame.surface!.path === 'gpu-cloth') {
        equal(frame.surface!.positions.length, frame.surface!.vertexCount * 3);
        equal(frame.surface!.restPositions.length, frame.surface!.vertexCount * 3);
        equal(frame.surface!.strain.length, frame.surface!.vertexCount);
      } else {
        equal(frame.surface!.eta.length, frame.surface!.vertexCount);
        equal(frame.surface!.u.length, frame.surface!.vertexCount);
        equal(frame.surface!.v.length, frame.surface!.vertexCount);
      }
      ok(frame.surface!.indices instanceof Uint16Array, `${scene.title} surface indices must use uint16`);
      ok(frame.surface!.indices.length >= frame.surface!.indexCount);
      let maxIndex = 0;
      for (let i = 0; i < frame.surface!.indexCount; i++) maxIndex = Math.max(maxIndex, frame.surface!.indices[i]);
      ok(maxIndex < frame.surface!.vertexCount, `${scene.title} surface index ${maxIndex} is out of range`);
      equal(frame.ropeGrid, null, `${scene.title} should not expose a rope grid`);
    } else {
      equal(frame.surface, null, `${scene.title} rope is rendered as tension-colored GPU-computed segments`);
      ok(frame.ropeGrid, `${scene.title} must expose a GPU rope grid`);
      ok(frame.ropeGrid!.segmentCount > 0, `${scene.title} must render rope segments`);
      ok(frame.ropeGrid!.segmentCount <= SOFT_INSTANCE_BUDGET, `${scene.title} exceeded the GPU rope segment budget`);
      ok(isFiniteArray(frame.ropeGrid!.positions), `${scene.title} rope positions must remain finite`);
      ok(isFiniteArray(frame.ropeGrid!.segments), `${scene.title} rope segment metadata must remain finite`);
      equal(frame.ropeGrid!.positions.length, frame.ropeGrid!.nodeCount * 3);
      ok(frame.ropeGrid!.segments.length >= frame.ropeGrid!.segmentCount * 8);
      ok(frame.instanceCount >= 0, `${scene.title} CPU payload instance count must remain valid`);
    }
  }
  deepEqual(counts, { cloth: 50, rope: 50, water: 50 });
  suite.destroy();
}

function testSoftFrameMemoization(): void {
  const suite = new SoftSimulationSuite();
  for (const sceneId of [600, 650, 700]) {
    const scene = SCENES[sceneId];
    ok(suite.createScene(scene, 3, 0xf18e000 + sceneId));
    const first = suite.buildFrame(false);
    const firstVersion = first.frameVersion;
    const repeated = suite.buildFrame(false);
    equal(repeated, first, `${scene.family} should reuse an unchanged frame object`);
    equal(repeated.frameVersion, firstVersion, `${scene.family} unchanged frame version should remain stable`);
    suite.step(1 / 60, 3);
    const advanced = suite.buildFrame(false);
    ok(advanced.frameVersion > firstVersion, `${scene.family} frame version should advance after simulation`);
  }
  suite.destroy();
}

function testSoftSimulationActionsAndDeterminism(): void {
  for (const sceneId of [600, 650, 700]) {
    const scene = SCENES[sceneId];
    const a = new SoftSimulationSuite();
    const b = new SoftSimulationSuite();
    ok(a.createScene(scene, 4, 0x51f700 + sceneId));
    ok(b.createScene(scene, 4, 0x51f700 + sceneId));
    for (let i = 0; i < 18; i++) {
      a.step(1 / 60, 3);
      b.step(1 / 60, 3);
    }
    equal(a.hash(), b.hash(), `${scene.family} must replay deterministically`);

    a.kick(12);
    a.explode([0, Math.max(2, scene.camera.target[1]), 0], 28, 16);
    const projectile = a.launchProjectile([-18, 8, 0], [32, 1, 0], 0.75);
    const rain = a.spawnRain(48, 12, 20);
    ok(projectile >= 0, `${scene.family} projectile coupling should be active`);
    ok(rain > 0, `${scene.family} rain coupling should be active`);
    for (let i = 0; i < 24; i++) a.step(1 / 60, 4);
    const frame = a.buildFrame(true);
    ok(isFiniteArray(frame.matrices) && isFiniteArray(frame.colors), `${scene.family} interactions must remain finite`);
    ok(!frame.surface || surfaceStateFinite(frame.surface), `${scene.family} dynamic surface must remain finite after impacts`);
    ok(
      !frame.ropeGrid || (isFiniteArray(frame.ropeGrid.positions) && isFiniteArray(frame.ropeGrid.segments)),
      `${scene.family} GPU rope state must remain finite after impacts`,
    );
    ok(frame.hash !== 0);
    a.destroy();
    b.destroy();
  }
}

function testFarProjectileBroadRejection(): void {
  for (const sceneId of [600, 650]) {
    const scene = SCENES[sceneId];
    const baseline = new SoftSimulationSuite();
    const rejected = new SoftSimulationSuite();
    ok(baseline.createScene(scene, 4, 0xb04d000 + sceneId));
    ok(rejected.createScene(scene, 4, 0xb04d000 + sceneId));
    ok(rejected.launchProjectile([200, 200, 200], [0, 0, 0], 0.75) >= 0);
    for (let i = 0; i < 24; i++) {
      baseline.step(1 / 60, 3);
      rejected.step(1 / 60, 3);
    }
    equal(rejected.hash(), baseline.hash(), `${scene.family} far projectile must not perturb solver state`);
    baseline.destroy();
    rejected.destroy();
  }
}

function testTurboQuantCodec(): void {
  const length = 4096;
  const source = new Float32Array(length);
  const next = new Float32Array(length);
  for (let i = 0; i < length; i++) {
    source[i] = Math.sin(i * 0.013) * 3 + Math.cos(i * 0.071) * 0.5;
    next[i] = source[i] + Math.sin(i * 0.037) * 0.025;
  }

  const dense = new TurboQuantCodec({ bits: 4, blockSize: 32, rotation: 'dense', centered: true, seed: 0x715517 });
  const densePacket = dense.encode(source);
  const denseDecoded = dense.decode(densePacket);
  const denseError = turboQuantError(source, denseDecoded);
  ok(turboQuantCompressionRatio(densePacket) > 5, 'dense TurboQuant should compress float state by more than 5x');
  ok(denseError.relativeL2 < 0.035, `dense TurboQuant reconstruction error is too high: ${denseError.relativeL2}`);

  const structuredA = new TurboQuantCodec({ bits: 3, blockSize: 64, rotation: 'structured', centered: false, seed: 0x715517 });
  const structuredB = new TurboQuantCodec({ bits: 3, blockSize: 64, rotation: 'structured', centered: false, seed: 0x715517 });
  const packetA = structuredA.encode(source);
  const packetB = structuredB.encode(source);
  deepEqual([...packetA.codes], [...packetB.codes], 'TurboQuant code stream must be deterministic');
  deepEqual([...packetA.norms], [...packetB.norms], 'TurboQuant block metadata must be deterministic');

  const encoder = new TurboQuantDeltaStream(length, { bits: 4, blockSize: 64, rotation: 'structured', centered: false, seed: 0x715517 });
  const decoder = new TurboQuantDeltaStream(length, { bits: 4, blockSize: 64, rotation: 'structured', centered: false, seed: 0x715517 });
  const firstPacket = encoder.encodeFrame(source);
  const firstDecoded = decoder.decodeFrame(firstPacket).slice();
  const secondPacket = encoder.encodeFrame(next);
  const secondDecoded = decoder.decodeFrame(secondPacket).slice();
  const firstError = turboQuantError(source, firstDecoded);
  const secondError = turboQuantError(next, secondDecoded);
  ok(firstError.relativeL2 < 0.12, `TurboQuant keyframe error is too high: ${firstError.relativeL2}`);
  ok(secondError.relativeL2 < 0.02, `TurboQuant predictive error is too high: ${secondError.relativeL2}`);
  for (let i = 0; i < length; i++) approx(encoder.reference[i], decoder.reference[i], 1e-6);
}

function testBreakthroughStormDeterminism(): void {
  for (const sceneId of [649, 699]) {
    const scene = SCENES[sceneId];
    const a = new SoftSimulationSuite();
    const b = new SoftSimulationSuite();
    ok(a.createScene(scene, 5, 0x515500 + sceneId));
    ok(b.createScene(scene, 5, 0x515500 + sceneId));
    const expectedRain = scene.family === 'rope' ? 96 : 150;
    equal(a.spawnRain(expectedRain, 14, 24), expectedRain);
    equal(b.spawnRain(expectedRain, 14, 24), expectedRain);
    for (let frame = 0; frame < 10; frame++) {
      a.step(1 / 60, 4);
      b.step(1 / 60, 4);
    }
    equal(a.hash(), b.hash(), `${scene.family} impact broad rejection must remain deterministic`);
    ok(a.validate().ok && b.validate().ok, `${scene.family} impact storm must remain finite`);

    if (scene.family === 'cloth') {
      const active = (a as unknown as { active: {
        iterations: number;
        fastIterations: number;
        constraintCountValue: number;
        constraintA: Uint16Array;
        constraintB: Uint16Array;
        constraintRest: Float32Array;
        constraintFastScaleA: Float32Array;
        constraintFastScaleB: Float32Array;
      } }).active;
      equal(active.fastIterations, 4, 'maximum membrane cloth must retain the validated four-pass adaptive schedule');
      ok(active.iterations >= active.fastIterations, 'adaptive cloth must never exceed the authoritative iteration count');
      ok(active.constraintCountValue > 0, 'adaptive cloth must retain a non-empty packed constraint stream');
      equal(active.constraintA.length, active.constraintCountValue, 'constraint A stream must cover every packed constraint');
      equal(active.constraintB.length, active.constraintCountValue, 'constraint B stream must cover every packed constraint');
      equal(active.constraintRest.length, active.constraintCountValue, 'constraint rest-length stream must cover every packed constraint');
      equal(active.constraintFastScaleA.length, active.constraintCountValue, 'fast-scale A stream must cover every packed constraint');
      equal(active.constraintFastScaleB.length, active.constraintCountValue, 'fast-scale B stream must cover every packed constraint');
      ok(isFiniteArray(active.constraintFastScaleA), 'adaptive cloth A stiffness compensation must remain finite');
      ok(isFiniteArray(active.constraintFastScaleB), 'adaptive cloth B stiffness compensation must remain finite');
    }
    a.destroy();
    b.destroy();
  }
}

function testCinematicEffects(): void {
  const effects = new CinematicEffects();
  effects.clear(0x515151);
  effects.spawnExplosion([0, 3, 0], 18, 512);
  effects.spawnProjectileMuzzle([-12, 6, 0], [24, 2, 0], 512);
  effects.spawnImpulseDust([0, 0.2, 0], 10, 512);
  effects.spawnRainFlash([0, 16, 0], 512);
  ok(effects.particleCount() >= 100, 'cinematic events should create a meaningful effect field');

  const before = effects.buildFrame(512);
  ok(before.count > 0);
  ok(isFiniteArray(before.matrices));
  ok(isFiniteArray(before.colors));
  ok(before.debugLines.length >= 72, 'explosion should create a shockwave ring');
  ok(before.colors.some((value, index) => index % 4 === 3 && value > 1), 'effects should carry emissive material tags');
  const beforeVersion = before.frameVersion;
  const repeated = effects.buildFrame(512);
  equal(repeated, before, 'unchanged effects should return the cached frame');
  equal(repeated.matrices, before.matrices, 'unchanged effects should reuse matrix storage');
  equal(repeated.colors, before.colors, 'unchanged effects should reuse color storage');

  effects.update(1 / 60);
  const after = effects.buildFrame(256);
  ok(after.frameVersion !== beforeVersion, 'effect simulation changes must advance the upload version');
  ok(after.count <= 256, 'effect frame must honor render budget');
  ok(isFiniteArray(after.matrices));
  const shake = effects.cameraShake();
  ok(Number.isFinite(shake.yaw + shake.pitch + shake.targetOffset[0] + shake.targetOffset[1] + shake.targetOffset[2]));
}

function testActions(): void {
  const backend = new FallbackPhysicsBackend(4096);
  backend.createScene(SCENES[40], 1, 0xcafe);
  const before = backend.bodyCount();
  backend.kick(6);
  backend.explode(0, 3, 0, 12, 8);
  const projectile = backend.launchProjectile(-10, 5, 0, 12, 0, 0, 0.5);
  ok(projectile >= 0, 'projectile should spawn');
  const rain = backend.spawnRain(20, 4, 8);
  equal(rain, 20);
  equal(backend.bodyCount(), before + 21);
  backend.step(1 / 60, 2);
  ok(backend.replayHash() !== 0);
}

const tests = [
  testMath,
  testSceneCatalog,
  testHeroShowcaseCatalog,
  testFallbackCanCreateEveryScene,
  testAAACinematicSetDressing,
  testFeaturedScenesStep,
  testDeterminism,
  testFallbackCoherentBroadphase,
  testSoftSimulationCatalog,
  testSoftSimulationActionsAndDeterminism,
  testFarProjectileBroadRejection,
  testSoftFrameMemoization,
  testTurboQuantCodec,
  testBreakthroughStormDeterminism,
  testCinematicEffects,
  testActions,
];

for (const test of tests) {
  test();
  console.log(`✓ ${test.name}`);
}

console.log(`All ${tests.length} unit suites passed.`);
