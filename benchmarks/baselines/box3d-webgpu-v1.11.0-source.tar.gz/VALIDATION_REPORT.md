# Validation Report — Box3D WebGPU AAA Physics Lab v1.11.0

Date: July 15, 2026

Status: **cross-platform release gate, Apple Metal hardware gate, and visible native-browser acceptance passed**

## Scope

V1.11 audits the optimization work from the prior project conversation against this repository's real v1.10 source, preserves the previously qualified architecture, and retains only exact or explicitly bounded new work:

- pinned native Box3D C17/Emscripten backend and tracked provenance;
- SIMD/scalar/JavaScript cloth, rope, and shallow-water kernels;
- GPU-resident intact cloth and water reconstruction;
- WebGPU-compute rope render expansion;
- allocation-free camera matrices and exact matrix invalidation;
- version-keyed main-frame diagnostic/effect line staging;
- exact soft-system miss rejection and right-sized retained storage;
- one-time fallback static streams, exact explosion/contact paths, and lazy replay hashing;
- native settled-world step elimination plus independent transform/material revisions;
- exact frame/upload caches for rigid, effects, debug lines, cloth, rope, and water;
- removal of one dead packed-water shader module and two unreachable render pipelines;
- maximum-stress rope projection batching only where a 250-combination equivalence test qualifies it;
- native BC4/R8 KTX2 texture loading;
- TurboQuant only for bandwidth-limited remote state;
- real 1×/4× MSAA, 1,024²/2,048² shadows, and 1/9-tap quality profiles;
- five-Hz averaged UI telemetry instead of per-frame DOM churn.

The v1.11 performance and rejection evidence is in [`docs/PERFORMANCE_V1.11.md`](docs/PERFORMANCE_V1.11.md). The prior integration map remains in [`docs/V1.10_INTEGRATION_AND_TEST_MATRIX.md`](docs/V1.10_INTEGRATION_AND_TEST_MATRIX.md).

## Release commands

```bash
npm ci
npm run verify:source
npm run validate:v1.11
npm run validate:hardware
npm audit --audit-level=moderate
```

`validate:v1.11` is the cross-platform CI and Pages release target. `validate:hardware` remains separate because it requires Dawn's Metal backend and timestamp-query support.

## Automated results

| Gate | Result |
|---|---:|
| Strict TypeScript | Passed |
| Deterministic Node suites | **21 / 21** |
| Catalog constructors | **750 / 750** |
| Hero definitions | **30 / 30** |
| C17 bridge syntax/API | Passed with warnings as errors |
| SIMD/scalar soft-kernel rebuild | Byte-identical |
| Dawn live WGSL modules | **11 / 11** |
| Dawn uncaptured errors | **0** |
| KTX2 R8/BC4/procedural paths | Passed on null and Metal |
| JavaScript soft soak | 150 scenes; 3,600 catalog + 1,800 replay frames |
| SIMD soft soak | 150 scenes; 3,600 catalog + 1,800 replay frames |
| Scalar soft soak | 150 scenes; 3,600 catalog + 1,800 replay frames |
| Rope legacy equivalence | **250 scene×stress combinations**, 720 frames each |
| Qualified rope batching | 38 maximum-stress combinations; 212 controls |
| Native Box3D soak | **750 scenes twice**, deterministic |
| Native body-frames per pass | **1,142,268** |
| Native maximum bodies | **4,096** |
| Invalid native timestep guard | NaN, ±Inf, zero, negative passed |
| Final v1.11 tournament | **100 / 100 cases**, zero correctness failures |
| Visible browser domains | Native rigid, cloth, rope, water passed |
| Visible browser state gate | **750 / 750 scenes; 30 / 30 heroes** |
| Production build | Passed |
| Relative-base Pages build | Passed; native asset path regression fixed |
| npm moderate-or-higher vulnerabilities | **0** |

The final production bundle is:

```text
dist/index.html                      24.89 kB ·  6.73 kB gzip
dist/assets/index-Ccbtu_6t.js       236.28 kB · 65.68 kB gzip
dist/assets/turboquant-DEooNtgG.js    9.25 kB ·  3.18 kB gzip
dist/box3d/box3d.wasm               395,305 bytes
```

## Cumulative CPU gains from the reproducible v1.2 baseline

Seven fresh processes per variant/workload, rotating order, medians/MAD, and 20,000 paired-bootstrap resamples produced:

| Maximum-detail CPU simulation + handoff | v1.2 JS | v1.10 SIMD/WASM | Speedup | Paired 95% interval |
|---|---:|---:|---:|---:|
| Tensioned Membrane cloth | 6.5829 ms | 0.8966 ms | **7.342×** | 7.272–7.442× |
| Rope Net Resonance | 0.9573 ms | 0.3486 ms | **2.746×** | 2.702–2.786× |
| Leviathan water | 0.4360 ms | 0.0327 ms | **13.342×** | 12.473–14.056× |

The SIMD/WASM geometric mean is **6.455×**; JavaScript-to-JavaScript is **3.692×**. Correctness failures were zero, and every comparison passed the 0.5% state-fidelity ceiling. Dynamic handoff volume fell 75.00% for cloth, 87.57% for rope, and 74.98% for water. Full evidence is in [`benchmarks/results/original-v1.2-v1.9.md`](benchmarks/results/original-v1.2-v1.9.md); the legacy filename is retained for compatibility, while the report identifies the current target as v1.10.

## V1.11 final 100-case result

The source-frozen comparison uses the exact archived v1.10 source, 100 production-path cases, eight timed samples per variant/case, equal baseline-first/candidate-first ordering, medians/MAD, and the geometric mean of the two order-stratified median ratios.

| Outcome | Count |
|---|---:|
| Accepted measured wins | **20** |
| Borderline | **2** |
| Rejected, no win | **4** |
| Controls | **74** |
| Correctness failures | **0** |

Changed paths measured **1.067× geometric mean** and **1.090× median**. All 200 baseline/candidate groups were deterministic, and all 10 unchanged before/after groups were exact. Dedicated evidence also proves 19.35× static camera resolution, 2.134× mixed main-frame line staging, 3.918× exact cloth explosion handling, 3.768× exact rope explosion handling, 1.063× incremental fallback contact resolution, 127.51× settled native-step elimination, 20% less active native upload traffic, and zero-byte settled uploads. These are scoped subsystem measurements, not factors to multiply into a universal FPS claim.

Exact shadow-depth reuse was tested and then fully reverted. Although its dependency, pixel, zero-error, and paused-frame checks passed, the active rigid CPU-submit confidence interval fell below the predeclared 0.98 non-regression floor.

## Physical-GPU quality evidence

On Apple M3 Ultra Metal, 1,920×1,080 with 4,096 instanced cubes and 312 timestamped frames per case:

| Profile-equivalent case | Median GPU frame span | Relative cost |
|---|---:|---:|
| 1× MSAA, shadows off | **0.1151 ms** | 1.000× |
| 1× MSAA, 1,024², 1 tap | **0.1966 ms** | 1.708× |
| 4× MSAA, 2,048², 9 taps | **0.1802 ms** | 1.566× |

The non-monotonic ordering reflects a very small synthetic workload and device scheduling; these numbers select profile architecture, not universal FPS. They were established for v1.10 and remain valid for the retained v1.11 profile architecture. V1.11's dead-resource removal is described only as strict module/pipeline elimination because its startup distributions overlap the declared noise boundary.

## TurboQuant decision

The refreshed benchmark now consumes solver-native cloth positions, compact rope nodes, and water `eta/u/v` directly. Predictive structured 4-bit packets are **6.73–7.11× smaller** with 1.090–1.919% relative L2 error. A local Worker path was **53.3× slower** because codec work dominates fast local transfer. TurboQuant therefore remains excluded from the local physics-to-WebGPU path and available only for remote snapshots, spectators, replay storage, and other bandwidth-constrained boundaries.

## Visible browser acceptance

The relative-base GitHub Pages build was served through Vite preview and opened in the Codex in-app Browser on macOS. The visible application reported **v1.11.0**, loaded **Box3D WASM** rather than the preview rigid backend, and selected the SIMD soft kernel. Interactive checks passed for native rigid bodies, projectile-driven cloth, paused/resumed rope with a stable replay hash, projectile-driven GPU water, Performance/Cinematic profiles, and diagnostics.

The in-app state gate completed **750 / 750 scenes** and **30 / 30 hero sequences**, including effects. This run found a real Pages-only defect: the relative-base bundle resolved the native Box3D module below `assets/` and silently fell back to preview physics. Public Box3D assets now resolve against `document.baseURI` before dynamic import, and a source regression assertion protects the fix.

Machine-readable evidence is in [`benchmarks/results/v111-visible-browser-acceptance.json`](benchmarks/results/v111-visible-browser-acceptance.json). Dawn/Metal separately proves shader compilation, bind groups, storage resources, compute dispatch, attachments, timestamp queries, indexed draws, KTX2 upload/sampling, cache behavior, and complete command submission. The visible pass is acceptance evidence, not a universal browser-FPS benchmark or a full device/driver matrix.

## Release assessment

V1.11 is the source-frozen validated release in this workspace. CPU, WebAssembly, native Box3D, Dawn/WebGPU, Metal, KTX2, deterministic soak, fidelity, build, Pages, audit, 100-case benchmark, and visible-browser gates pass. Universal FPS and a native-Box3D-versus-preview speed multiplier remain out of scope until measured under a defined target-browser workload and device matrix.
