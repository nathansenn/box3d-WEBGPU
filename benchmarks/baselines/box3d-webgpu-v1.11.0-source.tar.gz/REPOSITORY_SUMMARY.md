# Repository Summary

## Box3D WebGPU AAA Physics Lab v1.9.0 semantic integration

Version 1.9 semantically ports the supplied GPU-cloth and GPU-rope changes onto the independently reconstructed v1.8.1 repository. The supplied archive verifies as SHA-256 `09fa0eec3db1858d57cdc58a9fe8f021b76cd6c19c5b8913eb9d55e1667a1fbb`, but its original-v1.8.0 lineage does not match this tree. The integration was therefore performed manually to preserve the current soft-kernel ABI, v1.8.1 fixes, and the final post-process V flip. The manifest-sealed `validate:v1.9` gate passed on July 14, 2026.

| Area | Delivered |
|---|---|
| Rigid physics | Box3D C17 → Emscripten/WASM bridge plus deterministic preview backend |
| Cloth | PBD particles and constraints; adaptive 4/6/8 intact schedules; 12-byte dynamic positions plus immutable rest pose; packed tearing fallback |
| Rope | PBD cables, anchors, payloads, breakage, persistent WASM projection, compact node/segment frames, and WebGPU render expansion |
| Water | Interactive 2.5D shallow-water solver with persistent WASM stepping and GPU-resident surface reconstruction |
| Catalog | 750 deterministic scenes across 15 families |
| Direction | 30 cinematic hero demonstrations and Maximum AAA Tour |
| Rendering | WebGPU instancing, 12-byte dynamic intact-cloth positions, GPU rope compute expansion, 12-byte water state, packed tearing surfaces, KTX2, HDR, 4× MSAA, shadows, fog, post |
| Diagnostics | Rigid/soft counts, constraints/cells, breaks, energy, CPU times, uploads, hashes |
| Validation | `validate:v1.9` passed: 16 unit suites, JavaScript/SIMD/scalar soaks, 12 Dawn shaders, actual renderer/cache checks, evidence consistency, C bridge, production and Pages |
| Transport | Optional predictive TurboQuant codec; measured network/storage use only, disabled on local frame path |
| Deployment | Vite production build, GitHub Pages workflow, push scripts, source checksum manifest |

### New in the v1.9 semantic integration

- Adaptive intact-cloth projection ceilings: four for membrane drums, six for hammocks/collider drapes, and eight for other intact recipes; tearing keeps its full schedule.
- Current/rest cloth reconstruction removes the steady per-vertex strain upload, reducing changed-frame dynamic cloth traffic from 16 to 12 bytes per vertex.
- Compact rope node/segment streams are expanded by a WebGPU compute pass; segment metadata is refreshed only after topology changes.
- Numerical soft solvers remain CPU/JavaScript or CPU/WebAssembly. WebGPU compute performs rope render preparation only.
- The v1.8.1 reconstruction history and the final post-process V flip remain unchanged.
- See [`docs/INTEGRATION_V1.9.md`](docs/INTEGRATION_V1.9.md) for the archive hash, manual-port rationale, and pending validation status.

### v1.8.1 reconstruction foundation

- Reproducible standalone SIMD and scalar WebAssembly kernels with automatic JavaScript fallback.
- Persistent soft-kernel memory for stable cloth, rope, water, and rope render-stream hot paths.
- GPU-resident intact cloth and shallow water with cached static topology and unchanged-frame zero-upload behavior.
- Coherent longest-axis sweep-and-prune for the deterministic rigid preview backend.
- Whole-system cloth/rope projectile rejection before particle-level contact checks.
- A manifest-sealed `validate:v1.8` gate covering deterministic rebuilds, all three full soft soaks, Dawn, production, and Pages builds in the reconstruction baseline.

### Retained from v1.4.0

- Independent blockwise TurboQuant-MSE and structured Walsh–Hadamard codecs.
- Predictive 4-bit simulation-state transport with real cloth/rope/water evidence.
- In-browser target-device TurboQuant probe loaded as a separate lazy chunk.
- Explicit local-path rejection after the Worker benchmark measured a 16.4× regression.
- Network break-even modeling around 40–42 MB/s for the recommended workloads in this environment.
- Updated Dawn tests for packed 24-byte vertices, `uint16` indices, KTX2 material binding, and cached topology uploads.

### New in v1.1.0

- 50 cloth scenes and two cloth hero demonstrations.
- 50 rope/rigging scenes and two cable hero demonstrations.
- 50 water scenes and two fluid hero demonstrations.
- Dynamic indexed cloth/water renderer path.
- Woven cloth and translucent water WGSL materials.
- Deterministic topology failure, line breakage, waves, currents, foam, droplets, and floaters.
- Permanent long-duration soft-simulation soak and C bridge syntax gates.

### Architectural boundary

Box3D owns rigid-body simulation. The soft-simulation suite owns cloth, rope, and water, with selected numerical kernels running in CPU WebAssembly. WebGPU reconstructs intact cloth and water presentation and uses compute to expand compact rope data into render instances; it does not run those numerical solvers as compute. Tearing cloth stays on the topology-aware packed path. The current water model is a heightfield, not a volumetric fluid engine.

### Evidence boundary

The supplied v1.9 benchmark evidence belongs to the archive's exact-release lineage. Its evidence gate validates recorded artifacts rather than rerunning measurements, some cases are noisy or have high MAD, and no supplied result proves physical-GPU timing or an FPS multiplier. Performance claims for this manual integration require a fresh rerun after `validate:v1.9` succeeds.

A separate fresh Apple M3 Ultra benchmark against the bundled v1.2.0 soft-system baseline measured a 6.224× SIMD/WASM geometric mean across maximum cloth, rope, and water CPU simulation-plus-handoff workloads (7.309×, 2.459×, and 13.416× respectively), with zero correctness failures. It remains a CPU-path result—not a physical-GPU or universal FPS claim. See `benchmarks/results/original-v1.2-v1.9.md`.
