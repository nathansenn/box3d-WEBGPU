# Performance evidence

See [the complete report](docs/PERFORMANCE_OPTIMIZATION_REPORT.md), [the 100 candidate measurements](benchmarks/results/optimization-candidates.md), and [the end-to-end comparison](benchmarks/results/end-to-end.md).

Run `npm run validate:performance` to reproduce the complete gate.
