# Validation Report — Box3D WebGPU AAA Physics Lab v1.9.0

Date: July 14, 2026
Status: **manifest-sealed automated gate passed**

## Scope and provenance

The supplied release archive verified as:

```text
box3d-WEBGPU-AAA-edition-1.9.0-fifth-breakthrough-validated.zip
SHA-256 09fa0eec3db1858d57cdc58a9fe8f021b76cd6c19c5b8913eb9d55e1667a1fbb
```

Its source descends from the bundled original v1.8.0 line, while this repository descends from the independently reconstructed v1.8.1 implementation. The v1.9 behavior was therefore ported manually instead of replacing the tree. The integration preserves the current soft-kernel ABI and loader, post-v1.8 cache tests, derivative-safe shadows, isolated shadow bind group, and the final HDR presentation V flip exactly once. See [`docs/INTEGRATION_V1.9.md`](docs/INTEGRATION_V1.9.md).

The integrated changes are:

- fidelity-bounded 4/6/8 intact-cloth projection ceilings with stiffness compensation;
- immutable cloth rest positions and 12-byte-per-vertex changed-frame position uploads;
- WGSL reconstruction of cloth strain from current/rest geometry;
- compact rope node/segment publication;
- WebGPU compute expansion into shared model-matrix and material buffers;
- topology, state-identity, frame-version, and unchanged-frame upload caches;
- updated benchmark, validation, deployment, and documentation contracts.

Cloth PBD, rope PBD, shallow-water stepping, collision selection, constraint failure, and native rigid-body physics remain CPU/JavaScript or CPU/WebAssembly work. The rope compute pass prepares rendering; it is not a GPU physics solver.

## Sealed release command

```bash
npm ci --registry=https://registry.npmjs.org --replace-registry-host=always
npm run manifest:generate
npm run validate:v1.9
npm audit --audit-level=moderate
```

`validate:v1.9` verifies the source manifest before and after all tests/builds and runs:

1. strict TypeScript and deterministic Node suites;
2. repository, UI, source, and deployment contracts;
3. strict C17 Box3D bridge syntax/API checks;
4. deterministic SIMD/scalar WebAssembly rebuild and numerical/integration tests;
5. Dawn shader, pipeline, compute, attachment, and command-submission checks;
6. actual `WebGPURenderer` runtime and upload-cache checks;
7. JavaScript, SIMD, and scalar 150-scene soft-system soaks;
8. supplied v1.9 benchmark-evidence consistency checks;
9. production and relative-base GitHub Pages builds.

## Final automated results

| Gate | Observed result |
|---|---:|
| Clean dependency install | 21 packages installed; 0 vulnerabilities |
| Source manifest | 139 / 139 entries before and after validation |
| Strict TypeScript | Passed |
| Deterministic Node suites | 16 / 16 passed |
| C17 Box3D bridge syntax/API contract | Passed with warnings as errors |
| SIMD/scalar soft-kernel rebuild | Byte-identical to packaged modules |
| Soft-kernel numerical/fallback/scene integration | Passed |
| Dawn WGSL modules | 12 / 12 passed |
| GPU-rope compute pipeline and dispatch | Passed |
| Compute-to-shadow/HDR render submission | Passed |
| Actual `WebGPURenderer` runtime | Passed |
| Dawn uncaptured validation errors | 0 |
| JavaScript soft soak | 150 scenes; 3,600 catalog + 1,800 replay frames |
| SIMD soft soak | 150 scenes; 3,600 catalog + 1,800 replay frames |
| Scalar soft soak | 150 scenes; 3,600 catalog + 1,800 replay frames |
| Supplied fifth-pass evidence gate | 100 experiments; internally consistent; 0 correctness failures |
| Production Vite build | Passed |
| Relative-base Pages build | Passed |
| npm moderate-or-higher audit | 0 vulnerabilities |

Across the three execution backends, the soak covered 450 scene executions, 10,800 catalog frames, and 5,400 deterministic replay frames. High-water marks were 7,011 nodes, 18,360 constraints, 571 soft instances, and 129 controlled breaks.

Production output:

```text
dist/index.html                      24.89 kB ·  6.73 kB gzip
dist/assets/index-mhw-gLxa.js       229.82 kB · 63.30 kB gzip
dist/assets/turboquant-DEooNtgG.js    9.25 kB ·  3.18 kB gzip
```

## Renderer-specific coverage

The Dawn and actual-runtime tests cover:

- rigid, packed-surface, and GPU-cloth shadows;
- PBR rigid solids and the atmospheric sky;
- packed tearing cloth;
- intact current/rest GPU cloth;
- packed water compatibility and GPU `eta/u/v` water;
- GPU-compute rope reconstruction into instance buffers;
- compute-to-render synchronization;
- debug/effect lines;
- HDR `rgba16float`, four-sample MSAA, and post-processing;
- RGBA/BGRA presentation variants;
- resize, empty-frame, no-shadow, and zero-instance paths;
- exact paused-frame zero-upload caching.

Permanent regressions assert that:

- `textureSampleCompareLevel` remains derivative-safe;
- the sky pipeline declares compatible `depth24plus` state;
- a writable shadow map is not sampled in the same pass;
- the resolved HDR image receives exactly one V flip;
- initial intact-cloth upload includes current/rest positions, changed frames upload 12 bytes per vertex, and unchanged frames upload zero bytes;
- rope segment metadata uploads only when topology changes;
- rope compute respects its base-instance range and leaves later soft/effect ranges intact.

## Original reproducible baseline benchmark

The earliest bundled source with equivalent maximum-detail cloth, rope, and water recipes is v1.2.0. The fresh benchmark used nine isolated processes per variant/workload, rotating order, medians/MAD, and 20,000 paired-bootstrap resamples on an Apple M3 Ultra.

| CPU simulation + handoff workload | v1.2 JS | v1.9 SIMD/WASM | Speedup | Paired 95% interval |
|---|---:|---:|---:|---:|
| Tensioned Membrane cloth | 7.000474 ms | 0.957803 ms | **7.309×** | 7.208–7.411× |
| Rope Net Resonance | 1.007938 ms | 0.409932 ms | **2.459×** | 2.443–2.481× |
| Leviathan water | 0.436570 ms | 0.032541 ms | **13.416×** | 13.298–13.589× |

The production SIMD/WASM geometric mean is **6.224×**; JavaScript-to-JavaScript is **3.651×**. Every variant was deterministic, all correctness gates passed, and cross-version relative L2 state error was 0.068–0.229% against a 0.5% ceiling. Dynamic handoff volume fell 75.00% for cloth, 87.57% for rope, and 74.98% for water.

The timing excludes WebGPU execution, physical-GPU FPS, and native Box3D rigid-body performance. Full raw evidence is in [`benchmarks/results/original-v1.2-v1.9.md`](benchmarks/results/original-v1.2-v1.9.md) and [`benchmarks/results/original-v1.2-v1.9.json`](benchmarks/results/original-v1.2-v1.9.json).

The separate command-level v1.2 comparison measured the full JavaScript soft-soak command at 15.1036 seconds versus 4.6567 seconds (**3.243×**, 69.2% less wall time). WebGPU validation and production build commands are intentionally larger in v1.9 and measured 0.930× and 0.954× respectively; they are not presented as speedups. The old baseline's complete `npm test` command did not pass its own warmup gate, so no overall test-suite ratio is claimed. See [`benchmarks/results/end-to-end.md`](benchmarks/results/end-to-end.md).

## Supplied v1.9 evidence boundary

The supplied archive's 100-result evidence gate passed: 69 accepted measurements, 15 borderline results, 6 rejected no-wins, 10 controls, and zero recorded correctness failures. Those artifacts belong to the archive's exact v1.8.0-derived lineage. The gate checks recorded evidence; it does not rerun the tournament.

Several supplied experiments have elevated normalized MAD, and the acceptance rule does not reject every high-variance case. The archive also does not include raw proof for its separately described 720-frame qualification. Consequently, the supplied aggregate is retained as reference evidence, while current-tree performance claims use the fresh original-baseline run above.

## Browser-render validation boundary

The local Vite server started successfully at `http://127.0.0.1:5173/`. The required in-app Browser runtime failed before tab acquisition with:

```text
Cannot redefine property: process
```

No regular-Playwright fallback was used because the browser-validation skill permits fallback after invocation failure only when the user has already authorized it. Therefore this v1.9 run does **not** claim a new visible browser screenshot, DOM interaction, console-health result, or physical-GPU timing result.

Dawn does prove WGSL compilation, bind groups, storage resources, compute dispatch, compute-to-render ordering, attachments, indexed draws, cache behavior, and complete command submission. A target-browser acceptance run remains required for pixel-level cloth/water/rope appearance, transparency, high-DPI layout, browser-driver behavior, and physical-GPU performance.

The earlier v1.8.1 visible smoke record remains historical evidence only; it is not relabeled as v1.9 evidence.

## Native Box3D boundary

The C17 bridge/API contract passed, and the packaged standalone cloth/rope/water SIMD/scalar modules rebuilt byte-identically. The upstream Box3D Emscripten artifact was not rebuilt during this integration. A native rigid-body acceptance run still requires:

```bash
npm run fetch:box3d
npm run build:wasm
npm run dev
```

After reload, the backend badge must report **Box3D WASM**.

## Release assessment

The semantic v1.9 integration is ready as a manifest-sealed source release. Its automated CPU, WebAssembly, Dawn/WebGPU, deterministic soak, benchmark-consistency, build, audit, and original-baseline gates passed. Remaining production boundaries are a visible target-browser acceptance run and a separately compiled upstream Box3D Emscripten backend. Universal FPS or physical-GPU speedup claims remain out of scope until measured on target hardware.
