# Validation Report — Box3D WebGPU AAA Physics Lab v1.8.1

## Scope and provenance

This report covers the reconstructed v1.8 architecture built on the verified v1.4.1 source present in this workspace:

- GPU-resident intact-cloth presentation;
- GPU-resident shallow-water presentation;
- topology-aware packed tearing-cloth fallback;
- persistent SIMD/scalar soft-kernel WebAssembly with JavaScript fallback;
- WASM rope instance-stream generation;
- coherent preview rigid broadphase and soft projectile broad rejection;
- frame/topology/identity caches for surfaces and soft instances;
- the existing 750 scenes, 30 hero sequences, KTX2 assets, TurboQuant transport, and AAA frame graph;
- the v1.4.1 final-presentation orientation correction.

The earlier conversation's v1.8 archive was unavailable. This source is a reconstruction, not a byte-for-byte import, and historical benchmark multipliers are not repeated as current evidence. See `docs/RECONSTRUCTION_V1.8.md`.

## Current automated contract

The complete repository gate is:

```bash
npm run validate:v1.8
```

It requires, in order:

1. source-manifest verification;
2. strict TypeScript and 15 deterministic Node suites;
3. repository/UI contract checks;
4. strict C17 native-bridge syntax checking;
5. deterministic SIMD/scalar soft-kernel rebuild and numerical/integration checks;
6. Dawn compilation of 11 WGSL modules and a complete offscreen frame;
7. actual `WebGPURenderer` runtime and repeated-frame upload-cache checks;
8. the 150-scene soft/fluid soak and paired replays;
9. production and relative-base GitHub Pages builds.

## Focused reconstruction evidence

The component work was checked at the point of integration:

| Focused gate | Observed result |
|---|---:|
| Strict TypeScript after hot-path edits | Passed |
| Deterministic Node suites | 15 / 15 passed |
| Repository/UI/build contract self-test | Passed |
| SIMD/scalar kernel ABI and numerical tests | Passed |
| SIMD real-scene cloth/rope/water integration and replay | Passed |
| Dawn WGSL modules | 11 / 11 passed |
| Packed, GPU-cloth, GPU-water, shadow, HDR/MSAA, and post pipelines | Passed |
| Actual renderer runtime path | Passed |
| Dawn uncaptured validation errors | 0 |
| Unchanged GPU surface additional upload bytes | 0 |
| Unchanged soft-instance additional upload bytes | 0 |
| Final HDR presentation V-flip source regression | Passed |

## Final serialized validation — July 13, 2026

The source manifest was regenerated with 102 release-tracked entries and the complete `npm run validate:v1.8` gate passed on the sealed tree. The command verified the manifest both before and after every test and build step.

| Final gate | Observed result |
|---|---:|
| Source manifest | 102 / 102 passed before and after validation |
| Strict TypeScript | Passed |
| Deterministic Node suites | 15 / 15 passed |
| Native bridge C17 syntax contract | Passed |
| SIMD/scalar soft-kernel deterministic rebuild | Byte-identical |
| Soft-kernel numerical, fallback, and scene integration | Passed |
| Dawn WGSL modules | 11 / 11 passed |
| Actual renderer runtime | Passed; 0 uncaptured validation errors |
| JavaScript soft soak | 150 scenes; 3,600 catalog + 1,800 replay frames |
| SIMD soft soak | 150 scenes; 3,600 catalog + 1,800 replay frames |
| Scalar soft soak | 150 scenes; 3,600 catalog + 1,800 replay frames |
| Production build | 218.25 kB main JS; 61.22 kB gzip |
| Relative-base GitHub Pages build | Passed |

Across JavaScript, SIMD, and scalar execution, the soak covered 450 scene executions, 10,800 catalog frames, and 5,400 paired replay frames. Its high-water marks were 7,011 nodes, 18,360 constraints, 571 rendered soft instances, and 129 controlled breaks. These figures describe the automated test workload, not universal device performance.

## Soft-kernel validation

`npm run test:soft-kernels` covers two packaged modules:

```text
public/soft-kernels-simd.wasm
public/soft-kernels-scalar.wasm
```

The build uses a standalone C17 source with no host imports, deterministic build settings, an exported version/variant marker, aligned persistent allocation, and bounded initial/maximum memory. Tests cover:

- two-build byte determinism;
- ABI and variant validation;
- SIMD preference;
- scalar fallback after SIMD rejection;
- JavaScript fallback after both modules reject;
- cloth and rope projection;
- shallow-water stepping;
- rope matrix and tension-color stream generation;
- real maximum-family cloth, rope, and water scenes;
- finite state and paired replay hashes.

The packaged soft-kernel modules are independent of the native Box3D Emscripten artifact.

## Surface and upload validation

### Intact cloth

```text
position.xyz     12 bytes
strain            4 bytes
total            16 bytes per vertex
```

WebGPU reconstructs normals, UVs, checker palette, strain heat, woven response, and shadow position. Static `uint16` topology is cached.

### Tearing cloth

Tearing scenes retain the 24-byte packed surface and mutable topology path. Tests require valid indices and finite topology-aware output.

### Water

```text
eta               4 bytes
u                 4 bytes
v                 4 bytes
total            12 bytes per cell
```

WebGPU reconstructs geometry, normals, curvature, foam, UVs, and material inputs. Static `uint16` topology is cached.

### Cache conditions

Surface uploads are keyed by `frameVersion`, topology version, array-buffer identity, counts, and grid/material configuration. Soft instance streams use their own frame-version/identity cache. The renderer runtime test asserts zero additional upload bytes when a frame is requested again unchanged.

## Renderer validation

The Dawn test exercises 11 WGSL modules and the complete render topology:

```text
rigid shadow
packed cloth shadow
GPU cloth shadow
atmospheric sky
PBR rigid solid
packed cloth
packed water compatibility
GPU cloth
GPU water
line/effect
post-processing (RGBA and BGRA variants)
```

The v1.0.2 and v1.4.1 protections remain enforced:

- `textureSampleCompareLevel` avoids derivative-uniformity failure;
- the atmospheric sky declares `depth24plus` compatibility;
- the writable shadow depth map is isolated from its sampled bind group;
- zero-instance rigid draws are skipped;
- the final HDR texture is sampled with exactly one V flip.

## Numerical and catalog gates

The Node/soak coverage checks:

- 750 generated scenes and 30 hero definitions;
- 150 cloth/rope/water scenes;
- finite matrices, colors, solver fields, and surface state;
- GPU and packed surface contract validity;
- frame-version memoization;
- coherent preview sweep-and-prune determinism;
- whole-system projectile AABB rejection for cloth and rope;
- action routing and paired replay hashes;
- explicit instance, vertex, index, and droplet budgets.

## TurboQuant boundary

TurboQuant remains optional transport compression for remote snapshots, replay, storage, or bandwidth-constrained boundaries. It is not inserted into the authoritative solver or local WebGPU upload path. Existing v1.4 benchmark results remain historical evidence for that codec version, not a performance claim for the reconstructed v1.8.1 tree.

## Browser-render validation boundary

Dawn proves shader compilation, layouts, resources, indexed draws, attachment compatibility, caching behavior, and command submission. A visible target-device browser run is still required for:

- pixel-level cloth/water appearance;
- transparency order and physical-GPU performance;
- browser/driver-specific behavior and device loss;
- high-DPI/resize behavior;
- final capture quality.

### Local visible smoke run — July 13, 2026

The final source was loaded through Vite in the Codex in-app browser at 1280 × 720. The browser selected the deterministic rigid preview and SIMD soft kernels. The following checks passed:

- intact GPU-cloth, tearing-cloth, WASM rope-stream, and GPU-water scene selection;
- upright cloth and water presentation with live node/constraint telemetry;
- diagnostics toggle and pause/resume controls;
- scene restoration and cache invalidation after the state gate;
- **750 / 750** generated scene states and **30 / 30** hero definitions;
- browser console: **0 warnings and 0 errors**.

This local smoke run supplements Dawn but is not a physical-GPU performance benchmark or a substitute for the target-device matrix below.

Use `docs/LOCAL_BROWSER_VALIDATION.md` and the in-app **Run 750 + 30 State Tests** control. The state gate validates simulation data and GPU-surface contracts but does not submit every scene through the renderer. Separately confirm intact cloth and water use their GPU paths, tearing cloth remains topologically correct, and paused unchanged scenes stop reporting repeated dynamic uploads.

## Native Box3D boundary

The native C bridge contract can pass without linking upstream Box3D. A real rigid-body WebAssembly build still requires Emscripten and the fetched source:

```bash
npm run fetch:box3d
npm run build:wasm
npm run dev
```

After reload, the backend badge must report **Box3D WASM**. This is separate from the packaged SIMD/scalar soft-kernel modules.

## Release assessment

The reconstructed architecture has passed its manifest-sealed automated release gate and retains explicit correctness fallbacks. A visible target-browser acceptance run and a separately compiled upstream Box3D Emscripten artifact remain the two production boundaries. Do not publish universal speedup or target-GPU FPS claims without fresh device measurements.
