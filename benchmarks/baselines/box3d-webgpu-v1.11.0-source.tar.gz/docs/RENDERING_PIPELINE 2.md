# Rendering Pipeline

The final fullscreen pass flips the resolved HDR texture's V coordinate exactly once. WebGPU's framebuffer/texture row origin differs from the fullscreen triangle's generated NDC-derived UV orientation; applying the correction at presentation keeps the camera, projection, shadows, and world geometry in one consistent convention.

## Frame graph

```text
CPU / WASM / TypeScript
  Box3D fixed step
  cloth PBD · rope PBD · shallow-water step
  rigid/soft transform + color streams
  cloth/water indexed dynamic surface
  cinematic effects and debug lines
          │
          ├── Pass 1: directional shadow depth (2048² depth32float)
          │       instanced rigid/rope geometry
          │       indexed cloth surface
          │
          ├── Pass 2: HDR scene (rgba16float, 4× MSAA)
          │       atmospheric sky
          │       instanced PBR-inspired rigid/rope/effect solids
          │       two-sided woven cloth
          │       translucent water
          │       additive debug/effect lines
          │       resolve to single-sample HDR texture
          │
          └── Pass 3: post-processing to swapchain
                  neighborhood glow
                  exposure
                  ACES-inspired tone map
                  vignette
                  film grain
                  display gamma
```

## Stream layouts

### Instanced geometry

Each rigid body, rope segment, payload, projectile, droplet, floater, or solid effect uses:

```text
model matrix   16 floats
color/tag       4 floats
```

The alpha component acts as an emissive/material-strength tag. One shared cube mesh handles the current instanced solid path.

### Dynamic indexed surfaces

Cloth and water use one active dynamic surface stream:

```text
position.xyz · normal.xyz · color.rgba · uv.xy
12 floats per vertex
uint32 triangle indices
```

Hard renderer budgets:

```text
16,384 vertices
98,304 indices
```

The renderer validates stream lengths, clamps counts to GPU capacity, and verifies every uploaded index before submission.

## Material pipelines

| Pipeline | Geometry | Key behavior |
|---|---|---|
| PBR solid | instanced cubes | GGX-inspired light, shadowing, emissive tag, fog |
| Woven cloth | indexed surface | two-sided light, weave modulation, stress heat, shadows |
| Interactive water | indexed surface | alpha blend, Fresnel, dual specular, foam, micro-waves |
| Line/effect | line list | additive debug vectors, grid, axes, shockwaves |
| Sky | fullscreen triangle | procedural atmosphere, stars, sun, horizon |
| Post | fullscreen triangle | bloom proxy, exposure, tone map, vignette, grain |

Cloth casts and receives directional shadows. Water receives scene lighting but does not cast in this edition and disables depth writes to support transparency.

## Scene uniform block

The 192-byte uniform block contains:

| Range | Data |
|---|---|
| 0–15 | camera view-projection |
| 16–31 | light view-projection |
| 32–35 | camera position + elapsed time |
| 36–39 | light direction + exposure |
| 40–43 | fog color + density |
| 44–47 | viewport + bloom + shadow contribution |

## Quality profiles

| Profile | Internal resolution | Shadows | Effect budget | Intended use |
|---|---:|---:|---:|---|
| Performance | 70% | skipped | 256 | low-power/mobile diagnostics |
| Balanced | 85% | reduced | 512 | general interaction |
| Cinematic | 100% | full | 1,024 | default demonstration |
| Ultra | 115% | full | 1,536 | high-end capture |

Internal resolution is multiplied by device pixel ratio and capped to protect allocations.

## WGSL validation protections

- `GPUShaderModule.getCompilationInfo()` promotes readable shader failures during startup.
- Shadow PCF uses `textureSampleCompareLevel`, avoiding fragment uniformity restrictions.
- Projected shadow coordinates are clamped and masked without a per-fragment early return before comparison sampling.
- The sky pipeline declares `depth24plus` compatibility for the shared HDR pass.
- The shadow pass uses a uniform-only bind group, so the writable shadow map is not simultaneously sampled.
- Empty rigid draws are skipped.
- Dynamic cloth/water surfaces are exercised with actual indexed draws in the Dawn tests.

## Validation gate

```bash
npm run test:webgpu
```

The gate compiles eight WGSL modules, creates all rigid/cloth/water/shadow/sky/line/post pipelines, validates layouts and attachments, submits a full offscreen frame through Dawn, and runs the actual `WebGPURenderer` class with rigid, cloth, and water frames.

## Deliberate simplifications

- Water is transparent forward rendering without order-independent transparency.
- Only one active dynamic indexed cloth or water surface is drawn per scene.
- Bloom is a compact neighborhood glow rather than a mip-chain implementation.
- Ambient occlusion is a lightweight proxy rather than GTAO/SSAO.
- Solid materials are inferred from stream data rather than texture sets.
- Render telemetry is CPU encode/submit time, not physical-GPU timestamp duration.
