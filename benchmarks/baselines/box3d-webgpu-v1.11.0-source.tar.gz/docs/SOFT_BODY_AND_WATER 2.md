# Cloth, Rope, and Water Simulation Architecture

## Purpose

Version 1.1.0 adds three deterministic simulation families without destabilizing the native Box3D boundary:

```text
Box3D / WASM                           Soft simulation suite / TypeScript
rigid-body authority                   deformable and fluid authority
       │                                      │
       ├── model matrices + colors            ├── rope segment instances
       │                                      ├── cloth indexed surface
       │                                      ├── water indexed surface
       │                                      └── telemetry / debug vectors
       └────────────────── fixed-step coordinator ──────────────────┐
                                                                    ↓
                                                               WebGPU renderer
```

Box3D remains the rigid-body solver. Cloth, rope, and water are deliberately isolated behind `SoftSimulationSuite`, which exposes the same interaction vocabulary—step, kick, explosion, projectile, rain, frame, hash, validation—without mirroring internal solver data into the UI.

## Shared runtime contract

Each active system publishes a `SoftSimulationFrame`:

| Field | Purpose |
|---|---|
| `kind` / `label` | active solver and human-readable configuration |
| `matrices` / `colors` | instanced rope segments, payloads, projectiles, droplets, floaters |
| `surface` | optional indexed cloth or water vertex/index stream |
| `debugLines` | pins, sample nodes, current vectors, and diagnostics |
| `nodeCount` | particles/cells plus transient objects |
| `constraintCount` | PBD links or water-field cell relationships |
| `brokenCount` | torn cloth links or broken rope segments |
| `energy` | normalized motion/field-energy diagnostic |
| `hash` | quantized deterministic replay signature |

Hard budgets:

```text
soft instances                 2,048
water droplets                   768
dynamic surface vertices      16,384
dynamic surface indices       98,304
surface vertex stride             12 floats
```

The surface stride is:

```text
position.xyz · normal.xyz · color.rgba · uv.xy
```

## Cloth solver

### Numerical model

Cloth uses deterministic position-based dynamics:

1. Verlet-style integration derives velocity from current and previous positions.
2. Gravity and time-varying wind/turbulence are applied.
3. Structural, shear, and bend constraints project positions toward rest lengths.
4. Ground and optional sphere collisions project penetrating particles outward.
5. Projectiles and rain particles transfer momentum.
6. Breakable constraints are evaluated against controlled stretch thresholds.
7. Dynamic normals, strain colors, topology, energy, and replay hash are rebuilt.

The solver uses bounded substeps and a stress/mode-dependent iteration count so high-detail scenes remain interactive in JavaScript while preserving folds and tension.

### Constraint classes

| Class | Purpose |
|---|---|
| Structural | horizontal and vertical weave integrity |
| Shear | diagonal resistance and shape retention |
| Bend | longer-range resistance to unrealistic folding |
| Pin | zero inverse-mass boundary or corner attachment |

### Tearing

Structural links may break in designated tear scenes or high-intensity modes. The solver records horizontal and vertical break maps. During index generation, triangles spanning broken structural edges are omitted, producing a real visual opening instead of only coloring an intact mesh.

Breakage is budgeted per step to avoid deleting a large part of the fabric in a single unstable frame. Strain is visualized from cool fabric colors toward hot emissive red near failure.

### Cloth collision and interaction

- ground-plane collision with tangential damping;
- optional sphere collision for drape/hammock/canopy scenes;
- broad kick impulse;
- radial explosion impulse;
- ballistic projectile collision and local tearing;
- rain/body-drop collision proxies;
- deterministic wind and turbulence.

### Cloth variants

1. Tempest Standard
2. Royal Banner Wind Tunnel
3. Parachute Canopy Deployment
4. Cargo Net Load Catch
5. Suspended Hammock Dynamics
6. Racing Sail Aerodynamics
7. Progressive Fabric Tear Lab
8. Drape Over Collider
9. Grand Theater Curtain
10. Tensioned Membrane Drum

## Rope and cable solver

### Numerical model

Rope uses the same deterministic Verlet/PBD foundation but publishes oriented instanced segments instead of a continuous triangle surface.

Each cable can contain:

- fixed anchors;
- renderable distance constraints;
- non-rendered bend constraints;
- one or more concentrated payload particles;
- cross-links between adjacent lines;
- break thresholds and tension colors.

The renderer constructs a model matrix between each active pair of particle endpoints. Segment thickness shrinks slightly under high tension and color shifts toward emissive red near failure.

### Rope interaction

- gravity, damping, ground collision, and bounded world limits;
- broad impulses and deterministic excitation;
- radial blasts;
- projectile impacts and nearest-link severing;
- rain impacts;
- payload inertia and swing;
- controlled high-tension breakage.

### Rope variants

1. Sky Crane Cable Load
2. Suspension Cable Bridge
3. Heavy Pendulum Strike
4. Industrial Rope Ladder
5. Four-Point Mooring Array
6. Cable Curtain Failure
7. High-Speed Zipline
8. Grappling Line Tension
9. Multi-Sling Rigging Test
10. Rope Net Resonance

## Water solver

### Numerical model

Water is a deterministic 2.5D linear shallow-water heightfield. Each grid cell tracks:

```text
eta   surface-height displacement
u     horizontal x velocity
v     horizontal z velocity
```

A step updates velocity from surface gradients, applies drag, updates surface height from velocity divergence, and reflects flow at the domain boundaries. The time step is clamped and substepped to keep the explicit integration stable.

This model is excellent for basin-scale ripples, wave fronts, wakes, fountains, rain impacts, and currents. It is intentionally not a volumetric free-surface solver and does not model overturning waves, air entrainment, viscosity layers, or arbitrary 3D topology.

### Water interaction

- localized height and velocity disturbances;
- automatic traveling waves and oscillators;
- rain droplets that inject impulses on contact;
- projectile/impact floaters;
- simple buoyancy and horizontal-current coupling for floating boxes;
- current-vector debug lines;
- curvature and speed-derived foam.

### Water variants

1. Interactive Ripple Basin
2. Tsunami Research Flume
3. Storm Ocean Surface
4. Hydrodynamic Boat Wake
5. Oscillating Fountain Pool
6. Rain Impact Reservoir
7. Dam-Breach Wave Front
8. Vortex Current Chamber
9. Harbor Buoyancy Lab
10. Leviathan Impact Pool

## WebGPU surface rendering

Cloth and water share a dynamic indexed surface upload path but use separate materials.

### Cloth material

- two-sided triangle rendering;
- dynamic normal lighting;
- subtle procedural weave modulation;
- stress and emissive heat visualization;
- directional shadow reception and casting;
- HDR/fog integration.

### Water material

- alpha blending and disabled depth writes;
- dynamic normals;
- Fresnel edge response;
- broad and sharp specular lobes;
- foam derived from per-vertex alpha;
- procedural micro-wave detail;
- HDR/fog/post-processing integration.

Cloth participates in the directional shadow pass. Water does not cast a shadow in the current edition, avoiding a visually heavy opaque depth silhouette for a transparent surface.

## Determinism

Every soft/fluid system is seeded by scene identity and a caller-provided seed. Replay hashes quantize a bounded subset of the simulation state before FNV-style accumulation. Determinism tests run paired instances with identical actions and verify matching hashes during long simulations.

The hash is a regression signal, not a cryptographic digest and not a promise of bit-identical behavior across every future JavaScript engine or code revision.

## Validation

Run:

```bash
npm test
npm run test:soft-soak
```

The gates verify:

- all 150 soft/fluid scene constructors;
- finite matrices, colors, vertices, normals, and energy;
- valid vertex stride and index bounds;
- explicit instance and droplet budgets;
- action routing for kick, projectile, explosion, and rain;
- deterministic paired replays;
- cloth tear topology;
- rope breakage and segment-stream integrity;
- water stability and bounded field values;
- WGSL compilation and indexed draw compatibility through Dawn;
- the actual renderer runtime path for cloth and water.

## Performance profile

The current solver intentionally avoids per-frame large typed-array allocations and precomputes repeated constraint values. Local Node benchmarks in the validation environment placed maximum cloth scenes around 10–15 ms per simulation frame after optimization, while rope and water were generally lower. These are CPU microbenchmarks from one environment—not universal browser or GPU frame-time guarantees.

## Next engineering steps

1. Bidirectional coupling against arbitrary Box3D shape queries.
2. Self-collision and continuous collision for cloth and rope.
3. XPBD compliance parameters and physically meaningful stiffness tuning.
4. Cloth aerodynamic pressure from relative wind and triangle area.
5. Rope pulleys, winches, motors, and contact against convex shapes.
6. Water obstacles, shoreline masks, depth maps, and rigid-body force integration.
7. Worker isolation and double-buffered soft-state streams.
8. WebGPU compute versions of constraint projection and water integration.
9. Multiple simultaneous dynamic surfaces and material batches.
10. GPU timestamp queries and target-device performance baselines.
