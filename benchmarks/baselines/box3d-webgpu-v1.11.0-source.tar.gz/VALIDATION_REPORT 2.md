# Validation Report — Box3D WebGPU AAA Physics Lab v1.4.1

## Release scope

This report covers the optimized cloth, rope, water, KTX2, packed-surface, and optional TurboQuant transport edition built on the validated rigid/WebGPU foundation, including the v1.4.1 camera-orientation presentation hotfix.

```text
750 deterministic scenes
30 cinematic hero demonstrations
150 cloth/rope/water scenes
8 WGSL shader modules in the Dawn gate
12 deterministic Node suites
```

## Automated release gates

| Gate | Result |
|---|---:|
| Strict TypeScript | Passed |
| Deterministic Node suites | 12 / 12 passed |
| Generated scene constructors | 750 / 750 passed |
| Cloth/rope/water constructors | 150 / 150 passed |
| Hero definitions and camera/beat validation | 30 / 30 passed |
| Repository/UI/build contract self-test | Passed |
| C17 native bridge syntax (`-Wall -Wextra -Werror`) | Passed |
| Dawn WGSL compilation | 8 / 8 shader modules passed |
| Rigid, cloth, water, line, sky, shadow, and post pipelines | Passed |
| Indexed dynamic-surface upload/draw | Passed |
| Full shadow → HDR/MSAA → post frame submission | Passed |
| Actual `WebGPURenderer` runtime path | Passed |
| Dawn uncaptured validation errors | 0 |
| Final HDR presentation V-flip regression | Passed |
| Production Vite build | Passed |
| GitHub Pages relative-base build | Passed |
| npm moderate-or-higher audit | 0 vulnerabilities |

## v1.4.1 live browser acceptance

The updated checkout was served at `http://127.0.0.1:5180/` and exercised through the active browser WebGPU implementation.

| Browser gate | Result |
|---|---:|
| Diagnostic ground grid renders beneath world geometry | Passed |
| Cloth baseline scene | 900 nodes / 5,050 constraints |
| Rope baseline scene | 50 nodes / 97 constraints |
| Water baseline scene | 3,536 nodes / 9,900 cells/links |
| Capability recipes | 750 / 750 passed |
| Cinematic hero sequences | 30 / 30 passed |
| Effects smoke test | Passed |
| Browser console errors | 0 |
| Browser console warnings | 0 |

The camera rig, pitch convention, view matrix, projection, shadows, and physics coordinates remain unchanged. The correction is isolated to a one-time V flip while sampling the resolved HDR render target in the final swapchain presentation pass.


## TurboQuant transport benchmark

TurboQuant is implemented as an optional bandwidth-boundary codec and is not enabled in the authoritative solver or the same-thread WebGPU upload path. The exact benchmark used 60 real maximum-detail frames per workload, two warmups, five timed samples, and predictive structured 4-bit blocks.

| Workload | Raw/frame | Packet/frame | Reduction | Codec time/frame | Relative L2 | Modeled link break-even |
|---|---:|---:|---:|---:|---:|---:|
| Cloth | 20,400 B | 2,880 B | 7.08× | 0.4410 ms | 1.258% | 39.7 MB/s |
| Rope | 25,664 B | 3,636 B | 7.06× | 0.5270 ms | 1.126% | 41.8 MB/s |
| Water | 77,280 B | 10,872 B | 7.11× | 1.6501 ms | 1.244% | 40.2 MB/s |

A 48-frame local Worker transfer test reduced water bytes 7.11× but took 94.383 ms with TurboQuant versus 5.751 ms raw, a 0.0609× speedup (16.4× slower). Therefore the release preserves the lossless local path and exposes TurboQuant only for opt-in network, archive, replay, and remote-state use. See `docs/TURBOQUANT.md` and `benchmarks/results/TURBOQUANT_BENCHMARK.md`.

## Soft-system catalog soak

The permanent `npm run test:soft-soak` gate performs a representative stress sequence in every soft/fluid scene and paired deterministic replays for the maximum cloth, rope, and water entries.

Default gate result:

```text
150 scenes
3,600 catalog frames
1,800 paired deterministic replay frames
50 cloth scenes
50 rope scenes
50 water scenes
maximum nodes:       7,011
maximum constraints: 18,360
maximum instances:     571
maximum breaks:        130
maximum energy:        447.153…
```

Each frame is checked for:

- finite model matrices and material colors;
- valid instance counts and stream lengths;
- finite energy and initialized replay hashes;
- finite dynamic-surface vertices;
- exact 24-byte packed surface stride;
- complete index streams with every index in range;
- correct solver family and initialized telemetry.

## Extended stress evidence

Additional long-duration runs were executed during release preparation.

| System | Coverage | Frames | High-water marks / result |
|---|---:|---:|---|
| Cloth | 50 scenes | 6,000 | 1,700 nodes, 9,782 constraints, 357 controlled breaks; finite topology |
| Rope | 50 scenes | 9,000 | 405 nodes, 783 constraints, 474 instances, 77 breaks; finite segment stream |
| Water | 50 scenes | 12,000 | 6,785 nodes, 18,360 cells, 345 instances; bounded finite field |

Deep paired/repeated deterministic runs:

```text
cloth scene 649  · 600 frames  · final hash 1423879200
rope scene 699   · 1,200 frames · final hash 3510898898
water scene 749  · 3,600 frames · final hash 4288531700
```

Hashes are regression signatures for this code/revision and action schedule. They are not cryptographic guarantees across future implementations.

## Renderer validation

The Dawn test extracts and compiles eight WGSL modules and creates the complete render topology:

```text
rigid shadow pipeline
dynamic cloth shadow pipeline
atmospheric sky pipeline
PBR rigid solid pipeline
woven cloth pipeline
interactive water pipeline
line/effect pipeline
post-processing pipeline
```

It also creates a BGRA post-process compatibility variant, binds isolated shadow resources, uploads dynamic indexed cloth/water surfaces, and submits a complete offscreen frame.

A second test transpiles and runs the actual `WebGPURenderer` class against a Dawn-backed canvas shim. It covers:

- renderer construction and resource allocation;
- rigid instances;
- cloth indexed surface upload and draw;
- water indexed surface upload and draw;
- shadows and dynamic-surface shadows;
- debug/effect lines;
- target resize;
- empty/no-shadow frames;
- zero uncaptured WebGPU errors.

The v1.0.2 protections remain enforced:

- `textureSampleCompareLevel` avoids derivative-uniformity failure;
- atmospheric sky declares `depth24plus` compatibility;
- writable shadow depth is isolated from the later sampled bind group;
- zero-instance rigid draws are skipped.

## Production bundle

The v1.4.0 production and relative-base GitHub Pages builds completed with:

```text
dist/index.html                       24.71 kB · 6.64 kB gzip
dist/assets/index-DpcsMwt0.js        181.36 kB · 54.30 kB gzip
dist/assets/turboquant-DEooNtgG.js    9.25 kB · 3.18 kB gzip (lazy-loaded)
```

The asset hash can change when source or toolchain output changes; the size is recorded as a release reference rather than a permanent contract.

## Solver performance observations

After allocation and constraint-loop optimization, local Node measurements in this validation environment showed maximum cloth scenes around 10–15 ms per simulation frame, with rope and water generally lower. The default 150-scene soak completed in about 28 seconds in this container. These are regression observations from one CPU environment—not cross-device browser benchmarks, visible compositing measurements, or physical-GPU timing.

## Browser-render validation boundary

Dawn validates shader compilation, pipeline creation, attachment compatibility, resources, indexed draws, and command submission without requiring a visible hardware-backed browser window. A target-device browser run is still required for:

- pixel-level appearance and transparency ordering;
- browser/driver-specific behavior;
- hardware performance;
- device-loss behavior;
- high-DPI and resize behavior;
- full-screen capture quality.

Use `docs/LOCAL_BROWSER_VALIDATION.md` and the in-app **Run 750 + 30 Browser Tests** control.

## Native Box3D build boundary

The native C bridge passed strict syntax/API-contract validation. A true Emscripten link against the fetched upstream Box3D source still requires a local machine with Emscripten activated:

```bash
npm run fetch:box3d
npm run build:wasm
npm run validate
npm run dev
```

The cloth, rope, and water solvers are TypeScript systems and do not depend on the WASM artifact. The native build changes rigid-body staging from the deterministic preview backend to Box3D WASM.

## Release assessment

The v1.4.0 source is suitable as a validated **engineering/demo release**: the codebase, generated catalog, soft-system numerical behavior, shader modules, pipeline resources, indexed rendering, and production bundle pass the automated gates. Native Box3D linking and a visible target-browser acceptance run remain the final machine-specific production gates.
